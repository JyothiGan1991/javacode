
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindGatewayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindGatewayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WAN" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindWANType" minOccurs="0"/&gt;
 *         &lt;element name="IPV6Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetworkMask" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkMaskType" minOccurs="0"/&gt;
 *         &lt;element name="ChapUsername" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqIPPort" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="UiqPhoneNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqPhoneNumSec" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPPort" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPV6WANAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayPhoneNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANHardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANSoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsSocketAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindGatewayType", propOrder = {
    "name",
    "description",
    "wan",
    "ipv6Address",
    "networkMask",
    "chapUsername",
    "uiqIPAddress",
    "uiqIPPort",
    "uiqPhoneNum",
    "uiqPhoneNumSec",
    "gatewayIPPort",
    "gatewayIPAddress",
    "gatewayIPV6WANAddress",
    "gatewayPhoneNum",
    "wanHardwareConfig",
    "wanSoftwareConfig",
    "isSocketAP"
})
public class FindGatewayType {

    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "WAN")
    protected FindWANType wan;
    @XmlElement(name = "IPV6Address")
    protected String ipv6Address;
    @XmlElement(name = "NetworkMask")
    protected Integer networkMask;
    @XmlElement(name = "ChapUsername")
    protected String chapUsername;
    @XmlElement(name = "UiqIPAddress")
    protected String uiqIPAddress;
    @XmlElement(name = "UiqIPPort")
    protected Integer uiqIPPort;
    @XmlElement(name = "UiqPhoneNum")
    protected String uiqPhoneNum;
    @XmlElement(name = "UiqPhoneNumSec")
    protected String uiqPhoneNumSec;
    @XmlElement(name = "GatewayIPPort")
    protected Integer gatewayIPPort;
    @XmlElement(name = "GatewayIPAddress")
    protected String gatewayIPAddress;
    @XmlElement(name = "GatewayIPV6WANAddress")
    protected String gatewayIPV6WANAddress;
    @XmlElement(name = "GatewayPhoneNum")
    protected String gatewayPhoneNum;
    @XmlElement(name = "WANHardwareConfig")
    protected String wanHardwareConfig;
    @XmlElement(name = "WANSoftwareConfig")
    protected String wanSoftwareConfig;
    @XmlElement(name = "IsSocketAP", defaultValue = "false")
    protected Boolean isSocketAP;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the wan property.
     * 
     * @return
     *     possible object is
     *     {@link FindWANType }
     *     
     */
    public FindWANType getWAN() {
        return wan;
    }

    /**
     * Sets the value of the wan property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindWANType }
     *     
     */
    public void setWAN(FindWANType value) {
        this.wan = value;
    }

    /**
     * Gets the value of the ipv6Address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPV6Address() {
        return ipv6Address;
    }

    /**
     * Sets the value of the ipv6Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPV6Address(String value) {
        this.ipv6Address = value;
    }

    /**
     * Gets the value of the networkMask property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNetworkMask() {
        return networkMask;
    }

    /**
     * Sets the value of the networkMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNetworkMask(Integer value) {
        this.networkMask = value;
    }

    /**
     * Gets the value of the chapUsername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChapUsername() {
        return chapUsername;
    }

    /**
     * Sets the value of the chapUsername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChapUsername(String value) {
        this.chapUsername = value;
    }

    /**
     * Gets the value of the uiqIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqIPAddress() {
        return uiqIPAddress;
    }

    /**
     * Sets the value of the uiqIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqIPAddress(String value) {
        this.uiqIPAddress = value;
    }

    /**
     * Gets the value of the uiqIPPort property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUiqIPPort() {
        return uiqIPPort;
    }

    /**
     * Sets the value of the uiqIPPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUiqIPPort(Integer value) {
        this.uiqIPPort = value;
    }

    /**
     * Gets the value of the uiqPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqPhoneNum() {
        return uiqPhoneNum;
    }

    /**
     * Sets the value of the uiqPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqPhoneNum(String value) {
        this.uiqPhoneNum = value;
    }

    /**
     * Gets the value of the uiqPhoneNumSec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqPhoneNumSec() {
        return uiqPhoneNumSec;
    }

    /**
     * Sets the value of the uiqPhoneNumSec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqPhoneNumSec(String value) {
        this.uiqPhoneNumSec = value;
    }

    /**
     * Gets the value of the gatewayIPPort property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGatewayIPPort() {
        return gatewayIPPort;
    }

    /**
     * Sets the value of the gatewayIPPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGatewayIPPort(Integer value) {
        this.gatewayIPPort = value;
    }

    /**
     * Gets the value of the gatewayIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPAddress() {
        return gatewayIPAddress;
    }

    /**
     * Sets the value of the gatewayIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPAddress(String value) {
        this.gatewayIPAddress = value;
    }

    /**
     * Gets the value of the gatewayIPV6WANAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPV6WANAddress() {
        return gatewayIPV6WANAddress;
    }

    /**
     * Sets the value of the gatewayIPV6WANAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPV6WANAddress(String value) {
        this.gatewayIPV6WANAddress = value;
    }

    /**
     * Gets the value of the gatewayPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayPhoneNum() {
        return gatewayPhoneNum;
    }

    /**
     * Sets the value of the gatewayPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayPhoneNum(String value) {
        this.gatewayPhoneNum = value;
    }

    /**
     * Gets the value of the wanHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANHardwareConfig() {
        return wanHardwareConfig;
    }

    /**
     * Sets the value of the wanHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANHardwareConfig(String value) {
        this.wanHardwareConfig = value;
    }

    /**
     * Gets the value of the wanSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANSoftwareConfig() {
        return wanSoftwareConfig;
    }

    /**
     * Sets the value of the wanSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANSoftwareConfig(String value) {
        this.wanSoftwareConfig = value;
    }

    /**
     * Gets the value of the isSocketAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSocketAP() {
        return isSocketAP;
    }

    /**
     * Sets the value of the isSocketAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSocketAP(Boolean value) {
        this.isSocketAP = value;
    }

}
