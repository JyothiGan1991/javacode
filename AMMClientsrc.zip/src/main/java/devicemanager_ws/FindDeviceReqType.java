
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindDeviceReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindDeviceReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceSearchParametersType"/&gt;
 *           &lt;element name="CachedResults" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}CachedResultsType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="ReturnNetworkInfrastructure" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="MaxResultCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="NumberRows" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="SortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}SortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindDeviceReqType", propOrder = {
    "searchParameters",
    "cachedResults",
    "returnNetworkInfrastructure",
    "maxResultCount",
    "numberRows",
    "sortMap"
})
public class FindDeviceReqType {

    @XmlElement(name = "SearchParameters")
    protected DeviceSearchParametersType searchParameters;
    @XmlElement(name = "CachedResults")
    protected CachedResultsType cachedResults;
    @XmlElement(name = "ReturnNetworkInfrastructure")
    protected Boolean returnNetworkInfrastructure;
    @XmlElement(name = "MaxResultCount")
    protected Integer maxResultCount;
    @XmlElement(name = "NumberRows")
    protected int numberRows;
    @XmlElement(name = "SortMap")
    protected List<SortMapType> sortMap;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSearchParametersType }
     *     
     */
    public DeviceSearchParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSearchParametersType }
     *     
     */
    public void setSearchParameters(DeviceSearchParametersType value) {
        this.searchParameters = value;
    }

    /**
     * Gets the value of the cachedResults property.
     * 
     * @return
     *     possible object is
     *     {@link CachedResultsType }
     *     
     */
    public CachedResultsType getCachedResults() {
        return cachedResults;
    }

    /**
     * Sets the value of the cachedResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link CachedResultsType }
     *     
     */
    public void setCachedResults(CachedResultsType value) {
        this.cachedResults = value;
    }

    /**
     * Gets the value of the returnNetworkInfrastructure property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReturnNetworkInfrastructure() {
        return returnNetworkInfrastructure;
    }

    /**
     * Sets the value of the returnNetworkInfrastructure property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReturnNetworkInfrastructure(Boolean value) {
        this.returnNetworkInfrastructure = value;
    }

    /**
     * Gets the value of the maxResultCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxResultCount() {
        return maxResultCount;
    }

    /**
     * Sets the value of the maxResultCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxResultCount(Integer value) {
        this.maxResultCount = value;
    }

    /**
     * Gets the value of the numberRows property.
     * 
     */
    public int getNumberRows() {
        return numberRows;
    }

    /**
     * Sets the value of the numberRows property.
     * 
     */
    public void setNumberRows(int value) {
        this.numberRows = value;
    }

    /**
     * Gets the value of the sortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SortMapType }
     * 
     * 
     */
    public List<SortMapType> getSortMap() {
        if (sortMap == null) {
            sortMap = new ArrayList<SortMapType>();
        }
        return this.sortMap;
    }

}
