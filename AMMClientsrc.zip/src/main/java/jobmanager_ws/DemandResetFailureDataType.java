
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DemandResetFailureDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DemandResetFailureDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}BaseExportDataType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileSegmenting" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DemandResetFailureFileSegmentingType" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycleNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="ExportType" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}ExportTypeEnumeration" default="Informational" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DemandResetFailureDataType", propOrder = {
    "fileSegmenting",
    "billingCycleNumber"
})
public class DemandResetFailureDataType
    extends BaseExportDataType
{

    @XmlElement(name = "FileSegmenting")
    protected DemandResetFailureFileSegmentingType fileSegmenting;
    @XmlElement(name = "BillingCycleNumber")
    protected String billingCycleNumber;
    @XmlAttribute(name = "ExportType")
    protected ExportTypeEnumeration exportType;

    /**
     * Gets the value of the fileSegmenting property.
     * 
     * @return
     *     possible object is
     *     {@link DemandResetFailureFileSegmentingType }
     *     
     */
    public DemandResetFailureFileSegmentingType getFileSegmenting() {
        return fileSegmenting;
    }

    /**
     * Sets the value of the fileSegmenting property.
     * 
     * @param value
     *     allowed object is
     *     {@link DemandResetFailureFileSegmentingType }
     *     
     */
    public void setFileSegmenting(DemandResetFailureFileSegmentingType value) {
        this.fileSegmenting = value;
    }

    /**
     * Gets the value of the billingCycleNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycleNumber() {
        return billingCycleNumber;
    }

    /**
     * Sets the value of the billingCycleNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycleNumber(String value) {
        this.billingCycleNumber = value;
    }

    /**
     * Gets the value of the exportType property.
     * 
     * @return
     *     possible object is
     *     {@link ExportTypeEnumeration }
     *     
     */
    public ExportTypeEnumeration getExportType() {
        if (exportType == null) {
            return ExportTypeEnumeration.INFORMATIONAL;
        } else {
            return exportType;
        }
    }

    /**
     * Sets the value of the exportType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExportTypeEnumeration }
     *     
     */
    public void setExportType(ExportTypeEnumeration value) {
        this.exportType = value;
    }

}
