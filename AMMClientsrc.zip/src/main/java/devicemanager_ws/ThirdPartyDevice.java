
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ThirdPartyDevice complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyDevice"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AssignedIPV4Address" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="InsertTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsConfigured" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="DeviceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ModelNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Manufacturer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ConfigIPV4Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastConfiguredTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyDevice", propOrder = {
    "macID",
    "assignedIPV4Address",
    "insertTime",
    "isConfigured",
    "deviceName",
    "modelNum",
    "manufacturer",
    "configIPV4Address",
    "description",
    "lastConfiguredTime"
})
public class ThirdPartyDevice {

    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "AssignedIPV4Address")
    protected List<String> assignedIPV4Address;
    @XmlElement(name = "InsertTime")
    protected String insertTime;
    @XmlElement(name = "IsConfigured")
    protected boolean isConfigured;
    @XmlElement(name = "DeviceName")
    protected String deviceName;
    @XmlElement(name = "ModelNum")
    protected String modelNum;
    @XmlElement(name = "Manufacturer")
    protected String manufacturer;
    @XmlElement(name = "ConfigIPV4Address")
    protected String configIPV4Address;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "LastConfiguredTime")
    protected String lastConfiguredTime;

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the assignedIPV4Address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assignedIPV4Address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssignedIPV4Address().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAssignedIPV4Address() {
        if (assignedIPV4Address == null) {
            assignedIPV4Address = new ArrayList<String>();
        }
        return this.assignedIPV4Address;
    }

    /**
     * Gets the value of the insertTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertTime() {
        return insertTime;
    }

    /**
     * Sets the value of the insertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertTime(String value) {
        this.insertTime = value;
    }

    /**
     * Gets the value of the isConfigured property.
     * 
     */
    public boolean isIsConfigured() {
        return isConfigured;
    }

    /**
     * Sets the value of the isConfigured property.
     * 
     */
    public void setIsConfigured(boolean value) {
        this.isConfigured = value;
    }

    /**
     * Gets the value of the deviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Sets the value of the deviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Gets the value of the modelNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelNum() {
        return modelNum;
    }

    /**
     * Sets the value of the modelNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelNum(String value) {
        this.modelNum = value;
    }

    /**
     * Gets the value of the manufacturer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * Sets the value of the manufacturer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManufacturer(String value) {
        this.manufacturer = value;
    }

    /**
     * Gets the value of the configIPV4Address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigIPV4Address() {
        return configIPV4Address;
    }

    /**
     * Sets the value of the configIPV4Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigIPV4Address(String value) {
        this.configIPV4Address = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the lastConfiguredTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastConfiguredTime() {
        return lastConfiguredTime;
    }

    /**
     * Sets the value of the lastConfiguredTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastConfiguredTime(String value) {
        this.lastConfiguredTime = value;
    }

}
