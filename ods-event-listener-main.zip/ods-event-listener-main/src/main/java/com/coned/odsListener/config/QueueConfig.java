/**
 * 
 */
package com.coned.odsListener.config;

import java.util.Hashtable;
import java.util.Vector;

import javax.jms.ConnectionFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import com.coned.odsListener.exception.JMSErrorHandler;
import com.conor.schema.ObjectFactory;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import com.tibco.ods.EndDeviceEventsEventMessageType;
import com.tibco.tibjms.TibjmsQueueConnectionFactory;

/**
 * @author DATHATHRIA
 *
 */
@Configuration
public class QueueConfig {
	@Autowired
	private Environment env;

	@Bean
	public JmsListenerContainerFactory<?> listenerConnFactory(@Qualifier("subscriber") ConnectionFactory subscriberConnectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		try {
			factory.setErrorHandler(new JMSErrorHandler());
			configurer.configure(factory, subscriberConnectionFactory);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return factory;
	}
	
	@Bean(name = "subscriber")
	public ConnectionFactory subscriberConnFactory() {
        TibjmsQueueConnectionFactory factory = new TibjmsQueueConnectionFactory(env.getProperty("tibco.url"), null, getTibcoProperties());
		factory.setUserName(env.getProperty("tibco.user.name"));
		factory.setUserPassword(env.getProperty("tibco.password"));
		
		return factory;
	}
	
	private Hashtable<Object, Object> getTibcoProperties() {
		Vector<String> ssl_trusted = new Vector<String>();
    	ssl_trusted.addElement(env.getProperty("tibco.ssl.certificate"));
    	
		Hashtable<Object, Object> tibcoProperites = new Hashtable<>();
		tibcoProperites.put("com.tibco.tibjms.naming.ssl_enable_verify_host", Boolean.parseBoolean(env.getProperty("tibco.ssl.enabled")));
		tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.TRUSTED_CERTIFICATES, ssl_trusted);
//    	tibcoProperites.put("com.tibco.tibjms.naming.security_protocol", "ssl");
		tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.VENDOR, env.getProperty("tibco.vendor"));
    	tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.EXPECTED_HOST_NAME, env.getProperty("tibco.host.name"));
		return tibcoProperites;
	}
	
	@Bean(name = "ceconyOutagePublisher")
	public ConnectionFactory ceconyOutagePublisherConnFactory() {
		MQConnectionFactory factory = new MQConnectionFactory();
		try {
			factory.setQueueManager(env.getProperty("ibm.mq.cecony.oms.outage.restore.queueManager"));
			factory.setChannel(env.getProperty("ibm.mq.cecony.oms.outage.restore.channel"));
			factory.setHostName(env.getProperty("ibm.mq.cecony.oms.outage.restore.connName"));
			factory.setPort(Integer.parseInt(env.getProperty("ibm.mq.cecony.oms.outage.restore.port")));
			factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			factory.setClientReconnectTimeout(600);
			factory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return factory;
	}
	
	@Bean(name = "ceconyOutageCaching")
	public CachingConnectionFactory ceconyOutagePublisherCachingConnFactory() {
		CachingConnectionFactory factory = new CachingConnectionFactory();
		factory.setSessionCacheSize(50);
		factory.setTargetConnectionFactory(ceconyOutagePublisherConnFactory());
		factory.setReconnectOnException(true);
		factory.afterPropertiesSet();
		return factory;
	}
	
	@Bean(name = "ceconyOutageJmsTemplate")
	public JmsTemplate setCeconyOutageJmsConnectionFactory() {
		JmsTemplate jmsTemplate = new JmsTemplate(ceconyOutagePublisherCachingConnFactory());
		return jmsTemplate;
	}
	
	@Bean(name = "ceconyRestorePublisher")
	public ConnectionFactory ceconyRestorePublisherConnFactory() {
		MQConnectionFactory factory = new MQConnectionFactory();
		try {
			factory.setQueueManager(env.getProperty("ibm.mq.cecony.oms.restore.queueManager"));
			factory.setChannel(env.getProperty("ibm.mq.cecony.oms.restore.channel"));
			factory.setHostName(env.getProperty("ibm.mq.cecony.oms.restore.connName"));
			factory.setPort(Integer.parseInt(env.getProperty("ibm.mq.cecony.oms.restore.port")));
			factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			factory.setClientReconnectTimeout(600);
			factory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return factory;
	}
	
	@Bean(name = "ceconyRestoreCaching")
	public CachingConnectionFactory ceconyRestorePublisherCachingConnFactory() {
		CachingConnectionFactory factory = new CachingConnectionFactory();
		factory.setSessionCacheSize(50);
		factory.setTargetConnectionFactory(ceconyRestorePublisherConnFactory());
		factory.setReconnectOnException(true);
		factory.afterPropertiesSet();
		return factory;
	}
	
	@Bean(name = "ceconyRestoreJmsTemplate")
	public JmsTemplate setCeconyRestoreJmsConnectionFactory() {
		JmsTemplate jmsTemplate = new JmsTemplate(ceconyRestorePublisherCachingConnFactory());
		return jmsTemplate;
	}
	
	@Bean(name = "onrPublisher")
	public ConnectionFactory onrPublisherConnFactory() {
		MQConnectionFactory factory = new MQConnectionFactory();
		try {
			factory.setQueueManager(env.getProperty("ibm.mq.onr.custom.filter.queueManager"));
			factory.setChannel(env.getProperty("ibm.mq.onr.custom.filter.channel"));
			factory.setHostName(env.getProperty("ibm.mq.onr.custom.filter.connName"));
			factory.setPort(Integer.parseInt(env.getProperty("ibm.mq.onr.custom.filter.port")));
			factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			factory.setClientReconnectTimeout(600);
			factory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return factory;
	}
	
	@Bean(name = "onrCaching")
	public CachingConnectionFactory onrPublisherCachingConnFactory() {
		CachingConnectionFactory factory = new CachingConnectionFactory();
		factory.setSessionCacheSize(50);
		factory.setTargetConnectionFactory(onrPublisherConnFactory());
		factory.setReconnectOnException(true);
		factory.afterPropertiesSet();
		return factory;
	}
	
	@Bean(name = "onrJmsTemplate")
	public JmsTemplate setOnrJmsConnectionFactory() {
		JmsTemplate jmsTemplate = new JmsTemplate(onrPublisherCachingConnFactory());
		return jmsTemplate;
	}
	
	@Bean(name = "odsUnmarshaller")
	public Unmarshaller setOdsUnmarshaller() throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(EndDeviceEventsEventMessageType.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return jaxbUnmarshaller;
	}
	
	@Bean(name = "multispeakMarshaller")
	public Marshaller setMultispeakMarshaller() throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(ObjectFactory.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		return jaxbMarshaller;
	}
}
