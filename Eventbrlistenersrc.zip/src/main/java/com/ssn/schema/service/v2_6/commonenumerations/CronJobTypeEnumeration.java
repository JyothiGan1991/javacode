
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CronJobTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CronJobTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_SEARCH_CACHE"/>
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_EXPORT_DATA"/>
 *     &lt;enumeration value="JOB_OP_CRON_JOB_UPDATE"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SEC_LOG_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_TASK_STATS_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_POP_DAILY_RSR_SUM"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_GAP_FILL"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_RECOVERY"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_NETWORK_STATUS"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_METER_SEC_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_ARCHIVE_JOBS"/>
 *     &lt;enumeration value="JOB_OP_CRON_BILL_CYCLE_SUMMARY"/>
 *     &lt;enumeration value="JOB_OP_CRON_UNFILL_GAP_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_NET_BACKBONE_HST"/>
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_RECOVERY"/>
 *     &lt;enumeration value="JOB_OP_CRON_CMD_QUEUE_RETRY"/>
 *     &lt;enumeration value="JOB_OP_CRON_RSND_FAIL_NP_RES"/>
 *     &lt;enumeration value="JOB_OP_CRON_ITVL_SUCCESS_PROC"/>
 *     &lt;enumeration value="JOB_OP_CRON_HEALTH_FLAG_EVENT"/>
 *     &lt;enumeration value="JOB_OP_CRON_DAY_START_PROC"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_NEW_ROUTES"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_INS_ROUTES"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_ROUTES_LAST"/>
 *     &lt;enumeration value="JOB_OP_CRON_SCHED_SUM_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_EVENT_LOG_GAP_FILL"/>
 *     &lt;enumeration value="JOB_OP_CRON_SET_UNREACHABLE"/>
 *     &lt;enumeration value="JOB_OP_CRON_RESET_UNREACHABLE"/>
 *     &lt;enumeration value="JOB_OP_CRON_ALARM_COUNTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_UNSCHED_METER_CNT"/>
 *     &lt;enumeration value="JOB_OP_CRON_TABLE_3_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_ERR_HIST_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_CARDINALITY_STATS"/>
 *     &lt;enumeration value="JOB_OP_CRON_ALL_OUTAGES_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_INFER_OUTAGES_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_LATENCY_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_DEV_STATE_SNAPSHOT"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_READ_SUCCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_RESOLVE_EVENTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DEVICE_CACHE"/>
 *     &lt;enumeration value="JOB_OP_CRON_ADD_PARTITIONS"/>
 *     &lt;enumeration value="JOB_OP_CRON_REMOVE_PARTITIONS"/>
 *     &lt;enumeration value="JOB_OP_CRON_NETSTATUS_COUNTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_RMT_PROV_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DB"/>
 *     &lt;enumeration value="JOB_OP_CRON_IMU_PREPROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_SEGMENT_DB"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CronJobTypeEnumeration")
@XmlEnum
public enum CronJobTypeEnumeration {

    JOB_OP_CRON_CLEAR_SEARCH_CACHE("JOB_OP_CRON_CLEAR_SEARCH_CACHE"),
    JOB_OP_CRON_CLEAR_EXPORT_DATA("JOB_OP_CRON_CLEAR_EXPORT_DATA"),
    JOB_OP_CRON_JOB_UPDATE("JOB_OP_CRON_JOB_UPDATE"),
    JOB_OP_CRON_INTERVAL_PROCESS("JOB_OP_CRON_INTERVAL_PROCESS"),
    JOB_OP_CRON_REGISTER_PROCESS("JOB_OP_CRON_REGISTER_PROCESS"),
    JOB_OP_CRON_SEC_LOG_PROCESS("JOB_OP_CRON_SEC_LOG_PROCESS"),
    JOB_OP_CRON_TASK_STATS_PROCESS("JOB_OP_CRON_TASK_STATS_PROCESS"),
    JOB_OP_CRON_POP_DAILY_RSR_SUM("JOB_OP_CRON_POP_DAILY_RSR_SUM"),
    JOB_OP_CRON_INTERVAL_GAP_FILL("JOB_OP_CRON_INTERVAL_GAP_FILL"),
    JOB_OP_CRON_INTERVAL_RECOVERY("JOB_OP_CRON_INTERVAL_RECOVERY"),
    JOB_OP_CRON_GEN_NETWORK_STATUS("JOB_OP_CRON_GEN_NETWORK_STATUS"),
    JOB_OP_CRON_GEN_METER_SEC_RPT("JOB_OP_CRON_GEN_METER_SEC_RPT"),
    JOB_OP_CRON_ARCHIVE_JOBS("JOB_OP_CRON_ARCHIVE_JOBS"),
    JOB_OP_CRON_BILL_CYCLE_SUMMARY("JOB_OP_CRON_BILL_CYCLE_SUMMARY"),
    JOB_OP_CRON_UNFILL_GAP_PROCESS("JOB_OP_CRON_UNFILL_GAP_PROCESS"),
    JOB_OP_CRON_NET_BACKBONE_HST("JOB_OP_CRON_NET_BACKBONE_HST"),
    JOB_OP_CRON_REGISTER_RECOVERY("JOB_OP_CRON_REGISTER_RECOVERY"),
    JOB_OP_CRON_CMD_QUEUE_RETRY("JOB_OP_CRON_CMD_QUEUE_RETRY"),
    JOB_OP_CRON_RSND_FAIL_NP_RES("JOB_OP_CRON_RSND_FAIL_NP_RES"),
    JOB_OP_CRON_ITVL_SUCCESS_PROC("JOB_OP_CRON_ITVL_SUCCESS_PROC"),
    JOB_OP_CRON_HEALTH_FLAG_EVENT("JOB_OP_CRON_HEALTH_FLAG_EVENT"),
    JOB_OP_CRON_DAY_START_PROC("JOB_OP_CRON_DAY_START_PROC"),
    JOB_OP_CRON_SYNC_NEW_ROUTES("JOB_OP_CRON_SYNC_NEW_ROUTES"),
    JOB_OP_CRON_SYNC_INS_ROUTES("JOB_OP_CRON_SYNC_INS_ROUTES"),
    JOB_OP_CRON_SYNC_ROUTES_LAST("JOB_OP_CRON_SYNC_ROUTES_LAST"),
    JOB_OP_CRON_SCHED_SUM_PROCESS("JOB_OP_CRON_SCHED_SUM_PROCESS"),
    JOB_OP_CRON_EVENT_LOG_GAP_FILL("JOB_OP_CRON_EVENT_LOG_GAP_FILL"),
    JOB_OP_CRON_SET_UNREACHABLE("JOB_OP_CRON_SET_UNREACHABLE"),
    JOB_OP_CRON_RESET_UNREACHABLE("JOB_OP_CRON_RESET_UNREACHABLE"),
    JOB_OP_CRON_ALARM_COUNTS("JOB_OP_CRON_ALARM_COUNTS"),
    JOB_OP_CRON_UNSCHED_METER_CNT("JOB_OP_CRON_UNSCHED_METER_CNT"),
    JOB_OP_CRON_TABLE_3_PROCESS("JOB_OP_CRON_TABLE_3_PROCESS"),
    JOB_OP_CRON_ERR_HIST_PROCESS("JOB_OP_CRON_ERR_HIST_PROCESS"),
    JOB_OP_CRON_CARDINALITY_STATS("JOB_OP_CRON_CARDINALITY_STATS"),
    JOB_OP_CRON_ALL_OUTAGES_RPT("JOB_OP_CRON_ALL_OUTAGES_RPT"),
    JOB_OP_CRON_INFER_OUTAGES_RPT("JOB_OP_CRON_INFER_OUTAGES_RPT"),
    JOB_OP_CRON_GEN_LATENCY_RPT("JOB_OP_CRON_GEN_LATENCY_RPT"),
    JOB_OP_CRON_DEV_STATE_SNAPSHOT("JOB_OP_CRON_DEV_STATE_SNAPSHOT"),
    JOB_OP_CRON_GEN_READ_SUCCESS("JOB_OP_CRON_GEN_READ_SUCCESS"),
    JOB_OP_CRON_RESOLVE_EVENTS("JOB_OP_CRON_RESOLVE_EVENTS"),
    JOB_OP_CRON_SYNC_DEVICE_CACHE("JOB_OP_CRON_SYNC_DEVICE_CACHE"),
    JOB_OP_CRON_ADD_PARTITIONS("JOB_OP_CRON_ADD_PARTITIONS"),
    JOB_OP_CRON_REMOVE_PARTITIONS("JOB_OP_CRON_REMOVE_PARTITIONS"),
    JOB_OP_CRON_NETSTATUS_COUNTS("JOB_OP_CRON_NETSTATUS_COUNTS"),
    JOB_OP_CRON_RMT_PROV_PROCESS("JOB_OP_CRON_RMT_PROV_PROCESS"),
    JOB_OP_CRON_SYNC_DB("JOB_OP_CRON_SYNC_DB"),
    JOB_OP_CRON_IMU_PREPROCESS("JOB_OP_CRON_IMU_PREPROCESS"),
    JOB_OP_CRON_SYNC_SEGMENT_DB("JOB_OP_CRON_SYNC_SEGMENT_DB"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    CronJobTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CronJobTypeEnumeration fromValue(String v) {
        for (CronJobTypeEnumeration c: CronJobTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
