package com.coned.ls.repository;

import com.coned.ls.domain.ExecuteExternalCall;
import com.coned.ls.exception.ExternalCallException;
import com.coned.ls.mapper.ExternalCallResponseMapper;

/**
 * 
 * Interface for Execute External Call Repository.
 *
 */
public interface ExecuteExternalCallRepository {
	public ExternalCallResponseMapper executeMeterEventList(final ExecuteExternalCall executeExternalCall)throws ExternalCallException;
}
