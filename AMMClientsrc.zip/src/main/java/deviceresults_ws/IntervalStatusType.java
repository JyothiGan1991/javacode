
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IntervalStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="IntervalStatusType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Daylight savings time is in effect during or at start of interval (std table 64)"/&gt;
 *     &lt;enumeration value="Power fail within interval (std table 64)"/&gt;
 *     &lt;enumeration value="Clock reset forward during interval (std table 64)"/&gt;
 *     &lt;enumeration value="Clock reset backward during interval (std table 64)"/&gt;
 *     &lt;enumeration value="METERING_ERROR"/&gt;
 *     &lt;enumeration value="REVERSE_ENERGY_FLOW"/&gt;
 *     &lt;enumeration value="SERVICE_ERROR"/&gt;
 *     &lt;enumeration value="DC_DETECT_ERROR"/&gt;
 *     &lt;enumeration value="LOW_VOLTAGE_ERROR"/&gt;
 *     &lt;enumeration value="RECOVERABLE_ERROR"/&gt;
 *     &lt;enumeration value="CRC_ERROR"/&gt;
 *     &lt;enumeration value="LEGACY_METERING_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_REV_ENERGY_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_SERVICE_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_DC_DETECT_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_METER_INVERSION_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_POWER_FAILURE"/&gt;
 *     &lt;enumeration value="LEGACY_OVER_CURRENT"/&gt;
 *     &lt;enumeration value="LEGACY_NVRAM_CRC_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_RECOVERABLE_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_LOW_VOLTAGE_ERR"/&gt;
 *     &lt;enumeration value="LEGACY_LOW_BATTERY"/&gt;
 *     &lt;enumeration value="UNKNOWN_FLAG_SET"/&gt;
 *     &lt;enumeration value="METERING_ERR"/&gt;
 *     &lt;enumeration value="REV_ENERGY_ERR"/&gt;
 *     &lt;enumeration value="SERVICE_ERR"/&gt;
 *     &lt;enumeration value="DC_DETECT_ERR"/&gt;
 *     &lt;enumeration value="METER_INVERSION_ERR"/&gt;
 *     &lt;enumeration value="POWER_FAILURE"/&gt;
 *     &lt;enumeration value="OVER_CURRENT"/&gt;
 *     &lt;enumeration value="NVRAM_CRC_ERR"/&gt;
 *     &lt;enumeration value="RECOVERABLE_ERR"/&gt;
 *     &lt;enumeration value="LOW_VOLTAGE_ERR"/&gt;
 *     &lt;enumeration value="LOW_BATTERY"/&gt;
 *     &lt;enumeration value="NVRAM_COMM_ERR"/&gt;
 *     &lt;enumeration value="MEASUREMENT_ERR"/&gt;
 *     &lt;enumeration value="CLOCK_ERR"/&gt;
 *     &lt;enumeration value="NVRAM_FAILURE"/&gt;
 *     &lt;enumeration value="ROM_FAILURE"/&gt;
 *     &lt;enumeration value="RAM_FAILURE"/&gt;
 *     &lt;enumeration value="SELF_CHECK_ERR"/&gt;
 *     &lt;enumeration value="CONFIGURATION_ERR"/&gt;
 *     &lt;enumeration value="UNPROGRAMMED_ERR"/&gt;
 *     &lt;enumeration value="DEMAND_OVERLOAD"/&gt;
 *     &lt;enumeration value="LOW_LOSS_POTENTIAL"/&gt;
 *     &lt;enumeration value="TAMPER_DETECT"/&gt;
 *     &lt;enumeration value="TIME_ADJUST_ERR"/&gt;
 *     &lt;enumeration value="STUCK_SWITCH_ERR"/&gt;
 *     &lt;enumeration value="PHASE_A_OUT"/&gt;
 *     &lt;enumeration value="PHASE_B_OUT"/&gt;
 *     &lt;enumeration value="PHASE_C_OUT"/&gt;
 *     &lt;enumeration value="INVALID_SERVICE"/&gt;
 *     &lt;enumeration value="FLASH_DATA_ERR"/&gt;
 *     &lt;enumeration value="FLASH_CODE_ERR"/&gt;
 *     &lt;enumeration value="LOSS_OF_PROGRAM"/&gt;
 *     &lt;enumeration value="LEADING_KVARH"/&gt;
 *     &lt;enumeration value="RECEIVED_KWH_ERR"/&gt;
 *     &lt;enumeration value="SYSTEM_ERR"/&gt;
 *     &lt;enumeration value="DSP_ERR"/&gt;
 *     &lt;enumeration value="MISSING_50_60_HZ"/&gt;
 *     &lt;enumeration value="UNKNOWN_SERVICE"/&gt;
 *     &lt;enumeration value="SD_SWITCH_ERR"/&gt;
 *     &lt;enumeration value="SD_SWITCH_SENSOR_ERR"/&gt;
 *     &lt;enumeration value="METERING_ERR_HST"/&gt;
 *     &lt;enumeration value="SERVICE_ERR_HST"/&gt;
 *     &lt;enumeration value="DC_DETECT_ERR_HST"/&gt;
 *     &lt;enumeration value="METER_INVERSION_ERR_HST"/&gt;
 *     &lt;enumeration value="REV_ENERGY_ERR_HST"/&gt;
 *     &lt;enumeration value="RESET_TAMPER_ERR"/&gt;
 *     &lt;enumeration value="TEMPER_CAUTION"/&gt;
 *     &lt;enumeration value="HIST_TEMPER_CAUTION"/&gt;
 *     &lt;enumeration value="RMS_VOLTAGE_ERROR"/&gt;
 *     &lt;enumeration value="OUT_OF_METER_MODE"/&gt;
 *     &lt;enumeration value="LOW_CAP_CHARGE"/&gt;
 *     &lt;enumeration value="HIGH_CAP_CHARGE"/&gt;
 *     &lt;enumeration value="CVR_OUT_OF_SPEC"/&gt;
 *     &lt;enumeration value="INACT_PHS_CURRENT"/&gt;
 *     &lt;enumeration value="HIGH_VOLTAGE_ERROR"/&gt;
 *     &lt;enumeration value="BAD_PASSWORDS"/&gt;
 *     &lt;enumeration value="CORRUPT_ST_15"/&gt;
 *     &lt;enumeration value="CORRUPT_MT_5"/&gt;
 *     &lt;enumeration value="PHASE_A_VOLTAGE_OUT_OF_SPEC"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_GENERAL_ERROR"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_SRC_SEL_ERROR"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_CRC_FLASH_ERROR"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_CRC_FLASH_CHECK_FAILED"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_CLOCK_FORWARD"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_CLOCK_BACKWARD"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_LONG_INTERVAL"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_PARTIAL_INTERVAL"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_CONVERTED_INTERVAL"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_READ_DELAY_HIGH"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_POWER_FAIL"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_METER_STATUS_NOT_READY"/&gt;
 *     &lt;enumeration value="INTERVAL_RAM_FAILURE"/&gt;
 *     &lt;enumeration value="INTERVAL_ROM_FAILURE"/&gt;
 *     &lt;enumeration value="INTERVAL_TEST_MODE"/&gt;
 *     &lt;enumeration value="INTERVAL_CLOCK_ERROR"/&gt;
 *     &lt;enumeration value="INTERVAL_PRI_PHASE_FAILURE"/&gt;
 *     &lt;enumeration value="INTERVAL_PRI_REVERSE_RUN"/&gt;
 *     &lt;enumeration value="INTERVAL_PRI_METER_DATA_CHANGED"/&gt;
 *     &lt;enumeration value="INTERVAL_PRI_TIME_SET"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_OUT_OF_SYNC"/&gt;
 *     &lt;enumeration value="INTERVAL_GMI_INDIRECT_INT_LEN"/&gt;
 *     &lt;enumeration value="NONVOL_MEM_FAILURE"/&gt;
 *     &lt;enumeration value="POSITIVE_OVERFLOW"/&gt;
 *     &lt;enumeration value="NEGATIVE_OVERFLOW"/&gt;
 *     &lt;enumeration value="BAD_ENCODER_DIGIT"/&gt;
 *     &lt;enumeration value="COULD_NOT_READ_ENCODER"/&gt;
 *     &lt;enumeration value="SUM_INTERVAL"/&gt;
 *     &lt;enumeration value="SUM_INTERVAL_BOUNDARY"/&gt;
 *     &lt;enumeration value="UNKNOWN_INTERVAL_ERROR"/&gt;
 *     &lt;enumeration value="INTERVAL_START_OF_MEASUREMENT"/&gt;
 *     &lt;enumeration value="CLOCK_SET"/&gt;
 *     &lt;enumeration value="EXTERNAL_CLOCK_SYNCHRONIZED"/&gt;
 *     &lt;enumeration value="DAYLIGHT_SAVINGS"/&gt;
 *     &lt;enumeration value="WATCHDOG_RESET"/&gt;
 *     &lt;enumeration value="EXTERNAL_CLOCK_INCOHERENCE"/&gt;
 *     &lt;enumeration value="NON_VOLATILE_MEMORY_NON_FATAL_ERROR"/&gt;
 *     &lt;enumeration value="COVER_OPENING"/&gt;
 *     &lt;enumeration value="CLOCK_LOSS"/&gt;
 *     &lt;enumeration value="EXTERNAL_ALARM"/&gt;
 *     &lt;enumeration value="CURRENT_REVERSAL_PHASE_1"/&gt;
 *     &lt;enumeration value="CURRENT_REVERSAL_PHASE_2"/&gt;
 *     &lt;enumeration value="CURRENT_REVERSAL_PHASE_3"/&gt;
 *     &lt;enumeration value="TEMPERATURE_ALARM"/&gt;
 *     &lt;enumeration value="VOLTAGE_CUT_PHASE_1"/&gt;
 *     &lt;enumeration value="VOLTAGE_CUT_PHASE_2"/&gt;
 *     &lt;enumeration value="VOLTAGE_CUT_PHASE_3"/&gt;
 *     &lt;enumeration value="BATTERY"/&gt;
 *     &lt;enumeration value="EXCESS_DEMAND"/&gt;
 *     &lt;enumeration value="MAGNET_SENSOR"/&gt;
 *     &lt;enumeration value="SHORT_INTERVAL_PERIOD"/&gt;
 *     &lt;enumeration value="CRITICAL_ERROR"/&gt;
 *     &lt;enumeration value="INVALID_CLOCK"/&gt;
 *     &lt;enumeration value="NOT_FOR_BILLING"/&gt;
 *     &lt;enumeration value="DST_NOT_USED"/&gt;
 *     &lt;enumeration value="GAP"/&gt;
 *     &lt;enumeration value="CLOCK_ADJUSTED"/&gt;
 *     &lt;enumeration value="BILLING_PERIOD_RESET"/&gt;
 *     &lt;enumeration value="ABSENT_READING"/&gt;
 *     &lt;enumeration value="INCOMPLETE_INTERVAL"/&gt;
 *     &lt;enumeration value="INVALID_DATA"/&gt;
 *     &lt;enumeration value="PULSE_OVERFLOW"/&gt;
 *     &lt;enumeration value="EEPROM_ERR"/&gt;
 *     &lt;enumeration value="HIGH_LINE_CURRENT_DETECTED"/&gt;
 *     &lt;enumeration value="HIGH_TEMPERATURE"/&gt;
 *     &lt;enumeration value="POWER_RESTORED"/&gt;
 *     &lt;enumeration value="NONE_OR_WRONG_COUNTING_SIGNAL"/&gt;
 *     &lt;enumeration value="LEAK_DETECTED"/&gt;
 *     &lt;enumeration value="NEGATIVE_FLOW"/&gt;
 *     &lt;enumeration value="TILT_DETECTED"/&gt;
 *     &lt;enumeration value="MAX_FLOW_THRESHOLD_EXCEEDED"/&gt;
 *     &lt;enumeration value="INTER_DIGIT_ERROR"/&gt;
 *     &lt;enumeration value="LONG_INTERVAL_PERIOD"/&gt;
 *     &lt;enumeration value="BACKFLOW_OCCURRED"/&gt;
 *     &lt;enumeration value="SUM_OF_PREVIOUS_NO_READ_ITVLS"/&gt;
 *     &lt;enumeration value="RESERVED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "IntervalStatusType")
@XmlEnum
public enum IntervalStatusType {

    @XmlEnumValue("Daylight savings time is in effect during or at start of interval (std table 64)")
    DAYLIGHT_SAVINGS_TIME_IS_IN_EFFECT_DURING_OR_AT_START_OF_INTERVAL_STD_TABLE_64("Daylight savings time is in effect during or at start of interval (std table 64)"),
    @XmlEnumValue("Power fail within interval (std table 64)")
    POWER_FAIL_WITHIN_INTERVAL_STD_TABLE_64("Power fail within interval (std table 64)"),
    @XmlEnumValue("Clock reset forward during interval (std table 64)")
    CLOCK_RESET_FORWARD_DURING_INTERVAL_STD_TABLE_64("Clock reset forward during interval (std table 64)"),
    @XmlEnumValue("Clock reset backward during interval (std table 64)")
    CLOCK_RESET_BACKWARD_DURING_INTERVAL_STD_TABLE_64("Clock reset backward during interval (std table 64)"),
    METERING_ERROR("METERING_ERROR"),
    REVERSE_ENERGY_FLOW("REVERSE_ENERGY_FLOW"),
    SERVICE_ERROR("SERVICE_ERROR"),
    DC_DETECT_ERROR("DC_DETECT_ERROR"),
    LOW_VOLTAGE_ERROR("LOW_VOLTAGE_ERROR"),
    RECOVERABLE_ERROR("RECOVERABLE_ERROR"),
    CRC_ERROR("CRC_ERROR"),
    LEGACY_METERING_ERR("LEGACY_METERING_ERR"),
    LEGACY_REV_ENERGY_ERR("LEGACY_REV_ENERGY_ERR"),
    LEGACY_SERVICE_ERR("LEGACY_SERVICE_ERR"),
    LEGACY_DC_DETECT_ERR("LEGACY_DC_DETECT_ERR"),
    LEGACY_METER_INVERSION_ERR("LEGACY_METER_INVERSION_ERR"),
    LEGACY_POWER_FAILURE("LEGACY_POWER_FAILURE"),
    LEGACY_OVER_CURRENT("LEGACY_OVER_CURRENT"),
    LEGACY_NVRAM_CRC_ERR("LEGACY_NVRAM_CRC_ERR"),
    LEGACY_RECOVERABLE_ERR("LEGACY_RECOVERABLE_ERR"),
    LEGACY_LOW_VOLTAGE_ERR("LEGACY_LOW_VOLTAGE_ERR"),
    LEGACY_LOW_BATTERY("LEGACY_LOW_BATTERY"),
    UNKNOWN_FLAG_SET("UNKNOWN_FLAG_SET"),
    METERING_ERR("METERING_ERR"),
    REV_ENERGY_ERR("REV_ENERGY_ERR"),
    SERVICE_ERR("SERVICE_ERR"),
    DC_DETECT_ERR("DC_DETECT_ERR"),
    METER_INVERSION_ERR("METER_INVERSION_ERR"),
    POWER_FAILURE("POWER_FAILURE"),
    OVER_CURRENT("OVER_CURRENT"),
    NVRAM_CRC_ERR("NVRAM_CRC_ERR"),
    RECOVERABLE_ERR("RECOVERABLE_ERR"),
    LOW_VOLTAGE_ERR("LOW_VOLTAGE_ERR"),
    LOW_BATTERY("LOW_BATTERY"),
    NVRAM_COMM_ERR("NVRAM_COMM_ERR"),
    MEASUREMENT_ERR("MEASUREMENT_ERR"),
    CLOCK_ERR("CLOCK_ERR"),
    NVRAM_FAILURE("NVRAM_FAILURE"),
    ROM_FAILURE("ROM_FAILURE"),
    RAM_FAILURE("RAM_FAILURE"),
    SELF_CHECK_ERR("SELF_CHECK_ERR"),
    CONFIGURATION_ERR("CONFIGURATION_ERR"),
    UNPROGRAMMED_ERR("UNPROGRAMMED_ERR"),
    DEMAND_OVERLOAD("DEMAND_OVERLOAD"),
    LOW_LOSS_POTENTIAL("LOW_LOSS_POTENTIAL"),
    TAMPER_DETECT("TAMPER_DETECT"),
    TIME_ADJUST_ERR("TIME_ADJUST_ERR"),
    STUCK_SWITCH_ERR("STUCK_SWITCH_ERR"),
    PHASE_A_OUT("PHASE_A_OUT"),
    PHASE_B_OUT("PHASE_B_OUT"),
    PHASE_C_OUT("PHASE_C_OUT"),
    INVALID_SERVICE("INVALID_SERVICE"),
    FLASH_DATA_ERR("FLASH_DATA_ERR"),
    FLASH_CODE_ERR("FLASH_CODE_ERR"),
    LOSS_OF_PROGRAM("LOSS_OF_PROGRAM"),
    LEADING_KVARH("LEADING_KVARH"),
    RECEIVED_KWH_ERR("RECEIVED_KWH_ERR"),
    SYSTEM_ERR("SYSTEM_ERR"),
    DSP_ERR("DSP_ERR"),
    MISSING_50_60_HZ("MISSING_50_60_HZ"),
    UNKNOWN_SERVICE("UNKNOWN_SERVICE"),
    SD_SWITCH_ERR("SD_SWITCH_ERR"),
    SD_SWITCH_SENSOR_ERR("SD_SWITCH_SENSOR_ERR"),
    METERING_ERR_HST("METERING_ERR_HST"),
    SERVICE_ERR_HST("SERVICE_ERR_HST"),
    DC_DETECT_ERR_HST("DC_DETECT_ERR_HST"),
    METER_INVERSION_ERR_HST("METER_INVERSION_ERR_HST"),
    REV_ENERGY_ERR_HST("REV_ENERGY_ERR_HST"),
    RESET_TAMPER_ERR("RESET_TAMPER_ERR"),
    TEMPER_CAUTION("TEMPER_CAUTION"),
    HIST_TEMPER_CAUTION("HIST_TEMPER_CAUTION"),
    RMS_VOLTAGE_ERROR("RMS_VOLTAGE_ERROR"),
    OUT_OF_METER_MODE("OUT_OF_METER_MODE"),
    LOW_CAP_CHARGE("LOW_CAP_CHARGE"),
    HIGH_CAP_CHARGE("HIGH_CAP_CHARGE"),
    CVR_OUT_OF_SPEC("CVR_OUT_OF_SPEC"),
    INACT_PHS_CURRENT("INACT_PHS_CURRENT"),
    HIGH_VOLTAGE_ERROR("HIGH_VOLTAGE_ERROR"),
    BAD_PASSWORDS("BAD_PASSWORDS"),
    CORRUPT_ST_15("CORRUPT_ST_15"),
    CORRUPT_MT_5("CORRUPT_MT_5"),
    PHASE_A_VOLTAGE_OUT_OF_SPEC("PHASE_A_VOLTAGE_OUT_OF_SPEC"),
    INTERVAL_GMI_GENERAL_ERROR("INTERVAL_GMI_GENERAL_ERROR"),
    INTERVAL_GMI_SRC_SEL_ERROR("INTERVAL_GMI_SRC_SEL_ERROR"),
    INTERVAL_GMI_CRC_FLASH_ERROR("INTERVAL_GMI_CRC_FLASH_ERROR"),
    INTERVAL_GMI_CRC_FLASH_CHECK_FAILED("INTERVAL_GMI_CRC_FLASH_CHECK_FAILED"),
    INTERVAL_GMI_CLOCK_FORWARD("INTERVAL_GMI_CLOCK_FORWARD"),
    INTERVAL_GMI_CLOCK_BACKWARD("INTERVAL_GMI_CLOCK_BACKWARD"),
    INTERVAL_GMI_LONG_INTERVAL("INTERVAL_GMI_LONG_INTERVAL"),
    INTERVAL_GMI_PARTIAL_INTERVAL("INTERVAL_GMI_PARTIAL_INTERVAL"),
    INTERVAL_GMI_CONVERTED_INTERVAL("INTERVAL_GMI_CONVERTED_INTERVAL"),
    INTERVAL_GMI_READ_DELAY_HIGH("INTERVAL_GMI_READ_DELAY_HIGH"),
    INTERVAL_GMI_POWER_FAIL("INTERVAL_GMI_POWER_FAIL"),
    INTERVAL_GMI_METER_STATUS_NOT_READY("INTERVAL_GMI_METER_STATUS_NOT_READY"),
    INTERVAL_RAM_FAILURE("INTERVAL_RAM_FAILURE"),
    INTERVAL_ROM_FAILURE("INTERVAL_ROM_FAILURE"),
    INTERVAL_TEST_MODE("INTERVAL_TEST_MODE"),
    INTERVAL_CLOCK_ERROR("INTERVAL_CLOCK_ERROR"),
    INTERVAL_PRI_PHASE_FAILURE("INTERVAL_PRI_PHASE_FAILURE"),
    INTERVAL_PRI_REVERSE_RUN("INTERVAL_PRI_REVERSE_RUN"),
    INTERVAL_PRI_METER_DATA_CHANGED("INTERVAL_PRI_METER_DATA_CHANGED"),
    INTERVAL_PRI_TIME_SET("INTERVAL_PRI_TIME_SET"),
    INTERVAL_GMI_OUT_OF_SYNC("INTERVAL_GMI_OUT_OF_SYNC"),
    INTERVAL_GMI_INDIRECT_INT_LEN("INTERVAL_GMI_INDIRECT_INT_LEN"),
    NONVOL_MEM_FAILURE("NONVOL_MEM_FAILURE"),
    POSITIVE_OVERFLOW("POSITIVE_OVERFLOW"),
    NEGATIVE_OVERFLOW("NEGATIVE_OVERFLOW"),
    BAD_ENCODER_DIGIT("BAD_ENCODER_DIGIT"),
    COULD_NOT_READ_ENCODER("COULD_NOT_READ_ENCODER"),
    SUM_INTERVAL("SUM_INTERVAL"),
    SUM_INTERVAL_BOUNDARY("SUM_INTERVAL_BOUNDARY"),
    UNKNOWN_INTERVAL_ERROR("UNKNOWN_INTERVAL_ERROR"),
    INTERVAL_START_OF_MEASUREMENT("INTERVAL_START_OF_MEASUREMENT"),
    CLOCK_SET("CLOCK_SET"),
    EXTERNAL_CLOCK_SYNCHRONIZED("EXTERNAL_CLOCK_SYNCHRONIZED"),
    DAYLIGHT_SAVINGS("DAYLIGHT_SAVINGS"),
    WATCHDOG_RESET("WATCHDOG_RESET"),
    EXTERNAL_CLOCK_INCOHERENCE("EXTERNAL_CLOCK_INCOHERENCE"),
    NON_VOLATILE_MEMORY_NON_FATAL_ERROR("NON_VOLATILE_MEMORY_NON_FATAL_ERROR"),
    COVER_OPENING("COVER_OPENING"),
    CLOCK_LOSS("CLOCK_LOSS"),
    EXTERNAL_ALARM("EXTERNAL_ALARM"),
    CURRENT_REVERSAL_PHASE_1("CURRENT_REVERSAL_PHASE_1"),
    CURRENT_REVERSAL_PHASE_2("CURRENT_REVERSAL_PHASE_2"),
    CURRENT_REVERSAL_PHASE_3("CURRENT_REVERSAL_PHASE_3"),
    TEMPERATURE_ALARM("TEMPERATURE_ALARM"),
    VOLTAGE_CUT_PHASE_1("VOLTAGE_CUT_PHASE_1"),
    VOLTAGE_CUT_PHASE_2("VOLTAGE_CUT_PHASE_2"),
    VOLTAGE_CUT_PHASE_3("VOLTAGE_CUT_PHASE_3"),
    BATTERY("BATTERY"),
    EXCESS_DEMAND("EXCESS_DEMAND"),
    MAGNET_SENSOR("MAGNET_SENSOR"),
    SHORT_INTERVAL_PERIOD("SHORT_INTERVAL_PERIOD"),
    CRITICAL_ERROR("CRITICAL_ERROR"),
    INVALID_CLOCK("INVALID_CLOCK"),
    NOT_FOR_BILLING("NOT_FOR_BILLING"),
    DST_NOT_USED("DST_NOT_USED"),
    GAP("GAP"),
    CLOCK_ADJUSTED("CLOCK_ADJUSTED"),
    BILLING_PERIOD_RESET("BILLING_PERIOD_RESET"),
    ABSENT_READING("ABSENT_READING"),
    INCOMPLETE_INTERVAL("INCOMPLETE_INTERVAL"),
    INVALID_DATA("INVALID_DATA"),
    PULSE_OVERFLOW("PULSE_OVERFLOW"),
    EEPROM_ERR("EEPROM_ERR"),
    HIGH_LINE_CURRENT_DETECTED("HIGH_LINE_CURRENT_DETECTED"),
    HIGH_TEMPERATURE("HIGH_TEMPERATURE"),
    POWER_RESTORED("POWER_RESTORED"),
    NONE_OR_WRONG_COUNTING_SIGNAL("NONE_OR_WRONG_COUNTING_SIGNAL"),
    LEAK_DETECTED("LEAK_DETECTED"),
    NEGATIVE_FLOW("NEGATIVE_FLOW"),
    TILT_DETECTED("TILT_DETECTED"),
    MAX_FLOW_THRESHOLD_EXCEEDED("MAX_FLOW_THRESHOLD_EXCEEDED"),
    INTER_DIGIT_ERROR("INTER_DIGIT_ERROR"),
    LONG_INTERVAL_PERIOD("LONG_INTERVAL_PERIOD"),
    BACKFLOW_OCCURRED("BACKFLOW_OCCURRED"),
    SUM_OF_PREVIOUS_NO_READ_ITVLS("SUM_OF_PREVIOUS_NO_READ_ITVLS"),
    RESERVED("RESERVED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    IntervalStatusType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IntervalStatusType fromValue(String v) {
        for (IntervalStatusType c: IntervalStatusType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
