package com.coned.ls.repository;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;

/**
 * 
 * Interface for Meter Event finalize repository class.
 *
 */
public interface MetersEventFinalizeRepository {
	public MeterFinalizeResponseMapper finalizeMeterEvent(final MeterEventFinalize meterEventFinalize, final String adid) throws MeterFinalizeException;
}
