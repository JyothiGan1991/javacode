
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateDeviceLocationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateDeviceLocationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="UtilServicePtID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="UtilLocationID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="UtilLocationIDType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UtilLocationIDType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="ServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AdminState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DevicePtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DeviceCtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="InstallTS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateDeviceLocationType", propOrder = {
    "utilServicePtID",
    "utilLocationID",
    "utilLocationIDType",
    "serviceType",
    "adminState",
    "billingCycle",
    "devicePtRatio",
    "deviceCtRatio",
    "installTS"
})
public class UpdateDeviceLocationType {

    @XmlElement(name = "UtilServicePtID")
    protected String utilServicePtID;
    @XmlElement(name = "UtilLocationID")
    protected String utilLocationID;
    @XmlElement(name = "UtilLocationIDType")
    protected UtilLocationIDType utilLocationIDType;
    @XmlElement(name = "ServiceType")
    protected String serviceType;
    @XmlElement(name = "AdminState")
    protected UtilDeviceStateType adminState;
    @XmlElement(name = "BillingCycle")
    protected String billingCycle;
    @XmlElement(name = "DevicePtRatio")
    protected Double devicePtRatio;
    @XmlElement(name = "DeviceCtRatio")
    protected Double deviceCtRatio;
    @XmlElement(name = "InstallTS")
    protected String installTS;

    /**
     * Gets the value of the utilServicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePtID() {
        return utilServicePtID;
    }

    /**
     * Sets the value of the utilServicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePtID(String value) {
        this.utilServicePtID = value;
    }

    /**
     * Gets the value of the utilLocationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilLocationID() {
        return utilLocationID;
    }

    /**
     * Sets the value of the utilLocationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilLocationID(String value) {
        this.utilLocationID = value;
    }

    /**
     * Gets the value of the utilLocationIDType property.
     * 
     * @return
     *     possible object is
     *     {@link UtilLocationIDType }
     *     
     */
    public UtilLocationIDType getUtilLocationIDType() {
        return utilLocationIDType;
    }

    /**
     * Sets the value of the utilLocationIDType property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilLocationIDType }
     *     
     */
    public void setUtilLocationIDType(UtilLocationIDType value) {
        this.utilLocationIDType = value;
    }

    /**
     * Gets the value of the serviceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * Sets the value of the serviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceType(String value) {
        this.serviceType = value;
    }

    /**
     * Gets the value of the adminState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getAdminState() {
        return adminState;
    }

    /**
     * Sets the value of the adminState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setAdminState(UtilDeviceStateType value) {
        this.adminState = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycle(String value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the devicePtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDevicePtRatio() {
        return devicePtRatio;
    }

    /**
     * Sets the value of the devicePtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDevicePtRatio(Double value) {
        this.devicePtRatio = value;
    }

    /**
     * Gets the value of the deviceCtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDeviceCtRatio() {
        return deviceCtRatio;
    }

    /**
     * Sets the value of the deviceCtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDeviceCtRatio(Double value) {
        this.deviceCtRatio = value;
    }

    /**
     * Gets the value of the installTS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstallTS() {
        return installTS;
    }

    /**
     * Sets the value of the installTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstallTS(String value) {
        this.installTS = value;
    }

}
