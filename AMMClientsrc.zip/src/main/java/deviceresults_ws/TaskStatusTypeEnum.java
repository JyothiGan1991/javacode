
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaskStatusTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaskStatusTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MRS_SUCCESS"/&gt;
 *     &lt;enumeration value="MRS_CFG_MISMATCH"/&gt;
 *     &lt;enumeration value="MRS_PROGRAM_SEAL_MISMATCH"/&gt;
 *     &lt;enumeration value="MRS_NO_ROUTE"/&gt;
 *     &lt;enumeration value="MRS_NO_RESOURCES"/&gt;
 *     &lt;enumeration value="MRS_TIMEOUT"/&gt;
 *     &lt;enumeration value="MRS_PARTIAL"/&gt;
 *     &lt;enumeration value="MRS_BLK_SHIFT"/&gt;
 *     &lt;enumeration value="MRS_SNAP_CHANGED"/&gt;
 *     &lt;enumeration value="MRS_INTERNAL"/&gt;
 *     &lt;enumeration value="MRS_PARAM_OUT_OF_BOUNDS"/&gt;
 *     &lt;enumeration value="MRS_PROGRAM_UNKNOWN"/&gt;
 *     &lt;enumeration value="MRS_UNKNOWN"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_ERROR"/&gt;
 *     &lt;enumeration value="MRS_LOW_MEM"/&gt;
 *     &lt;enumeration value="MRS_NO_NEW_DATA"/&gt;
 *     &lt;enumeration value="MRS_FAILURE"/&gt;
 *     &lt;enumeration value="MRS_CMD_WRONG_VERSION"/&gt;
 *     &lt;enumeration value="MRS_CMD_UNKNOWN"/&gt;
 *     &lt;enumeration value="MRS_EXEC_PROC_ERROR"/&gt;
 *     &lt;enumeration value="MRS_READ_TABLE_ERROR"/&gt;
 *     &lt;enumeration value="MRS_WRITE_TABLE_ERROR"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_ERROR_SEQ"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_ASSOC_ERROR"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_VERIFY_ERROR"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_C1218_INSUFF_CLR"/&gt;
 *     &lt;enumeration value="GMI_MRS_SUCCESS"/&gt;
 *     &lt;enumeration value="GMI_MRS_CFG_MISMATCH"/&gt;
 *     &lt;enumeration value="GMI_MRS_PROGRAM_SEAL_MISMATCH"/&gt;
 *     &lt;enumeration value="GMI_MRS_NO_ROUTE"/&gt;
 *     &lt;enumeration value="GMI_MRS_NO_RESOURCES"/&gt;
 *     &lt;enumeration value="GMI_MRS_TIMEOUT"/&gt;
 *     &lt;enumeration value="GMI_MRS_PARTIAL"/&gt;
 *     &lt;enumeration value="GMI_MRS_BLK_SHIFT"/&gt;
 *     &lt;enumeration value="GMI_MRS_SNAP_CHANGED"/&gt;
 *     &lt;enumeration value="GMI_MRS_INTERNAL"/&gt;
 *     &lt;enumeration value="GMI_MRS_PARAM_OUT_OF_BOUNDS"/&gt;
 *     &lt;enumeration value="GMI_MRS_PROGRAM_UNKNOWN"/&gt;
 *     &lt;enumeration value="GMI_MRS_UNKNOWN"/&gt;
 *     &lt;enumeration value="GMI_MRS_LOW_MEM"/&gt;
 *     &lt;enumeration value="GMI_METERING_NOT_CONFIGURED"/&gt;
 *     &lt;enumeration value="GMI_MRS_NO_NEW_DATA"/&gt;
 *     &lt;enumeration value="GMI_MRS_FAILURE"/&gt;
 *     &lt;enumeration value="GMI_MRS_RSM_CMD_UNSUPPORTED"/&gt;
 *     &lt;enumeration value="GMI_MRS_RSM_BAD_STATE"/&gt;
 *     &lt;enumeration value="GMI_MRS_RSM_SUCCESS_PENDING"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_ASSOC_TIMEOUT"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_NO_CERT"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_FUTURE_INCEPTION"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_MISSING_BLOB"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_NO_TIME"/&gt;
 *     &lt;enumeration value="MRS_CMD_BUILD_FAILURE"/&gt;
 *     &lt;enumeration value="MRS_ROUTE_INVALID"/&gt;
 *     &lt;enumeration value="MRS_AP_ROUTE_INVALID"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_NO_PRIVILEGE"/&gt;
 *     &lt;enumeration value="MRS_NO_METER_PROGRAM"/&gt;
 *     &lt;enumeration value="MRS_PROCESSING_NODE_NOT_FOUND"/&gt;
 *     &lt;enumeration value="MRS_DNS_TIMEOUT"/&gt;
 *     &lt;enumeration value="MRS_TASKPOOL_SATURATION"/&gt;
 *     &lt;enumeration value="MRS_JOB_EXPIRATION"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_RATE_LIMIT_EXCEED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TaskStatusTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum TaskStatusTypeEnum {

    MRS_SUCCESS("MRS_SUCCESS"),
    MRS_CFG_MISMATCH("MRS_CFG_MISMATCH"),
    MRS_PROGRAM_SEAL_MISMATCH("MRS_PROGRAM_SEAL_MISMATCH"),
    MRS_NO_ROUTE("MRS_NO_ROUTE"),
    MRS_NO_RESOURCES("MRS_NO_RESOURCES"),
    MRS_TIMEOUT("MRS_TIMEOUT"),
    MRS_PARTIAL("MRS_PARTIAL"),
    MRS_BLK_SHIFT("MRS_BLK_SHIFT"),
    MRS_SNAP_CHANGED("MRS_SNAP_CHANGED"),
    MRS_INTERNAL("MRS_INTERNAL"),
    MRS_PARAM_OUT_OF_BOUNDS("MRS_PARAM_OUT_OF_BOUNDS"),
    MRS_PROGRAM_UNKNOWN("MRS_PROGRAM_UNKNOWN"),
    MRS_UNKNOWN("MRS_UNKNOWN"),
    MRS_SECURITY_ERROR("MRS_SECURITY_ERROR"),
    MRS_LOW_MEM("MRS_LOW_MEM"),
    MRS_NO_NEW_DATA("MRS_NO_NEW_DATA"),
    MRS_FAILURE("MRS_FAILURE"),
    MRS_CMD_WRONG_VERSION("MRS_CMD_WRONG_VERSION"),
    MRS_CMD_UNKNOWN("MRS_CMD_UNKNOWN"),
    MRS_EXEC_PROC_ERROR("MRS_EXEC_PROC_ERROR"),
    MRS_READ_TABLE_ERROR("MRS_READ_TABLE_ERROR"),
    MRS_WRITE_TABLE_ERROR("MRS_WRITE_TABLE_ERROR"),
    MRS_SECURITY_ERROR_SEQ("MRS_SECURITY_ERROR_SEQ"),
    MRS_SECURITY_ASSOC_ERROR("MRS_SECURITY_ASSOC_ERROR"),
    MRS_SECURITY_VERIFY_ERROR("MRS_SECURITY_VERIFY_ERROR"),
    @XmlEnumValue("MRS_SECURITY_C1218_INSUFF_CLR")
    MRS_SECURITY_C_1218_INSUFF_CLR("MRS_SECURITY_C1218_INSUFF_CLR"),
    GMI_MRS_SUCCESS("GMI_MRS_SUCCESS"),
    GMI_MRS_CFG_MISMATCH("GMI_MRS_CFG_MISMATCH"),
    GMI_MRS_PROGRAM_SEAL_MISMATCH("GMI_MRS_PROGRAM_SEAL_MISMATCH"),
    GMI_MRS_NO_ROUTE("GMI_MRS_NO_ROUTE"),
    GMI_MRS_NO_RESOURCES("GMI_MRS_NO_RESOURCES"),
    GMI_MRS_TIMEOUT("GMI_MRS_TIMEOUT"),
    GMI_MRS_PARTIAL("GMI_MRS_PARTIAL"),
    GMI_MRS_BLK_SHIFT("GMI_MRS_BLK_SHIFT"),
    GMI_MRS_SNAP_CHANGED("GMI_MRS_SNAP_CHANGED"),
    GMI_MRS_INTERNAL("GMI_MRS_INTERNAL"),
    GMI_MRS_PARAM_OUT_OF_BOUNDS("GMI_MRS_PARAM_OUT_OF_BOUNDS"),
    GMI_MRS_PROGRAM_UNKNOWN("GMI_MRS_PROGRAM_UNKNOWN"),
    GMI_MRS_UNKNOWN("GMI_MRS_UNKNOWN"),
    GMI_MRS_LOW_MEM("GMI_MRS_LOW_MEM"),
    GMI_METERING_NOT_CONFIGURED("GMI_METERING_NOT_CONFIGURED"),
    GMI_MRS_NO_NEW_DATA("GMI_MRS_NO_NEW_DATA"),
    GMI_MRS_FAILURE("GMI_MRS_FAILURE"),
    GMI_MRS_RSM_CMD_UNSUPPORTED("GMI_MRS_RSM_CMD_UNSUPPORTED"),
    GMI_MRS_RSM_BAD_STATE("GMI_MRS_RSM_BAD_STATE"),
    GMI_MRS_RSM_SUCCESS_PENDING("GMI_MRS_RSM_SUCCESS_PENDING"),
    MRS_SECURITY_ASSOC_TIMEOUT("MRS_SECURITY_ASSOC_TIMEOUT"),
    MRS_SECURITY_NO_CERT("MRS_SECURITY_NO_CERT"),
    MRS_SECURITY_FUTURE_INCEPTION("MRS_SECURITY_FUTURE_INCEPTION"),
    MRS_SECURITY_MISSING_BLOB("MRS_SECURITY_MISSING_BLOB"),
    MRS_SECURITY_NO_TIME("MRS_SECURITY_NO_TIME"),
    MRS_CMD_BUILD_FAILURE("MRS_CMD_BUILD_FAILURE"),
    MRS_ROUTE_INVALID("MRS_ROUTE_INVALID"),
    MRS_AP_ROUTE_INVALID("MRS_AP_ROUTE_INVALID"),
    MRS_SECURITY_NO_PRIVILEGE("MRS_SECURITY_NO_PRIVILEGE"),
    MRS_NO_METER_PROGRAM("MRS_NO_METER_PROGRAM"),
    MRS_PROCESSING_NODE_NOT_FOUND("MRS_PROCESSING_NODE_NOT_FOUND"),
    MRS_DNS_TIMEOUT("MRS_DNS_TIMEOUT"),
    MRS_TASKPOOL_SATURATION("MRS_TASKPOOL_SATURATION"),
    MRS_JOB_EXPIRATION("MRS_JOB_EXPIRATION"),
    MRS_SECURITY_RATE_LIMIT_EXCEED("MRS_SECURITY_RATE_LIMIT_EXCEED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    TaskStatusTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TaskStatusTypeEnum fromValue(String v) {
        for (TaskStatusTypeEnum c: TaskStatusTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
