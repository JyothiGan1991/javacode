/**
 * 
 */
package com.coned.odsListener.dao;

import java.util.List;

import com.coned.odsListener.model.ODSEvent;

/**
 * @author DATHATHRIA
 *
 */
public interface OdsMessageDao {
	void persistOdsMessage(List<ODSEvent> listOfOdsEvents);
}
