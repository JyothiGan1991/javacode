package com.coned.aoccws.beans;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AoccRequest {	
	private String eventName, subEventName, boro;	
	
	private String eventType;  //TODO - HIMA - Change the eventType to Enum
	
	private int eventId;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "America/New_York")
	private Timestamp eventTime;
	
	private Boolean isGetStatus;
	
	public AoccRequest(){}

	public AoccRequest(String eventName, String boro, String eventType, Timestamp eventTime,
			Boolean isGetStatus) {
		super();
		this.eventName = eventName;
		this.boro = boro;
		this.eventType = eventType;	
		this.eventTime = eventTime != null ? new Timestamp(eventTime.getTime()) : null;	
		this.isGetStatus = isGetStatus;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getBoro() {
		return boro;
	}

	public void setBoro(String boro) {
		this.boro = boro;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public Timestamp getEventTime() {
		return eventTime;
	}

	public void setEventTime(Timestamp eventTime) {
		this.eventTime = eventTime;
	}

	public Boolean getIsGetStatus() {
		return isGetStatus;
	}

	public void setIsGetStatus(Boolean isGetStatus) {
		this.isGetStatus = isGetStatus;
	}

	public String getSubEventName() {
		return subEventName;
	}

	public void setSubEventName(String subEventName) {
		this.subEventName = subEventName;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	@Override
	public String toString() {
		return "AoccRequest [eventName=" + eventName + ", subEventName=" + subEventName + ", boro=" + boro
				+ ", eventType=" + eventType + ", eventId=" + eventId + ", eventTime=" + eventTime + ", isGetStatus="
				+ isGetStatus + "]";
	}	
}
