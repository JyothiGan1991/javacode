package com.coned.amm.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "rp")
@PropertySource("file:${external.config}/amm_config.properties")
public class GlobalProperties {
	private String cdpriority, disconnect, connect, retryCount, sspriority;

	public String getCdpriority() {
		return cdpriority;
	}

	public void setCdpriority(String cdpriority) {
		this.cdpriority = cdpriority;
	}

	public String getDisconnect() {
		return disconnect;
	}

	public void setDisconnect(String disconnect) {
		this.disconnect = disconnect;
	}

	public String getConnect() {
		return connect;
	}

	public void setConnect(String connect) {
		this.connect = connect;
	}

	public String getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}

	public String getSspriority() {
		return sspriority;
	}

	public void setSspriority(String sspriority) {
		this.sspriority = sspriority;
	}

	@Override
	public String toString() {
		return "GlobalProperties [cdpriority=" + cdpriority + ", disconnect=" + disconnect + ", connect=" + connect
				+ ", retryCount=" + retryCount + ", sspriority=" + sspriority + "]";
	}

}
