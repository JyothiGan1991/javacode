
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseExportDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseExportDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="DeviceGroupID" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="DeviceSearchKey" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded"/&gt;
 *         &lt;/choice&gt;
 *         &lt;choice&gt;
 *           &lt;element name="OneTimeExport" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}OneTimeExportType"/&gt;
 *           &lt;element name="RecurringExport" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}RecurringExportType"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseExportDataType", propOrder = {
    "deviceGroupID",
    "deviceMacID",
    "deviceSearchKey",
    "oneTimeExport",
    "recurringExport"
})
@XmlSeeAlso({
    AdvancedMeterReadDataType.class,
    DemandResetFailureDataType.class,
    PreviousSeasonExceptionReportDataType.class,
    FilterableExportDataType.class
})
public class BaseExportDataType {

    @XmlElement(name = "DeviceGroupID", type = Long.class)
    protected List<Long> deviceGroupID;
    @XmlElement(name = "DeviceMacID")
    protected List<String> deviceMacID;
    @XmlElement(name = "DeviceSearchKey", type = Long.class)
    protected List<Long> deviceSearchKey;
    @XmlElement(name = "OneTimeExport")
    protected OneTimeExportType oneTimeExport;
    @XmlElement(name = "RecurringExport")
    protected RecurringExportType recurringExport;

    /**
     * Gets the value of the deviceGroupID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceGroupID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceGroupID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceGroupID() {
        if (deviceGroupID == null) {
            deviceGroupID = new ArrayList<Long>();
        }
        return this.deviceGroupID;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the deviceSearchKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceSearchKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceSearchKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceSearchKey() {
        if (deviceSearchKey == null) {
            deviceSearchKey = new ArrayList<Long>();
        }
        return this.deviceSearchKey;
    }

    /**
     * Gets the value of the oneTimeExport property.
     * 
     * @return
     *     possible object is
     *     {@link OneTimeExportType }
     *     
     */
    public OneTimeExportType getOneTimeExport() {
        return oneTimeExport;
    }

    /**
     * Sets the value of the oneTimeExport property.
     * 
     * @param value
     *     allowed object is
     *     {@link OneTimeExportType }
     *     
     */
    public void setOneTimeExport(OneTimeExportType value) {
        this.oneTimeExport = value;
    }

    /**
     * Gets the value of the recurringExport property.
     * 
     * @return
     *     possible object is
     *     {@link RecurringExportType }
     *     
     */
    public RecurringExportType getRecurringExport() {
        return recurringExport;
    }

    /**
     * Sets the value of the recurringExport property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecurringExportType }
     *     
     */
    public void setRecurringExport(RecurringExportType value) {
        this.recurringExport = value;
    }

}
