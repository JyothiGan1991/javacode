
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArbitraryCommandSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ArbitraryCommandSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="GatewaySerialNumber"/&gt;
 *     &lt;enumeration value="GatewayName"/&gt;
 *     &lt;enumeration value="GatewayCollectedTimestamp"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="JobCreator"/&gt;
 *     &lt;enumeration value="JobExecutionTime"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ArbitraryCommandSortColumnEnumeration")
@XmlEnum
public enum ArbitraryCommandSortColumnEnumeration {

    @XmlEnumValue("GatewaySerialNumber")
    GATEWAY_SERIAL_NUMBER("GatewaySerialNumber"),
    @XmlEnumValue("GatewayName")
    GATEWAY_NAME("GatewayName"),
    @XmlEnumValue("GatewayCollectedTimestamp")
    GATEWAY_COLLECTED_TIMESTAMP("GatewayCollectedTimestamp"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("JobCreator")
    JOB_CREATOR("JobCreator"),
    @XmlEnumValue("JobExecutionTime")
    JOB_EXECUTION_TIME("JobExecutionTime");
    private final String value;

    ArbitraryCommandSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ArbitraryCommandSortColumnEnumeration fromValue(String v) {
        for (ArbitraryCommandSortColumnEnumeration c: ArbitraryCommandSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
