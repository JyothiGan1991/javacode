# ORU NRG REST Wrapper (POE + Nucon)

Spring Boot 2.7 / **Java 8** WAR wrapping POE and Nucon SOAP services under a **common** path:

```
/api/v1/nrg/**
```

SOAP client sources are under `src/main/java/com/oru/soap/**` (Eclipse-friendly, no CXF codegen at import time).

## Build

```bash
mvn clean package
```

- `target/oru-rest-wrapper.war` — Tomcat deployable
- `target/oru-rest-wrapper-exec.war` — optional standalone

## Run locally

```bash
mvn spring-boot:run
```

Default port: **9090**

## Swagger

| Resource | URL (local) |
|----------|-------------|
| **Swagger UI** | http://localhost:9090/swagger-ui.html |
| **OpenAPI JSON** | http://localhost:9090/v3/api-docs |
| **OpenAPI YAML** | http://localhost:9090/v3/api-docs.yaml |

Swagger UI and `/v3/api-docs` do **not** require a Bearer token.

In Swagger UI: click **Authorize**, enter the token value (without the word `Bearer`), then try endpoints.

### After Tomcat deploy

If WAR context is `/oru-rest-wrapper`:

- UI: `http://localhost:8080/oru-rest-wrapper/swagger-ui.html`
- JSON: `http://localhost:8080/oru-rest-wrapper/v3/api-docs`

## Authentication

All `/api/v1/nrg/**` endpoints require:

```http
Authorization: Bearer <token>
```

```yaml
api:
  auth:
    enabled: true
    token: change-me-oru-secret-token
```

## API endpoints (all under `/api/v1/nrg`)

### POE-backed

| Method | Path |
|--------|------|
| POST/GET | `/api/v1/nrg/is-gas-main` |
| POST/GET | `/api/v1/nrg/verify-pole` |
| POST/GET | `/api/v1/nrg/incident-count` |

### Nucon-backed

| Method | Path |
|--------|------|
| POST/GET | `/api/v1/nrg/electric-info/by-account` |
| POST/GET | `/api/v1/nrg/electric-info/by-premise` |
| POST/GET | `/api/v1/nrg/electric-info/by-xy` |
| POST | `/api/v1/nrg/send-to-nrg` |
| POST | `/api/v1/nrg/locate-in-nrg-viewer` |

## Example

```bash
TOKEN=change-me-oru-secret-token

curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:9090/api/v1/nrg/verify-pole?x=100&y=200"

curl -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"account":"ACC123"}' \
  http://localhost:9090/api/v1/nrg/electric-info/by-account
```

## Eclipse

1. Import → Maven → Existing Maven Projects
2. Java 8+ JRE
3. Maven → Update Project
4. Project → Clean

## SOAP config

```yaml
poe:
  soap:
    endpoint-url: http://localhost:8080/poeWebServices/services/POEWebServicesPort
nucon:
  soap:
    endpoint-url: http://localhost:8080/nuconWS/services/NuconWSPort
```
