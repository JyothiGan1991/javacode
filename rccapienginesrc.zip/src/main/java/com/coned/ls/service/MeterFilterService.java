package com.coned.ls.service;

import java.util.List;

import com.coned.ls.domain.FilterAttribute;

/**
 * 
 * Interface for Meter Filter Service class.
 *
 */
public interface MeterFilterService {
	
	public List<FilterAttribute> initMeterFilter(final String borough, final String eventName, final String filterAttribute, final int startIndex, final int fetchNext);
	
}
