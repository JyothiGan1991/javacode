package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coned.model.FinalizeEventListDetails;
import com.coned.model.FinalizeSubEventListDetails;

@Repository
public interface FinalizeSubEventListDetailsRepository extends JpaRepository<FinalizeSubEventListDetails, Long> {
}