package com.coned.um.controller;

import java.io.IOException;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

public class CustCallbackHandler implements CallbackHandler{

	private String userid;
	private String password;
	private String url;
	
	public CustCallbackHandler(String userid, String password, String url){
		this.userid = userid;
		this.password = password;
		this.url = url;
	}
	
	@Override
	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
		for (int i = 0; i < callbacks.length; i++) {
			if (callbacks[i] instanceof TextOutputCallback){
				TextOutputCallback toc = (TextOutputCallback)callbacks[i];
			} else if (callbacks[i] instanceof NameCallback) {
				NameCallback nc = (NameCallback)callbacks[i];
				nc.setName(userid);
			} else if (callbacks[i] instanceof PasswordCallback) {
				PasswordCallback pc = (PasswordCallback)callbacks[i];
				pc.setPassword(password.toCharArray());
			} else {}
		}
	}
}

/*
 * public class CustCallbackHandler implements CallbackHandler { private String
 * user = null; private String password = null; public
 * CustCallbackHandler(String user, String password) { this.user = user;
 * this.password = password; }
 * 
 * @Override public void handle(Callback[] cba) throws IOException,
 * UnsupportedCallbackException { int counter = 0; while(counter < cba.length) {
 * if(cba[counter] instanceof NameCallback) { NameCallback ncb =
 * (NameCallback)cba[counter++]; ncb.setName(user); } else if(cba[counter]
 * instanceof PasswordCallback) { PasswordCallback pcb =
 * (PasswordCallback)cba[counter++]; pcb.setPassword(password.toCharArray()); }
 * }
 * 
 * }
 * 
 * }
 */
