package com.coned.ls.domain;

public class StarDBValidation {

	private Long accountNumber;
	private Long meterNumber;
	private String custmerZipCode;
	private String critical;
	private String lsa;
	private String borough;
	private String eventName;
	private Long meterEventLoadId;
	
	
	
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	@Override
	public String toString() {
		return "StarDBValidation [accountNumber=" + accountNumber + ", meterNumber=" + meterNumber + ", custmerZipCode="
				+ custmerZipCode + ", critical=" + critical + ", lsa=" + lsa + ", borough=" + borough + "]";
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getMeterNumber() {
		return meterNumber;
	}
	public void setMeterNumber(Long meterNumber) {
		this.meterNumber = meterNumber;
	}
	public String getCustmerZipCode() {
		return custmerZipCode;
	}
	public void setCustmerZipCode(String custmerZipCode) {
		this.custmerZipCode = custmerZipCode;
	}
	public String getCritical() {
		return critical;
	}
	public void setCritical(String critical) {
		this.critical = critical;
	}
	public String getLsa() {
		return lsa;
	}
	public void setLsa(String lsa) {
		this.lsa = lsa;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public Long getMeterEventLoadId() {
		return meterEventLoadId;
	}
	public void setMeterEventLoadId(Long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}
	
	
}
