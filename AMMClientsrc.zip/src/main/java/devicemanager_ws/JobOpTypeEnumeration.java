
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JobOpTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="JobOpTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_CRON_JOB"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_METER_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_EXPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_IMPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_REPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_PING"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_NCC_ALARM_CLEAR"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEV_PROG_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_REMOTE_PROVISION"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_ARB_METER_COMMAND"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEVICE_INIT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEVICE_EVENT_LOG"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_BRIDGE_CONFIGURE"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"/&gt;
 *     &lt;enumeration value="JOB_OP_LP_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_SECLOG_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_CONS_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_RST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_RST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_DL"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_REG"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_EL"/&gt;
 *     &lt;enumeration value="JOB_OP_IMU_PROXY_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NEW_DATA_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_METER_EL_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_ERR_HIST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NIC_NEW_DATA_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_NET"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_NET"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ADVANCED_METER"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_EVENT"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DEVICE"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ARB_METER_CMD"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_POWER_QUALITY"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DMD_RESET_FAILS"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_PREVIOUS_SEASON"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ARM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GET_STATUS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_RESET_TS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_PP_BALNCE"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_DLP_PROPS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DEACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_ESCC_PROP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GROUP_CONFIG"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_BROADCAST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROV_SET_IGNORE_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CLEAR_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DS"/&gt;
 *     &lt;enumeration value="JOB_OP_BRDG_NTFCTN_LINK_STATE"/&gt;
 *     &lt;enumeration value="JOB_OP_ZB_METER_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_ITRON_IMU_PROXY_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_GENERIC_IMU_PROXY_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEMAND_RESET"/&gt;
 *     &lt;enumeration value="JOB_OP_REG_PREV_SESN_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_GENERIC_METER_READ"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "JobOpTypeEnumeration")
@XmlEnum
public enum JobOpTypeEnumeration {

    JOB_OP_TYPE_CRON_JOB("JOB_OP_TYPE_CRON_JOB"),
    JOB_OP_TYPE_METER_READ("JOB_OP_TYPE_METER_READ"),
    JOB_OP_TYPE_EXPORT("JOB_OP_TYPE_EXPORT"),
    JOB_OP_TYPE_IMPORT("JOB_OP_TYPE_IMPORT"),
    JOB_OP_TYPE_REPORT("JOB_OP_TYPE_REPORT"),
    JOB_OP_TYPE_PING("JOB_OP_TYPE_PING"),
    JOB_OP_TYPE_NCC_ALARM_CLEAR("JOB_OP_TYPE_NCC_ALARM_CLEAR"),
    JOB_OP_TYPE_DEV_PROG_READ("JOB_OP_TYPE_DEV_PROG_READ"),
    JOB_OP_TYPE_REMOTE_PROVISION("JOB_OP_TYPE_REMOTE_PROVISION"),
    JOB_OP_TYPE_ARB_METER_COMMAND("JOB_OP_TYPE_ARB_METER_COMMAND"),
    JOB_OP_TYPE_DEVICE_INIT("JOB_OP_TYPE_DEVICE_INIT"),
    JOB_OP_TYPE_DEVICE_EVENT_LOG("JOB_OP_TYPE_DEVICE_EVENT_LOG"),
    JOB_OP_TYPE_BRIDGE_CONFIGURE("JOB_OP_TYPE_BRIDGE_CONFIGURE"),
    JOB_OP_TYPE_TRGGR_BRDG_NTFCTN("JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"),
    JOB_OP_LP_READ("JOB_OP_LP_READ"),
    JOB_OP_REGISTER_CURR_READ("JOB_OP_REGISTER_CURR_READ"),
    JOB_OP_SECLOG_READ("JOB_OP_SECLOG_READ"),
    JOB_OP_CONS_READ("JOB_OP_CONS_READ"),
    JOB_OP_REGISTER_CURR_RST_READ("JOB_OP_REGISTER_CURR_RST_READ"),
    JOB_OP_REGISTER_SELF_READ("JOB_OP_REGISTER_SELF_READ"),
    JOB_OP_REGISTER_SELF_RST_READ("JOB_OP_REGISTER_SELF_RST_READ"),
    JOB_OP_NCC_DL("JOB_OP_NCC_DL"),
    JOB_OP_NCC_REG("JOB_OP_NCC_REG"),
    JOB_OP_NCC_EL("JOB_OP_NCC_EL"),
    JOB_OP_IMU_PROXY_READ("JOB_OP_IMU_PROXY_READ"),
    JOB_OP_NEW_DATA_READ("JOB_OP_NEW_DATA_READ"),
    JOB_OP_METER_EL_READ("JOB_OP_METER_EL_READ"),
    JOB_OP_ERR_HIST_READ("JOB_OP_ERR_HIST_READ"),
    JOB_OP_NIC_NEW_DATA_READ("JOB_OP_NIC_NEW_DATA_READ"),
    JOB_OP_PING_GW_APP("JOB_OP_PING_GW_APP"),
    JOB_OP_PING_GW_NET("JOB_OP_PING_GW_NET"),
    JOB_OP_PING_DEV_APP("JOB_OP_PING_DEV_APP"),
    JOB_OP_PING_DEV_NET("JOB_OP_PING_DEV_NET"),
    JOB_OP_EXPORT_ADVANCED_METER("JOB_OP_EXPORT_ADVANCED_METER"),
    JOB_OP_EXPORT_EVENT("JOB_OP_EXPORT_EVENT"),
    JOB_OP_EXPORT_DEVICE("JOB_OP_EXPORT_DEVICE"),
    JOB_OP_EXPORT_ARB_METER_CMD("JOB_OP_EXPORT_ARB_METER_CMD"),
    JOB_OP_EXPORT_POWER_QUALITY("JOB_OP_EXPORT_POWER_QUALITY"),
    JOB_OP_EXPORT_DMD_RESET_FAILS("JOB_OP_EXPORT_DMD_RESET_FAILS"),
    JOB_OP_EXPORT_PREVIOUS_SEASON("JOB_OP_EXPORT_PREVIOUS_SEASON"),
    JOB_OP_PROVISION_ARM("JOB_OP_PROVISION_ARM"),
    JOB_OP_PROVISION_CONNECT("JOB_OP_PROVISION_CONNECT"),
    JOB_OP_PROVISION_DISCONNECT("JOB_OP_PROVISION_DISCONNECT"),
    JOB_OP_PROVISION_GET_STATUS("JOB_OP_PROVISION_GET_STATUS"),
    JOB_OP_PROVISION_RESET_TS("JOB_OP_PROVISION_RESET_TS"),
    JOB_OP_PROVISION_ENABLE_PPM("JOB_OP_PROVISION_ENABLE_PPM"),
    JOB_OP_PROVISION_DISABLE_PPM("JOB_OP_PROVISION_DISABLE_PPM"),
    JOB_OP_PROVISION_SET_PP_BALNCE("JOB_OP_PROVISION_SET_PP_BALNCE"),
    JOB_OP_PROVISION_ENABLE_DLP("JOB_OP_PROVISION_ENABLE_DLP"),
    JOB_OP_PROVISION_DISABLE_DLP("JOB_OP_PROVISION_DISABLE_DLP"),
    JOB_OP_PROVISION_SET_DLP_PROPS("JOB_OP_PROVISION_SET_DLP_PROPS"),
    JOB_OP_PROVISION_ENABLE_LOCK("JOB_OP_PROVISION_ENABLE_LOCK"),
    JOB_OP_PROVISION_DISABLE_LOCK("JOB_OP_PROVISION_DISABLE_LOCK"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L1")
    JOB_OP_PROVISION_CONNECT_L_1("JOB_OP_PROVISION_CONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L1")
    JOB_OP_PROVISION_DISCONNECT_L_1("JOB_OP_PROVISION_DISCONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L2")
    JOB_OP_PROVISION_CONNECT_L_2("JOB_OP_PROVISION_CONNECT_L2"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L2")
    JOB_OP_PROVISION_DISCONNECT_L_2("JOB_OP_PROVISION_DISCONNECT_L2"),
    JOB_OP_PROVISION_ACT_ESCC("JOB_OP_PROVISION_ACT_ESCC"),
    JOB_OP_PROVISION_DEACT_ESCC("JOB_OP_PROVISION_DEACT_ESCC"),
    JOB_OP_PROVISION_ENABLE_ESCC("JOB_OP_PROVISION_ENABLE_ESCC"),
    JOB_OP_PROVISION_DISABLE_ESCC("JOB_OP_PROVISION_DISABLE_ESCC"),
    JOB_OP_PROVISION_SET_ESCC_PROP("JOB_OP_PROVISION_SET_ESCC_PROP"),
    JOB_OP_PROVISION_ENABLE_BOOST("JOB_OP_PROVISION_ENABLE_BOOST"),
    JOB_OP_PROVISION_DISABLE_BOOST("JOB_OP_PROVISION_DISABLE_BOOST"),
    JOB_OP_PROVISION_GROUP_CONFIG("JOB_OP_PROVISION_GROUP_CONFIG"),
    JOB_OP_PROVISION_BROADCAST("JOB_OP_PROVISION_BROADCAST"),
    JOB_OP_PROV_SET_IGNORE_TAMPER("JOB_OP_PROV_SET_IGNORE_TAMPER"),
    JOB_OP_PROVISION_CLEAR_TAMPER("JOB_OP_PROVISION_CLEAR_TAMPER"),
    JOB_OP_PROVISION_ENABLE_DS("JOB_OP_PROVISION_ENABLE_DS"),
    JOB_OP_PROVISION_DISABLE_DS("JOB_OP_PROVISION_DISABLE_DS"),
    JOB_OP_BRDG_NTFCTN_LINK_STATE("JOB_OP_BRDG_NTFCTN_LINK_STATE"),
    JOB_OP_ZB_METER_READ("JOB_OP_ZB_METER_READ"),
    JOB_OP_ITRON_IMU_PROXY_READ("JOB_OP_ITRON_IMU_PROXY_READ"),
    JOB_OP_GENERIC_IMU_PROXY_READ("JOB_OP_GENERIC_IMU_PROXY_READ"),
    JOB_OP_TYPE_DEMAND_RESET("JOB_OP_TYPE_DEMAND_RESET"),
    JOB_OP_REG_PREV_SESN_READ("JOB_OP_REG_PREV_SESN_READ"),
    JOB_OP_GENERIC_METER_READ("JOB_OP_GENERIC_METER_READ");
    private final String value;

    JobOpTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JobOpTypeEnumeration fromValue(String v) {
        for (JobOpTypeEnumeration c: JobOpTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
