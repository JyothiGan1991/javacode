package com.coned.ls.exception;


import org.springframework.http.HttpStatus;

public class HttpClientException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	private HttpStatus httpStatus;
	
	public HttpClientException() {
		super();
	}
	
	public HttpClientException(String message) {
		super(message);
	}
	
	public HttpClientException(String message, Throwable cause) {
		super(message,cause);
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
