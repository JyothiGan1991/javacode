package com.coned.aoccws.controller;

import jakarta.validation.Valid;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coned.aoccws.beans.AoccRequest;
import com.coned.aoccws.error.AMMException;
import com.coned.aoccws.service.RemoteConnectDisconnectServ;
import com.coned.aoccws.validator.AoccRequestValidator;

@RestController
public class AOCCController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	protected RemoteConnectDisconnectServ ammService;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(new AoccRequestValidator());
	}

	/*Request to register the connect/disconnect job. */
	@PostMapping("/register/remotejob")
	public ResponseEntity<Object> registerRemoteJob(@Valid @RequestBody AoccRequest req) throws AMMException {
		logger.info("Received request " + req);
		return new ResponseEntity<Object>(ammService.saveRequest(req), HttpStatus.CREATED);
	}

	/*@RequestMapping(value = "/register/getstatus", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<Object> findDeviceStatus(@RequestBody String request) throws AMMException {
		ObjectMapper mapper = new ObjectMapper();
		AoccRequest req = null;
		try {
			req = mapper.readValue(request, AoccRequest.class);
		} catch (IOException e) {
			System.out.println(e);
			// logger.error("" + e);
			throw new AMMException("Invalid Data format; ");
		}
		// logger.info(req);

		return new ResponseEntity<Object>(ammService.saveRequest(req), HttpStatus.OK);
	}*/

	// @ApiOperation(value = "Get the version of the jar")
	/*@RequestMapping(value = "/version", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> getVersion() throws AuthException {
		return new ResponseEntity<Object>(ammService.getVersion(), HttpStatus.OK);
	}*/

}
