
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PriorityEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PriorityEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_PRIORITY_LOW"/>
 *     &lt;enumeration value="JOB_PRIORITY_NORMAL"/>
 *     &lt;enumeration value="JOB_PRIORITY_HIGH"/>
 *     &lt;enumeration value="JOB_PRIORITY_CRITICAL"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PriorityEnumeration")
@XmlEnum
public enum PriorityEnumeration {

    JOB_PRIORITY_LOW("JOB_PRIORITY_LOW"),
    JOB_PRIORITY_NORMAL("JOB_PRIORITY_NORMAL"),
    JOB_PRIORITY_HIGH("JOB_PRIORITY_HIGH"),
    JOB_PRIORITY_CRITICAL("JOB_PRIORITY_CRITICAL"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    PriorityEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PriorityEnumeration fromValue(String v) {
        for (PriorityEnumeration c: PriorityEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
