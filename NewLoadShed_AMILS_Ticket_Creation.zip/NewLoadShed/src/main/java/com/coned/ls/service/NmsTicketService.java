package com.coned.ls.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.coned.ls.domain.Meter;

/**
 * Service responsible for creating AMI Load Shed outage tickets in NMS.
 * All integration details (URL, payload field names, clue code, work queue, etc.)
 * are externalized so they can be updated once the final NMS contract is known.
 */
@Service
public class NmsTicketService {

	private static final Logger logger = LoggerFactory.getLogger(NmsTicketService.class);

	private final RestTemplate restTemplate = new RestTemplate();

	/** In-memory cache of the event start timestamp per REQUEST_IDX (batch). */
	private final ConcurrentHashMap<BigDecimal, Instant> batchStartTimes = new ConcurrentHashMap<>();


	// ---------- Feature switches ----------
	@Value("${nms.ticket.enabled:true}")
	private boolean ticketCreationEnabled;

	/**
	 * When true, create the NMS ticket immediately after the disconnect command
	 * is successfully submitted to HES (jobId received).  
	 * When false, ticket creation is skipped in this application (intended for a
	 * future process that runs after AMI job status becomes successful).
	 */
	@Value("${nms.ticket.create.on.command.sent:true}")
	private boolean createOnCommandSent;

	// ---------- NMS endpoint ----------
	@Value("${nms.ticket.create.url:http://nms-dummy.conedison.net:8080/api/outage/create}")
	private String createTicketUrl;

	@Value("${nms.ticket.create.http.method:POST}")
	private String httpMethod;

	@Value("${nms.ticket.auth.header.name:}")
	private String authHeaderName;

	@Value("${nms.ticket.auth.header.value:}")
	private String authHeaderValue;

	// ---------- Configurable payload field names / values ----------
	@Value("${nms.ticket.field.clueCode:clueCode}")
	private String fieldClueCode;

	@Value("${nms.ticket.value.clueCode:AMILS}")
	private String valueClueCode;

	@Value("${nms.ticket.field.workQueue:workQueue}")
	private String fieldWorkQueue;

	@Value("${nms.ticket.value.workQueue:AMI Load Shed}")
	private String valueWorkQueue;

	@Value("${nms.ticket.field.remarks:remarks}")
	private String fieldRemarks;

	@Value("${nms.ticket.remarks.template:Customer affected by AMI Load Shed event {eventName}}")
	private String remarksTemplate;

	@Value("${nms.ticket.field.startTime:startTime}")
	private String fieldStartTime;

	@Value("${nms.ticket.field.meterNumber:meterNumber}")
	private String fieldMeterNumber;

	@Value("${nms.ticket.field.eventName:eventName}")
	private String fieldEventName;

	@Value("${nms.ticket.field.eventId:eventId}")
	private String fieldEventId;

	@Value("${nms.ticket.field.macAddress:macAddress}")
	private String fieldMacAddress;

	@Value("${nms.ticket.field.requestId:requestId}")
	private String fieldRequestId;

	/** Optional extra static fields (comma-separated key=value pairs). */
	@Value("${nms.ticket.extra.fields:}")
	private String extraFields;

	/**
	 * Creates an NMS outage ticket for the given meter after a successful
	 * disconnect command submission (when configured to do so).
	 * Failures are logged but never propagated so that the core load-shed
	 * flow is not impacted.
	 */
	public void createAmilsTicketIfRequired(Meter meter, long jobId) {
		if (!ticketCreationEnabled) {
			logger.debug("NMS ticket creation is disabled (nms.ticket.enabled=false)");
			return;
		}
		if (!createOnCommandSent) {
			logger.debug("NMS ticket creation on command-sent is disabled (nms.ticket.create.on.command.sent=false)");
			return;
		}

		try {
			Instant startTime = resolveBatchStartTime(meter.getRequestId());
			Map<String, Object> payload = buildPayload(meter, startTime, jobId);

			logger.info("Creating AMILS NMS ticket for meter [{}], requestId [{}], eventName [{}]",
					meter.getMeterNumber(), meter.getRequestId(), meter.getEventName());

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authHeaderName != null && !authHeaderName.trim().isEmpty()
					&& authHeaderValue != null && !authHeaderValue.trim().isEmpty()) {
				headers.set(authHeaderName, authHeaderValue);
			}

			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, headers);

			ResponseEntity<String> response;
			if ("PUT".equalsIgnoreCase(httpMethod)) {
				response = restTemplate.exchange(createTicketUrl, HttpMethod.PUT, entity, String.class);
			} else {
				response = restTemplate.exchange(createTicketUrl, HttpMethod.POST, entity, String.class);
			}

			logger.info("NMS ticket creation response for meter [{}]: status={}, body={}",
					meter.getMeterNumber(), response.getStatusCodeValue(), response.getBody());

		} catch (Exception e) {
			// Fail-soft: never break the existing disconnect flow
			logger.error("Failed to create NMS AMILS ticket for meter [" + meter.getMeterNumber()
					+ "], requestId [" + meter.getRequestId() + "]. Continuing with load-shed processing.", e);
		}
	}

	/**
	 * Ensures all tickets belonging to the same REQUEST_IDX share the same
	 * OMS event start time (the instant the first disconnect command of the
	 * batch was sent).
	 */
	private Instant resolveBatchStartTime(BigDecimal requestId) {
		return batchStartTimes.computeIfAbsent(requestId, k -> Instant.now());
	}

	private Map<String, Object> buildPayload(Meter meter, Instant startTime, long jobId) {
		Map<String, Object> payload = new HashMap<>();

		payload.put(fieldClueCode, valueClueCode);
		payload.put(fieldWorkQueue, valueWorkQueue);

		String remarks = remarksTemplate
				.replace("{eventName}", nullSafe(meter.getEventName()))
				.replace("{meterNumber}", nullSafe(meter.getMeterNumber()))
				.replace("{requestId}", meter.getRequestId() != null ? meter.getRequestId().toPlainString() : "");
		payload.put(fieldRemarks, remarks);

		// ISO-8601 UTC
		String startTimeStr = DateTimeFormatter.ISO_INSTANT.withZone(ZoneOffset.UTC).format(startTime);
		payload.put(fieldStartTime, startTimeStr);

		payload.put(fieldMeterNumber, meter.getMeterNumber());
		payload.put(fieldEventName, meter.getEventName());
		// Use REQUEST_IDX as the Event ID for traceability (configurable field name)
		payload.put(fieldEventId, meter.getRequestId() != null ? meter.getRequestId().toPlainString() : null);
		payload.put(fieldMacAddress, meter.getMacAddress());
		payload.put(fieldRequestId, meter.getRequestId() != null ? meter.getRequestId().toPlainString() : null);

		// Optional extra static fields from configuration (key1=value1,key2=value2)
		if (extraFields != null && !extraFields.trim().isEmpty()) {
			for (String pair : extraFields.split(",")) {
				String[] kv = pair.split("=", 2);
				if (kv.length == 2) {
					payload.put(kv[0].trim(), kv[1].trim());
				}
			}
		}

		// Always include the AMI job id for operational correlation (field name fixed for now)
		payload.put("amiJobId", jobId);

		return payload;
	}

	private String nullSafe(String value) {
		return value == null ? "" : value;
	}

	/**
	 * Clears the in-memory batch start-time cache. Can be called periodically
	 * if the process runs for a very long time and memory pressure is a concern.
	 */
	public void clearBatchStartTimeCache() {
		batchStartTimes.clear();
	}
}
