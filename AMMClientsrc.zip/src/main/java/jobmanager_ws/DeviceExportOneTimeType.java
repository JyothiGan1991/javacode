
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceExportOneTimeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceExportOneTimeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="SearchKey" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *           &lt;element name="CriteriaKey" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *           &lt;element name="DeviceGroupID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceExportOneTimeType", propOrder = {
    "searchKey",
    "criteriaKey",
    "deviceGroupID"
})
public class DeviceExportOneTimeType {

    @XmlElement(name = "SearchKey")
    protected Long searchKey;
    @XmlElement(name = "CriteriaKey")
    protected Long criteriaKey;
    @XmlElement(name = "DeviceGroupID")
    protected Long deviceGroupID;

    /**
     * Gets the value of the searchKey property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSearchKey(Long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the criteriaKey property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCriteriaKey() {
        return criteriaKey;
    }

    /**
     * Sets the value of the criteriaKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCriteriaKey(Long value) {
        this.criteriaKey = value;
    }

    /**
     * Gets the value of the deviceGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDeviceGroupID() {
        return deviceGroupID;
    }

    /**
     * Sets the value of the deviceGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDeviceGroupID(Long value) {
        this.deviceGroupID = value;
    }

}
