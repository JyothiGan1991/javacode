package com.coned.ls.repository;

import java.util.List;

import com.coned.ls.domain.MeterSearch;

import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;

/**
 * 
 * Interface for RCC Disconnect repository class.
 *
 */
public interface MeterEventValidateRepository {

	public MeterValidateResponseMapper getValidateMeter(final String borough, final String eventName, final int startRowIndex,final int batchSize,final String fromDate, final String toDate) throws MeterValidateException,VcapRecordNotFoundException;
	public MeterValidateResponseMapper searchMeters(final MeterSearch meterSearch);

	public boolean verifyNewEventEntryInLS(final String borough, final String eventName);
	
	public boolean pushMeterEventFromVcapToLS(final String borough, final String eventName, final String fromDate, final String toDate, final String adid) throws MeterValidateException,VcapRecordNotFoundException;
	public MeterValidateResponseMapper getValidateMeterList(final String borough, final String eventName, final int startRowIndex, final int batchSize,  final String filterList, final String sortList)throws MeterValidateException;
	
	public MeterValidateResponseMapper isEventLocked(final String borough, final String eventName, final String adid);
	public boolean validateMeterEventWithStar(final String borough, final String eventName);

	public MeterValidateResponseMapper getInValidateMeterList(final String borough, final String eventName, final int startRowIndex, final int batchSize);
	
	public List<String> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName);
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(final String borough, final String eventName, final String adid);
	public MeterValidateResponseMapper isEventFinalized(String borough, final String eventName);
	public void unlockEvents(final String adid);
}
