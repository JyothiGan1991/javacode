
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseIMUTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseIMUTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConfigName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MfgCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PartNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="RevisionNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseIMUTypeConfig", propOrder = {
    "configName",
    "mfgCode",
    "mfgName",
    "partNumber",
    "revisionNumber"
})
@XmlSeeAlso({
    IMUTypeConfig.class
})
public class BaseIMUTypeConfig {

    @XmlElement(name = "ConfigName", required = true)
    protected String configName;
    @XmlElement(name = "MfgCode", required = true)
    protected String mfgCode;
    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "PartNumber", required = true)
    protected String partNumber;
    @XmlElement(name = "RevisionNumber")
    protected String revisionNumber;

    /**
     * Gets the value of the configName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigName() {
        return configName;
    }

    /**
     * Sets the value of the configName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigName(String value) {
        this.configName = value;
    }

    /**
     * Gets the value of the mfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgCode() {
        return mfgCode;
    }

    /**
     * Sets the value of the mfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgCode(String value) {
        this.mfgCode = value;
    }

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the partNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * Sets the value of the partNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartNumber(String value) {
        this.partNumber = value;
    }

    /**
     * Gets the value of the revisionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevisionNumber() {
        return revisionNumber;
    }

    /**
     * Sets the value of the revisionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevisionNumber(String value) {
        this.revisionNumber = value;
    }

}
