
package com.oru.soap.nucon.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for electricInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="electricInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://oss.oru.com/}abstractBusinessObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="circuit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="hgridX" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="hgridY" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="involt" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="KVA1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="KVA2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="KVA3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ky_ba" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ky_prem_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="phase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="phase3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="segment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="service" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="servpoleX" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="servpoleY" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="tranGridX" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="tranGridY" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="transformer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="transtype" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "electricInfo", propOrder = {
    "circuit",
    "code",
    "hgridX",
    "hgridY",
    "involt",
    "kva1",
    "kva2",
    "kva3",
    "kyBa",
    "kyPremNo",
    "phase",
    "phase3",
    "segment",
    "service",
    "servpoleX",
    "servpoleY",
    "tranGridX",
    "tranGridY",
    "transformer",
    "transtype"
})
public class ElectricInfo
    extends AbstractBusinessObject
{

    protected String circuit;
    protected String code;
    protected Integer hgridX;
    protected Integer hgridY;
    protected double involt;
    @XmlElement(name = "KVA1")
    protected String kva1;
    @XmlElement(name = "KVA2")
    protected String kva2;
    @XmlElement(name = "KVA3")
    protected String kva3;
    @XmlElement(name = "ky_ba")
    protected String kyBa;
    @XmlElement(name = "ky_prem_no")
    protected String kyPremNo;
    protected String phase;
    protected String phase3;
    protected String segment;
    protected String service;
    protected Integer servpoleX;
    protected Integer servpoleY;
    protected Integer tranGridX;
    protected Integer tranGridY;
    protected String transformer;
    protected String transtype;

    /**
     * Gets the value of the circuit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCircuit() {
        return circuit;
    }

    /**
     * Sets the value of the circuit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCircuit(String value) {
        this.circuit = value;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the hgridX property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHgridX() {
        return hgridX;
    }

    /**
     * Sets the value of the hgridX property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHgridX(Integer value) {
        this.hgridX = value;
    }

    /**
     * Gets the value of the hgridY property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHgridY() {
        return hgridY;
    }

    /**
     * Sets the value of the hgridY property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHgridY(Integer value) {
        this.hgridY = value;
    }

    /**
     * Gets the value of the involt property.
     * 
     */
    public double getInvolt() {
        return involt;
    }

    /**
     * Sets the value of the involt property.
     * 
     */
    public void setInvolt(double value) {
        this.involt = value;
    }

    /**
     * Gets the value of the kva1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKVA1() {
        return kva1;
    }

    /**
     * Sets the value of the kva1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKVA1(String value) {
        this.kva1 = value;
    }

    /**
     * Gets the value of the kva2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKVA2() {
        return kva2;
    }

    /**
     * Sets the value of the kva2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKVA2(String value) {
        this.kva2 = value;
    }

    /**
     * Gets the value of the kva3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKVA3() {
        return kva3;
    }

    /**
     * Sets the value of the kva3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKVA3(String value) {
        this.kva3 = value;
    }

    /**
     * Gets the value of the kyBa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKyBa() {
        return kyBa;
    }

    /**
     * Sets the value of the kyBa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKyBa(String value) {
        this.kyBa = value;
    }

    /**
     * Gets the value of the kyPremNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKyPremNo() {
        return kyPremNo;
    }

    /**
     * Sets the value of the kyPremNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKyPremNo(String value) {
        this.kyPremNo = value;
    }

    /**
     * Gets the value of the phase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the value of the phase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhase(String value) {
        this.phase = value;
    }

    /**
     * Gets the value of the phase3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhase3() {
        return phase3;
    }

    /**
     * Sets the value of the phase3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhase3(String value) {
        this.phase3 = value;
    }

    /**
     * Gets the value of the segment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegment() {
        return segment;
    }

    /**
     * Sets the value of the segment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegment(String value) {
        this.segment = value;
    }

    /**
     * Gets the value of the service property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getService() {
        return service;
    }

    /**
     * Sets the value of the service property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setService(String value) {
        this.service = value;
    }

    /**
     * Gets the value of the servpoleX property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getServpoleX() {
        return servpoleX;
    }

    /**
     * Sets the value of the servpoleX property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setServpoleX(Integer value) {
        this.servpoleX = value;
    }

    /**
     * Gets the value of the servpoleY property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getServpoleY() {
        return servpoleY;
    }

    /**
     * Sets the value of the servpoleY property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setServpoleY(Integer value) {
        this.servpoleY = value;
    }

    /**
     * Gets the value of the tranGridX property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTranGridX() {
        return tranGridX;
    }

    /**
     * Sets the value of the tranGridX property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTranGridX(Integer value) {
        this.tranGridX = value;
    }

    /**
     * Gets the value of the tranGridY property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTranGridY() {
        return tranGridY;
    }

    /**
     * Sets the value of the tranGridY property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTranGridY(Integer value) {
        this.tranGridY = value;
    }

    /**
     * Gets the value of the transformer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransformer() {
        return transformer;
    }

    /**
     * Sets the value of the transformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransformer(String value) {
        this.transformer = value;
    }

    /**
     * Gets the value of the transtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranstype() {
        return transtype;
    }

    /**
     * Sets the value of the transtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranstype(String value) {
        this.transtype = value;
    }

}
