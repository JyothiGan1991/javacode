package com.oru.poe.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * Main application class.
 * Extends SpringBootServletInitializer so the app can be deployed as a WAR to external Tomcat.
 * Can still be run standalone via main() for local development.
 */
@SpringBootApplication
public class PoeRestWrapperApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(PoeRestWrapperApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(PoeRestWrapperApplication.class, args);
    }
}
