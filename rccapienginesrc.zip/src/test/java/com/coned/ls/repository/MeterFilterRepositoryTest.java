package com.coned.ls.repository;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.FilterAttribute;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.OpenEvent;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { MeterFilterRepository.class })
@AutoConfigureMockMvc

public class MeterFilterRepositoryTest {
	@Autowired
	private WebApplicationContext wac;

	@MockBean
	private MeterFilterRepository meterFilterRepository;

	private OpenEvent openEvent;

	private List<MeterEventLoad> meterEventLoads;

	@InjectMocks
	private JdbcMeterFilterRepository jdbcMeterFilterRepo;

	private MockMvc mockMvc;

	MeterEventFinalize meterEventFinalize;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	protected JdbcTemplate sqlServerJdbcTemplate;

	@Mock
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	protected JdbcTemplate oracleCommonJdbcTemplate;

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcMeterFilterRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		//ReflectionTestUtils.setField(jdbcMeterFilterRepo, "sqlServerJdbcTemplate", sqlServerJdbcTemplate);
		//ReflectionTestUtils.setField(jdbcMeterFilterRepo, "starJdbcTemplate", starJdbcTemplate);
		//ReflectionTestUtils.setField(jdbcMeterFilterRepo, "oracleCommonJdbcTemplate", oracleCommonJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void initMeterFilter(){
		
		List<FilterAttribute> lst = jdbcMeterFilterRepo.initMeterFilter("Test","Test","Test",1,1);
		Assert.assertNotNull(lst);
	}
	
}
