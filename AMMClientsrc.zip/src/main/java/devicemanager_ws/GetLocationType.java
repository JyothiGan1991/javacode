
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetLocationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetLocationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}LocationType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DeviceCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="LocInsertTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocInsertBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocUpdateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocUpdateBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DistNetwork" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DistNetworkType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePoint" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetServicePtType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Contacts" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetDevContactListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetLocationType", propOrder = {
    "deviceCount",
    "locInsertTime",
    "locInsertBy",
    "locUpdateTime",
    "locUpdateBy",
    "distNetwork",
    "servicePoint",
    "contacts"
})
public class GetLocationType
    extends LocationType
{

    @XmlElement(name = "DeviceCount")
    protected Integer deviceCount;
    @XmlElement(name = "LocInsertTime")
    protected String locInsertTime;
    @XmlElement(name = "LocInsertBy")
    protected String locInsertBy;
    @XmlElement(name = "LocUpdateTime")
    protected String locUpdateTime;
    @XmlElement(name = "LocUpdateBy")
    protected String locUpdateBy;
    @XmlElement(name = "DistNetwork")
    protected DistNetworkType distNetwork;
    @XmlElement(name = "ServicePoint")
    protected List<GetServicePtType> servicePoint;
    @XmlElement(name = "Contacts")
    protected GetDevContactListType contacts;

    /**
     * Gets the value of the deviceCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDeviceCount() {
        return deviceCount;
    }

    /**
     * Sets the value of the deviceCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDeviceCount(Integer value) {
        this.deviceCount = value;
    }

    /**
     * Gets the value of the locInsertTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocInsertTime() {
        return locInsertTime;
    }

    /**
     * Sets the value of the locInsertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocInsertTime(String value) {
        this.locInsertTime = value;
    }

    /**
     * Gets the value of the locInsertBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocInsertBy() {
        return locInsertBy;
    }

    /**
     * Sets the value of the locInsertBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocInsertBy(String value) {
        this.locInsertBy = value;
    }

    /**
     * Gets the value of the locUpdateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocUpdateTime() {
        return locUpdateTime;
    }

    /**
     * Sets the value of the locUpdateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocUpdateTime(String value) {
        this.locUpdateTime = value;
    }

    /**
     * Gets the value of the locUpdateBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocUpdateBy() {
        return locUpdateBy;
    }

    /**
     * Sets the value of the locUpdateBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocUpdateBy(String value) {
        this.locUpdateBy = value;
    }

    /**
     * Gets the value of the distNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link DistNetworkType }
     *     
     */
    public DistNetworkType getDistNetwork() {
        return distNetwork;
    }

    /**
     * Sets the value of the distNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistNetworkType }
     *     
     */
    public void setDistNetwork(DistNetworkType value) {
        this.distNetwork = value;
    }

    /**
     * Gets the value of the servicePoint property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the servicePoint property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getServicePoint().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetServicePtType }
     * 
     * 
     */
    public List<GetServicePtType> getServicePoint() {
        if (servicePoint == null) {
            servicePoint = new ArrayList<GetServicePtType>();
        }
        return this.servicePoint;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * @return
     *     possible object is
     *     {@link GetDevContactListType }
     *     
     */
    public GetDevContactListType getContacts() {
        return contacts;
    }

    /**
     * Sets the value of the contacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetDevContactListType }
     *     
     */
    public void setContacts(GetDevContactListType value) {
        this.contacts = value;
    }

}
