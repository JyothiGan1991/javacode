
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MonthEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MonthEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MONTH_JANUARY"/&gt;
 *     &lt;enumeration value="MONTH_FEBRUARY"/&gt;
 *     &lt;enumeration value="MONTH_MARCH"/&gt;
 *     &lt;enumeration value="MONTH_APRIL"/&gt;
 *     &lt;enumeration value="MONTH_MAY"/&gt;
 *     &lt;enumeration value="MONTH_JUNE"/&gt;
 *     &lt;enumeration value="MONTH_JULY"/&gt;
 *     &lt;enumeration value="MONTH_AUGUST"/&gt;
 *     &lt;enumeration value="MONTH_SEPTEMBER"/&gt;
 *     &lt;enumeration value="MONTH_OCTOBER"/&gt;
 *     &lt;enumeration value="MONTH_NOVEMBER"/&gt;
 *     &lt;enumeration value="MONTH_DECEMBER"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MonthEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum MonthEnumeration {

    MONTH_JANUARY("MONTH_JANUARY"),
    MONTH_FEBRUARY("MONTH_FEBRUARY"),
    MONTH_MARCH("MONTH_MARCH"),
    MONTH_APRIL("MONTH_APRIL"),
    MONTH_MAY("MONTH_MAY"),
    MONTH_JUNE("MONTH_JUNE"),
    MONTH_JULY("MONTH_JULY"),
    MONTH_AUGUST("MONTH_AUGUST"),
    MONTH_SEPTEMBER("MONTH_SEPTEMBER"),
    MONTH_OCTOBER("MONTH_OCTOBER"),
    MONTH_NOVEMBER("MONTH_NOVEMBER"),
    MONTH_DECEMBER("MONTH_DECEMBER"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MonthEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MonthEnumeration fromValue(String v) {
        for (MonthEnumeration c: MonthEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
