
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OutputContent" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DeviceExportOutputContentEnum"/&gt;
 *         &lt;element name="OutputFormat" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DeviceExportOutputFormatTypeEnum"/&gt;
 *         &lt;element name="FileSegmenting" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DeviceExportFileSegmentingType" minOccurs="0"/&gt;
 *         &lt;element name="IncludeDevicePasswords" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="IncludeLastReadPointers" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="OneTime" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DeviceExportOneTimeType"/&gt;
 *           &lt;element name="Recurring" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}DeviceExportRecurringType"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceDataType", propOrder = {
    "outputContent",
    "outputFormat",
    "fileSegmenting",
    "includeDevicePasswords",
    "includeLastReadPointers",
    "oneTime",
    "recurring"
})
public class DeviceDataType {

    @XmlElement(name = "OutputContent", required = true)
    @XmlSchemaType(name = "string")
    protected DeviceExportOutputContentEnum outputContent;
    @XmlElement(name = "OutputFormat", required = true)
    @XmlSchemaType(name = "string")
    protected DeviceExportOutputFormatTypeEnum outputFormat;
    @XmlElement(name = "FileSegmenting")
    protected DeviceExportFileSegmentingType fileSegmenting;
    @XmlElement(name = "IncludeDevicePasswords")
    protected Boolean includeDevicePasswords;
    @XmlElement(name = "IncludeLastReadPointers")
    protected Boolean includeLastReadPointers;
    @XmlElement(name = "OneTime")
    protected DeviceExportOneTimeType oneTime;
    @XmlElement(name = "Recurring")
    protected DeviceExportRecurringType recurring;

    /**
     * Gets the value of the outputContent property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceExportOutputContentEnum }
     *     
     */
    public DeviceExportOutputContentEnum getOutputContent() {
        return outputContent;
    }

    /**
     * Sets the value of the outputContent property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceExportOutputContentEnum }
     *     
     */
    public void setOutputContent(DeviceExportOutputContentEnum value) {
        this.outputContent = value;
    }

    /**
     * Gets the value of the outputFormat property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceExportOutputFormatTypeEnum }
     *     
     */
    public DeviceExportOutputFormatTypeEnum getOutputFormat() {
        return outputFormat;
    }

    /**
     * Sets the value of the outputFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceExportOutputFormatTypeEnum }
     *     
     */
    public void setOutputFormat(DeviceExportOutputFormatTypeEnum value) {
        this.outputFormat = value;
    }

    /**
     * Gets the value of the fileSegmenting property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceExportFileSegmentingType }
     *     
     */
    public DeviceExportFileSegmentingType getFileSegmenting() {
        return fileSegmenting;
    }

    /**
     * Sets the value of the fileSegmenting property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceExportFileSegmentingType }
     *     
     */
    public void setFileSegmenting(DeviceExportFileSegmentingType value) {
        this.fileSegmenting = value;
    }

    /**
     * Gets the value of the includeDevicePasswords property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeDevicePasswords() {
        return includeDevicePasswords;
    }

    /**
     * Sets the value of the includeDevicePasswords property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeDevicePasswords(Boolean value) {
        this.includeDevicePasswords = value;
    }

    /**
     * Gets the value of the includeLastReadPointers property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeLastReadPointers() {
        return includeLastReadPointers;
    }

    /**
     * Sets the value of the includeLastReadPointers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeLastReadPointers(Boolean value) {
        this.includeLastReadPointers = value;
    }

    /**
     * Gets the value of the oneTime property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceExportOneTimeType }
     *     
     */
    public DeviceExportOneTimeType getOneTime() {
        return oneTime;
    }

    /**
     * Sets the value of the oneTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceExportOneTimeType }
     *     
     */
    public void setOneTime(DeviceExportOneTimeType value) {
        this.oneTime = value;
    }

    /**
     * Gets the value of the recurring property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceExportRecurringType }
     *     
     */
    public DeviceExportRecurringType getRecurring() {
        return recurring;
    }

    /**
     * Sets the value of the recurring property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceExportRecurringType }
     *     
     */
    public void setRecurring(DeviceExportRecurringType value) {
        this.recurring = value;
    }

}
