
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TOUTierWeekdayEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TOUTierWeekdayEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TOU_TIER_DAY_SATURDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_SUNDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_WEEKDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_WEEKEND"/>
 *     &lt;enumeration value="TOU_TIER_DAY_MONDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_TUESDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_WEDNESDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_THURSDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_FRIDAY"/>
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY_1"/>
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY_2"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TOUTierWeekdayEnum")
@XmlEnum
public enum TOUTierWeekdayEnum {

    TOU_TIER_DAY_SATURDAY("TOU_TIER_DAY_SATURDAY"),
    TOU_TIER_DAY_SUNDAY("TOU_TIER_DAY_SUNDAY"),
    TOU_TIER_DAY_WEEKDAY("TOU_TIER_DAY_WEEKDAY"),
    TOU_TIER_DAY_HOLIDAY("TOU_TIER_DAY_HOLIDAY"),
    TOU_TIER_DAY_WEEKEND("TOU_TIER_DAY_WEEKEND"),
    TOU_TIER_DAY_MONDAY("TOU_TIER_DAY_MONDAY"),
    TOU_TIER_DAY_TUESDAY("TOU_TIER_DAY_TUESDAY"),
    TOU_TIER_DAY_WEDNESDAY("TOU_TIER_DAY_WEDNESDAY"),
    TOU_TIER_DAY_THURSDAY("TOU_TIER_DAY_THURSDAY"),
    TOU_TIER_DAY_FRIDAY("TOU_TIER_DAY_FRIDAY"),
    TOU_TIER_DAY_HOLIDAY_1("TOU_TIER_DAY_HOLIDAY_1"),
    TOU_TIER_DAY_HOLIDAY_2("TOU_TIER_DAY_HOLIDAY_2"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    TOUTierWeekdayEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TOUTierWeekdayEnum fromValue(String v) {
        for (TOUTierWeekdayEnum c: TOUTierWeekdayEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
