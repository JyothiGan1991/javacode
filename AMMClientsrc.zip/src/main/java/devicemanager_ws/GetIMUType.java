
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetIMUType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetIMUType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}IMUType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IMUTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}IMUTypeConfig" minOccurs="0"/&gt;
 *         &lt;element name="IMUMeterTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}IMUMeterTypeConfig" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetIMUType", propOrder = {
    "imuTypeConfig",
    "imuMeterTypeConfig"
})
public class GetIMUType
    extends IMUType
{

    @XmlElement(name = "IMUTypeConfig")
    protected IMUTypeConfig imuTypeConfig;
    @XmlElement(name = "IMUMeterTypeConfig")
    protected IMUMeterTypeConfig imuMeterTypeConfig;

    /**
     * Gets the value of the imuTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link IMUTypeConfig }
     *     
     */
    public IMUTypeConfig getIMUTypeConfig() {
        return imuTypeConfig;
    }

    /**
     * Sets the value of the imuTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link IMUTypeConfig }
     *     
     */
    public void setIMUTypeConfig(IMUTypeConfig value) {
        this.imuTypeConfig = value;
    }

    /**
     * Gets the value of the imuMeterTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link IMUMeterTypeConfig }
     *     
     */
    public IMUMeterTypeConfig getIMUMeterTypeConfig() {
        return imuMeterTypeConfig;
    }

    /**
     * Sets the value of the imuMeterTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link IMUMeterTypeConfig }
     *     
     */
    public void setIMUMeterTypeConfig(IMUMeterTypeConfig value) {
        this.imuMeterTypeConfig = value;
    }

}
