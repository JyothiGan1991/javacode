
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HopType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HopType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DeviceMACID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UIQDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType" minOccurs="0"/&gt;
 *         &lt;element name="Rssi" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RssiType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HopType", propOrder = {
    "deviceMACID",
    "name",
    "uiqDeviceState",
    "didType",
    "rssi"
})
@XmlSeeAlso({
    GatewayHopType.class
})
public class HopType {

    @XmlElement(name = "DeviceMACID")
    protected String deviceMACID;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "UIQDeviceState")
    protected UIQDeviceStateType uiqDeviceState;
    @XmlElement(name = "DidType")
    protected DeviceTypeType didType;
    @XmlElement(name = "Rssi")
    protected List<RssiType> rssi;

    /**
     * Gets the value of the deviceMACID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMACID() {
        return deviceMACID;
    }

    /**
     * Sets the value of the deviceMACID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMACID(String value) {
        this.deviceMACID = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the uiqDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUIQDeviceState() {
        return uiqDeviceState;
    }

    /**
     * Sets the value of the uiqDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUIQDeviceState(UIQDeviceStateType value) {
        this.uiqDeviceState = value;
    }

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the rssi property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rssi property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRssi().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RssiType }
     * 
     * 
     */
    public List<RssiType> getRssi() {
        if (rssi == null) {
            rssi = new ArrayList<RssiType>();
        }
        return this.rssi;
    }

}
