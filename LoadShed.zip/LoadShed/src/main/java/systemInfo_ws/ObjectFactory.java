
package systemInfo_ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the systemInfo_ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetUIQVersion_QNAME = new QName("urn:com:ssn:schema:service:v2.2:SystemInfo.xsd", "GetUIQVersion");
    private final static QName _GetVersion_QNAME = new QName("urn:com:ssn:schema:service:v2.2:SystemInfo.xsd", "GetVersion");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: systemInfo_ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EmptyType }
     * 
     */
    public EmptyType createEmptyType() {
        return new EmptyType();
    }

    /**
     * Create an instance of {@link UIQVersion }
     * 
     */
    public UIQVersion createUIQVersion() {
        return new UIQVersion();
    }

    /**
     * Create an instance of {@link Version }
     * 
     */
    public Version createVersion() {
        return new Version();
    }

    /**
     * Create an instance of {@link VersionInfoType }
     * 
     */
    public VersionInfoType createVersionInfoType() {
        return new VersionInfoType();
    }

    /**
     * Create an instance of {@link ErrorCodeFault }
     * 
     */
    public ErrorCodeFault createErrorCodeFault() {
        return new ErrorCodeFault();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.2:SystemInfo.xsd", name = "GetUIQVersion")
    public JAXBElement<EmptyType> createGetUIQVersion(EmptyType value) {
        return new JAXBElement<EmptyType>(_GetUIQVersion_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.2:SystemInfo.xsd", name = "GetVersion")
    public JAXBElement<EmptyType> createGetVersion(EmptyType value) {
        return new JAXBElement<EmptyType>(_GetVersion_QNAME, EmptyType.class, null, value);
    }

}
