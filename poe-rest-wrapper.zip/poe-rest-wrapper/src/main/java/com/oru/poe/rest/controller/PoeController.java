package com.oru.poe.rest.controller;

import com.oru.poe.rest.dto.BooleanResponse;
import com.oru.poe.rest.dto.IncidentCountRequest;
import com.oru.poe.rest.dto.IntegerResponse;
import com.oru.poe.rest.dto.IsGasMainRequest;
import com.oru.poe.rest.dto.VerifyPoleRequest;
import com.oru.poe.rest.service.PoeSoapService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/poe")
public class PoeController {

    private final PoeSoapService poeSoapService;

    public PoeController(PoeSoapService poeSoapService) {
        this.poeSoapService = poeSoapService;
    }

    /**
     * REST wrapper for SOAP isGasMain.
     * POST /api/v1/poe/is-gas-main
     * Body: { "premise": "optional", "radius": 100 }
     */
    @PostMapping(value = "/is-gas-main",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> isGasMain(@Valid @RequestBody IsGasMainRequest request) {
        boolean result = poeSoapService.isGasMain(request);
        return ResponseEntity.ok(new BooleanResponse(result));
    }

    /**
     * Convenience GET for isGasMain (query params).
     * GET /api/v1/poe/is-gas-main?premise=xxx&radius=100
     */
    @GetMapping(value = "/is-gas-main", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> isGasMainGet(
            @RequestParam(required = false) String premise,
            @RequestParam int radius) {
        IsGasMainRequest request = new IsGasMainRequest(premise, radius);
        boolean result = poeSoapService.isGasMain(request);
        return ResponseEntity.ok(new BooleanResponse(result));
    }

    /**
     * REST wrapper for SOAP verifyPole.
     * POST /api/v1/poe/verify-pole
     * Body: { "x": 100, "y": 200 }
     */
    @PostMapping(value = "/verify-pole",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> verifyPole(@Valid @RequestBody VerifyPoleRequest request) {
        boolean result = poeSoapService.verifyPole(request);
        return ResponseEntity.ok(new BooleanResponse(result));
    }

    /**
     * Convenience GET for verifyPole.
     * GET /api/v1/poe/verify-pole?x=100&y=200
     */
    @GetMapping(value = "/verify-pole", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> verifyPoleGet(
            @RequestParam int x,
            @RequestParam int y) {
        VerifyPoleRequest request = new VerifyPoleRequest(x, y);
        boolean result = poeSoapService.verifyPole(request);
        return ResponseEntity.ok(new BooleanResponse(result));
    }

    /**
     * REST wrapper for SOAP incidentCount.
     * POST /api/v1/poe/incident-count
     * Body: { "startDate": "2024-01-01", "startTime": "00:00:00", "endDate": "2024-12-31", "endTime": "23:59:59" }
     */
    @PostMapping(value = "/incident-count",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IntegerResponse> incidentCount(@RequestBody IncidentCountRequest request) {
        int result = poeSoapService.incidentCount(request);
        return ResponseEntity.ok(new IntegerResponse(result));
    }

    /**
     * Convenience GET for incidentCount.
     * GET /api/v1/poe/incident-count?startDate=...&startTime=...&endDate=...&endTime=...
     */
    @GetMapping(value = "/incident-count", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IntegerResponse> incidentCountGet(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String endTime) {
        IncidentCountRequest request = new IncidentCountRequest(startDate, startTime, endDate, endTime);
        int result = poeSoapService.incidentCount(request);
        return ResponseEntity.ok(new IntegerResponse(result));
    }
}
