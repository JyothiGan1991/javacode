/*package com.coned.jpa.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coned.model.Role;
import com.coned.model.User;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.UserRepository;
import com.coned.jpa.repository.RoleRepository;

@RestController
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping("/roles/{roleId}/users")
    public List < User > getUsersByRole(@PathVariable(value = "roleId") Long roleId) {
        return userRepository.findByRoleId(roleId);
    }

    @GetMapping("/search/users/{username}")
    public List<User> getByFirstName(@PathVariable("username") String username) {
        List< User > ret = userRepository.findByUsernameContaining(username);
        return ( ret );
    }
    
	@GetMapping("/check/{username}")
	public String check(@PathVariable("username") String username) {
		Optional<User> user = userRepository.findByUsername(username);
		return user.isPresent() ? "exist" : "doesn't exist";
	}
    
    
    @PostMapping("/roles/{roleId}/users")
    public User createUser(@PathVariable(value = "roleId") Long roleId,
        @Valid @RequestBody User user) throws ResourceMissingException {
        return roleRepository.findById(roleId).map(role -> {
            user.setRole(role);
            return userRepository.save(user);
        }).orElseThrow(() -> new ResourceMissingException("Role not found"));
    }
    
    @PutMapping("/roles/{roleId}/users/{userId}")
    public User updateUser(@PathVariable(value = "roleId") Long roleId,
        @PathVariable(value = "userId") Long userId, @Valid @RequestBody User userRequest)
    throws ResourceMissingException {
        if (!roleRepository.existsById(roleId)) {
            throw new ResourceMissingException("roleId not found");
        }
        return userRepository.findById(userId).map(user -> {
            user.setUsername(userRequest.getUsername());
            user.setFirstName(userRequest.getFirstName());
            user.setLastName(userRequest.getLastName());
            user.setEmail(userRequest.getEmail());
            user.setStatus(userRequest.getStatus());
            return userRepository.save(user);
        }).orElseThrow(() -> new ResourceMissingException("User id not found"));
    }

    @DeleteMapping("/roles/{roleId}/users/{userId}")
    public ResponseEntity < ? > deleteUser(@PathVariable(value = "roleId") Long roleId,
        @PathVariable(value = "userId") Long userId) throws ResourceMissingException {
        return userRepository.findByIdAndRoleId(userId, roleId).map(user -> {
            userRepository.delete(user);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceMissingException(
            "User not found with id " + userId + " and roleId " + roleId));
    }
}
*/