
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StateTransitionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StateTransitionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EnteredUIQDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="ExitedUIQDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="Start" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="End" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StateTransitionType", propOrder = {
    "enteredUIQDeviceState",
    "exitedUIQDeviceState",
    "start",
    "end"
})
public class StateTransitionType {

    @XmlElement(name = "EnteredUIQDeviceState")
    protected UIQDeviceStateType enteredUIQDeviceState;
    @XmlElement(name = "ExitedUIQDeviceState")
    protected UIQDeviceStateType exitedUIQDeviceState;
    @XmlElement(name = "Start", required = true)
    protected String start;
    @XmlElement(name = "End")
    protected String end;

    /**
     * Gets the value of the enteredUIQDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getEnteredUIQDeviceState() {
        return enteredUIQDeviceState;
    }

    /**
     * Sets the value of the enteredUIQDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setEnteredUIQDeviceState(UIQDeviceStateType value) {
        this.enteredUIQDeviceState = value;
    }

    /**
     * Gets the value of the exitedUIQDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getExitedUIQDeviceState() {
        return exitedUIQDeviceState;
    }

    /**
     * Sets the value of the exitedUIQDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setExitedUIQDeviceState(UIQDeviceStateType value) {
        this.exitedUIQDeviceState = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStart(String value) {
        this.start = value;
    }

    /**
     * Gets the value of the end property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnd() {
        return end;
    }

    /**
     * Sets the value of the end property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnd(String value) {
        this.end = value;
    }

}
