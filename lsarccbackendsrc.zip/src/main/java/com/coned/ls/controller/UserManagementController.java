package com.coned.ls.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.UserManagementService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/lsa-rcc-um")
public class UserManagementController {
	private static final Logger LOGGER = LogManager.getLogger(RCCDisconnectController.class);

	@Autowired
	private UserManagementService userManagementService;
	
    /*
     * API to return list of values for a given field.
     * 
     * @return 					ResponseEntity<Map<String, Object>>  
     *                         
     */
	@GetMapping("/users")
	public ResponseEntity<List<Object>> getUsers() {
		LOGGER.debug(String.format("Request for get users :"));
		return userManagementService.getUsers();
	}
    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable username  	String 
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/adusers/{username}")
	public ResponseEntity<Map<String, Object>> listLDAPUser(@PathVariable("username") String username) {
		LOGGER.debug(String.format("Request for Check LDAP user :"));
		return userManagementService.listLDAPUser(username);
	}
    /*
     * API to return list of values for a given field.
     * 
     * @return 					ResponseEntity<Map<String, Object>>  
     *                         
     */
	@PostMapping("/users")
	public ResponseEntity<Map<String, Object>> createUser(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for CREATE USER into database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		String[] keys = header.split("-");
		String adid = keys[1];
		payload.put("adid", adid);
		return userManagementService.createUser(payload);
	}
    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable username  	String 
     * @return 					ResponseEntity<Map<String, Object>>  
     *                         
     */
	@PutMapping("/users/{username}")
	public ResponseEntity<Map<String, Object>> updateUser(@PathVariable(name = "username") String username, HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for deleteUser"));
		
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		String[] keys = header.split("-");
		String adid = keys[1];
		payload.put("adid", adid);
		
		return userManagementService.updateUser(username, payload);
	}
    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable username  	String 
     * @return 					ResponseEntity<Map<String, Object>>  
     *                         
     */
	@DeleteMapping("/users/{username}")
	public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable(name = "username") String username, HttpServletRequest request) {
		LOGGER.info(String.format("Request for deleteUser"));
		
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		String[] keys = header.split("-");
		String adid = keys[1];
		
		return userManagementService.deleteUser(username, adid);
	}
	
}