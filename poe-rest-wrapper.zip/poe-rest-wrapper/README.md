# POE REST Wrapper API

Spring Boot 3 / Java 21 Maven project that exposes a REST API wrapping the POE SOAP Web Services defined in `POEWebServices.wsdl`.

## Features

- REST endpoints that internally invoke the corresponding SOAP operations
- Configurable SOAP endpoint URL
- Request validation
- Global exception handling
- Unit tests with mocked SOAP client
- Ready to import into Eclipse (Maven project)

## SOAP Operations Wrapped

| SOAP Operation   | REST Endpoint (POST & GET)          | Request fields                          | Response      |
|------------------|-------------------------------------|-----------------------------------------|---------------|
| `isGasMain`      | `/api/v1/poe/is-gas-main`           | `premise` (optional), `radius` (int)    | `{ "result": true/false }` |
| `verifyPole`     | `/api/v1/poe/verify-pole`           | `x` (int), `y` (int)                    | `{ "result": true/false }` |
| `incidentCount`  | `/api/v1/poe/incident-count`        | `startDate`, `startTime`, `endDate`, `endTime` (all optional strings) | `{ "result": <int> }` |

## Requirements

- JDK 21+
- Maven 3.9+

## Build & Run

```bash
# From project root
mvn clean package

# Run (default REST port 9090)
mvn spring-boot:run
```

Or run the jar:

```bash
java -jar target/poe-rest-wrapper-1.0.0-SNAPSHOT.jar
```

## Configuration

Edit `src/main/resources/application.yml`:

```yaml
server:
  port: 9090

poe:
  soap:
    endpoint-url: http://localhost:8080/poeWebServices/services/POEWebServicesPort
    connect-timeout-ms: 5000
    read-timeout-ms: 10000
```

Override at runtime:

```bash
java -jar target/poe-rest-wrapper-1.0.0-SNAPSHOT.jar \
  --poe.soap.endpoint-url=http://your-soap-host:8080/poeWebServices/services/POEWebServicesPort
```

## Example Requests

### isGasMain (POST)

```bash
curl -X POST http://localhost:9090/api/v1/poe/is-gas-main \
  -H "Content-Type: application/json" \
  -d '{"premise":"123 Main St","radius":50}'
```

### isGasMain (GET)

```bash
curl "http://localhost:9090/api/v1/poe/is-gas-main?premise=123%20Main%20St&radius=50"
```

### verifyPole (POST)

```bash
curl -X POST http://localhost:9090/api/v1/poe/verify-pole \
  -H "Content-Type: application/json" \
  -d '{"x":100,"y":200}'
```

### incidentCount (POST)

```bash
curl -X POST http://localhost:9090/api/v1/poe/incident-count \
  -H "Content-Type: application/json" \
  -d '{"startDate":"2024-01-01","startTime":"00:00:00","endDate":"2024-12-31","endTime":"23:59:59"}'
```

## Import into Eclipse

1. File → Import → Existing Maven Projects
2. Select the `poe-rest-wrapper` folder
3. Ensure JDK 21 is configured in Eclipse
4. After import, run `Maven → Update Project` if needed
5. The CXF code generation runs on `mvn generate-sources` / `mvn compile`

## Project Structure

```
poe-rest-wrapper/
├── pom.xml
├── README.md
├── src/main/java/com/oru/poe/rest/
│   ├── PoeRestWrapperApplication.java
│   ├── config/SoapClientConfig.java
│   ├── controller/PoeController.java
│   ├── dto/ ...
│   ├── exception/ ...
│   └── service/PoeSoapService.java
├── src/main/resources/
│   ├── application.yml
│   └── wsdl/POEWebServices.wsdl
└── src/test/java/com/oru/poe/rest/
    ├── controller/PoeControllerTest.java
    └── service/PoeSoapServiceTest.java
```

## Notes

- SOAP client classes are generated at build time from the WSDL into `target/generated-sources/cxf`.
- The REST service runs on port **9090** by default so it does not conflict with a SOAP service typically on 8080.
- If the SOAP service is unavailable, REST endpoints return HTTP 502 with an error body.
