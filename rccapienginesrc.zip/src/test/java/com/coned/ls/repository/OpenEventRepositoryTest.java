package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SimpleJdbcCallFactory;

import jakarta.activation.DataSource;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { OpenEventRepository.class })
@AutoConfigureMockMvc
public class OpenEventRepositoryTest {

	@Autowired
	private WebApplicationContext wac;
	@Mock
	JndiDataSourceLookup test;

	@MockBean
	@Qualifier("lsarccds")
	private DataSource dataSource;

	@Mock
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	@Mock
	@Qualifier("starJdbcTemplate")
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	private SimpleJdbcCall simpleJdbcCall;

	@InjectMocks
	JdbcOpenEventRepository openEventRepository;
	
	@Mock
	private SimpleJdbcCallFactory simpleJdbcCallFactory;

	private MockMvc mockMvc;

	private OpenEvent openEvent;

	@Mock
	ResultSet rs;

	@Test
	@Before
	public void setup() throws SQLException {
		ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		openEvent = new OpenEvent();
		DataSource mockedDataSrc = Mockito.mock(DataSource.class);
		this.oracleJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.sqlServerJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.starJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.simpleJdbcCall = Mockito.mock(SimpleJdbcCall.class);

	}

	@Test
	public void testEvent() {
		List<String> eventName = new ArrayList<>();
		eventName.add("'-1300");
		openEvent.setEventName(eventName);
		Assert.assertEquals(eventName.get(0), openEvent.getEventName().get(0));

	}

	@SuppressWarnings("unchecked")
	@Test
	public void getNewAndActiveBoroughtest() throws SQLException {
		List<String> activeBoroughList = new ArrayList<>();
		// activeBoroughList.add("B");
		// activeBoroughList.add("M");

		List<String> newBoroughList = new ArrayList<>();
		// newBoroughList.add("B");
		// newBoroughList.add("M");

		List<String> newActiveBorough = new ArrayList<>();
		// newBoroughList.add("B");
		// newBoroughList.add("M");

		Mockito.when(rs.getString(Mockito.anyString())).thenReturn("B");
		Mockito.when(sqlServerJdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class),
				Mockito.any(RowMapper.class))).thenReturn(newBoroughList);
		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class)))
				.thenReturn(activeBoroughList);
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(newActiveBorough);
		List<String> actual = openEventRepository.getNewAndActiveBorough();
		Assert.assertEquals(newActiveBorough.size(), actual.size());

	}

	@Test
	public void getNewAndActiveEventTest() {
		List<String> eventName = new ArrayList<>();
		// eventName.add("SheepsheadBaySampleData7.27.20-1300");

		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class))).thenReturn(eventName);
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(eventName);
		List<String> actual = openEventRepository.getNewAndActiveEvent();
		Assert.assertEquals(eventName.size(), actual.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getNewAndActiveEventByBoroughtest() {

		List<String> eventName = new ArrayList<>();
		ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		eventName.add("SheepsheadBaySampleData7.27.20-1300");
		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class),
				Mockito.any(RowMapper.class))).thenReturn(eventName);
		Mockito.when(openEventRepository.getNewAndActiveEventByBorough("borough")).thenReturn(eventName);
		List<String> actual = openEventRepository.getNewAndActiveEventByBorough("borough");
		Assert.assertEquals(eventName.size(), actual.size());
	}

	/*
	 * * @Test public void getSubFinalizeBoroughTest(){ List<String> boroughList
	 * = new ArrayList<String>(); boroughList.add("M"); Map<String, Object>
	 * simpleJdbcCallResult = new HashMap<>(); JdbcTemplate jdbcTemplateMock =
	 * Mockito.mock(JdbcTemplate.class); SimpleJdbcCall mockedSimpleJdbcCall =
	 * Mockito.mock(SimpleJdbcCall.class);
	 * //Mockito.when(simpleJdbcCall.execute()).thenReturn(simpleJdbcCallResult)
	 * ; //
	 * Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(),Mockito.any(
	 * Object[].class),Mockito.any(RowMapper.class))).thenReturn(
	 * Mockito.when(openEventRepository.getSubFinalizeBorough()).thenReturn(
	 * boroughList) );
	 * Mockito.when(openEventRepository.getSubFinalizeBorough()).thenReturn(
	 * boroughList); List<String> actual =
	 * openEventRepository.getSubFinalizeBorough();
	 * Assert.assertEquals(boroughList.size(), actual.size());
	 * 
	 * }
	 */

	@SuppressWarnings("unchecked")
	@Test
	public void getExecuteBoroughTest() {

		List<String> boroughList = new ArrayList<String>();

		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class)))
				.thenReturn(boroughList);
		Mockito.when(openEventRepository.getExecuteBorough()).thenReturn(boroughList);
		List<String> actual = openEventRepository.getExecuteBorough();
		Assert.assertEquals(boroughList.size(), actual.size());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void getExecuteEventTest() {

		List<String> eventList = new ArrayList<String>();

		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class))).thenReturn(eventList);
		Mockito.when(openEventRepository.getExecuteEvent()).thenReturn(eventList);
		List<String> actual = openEventRepository.getExecuteEvent();
		Assert.assertEquals(eventList.size(), actual.size());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void getExecuteEventByBorough() throws SQLException {

		List<String> executeEventList = new ArrayList<String>();

		ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class),
				Mockito.any(RowMapper.class))).thenReturn(executeEventList);
		Mockito.when(openEventRepository.getExecuteEventByBorough("borough")).thenReturn(executeEventList);
		List<String> response = openEventRepository.getExecuteEventByBorough("borough");
		Assert.assertEquals(response.size(), executeEventList.size());

	}

	/*@Test
	public void getSubFinalizeBorough() {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		DataSource mockDataSource = Mockito.mock(DataSource.class);

		Map<String, Object> simpleJdbcCallResult = new HashMap<>();

		// Mockito.when(
		// simpleJdbcCall.withProcedureName(Mockito.anyString())).thenReturn(mockedCall);
		mockedCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_CON_FIN_BOROUGH")
				.returningResultSet("SP_SUB_FIN_BOROUGH", Mockito.any(RowMapper.class));
		Map<String, Object> map = new HashMap<>();
		map.put("data", Arrays.asList(new JdbcOpenEventRepository(), new JdbcOpenEventRepository()));
		Mockito.when(simpleJdbcCall.execute(Mockito.mock(SqlParameterSource.class))).thenReturn(map);
		Mockito.when(mockedCall.execute()).thenReturn(simpleJdbcCallResult);
		// ReflectionTestUtils.invokeMethod(openEventRepository,
		// "getSubFinalizeBorough");
		// ReflectionTestUtils.setField(openEventRepository,
		// "oracleJdbcTemplate", oracleJdbcTemplate);
		List<String> response = openEventRepository.getSubFinalizeBorough();
		Assert.assertEquals(response.size(), boroughList.size());

	}*/

	/*@Test
	public void getSubFinalizeBoroughTest() {

		DataSource datasource = Mockito.mock(DataSource.class);
		List<String> boroughList = new ArrayList<String>();
		Mockito.when(openEventRepository.getSubFinalizeBorough()).thenReturn(boroughList);
		List<String> response = openEventRepository.getSubFinalizeBorough();
		Assert.assertEquals(response.size(), boroughList.size());

	}
	
	@Test
	public void getSubFinalizeBoroughT() {
		List<String> boroughList = new ArrayList<String>();
		 SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
	     Mockito.when( simpleJdbcCallFactory.create(Mockito.any())).thenReturn(mockedCall);
	     //Mockito.when( mockedCall.withProcedureName(Mockito.anyString()) ;
		
		
        //Mockito.when( simpleJdbcCallFactory.create(Mockito.any())).thenReturn(mockedCall);
        //Mockito.when( mockedCall ).withProcedureName(Mockito.anyString()).thenReturn(mockedCall);
		//Mockito.when(mockedCall).withArguments(oracleJdbcTemplate).thenReturn(mockedCall);
	    List<String> getSubFinalizeBorough =  openEventRepository.getSubFinalizeBorough();
	}
	*/
	@Test(expected = IllegalStateException.class)
	public void getSubFinalizeBorough1() {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Map<String, Object> map = new HashMap<>();

		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("BORO_MUNI", "Test");
		list.add(lList);
		map.put("BORO", list);
		Mockito.when(simpleJdbcCall.execute()).thenReturn(map);
		//Mockito.when( mockedCall ).withProcedureName(Mockito.anyString()).thenReturn(mockedCall);
		//ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);	
		List<String> lstStr = openEventRepository.getSubFinalizeBorough();
		Assert.assertNotNull(lstStr);
	}
	@Test(expected = IllegalStateException.class)
	public void getSubFinalizeEvent() {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Map<String, Object> map = new HashMap<>();
		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("EVENT_NAME", "Test");
		list.add(lList);
		map.put("Event", list);
		Mockito.when(simpleJdbcCall.execute()).thenReturn(map);
		List<String> lstStr = openEventRepository.getSubFinalizeEvent();
		Assert.assertNotNull(lstStr);
		
	}
	@Test(expected = IllegalStateException.class)
	public void getSubFinalizeEventByBorough() {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		String borough = "Test";
		Map<String, Object> map = new HashMap<>();
		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("BORO_MUNI", "Test");
		list.add(lList);
		map.put("BORO", list);
		Mockito.when(simpleJdbcCall.execute()).thenReturn(map);
		List<String> lstStr = openEventRepository.getSubFinalizeEventByBorough("Test");
		Assert.assertNotNull(lstStr);
	}
	@Test(expected = IllegalStateException.class)
	public void getSubFinalizeEventByEventAndBorough() {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Map<String, Object> map = new HashMap<>();
		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("BOROUGH", "Test");
		lList.put("EVENTNAME", "Test");
		list.add(lList);
		map.put("BORO", list);
		map.put("Event", list);
		Mockito.when(simpleJdbcCall.execute()).thenReturn(map);
		List<String> lstStr = openEventRepository.getSubFinalizeEventByEventAndBorough("Test","Test");
		Assert.assertNotNull(lstStr);
	}


}

	
