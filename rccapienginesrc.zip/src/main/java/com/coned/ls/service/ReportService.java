package com.coned.ls.service;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

public interface ReportService {

	public ResponseEntity<List<Map<String, Object>>> getEvents(String report_name);
	public ResponseEntity<List<Map<String, Object>>> getCWRData(@RequestBody Map<String, Object> payload);
	public ResponseEntity<List<Map<String, Object>>> getCDRData(@RequestBody Map<String, Object> payload);
	public ResponseEntity<List<Map<String, Object>>> getCRRData(@RequestBody Map<String, Object> payload);
	public  ResponseEntity<Map<String, Object>> getCMRData(@RequestBody Map<String, Object> payload);
	public ResponseEntity<Map<String, Object>> getCERData(@RequestBody Map<String, Object> payload);
}
