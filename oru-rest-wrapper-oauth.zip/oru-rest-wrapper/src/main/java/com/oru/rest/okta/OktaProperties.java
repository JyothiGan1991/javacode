package com.oru.rest.okta;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Okta OAuth 2.0 client-credentials configuration.
 * Token endpoint: https://{domain}/oauth2/{authorizationServerId}/v1/token
 */
@Component
@ConfigurationProperties(prefix = "okta")
public class OktaProperties {

    private boolean enabled = false;
    private String domain = "your-org.okta.com";
    private String authorizationServerId = "default";
    private String clientId = "";
    private String clientSecret = "";
    private String scope = "api.read";
    private String issuer = "";
    private String tokenUri = "";
    private String jwksUri = "";
    private String audience = "";
    private long connectTimeoutMs = 5000;
    private long readTimeoutMs = 10000;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getAuthorizationServerId() {
        return authorizationServerId;
    }

    public void setAuthorizationServerId(String authorizationServerId) {
        this.authorizationServerId = authorizationServerId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getIssuer() {
        if (StringUtils.hasText(issuer)) {
            return issuer;
        }
        return "https://" + domain + "/oauth2/" + authorizationServerId;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getTokenUri() {
        if (StringUtils.hasText(tokenUri)) {
            return tokenUri;
        }
        return "https://" + domain + "/oauth2/" + authorizationServerId + "/v1/token";
    }

    public void setTokenUri(String tokenUri) {
        this.tokenUri = tokenUri;
    }

    public String getJwksUri() {
        if (StringUtils.hasText(jwksUri)) {
            return jwksUri;
        }
        return "https://" + domain + "/oauth2/" + authorizationServerId + "/v1/keys";
    }

    public void setJwksUri(String jwksUri) {
        this.jwksUri = jwksUri;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public long getConnectTimeoutMs() {
        return connectTimeoutMs;
    }

    public void setConnectTimeoutMs(long connectTimeoutMs) {
        this.connectTimeoutMs = connectTimeoutMs;
    }

    public long getReadTimeoutMs() {
        return readTimeoutMs;
    }

    public void setReadTimeoutMs(long readTimeoutMs) {
        this.readTimeoutMs = readTimeoutMs;
    }
}
