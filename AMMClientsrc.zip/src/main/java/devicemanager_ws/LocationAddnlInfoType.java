
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocationAddnlInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocationAddnlInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="HazardCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClimateZoneCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ThermalZoneCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TrafficCtlCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MountingCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PowerTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MorphologyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BldgClutterCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TreeClutterCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TerrainTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OtherRadioCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Surveyor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SurveyTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TotalElecMtrCnt" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TotalIMUCnt" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocationAddnlInfoType", propOrder = {
    "hazardCode",
    "climateZoneCode",
    "thermalZoneCode",
    "trafficCtlCode",
    "mountingCode",
    "powerTypeCode",
    "morphologyCode",
    "bldgClutterCode",
    "treeClutterCode",
    "terrainTypeCode",
    "otherRadioCode",
    "surveyor",
    "surveyTime",
    "totalElecMtrCnt",
    "totalIMUCnt"
})
@XmlSeeAlso({
    EditLocationAddnlInfoType.class,
    GetLocationAddnlInfoType.class
})
public class LocationAddnlInfoType {

    @XmlElement(name = "HazardCode")
    protected String hazardCode;
    @XmlElement(name = "ClimateZoneCode")
    protected String climateZoneCode;
    @XmlElement(name = "ThermalZoneCode")
    protected String thermalZoneCode;
    @XmlElement(name = "TrafficCtlCode")
    protected Integer trafficCtlCode;
    @XmlElement(name = "MountingCode")
    protected String mountingCode;
    @XmlElement(name = "PowerTypeCode")
    protected String powerTypeCode;
    @XmlElement(name = "MorphologyCode")
    protected String morphologyCode;
    @XmlElement(name = "BldgClutterCode")
    protected String bldgClutterCode;
    @XmlElement(name = "TreeClutterCode")
    protected String treeClutterCode;
    @XmlElement(name = "TerrainTypeCode")
    protected String terrainTypeCode;
    @XmlElement(name = "OtherRadioCode")
    protected String otherRadioCode;
    @XmlElement(name = "Surveyor")
    protected String surveyor;
    @XmlElement(name = "SurveyTime")
    protected String surveyTime;
    @XmlElement(name = "TotalElecMtrCnt")
    protected Integer totalElecMtrCnt;
    @XmlElement(name = "TotalIMUCnt")
    protected Integer totalIMUCnt;

    /**
     * Gets the value of the hazardCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHazardCode() {
        return hazardCode;
    }

    /**
     * Sets the value of the hazardCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHazardCode(String value) {
        this.hazardCode = value;
    }

    /**
     * Gets the value of the climateZoneCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClimateZoneCode() {
        return climateZoneCode;
    }

    /**
     * Sets the value of the climateZoneCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClimateZoneCode(String value) {
        this.climateZoneCode = value;
    }

    /**
     * Gets the value of the thermalZoneCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThermalZoneCode() {
        return thermalZoneCode;
    }

    /**
     * Sets the value of the thermalZoneCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThermalZoneCode(String value) {
        this.thermalZoneCode = value;
    }

    /**
     * Gets the value of the trafficCtlCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTrafficCtlCode() {
        return trafficCtlCode;
    }

    /**
     * Sets the value of the trafficCtlCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTrafficCtlCode(Integer value) {
        this.trafficCtlCode = value;
    }

    /**
     * Gets the value of the mountingCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMountingCode() {
        return mountingCode;
    }

    /**
     * Sets the value of the mountingCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMountingCode(String value) {
        this.mountingCode = value;
    }

    /**
     * Gets the value of the powerTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPowerTypeCode() {
        return powerTypeCode;
    }

    /**
     * Sets the value of the powerTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPowerTypeCode(String value) {
        this.powerTypeCode = value;
    }

    /**
     * Gets the value of the morphologyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMorphologyCode() {
        return morphologyCode;
    }

    /**
     * Sets the value of the morphologyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMorphologyCode(String value) {
        this.morphologyCode = value;
    }

    /**
     * Gets the value of the bldgClutterCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBldgClutterCode() {
        return bldgClutterCode;
    }

    /**
     * Sets the value of the bldgClutterCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBldgClutterCode(String value) {
        this.bldgClutterCode = value;
    }

    /**
     * Gets the value of the treeClutterCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTreeClutterCode() {
        return treeClutterCode;
    }

    /**
     * Sets the value of the treeClutterCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTreeClutterCode(String value) {
        this.treeClutterCode = value;
    }

    /**
     * Gets the value of the terrainTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerrainTypeCode() {
        return terrainTypeCode;
    }

    /**
     * Sets the value of the terrainTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerrainTypeCode(String value) {
        this.terrainTypeCode = value;
    }

    /**
     * Gets the value of the otherRadioCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherRadioCode() {
        return otherRadioCode;
    }

    /**
     * Sets the value of the otherRadioCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherRadioCode(String value) {
        this.otherRadioCode = value;
    }

    /**
     * Gets the value of the surveyor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurveyor() {
        return surveyor;
    }

    /**
     * Sets the value of the surveyor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurveyor(String value) {
        this.surveyor = value;
    }

    /**
     * Gets the value of the surveyTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurveyTime() {
        return surveyTime;
    }

    /**
     * Sets the value of the surveyTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurveyTime(String value) {
        this.surveyTime = value;
    }

    /**
     * Gets the value of the totalElecMtrCnt property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTotalElecMtrCnt() {
        return totalElecMtrCnt;
    }

    /**
     * Sets the value of the totalElecMtrCnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTotalElecMtrCnt(Integer value) {
        this.totalElecMtrCnt = value;
    }

    /**
     * Gets the value of the totalIMUCnt property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTotalIMUCnt() {
        return totalIMUCnt;
    }

    /**
     * Sets the value of the totalIMUCnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTotalIMUCnt(Integer value) {
        this.totalIMUCnt = value;
    }

}
