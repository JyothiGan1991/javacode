package com.coned.ls.domain;

import java.util.List;

/**
 * 
 * Class to store borough and eventName for the event.
 *
 */
public class OpenEvent {

	private String borough;
	private List<String> eventName;
	
	public OpenEvent() {
		super();
	}
	public OpenEvent(String borough, List<String> eventName) {
		super();
		this.borough = borough;
		this.eventName = eventName;
	}
	
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public List<String> getEventName() {
		return eventName;
	}
	public void setEventName(List<String> eventName) {
		this.eventName = eventName;
	}	
	@Override
	public String toString() {
		return "OpenEvent [borough=" + borough + ", eventName=" + eventName
				+ "]";
	}
}
