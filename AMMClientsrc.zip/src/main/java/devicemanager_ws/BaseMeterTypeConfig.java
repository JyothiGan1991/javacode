
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseMeterTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseMeterTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Class" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RolloverPoint" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="FormType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VoltType" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MeterModeType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="IsNetByteOrder" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="MeterLineFreq" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MeterKH" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterKT" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterCA" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterTV" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseMeterTypeConfig", propOrder = {
    "configName",
    "mfgCode",
    "mfgName",
    "mfgModel",
    "softwareVersion",
    "softwareRev",
    "softwarePatch",
    "hardwareVersion",
    "hardwareRev",
    "hardwarePatch",
    "clazz",
    "rolloverPoint",
    "formType",
    "baseType",
    "voltType",
    "meterModeType",
    "isNetByteOrder",
    "meterLineFreq",
    "meterKH",
    "meterKT",
    "meterCA",
    "meterTV"
})
@XmlSeeAlso({
    MeterTypeConfig.class
})
public class BaseMeterTypeConfig {

    @XmlElement(name = "ConfigName")
    protected String configName;
    @XmlElement(name = "MfgCode", required = true)
    protected String mfgCode;
    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "MfgModel")
    protected String mfgModel;
    @XmlElement(name = "SoftwareVersion")
    protected String softwareVersion;
    @XmlElement(name = "SoftwareRev")
    protected String softwareRev;
    @XmlElement(name = "SoftwarePatch")
    protected String softwarePatch;
    @XmlElement(name = "HardwareVersion")
    protected String hardwareVersion;
    @XmlElement(name = "HardwareRev")
    protected String hardwareRev;
    @XmlElement(name = "HardwarePatch")
    protected String hardwarePatch;
    @XmlElement(name = "Class")
    protected Integer clazz;
    @XmlElement(name = "RolloverPoint")
    protected Integer rolloverPoint;
    @XmlElement(name = "FormType")
    protected String formType;
    @XmlElement(name = "BaseType")
    protected String baseType;
    @XmlElement(name = "VoltType")
    protected Long voltType;
    @XmlElement(name = "MeterModeType")
    protected MeterModeType meterModeType;
    @XmlElement(name = "IsNetByteOrder")
    protected Boolean isNetByteOrder;
    @XmlElement(name = "MeterLineFreq")
    protected Integer meterLineFreq;
    @XmlElement(name = "MeterKH")
    protected Double meterKH;
    @XmlElement(name = "MeterKT")
    protected Double meterKT;
    @XmlElement(name = "MeterCA")
    protected Double meterCA;
    @XmlElement(name = "MeterTV")
    protected Double meterTV;

    /**
     * Gets the value of the configName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigName() {
        return configName;
    }

    /**
     * Sets the value of the configName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigName(String value) {
        this.configName = value;
    }

    /**
     * Gets the value of the mfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgCode() {
        return mfgCode;
    }

    /**
     * Sets the value of the mfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgCode(String value) {
        this.mfgCode = value;
    }

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the mfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgModel() {
        return mfgModel;
    }

    /**
     * Sets the value of the mfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgModel(String value) {
        this.mfgModel = value;
    }

    /**
     * Gets the value of the softwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareVersion() {
        return softwareVersion;
    }

    /**
     * Sets the value of the softwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareVersion(String value) {
        this.softwareVersion = value;
    }

    /**
     * Gets the value of the softwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareRev() {
        return softwareRev;
    }

    /**
     * Sets the value of the softwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareRev(String value) {
        this.softwareRev = value;
    }

    /**
     * Gets the value of the softwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwarePatch() {
        return softwarePatch;
    }

    /**
     * Sets the value of the softwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwarePatch(String value) {
        this.softwarePatch = value;
    }

    /**
     * Gets the value of the hardwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareVersion() {
        return hardwareVersion;
    }

    /**
     * Sets the value of the hardwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareVersion(String value) {
        this.hardwareVersion = value;
    }

    /**
     * Gets the value of the hardwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareRev() {
        return hardwareRev;
    }

    /**
     * Sets the value of the hardwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareRev(String value) {
        this.hardwareRev = value;
    }

    /**
     * Gets the value of the hardwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwarePatch() {
        return hardwarePatch;
    }

    /**
     * Sets the value of the hardwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwarePatch(String value) {
        this.hardwarePatch = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClazz(Integer value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the rolloverPoint property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRolloverPoint() {
        return rolloverPoint;
    }

    /**
     * Sets the value of the rolloverPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRolloverPoint(Integer value) {
        this.rolloverPoint = value;
    }

    /**
     * Gets the value of the formType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormType() {
        return formType;
    }

    /**
     * Sets the value of the formType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormType(String value) {
        this.formType = value;
    }

    /**
     * Gets the value of the baseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseType() {
        return baseType;
    }

    /**
     * Sets the value of the baseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseType(String value) {
        this.baseType = value;
    }

    /**
     * Gets the value of the voltType property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltType() {
        return voltType;
    }

    /**
     * Sets the value of the voltType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltType(Long value) {
        this.voltType = value;
    }

    /**
     * Gets the value of the meterModeType property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getMeterModeType() {
        return meterModeType;
    }

    /**
     * Sets the value of the meterModeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setMeterModeType(MeterModeType value) {
        this.meterModeType = value;
    }

    /**
     * Gets the value of the isNetByteOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsNetByteOrder() {
        return isNetByteOrder;
    }

    /**
     * Sets the value of the isNetByteOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsNetByteOrder(Boolean value) {
        this.isNetByteOrder = value;
    }

    /**
     * Gets the value of the meterLineFreq property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMeterLineFreq() {
        return meterLineFreq;
    }

    /**
     * Sets the value of the meterLineFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMeterLineFreq(Integer value) {
        this.meterLineFreq = value;
    }

    /**
     * Gets the value of the meterKH property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterKH() {
        return meterKH;
    }

    /**
     * Sets the value of the meterKH property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterKH(Double value) {
        this.meterKH = value;
    }

    /**
     * Gets the value of the meterKT property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterKT() {
        return meterKT;
    }

    /**
     * Sets the value of the meterKT property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterKT(Double value) {
        this.meterKT = value;
    }

    /**
     * Gets the value of the meterCA property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterCA() {
        return meterCA;
    }

    /**
     * Sets the value of the meterCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterCA(Double value) {
        this.meterCA = value;
    }

    /**
     * Gets the value of the meterTV property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterTV() {
        return meterTV;
    }

    /**
     * Sets the value of the meterTV property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterTV(Double value) {
        this.meterTV = value;
    }

}
