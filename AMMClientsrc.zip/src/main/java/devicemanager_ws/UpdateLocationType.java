
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateLocationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateLocationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UtilPremiseID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DefinedLocationType" minOccurs="0"/&gt;
 *         &lt;element name="DescLong" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DescShort" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocationRouteID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Address1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Address2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="City" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="State" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="PostalCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="CountryID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *           &lt;element name="CountryCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="RegionCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="CrossStreet" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableTimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="RateProgramID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="TBPageNum" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="TBCoordID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocLongitude" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="LocLatitude" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="LocHeight" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="LocGISMapCoords" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocGISGridCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocGISGridCoords" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocExtUrl" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableAnyURIArrayType" minOccurs="0"/&gt;
 *         &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="DistNetwork" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDistNetworkType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePoint" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableServicePtType" minOccurs="0"/&gt;
 *         &lt;element name="Contacts" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDevContactListType" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute4" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute5" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateLocationType", propOrder = {
    "utilPremiseID",
    "locationType",
    "descLong",
    "descShort",
    "locationRouteID",
    "address1",
    "address2",
    "city",
    "state",
    "postalCode",
    "countryID",
    "countryCode",
    "regionCode",
    "crossStreet",
    "timeZoneID",
    "rateProgramID",
    "tbPageNum",
    "tbCoordID",
    "locLongitude",
    "locLatitude",
    "locHeight",
    "locGISMapCoords",
    "locGISGridCode",
    "locGISGridCoords",
    "locExtUrl",
    "locationID",
    "distNetwork",
    "servicePoint",
    "contacts",
    "locationAttribute1",
    "locationAttribute2",
    "locationAttribute3",
    "locationAttribute4",
    "locationAttribute5"
})
@XmlSeeAlso({
    NullableLocationType.class
})
public class UpdateLocationType {

    @XmlElement(name = "UtilPremiseID")
    protected String utilPremiseID;
    @XmlElement(name = "LocationType")
    protected DefinedLocationType locationType;
    @XmlElement(name = "DescLong")
    protected NullableString descLong;
    @XmlElement(name = "DescShort")
    protected NullableString descShort;
    @XmlElement(name = "LocationRouteID")
    protected NullableString locationRouteID;
    @XmlElement(name = "Address1")
    protected NullableString address1;
    @XmlElement(name = "Address2")
    protected NullableString address2;
    @XmlElement(name = "City")
    protected NullableString city;
    @XmlElement(name = "State")
    protected NullableString state;
    @XmlElement(name = "PostalCode")
    protected NullableString postalCode;
    @XmlElement(name = "CountryID")
    protected NullableInt countryID;
    @XmlElement(name = "CountryCode")
    protected NullableString countryCode;
    @XmlElement(name = "RegionCode")
    protected NullableString regionCode;
    @XmlElement(name = "CrossStreet")
    protected NullableString crossStreet;
    @XmlElement(name = "TimeZoneID")
    protected NullableTimeZoneType timeZoneID;
    @XmlElement(name = "RateProgramID")
    protected NullableString rateProgramID;
    @XmlElement(name = "TBPageNum")
    protected NullableInt tbPageNum;
    @XmlElement(name = "TBCoordID")
    protected NullableString tbCoordID;
    @XmlElement(name = "LocLongitude")
    protected NullableDouble locLongitude;
    @XmlElement(name = "LocLatitude")
    protected NullableDouble locLatitude;
    @XmlElement(name = "LocHeight")
    protected NullableDouble locHeight;
    @XmlElement(name = "LocGISMapCoords")
    protected NullableString locGISMapCoords;
    @XmlElement(name = "LocGISGridCode")
    protected NullableString locGISGridCode;
    @XmlElement(name = "LocGISGridCoords")
    protected NullableString locGISGridCoords;
    @XmlElement(name = "LocExtUrl")
    protected NullableAnyURIArrayType locExtUrl;
    @XmlElement(name = "LocationID")
    protected Long locationID;
    @XmlElement(name = "DistNetwork")
    protected NullableDistNetworkType distNetwork;
    @XmlElement(name = "ServicePoint")
    protected NullableServicePtType servicePoint;
    @XmlElement(name = "Contacts")
    protected NullableDevContactListType contacts;
    @XmlElement(name = "LocationAttribute1")
    protected NullableString locationAttribute1;
    @XmlElement(name = "LocationAttribute2")
    protected NullableString locationAttribute2;
    @XmlElement(name = "LocationAttribute3")
    protected NullableString locationAttribute3;
    @XmlElement(name = "LocationAttribute4")
    protected NullableString locationAttribute4;
    @XmlElement(name = "LocationAttribute5")
    protected NullableString locationAttribute5;

    /**
     * Gets the value of the utilPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilPremiseID() {
        return utilPremiseID;
    }

    /**
     * Sets the value of the utilPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilPremiseID(String value) {
        this.utilPremiseID = value;
    }

    /**
     * Gets the value of the locationType property.
     * 
     * @return
     *     possible object is
     *     {@link DefinedLocationType }
     *     
     */
    public DefinedLocationType getLocationType() {
        return locationType;
    }

    /**
     * Sets the value of the locationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DefinedLocationType }
     *     
     */
    public void setLocationType(DefinedLocationType value) {
        this.locationType = value;
    }

    /**
     * Gets the value of the descLong property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDescLong() {
        return descLong;
    }

    /**
     * Sets the value of the descLong property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDescLong(NullableString value) {
        this.descLong = value;
    }

    /**
     * Gets the value of the descShort property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDescShort() {
        return descShort;
    }

    /**
     * Sets the value of the descShort property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDescShort(NullableString value) {
        this.descShort = value;
    }

    /**
     * Gets the value of the locationRouteID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationRouteID() {
        return locationRouteID;
    }

    /**
     * Sets the value of the locationRouteID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationRouteID(NullableString value) {
        this.locationRouteID = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setAddress1(NullableString value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setAddress2(NullableString value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setCity(NullableString value) {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setState(NullableString value) {
        this.state = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setPostalCode(NullableString value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the countryID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getCountryID() {
        return countryID;
    }

    /**
     * Sets the value of the countryID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setCountryID(NullableInt value) {
        this.countryID = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setCountryCode(NullableString value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the regionCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRegionCode() {
        return regionCode;
    }

    /**
     * Sets the value of the regionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRegionCode(NullableString value) {
        this.regionCode = value;
    }

    /**
     * Gets the value of the crossStreet property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getCrossStreet() {
        return crossStreet;
    }

    /**
     * Sets the value of the crossStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setCrossStreet(NullableString value) {
        this.crossStreet = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableTimeZoneType }
     *     
     */
    public NullableTimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableTimeZoneType }
     *     
     */
    public void setTimeZoneID(NullableTimeZoneType value) {
        this.timeZoneID = value;
    }

    /**
     * Gets the value of the rateProgramID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRateProgramID() {
        return rateProgramID;
    }

    /**
     * Sets the value of the rateProgramID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRateProgramID(NullableString value) {
        this.rateProgramID = value;
    }

    /**
     * Gets the value of the tbPageNum property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getTBPageNum() {
        return tbPageNum;
    }

    /**
     * Sets the value of the tbPageNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setTBPageNum(NullableInt value) {
        this.tbPageNum = value;
    }

    /**
     * Gets the value of the tbCoordID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getTBCoordID() {
        return tbCoordID;
    }

    /**
     * Sets the value of the tbCoordID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setTBCoordID(NullableString value) {
        this.tbCoordID = value;
    }

    /**
     * Gets the value of the locLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getLocLongitude() {
        return locLongitude;
    }

    /**
     * Sets the value of the locLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setLocLongitude(NullableDouble value) {
        this.locLongitude = value;
    }

    /**
     * Gets the value of the locLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getLocLatitude() {
        return locLatitude;
    }

    /**
     * Sets the value of the locLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setLocLatitude(NullableDouble value) {
        this.locLatitude = value;
    }

    /**
     * Gets the value of the locHeight property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getLocHeight() {
        return locHeight;
    }

    /**
     * Sets the value of the locHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setLocHeight(NullableDouble value) {
        this.locHeight = value;
    }

    /**
     * Gets the value of the locGISMapCoords property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocGISMapCoords() {
        return locGISMapCoords;
    }

    /**
     * Sets the value of the locGISMapCoords property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocGISMapCoords(NullableString value) {
        this.locGISMapCoords = value;
    }

    /**
     * Gets the value of the locGISGridCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocGISGridCode() {
        return locGISGridCode;
    }

    /**
     * Sets the value of the locGISGridCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocGISGridCode(NullableString value) {
        this.locGISGridCode = value;
    }

    /**
     * Gets the value of the locGISGridCoords property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocGISGridCoords() {
        return locGISGridCoords;
    }

    /**
     * Sets the value of the locGISGridCoords property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocGISGridCoords(NullableString value) {
        this.locGISGridCoords = value;
    }

    /**
     * Gets the value of the locExtUrl property.
     * 
     * @return
     *     possible object is
     *     {@link NullableAnyURIArrayType }
     *     
     */
    public NullableAnyURIArrayType getLocExtUrl() {
        return locExtUrl;
    }

    /**
     * Sets the value of the locExtUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableAnyURIArrayType }
     *     
     */
    public void setLocExtUrl(NullableAnyURIArrayType value) {
        this.locExtUrl = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the distNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDistNetworkType }
     *     
     */
    public NullableDistNetworkType getDistNetwork() {
        return distNetwork;
    }

    /**
     * Sets the value of the distNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDistNetworkType }
     *     
     */
    public void setDistNetwork(NullableDistNetworkType value) {
        this.distNetwork = value;
    }

    /**
     * Gets the value of the servicePoint property.
     * 
     * @return
     *     possible object is
     *     {@link NullableServicePtType }
     *     
     */
    public NullableServicePtType getServicePoint() {
        return servicePoint;
    }

    /**
     * Sets the value of the servicePoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableServicePtType }
     *     
     */
    public void setServicePoint(NullableServicePtType value) {
        this.servicePoint = value;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDevContactListType }
     *     
     */
    public NullableDevContactListType getContacts() {
        return contacts;
    }

    /**
     * Sets the value of the contacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDevContactListType }
     *     
     */
    public void setContacts(NullableDevContactListType value) {
        this.contacts = value;
    }

    /**
     * Gets the value of the locationAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationAttribute1() {
        return locationAttribute1;
    }

    /**
     * Sets the value of the locationAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationAttribute1(NullableString value) {
        this.locationAttribute1 = value;
    }

    /**
     * Gets the value of the locationAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationAttribute2() {
        return locationAttribute2;
    }

    /**
     * Sets the value of the locationAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationAttribute2(NullableString value) {
        this.locationAttribute2 = value;
    }

    /**
     * Gets the value of the locationAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationAttribute3() {
        return locationAttribute3;
    }

    /**
     * Sets the value of the locationAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationAttribute3(NullableString value) {
        this.locationAttribute3 = value;
    }

    /**
     * Gets the value of the locationAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationAttribute4() {
        return locationAttribute4;
    }

    /**
     * Sets the value of the locationAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationAttribute4(NullableString value) {
        this.locationAttribute4 = value;
    }

    /**
     * Gets the value of the locationAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocationAttribute5() {
        return locationAttribute5;
    }

    /**
     * Sets the value of the locationAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocationAttribute5(NullableString value) {
        this.locationAttribute5 = value;
    }

}
