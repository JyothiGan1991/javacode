package com.coned.model;

import java.sql.Date;
import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_reject_event_details", schema = "AMI_LOAD_SHEDDING")
public class RejectEventListDetails {

    @Id
//    @JsonIgnore
    @Column(name = "fk_finalized_event_id")
    private Long id;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "boro_muni")
    private String borough;
    
    @Column(name = "reject_time")
    private LocalDateTime rejectTime;
 
    @Column(name = "operator_ad_id")
    private String operatorAdId;
    
    public String getOperatorAdId() {
		return operatorAdId;
	}

	public void setOperatorAdId(String countOfMeters) {
		this.operatorAdId = operatorAdId;
	}

	public RejectEventListDetails() {

    }

    public RejectEventListDetails(String username, String token, LocalDateTime logintime) {
        this.eventName = username;
        this.borough = token;
        this.rejectTime = logintime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
   
    public String getEventname() {
        return eventName;
    }

    public void setEventname(String eventname) {
        this.eventName = eventname;
    }

    public String getBorough() {
        return borough;
    }

    public void setBorough(String borough) {
        this.borough = borough;
    }
    
    public LocalDateTime getRejectTime() {
        return rejectTime;
    }

    public void setRejectTime(LocalDateTime rejecttime) {
        this.rejectTime = rejecttime;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", rejectTime=" + rejectTime + "]";
    }
}
