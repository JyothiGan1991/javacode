
package com.coned.rsmc.service;

import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.coned.rsmc.AppRunner;
import com.coned.rsmc.domain.Meter;

public class Task implements Callable<Meter> {
	private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

	private final RestTemplate restTemplate;
	private final Meter meter;
	private String url;

	public Task(Meter m, String connect_meter_url, RestTemplate template) {
		this.restTemplate = template;
		this.meter = m;
		this.url = connect_meter_url;
	}

	/**
	 * Invoke RSM connect operation
	 */
	@Override
	public Meter call() throws Exception {
		logger.info("Thread {} -> Invoke connect for meter {} with MAC ID {}", Thread.currentThread().getName(),
				meter.getMeterNumber(), meter.getMacAddress());

		Long jobId = 0L;
		try {
			
			Object obj = restTemplate.getForObject(url, Object.class,
					new Object[] { this.meter.getMeterNumber(), this.meter.getMacAddress() });
			
			jobId = Long.parseLong(obj.toString());
			
		} catch (Exception e) {
			logger.error("Error invoking the connect for meter [" + this.meter.getMeterNumber() + "] and mac ["
					+ this.meter.getMacAddress() + "] ", e);
		}
		logger.info("Thread {} -> Job Id {}", Thread.currentThread().getName(), jobId);
	
		meter.setJobId(jobId);
		meter.setConnectTime(Timestamp.from(ZonedDateTime.now(ZoneId.of("US/Eastern")).toInstant()));
		return this.meter;
	}

}
