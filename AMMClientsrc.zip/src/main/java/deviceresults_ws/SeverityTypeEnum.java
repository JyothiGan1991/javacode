
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SeverityTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SeverityTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_EMERGENCY"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_ALERT"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_CRITICAL"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_ERROR"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_WARNING"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_NOTICE"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_INFORMATION"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_DEBUG"/&gt;
 *     &lt;enumeration value="EVENT_SEVERITY_CLEAR"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SeverityTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum SeverityTypeEnum {

    EVENT_SEVERITY_EMERGENCY("EVENT_SEVERITY_EMERGENCY"),
    EVENT_SEVERITY_ALERT("EVENT_SEVERITY_ALERT"),
    EVENT_SEVERITY_CRITICAL("EVENT_SEVERITY_CRITICAL"),
    EVENT_SEVERITY_ERROR("EVENT_SEVERITY_ERROR"),
    EVENT_SEVERITY_WARNING("EVENT_SEVERITY_WARNING"),
    EVENT_SEVERITY_NOTICE("EVENT_SEVERITY_NOTICE"),
    EVENT_SEVERITY_INFORMATION("EVENT_SEVERITY_INFORMATION"),
    EVENT_SEVERITY_DEBUG("EVENT_SEVERITY_DEBUG"),
    EVENT_SEVERITY_CLEAR("EVENT_SEVERITY_CLEAR"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    SeverityTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SeverityTypeEnum fromValue(String v) {
        for (SeverityTypeEnum c: SeverityTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
