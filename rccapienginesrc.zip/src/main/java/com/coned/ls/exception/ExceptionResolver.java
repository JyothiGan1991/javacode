package com.coned.ls.exception;

import java.util.Date;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.ResourceAccessException;

import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 
 *
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class ExceptionResolver extends ResponseEntityExceptionHandler {
	
	private static final Logger LOGGER = LogManager.getLogger(ExceptionResolver.class);
	
	/*
     * Handle Exception. This handler is called when an exception occured during execution.
     * 
     * @param request HttpServletRequest
     * @param ex      Exception
     * @return        ResponseEntity
	 */ 
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleException(HttpServletRequest request, Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse();
        
        errorResponse.setTitle("Exception");
        errorResponse.setType("Exception");
        errorResponse.setTimestamp(new Date());
        errorResponse.setMethod(request.getMethod());
        errorResponse.setDetail("An exception occured during execution");
        errorResponse.setDebugMessage(ex.getMessage());
        LOGGER.error("adding the error detail here:", ex);
        
        return buildResponseEntity(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(OperatorAuthorizationException.class)
    public ResponseEntity<Object> handleExceptionForAuthorization(HttpServletRequest request, Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse();
        
        errorResponse.setTitle("Exception");
        errorResponse.setType("Exception");
        errorResponse.setTimestamp(new Date());
        errorResponse.setMethod(request.getMethod());
        errorResponse.setDetail("An exception occured during execution");
        errorResponse.setDebugMessage(ex.getMessage());
        
        return buildResponseEntity(errorResponse, HttpStatus.UNAUTHORIZED);
    }


	/*
     * Handle EmptyResultDataAccessException. This handler is called when expected and actual number of records 
     *                                        found by database operation are different.
     * 
     * @param request HttpServletRequest
     * @param ex      IncorrectResultSizeDataAccessException
     * @return        ResponseEntity
	 */ 	
    @ExceptionHandler(IncorrectResultSizeDataAccessException.class)
    public ResponseEntity<Object> handleIncorrectResultSizeDataAccessException(HttpServletRequest request, IncorrectResultSizeDataAccessException ex) {
    	 ErrorResponse errorResponse = new ErrorResponse();
    	 
         errorResponse.setTitle("Incorrect records");
         errorResponse.setType("IncorrectResultSizeDataAccessException");
         errorResponse.setTimestamp(new Date());
         errorResponse.setMethod(request.getMethod());
         errorResponse.setDetail("No record found");
         errorResponse.setDebugMessage(ex.getMessage());
         
         return buildResponseEntity(errorResponse, HttpStatus.NOT_ACCEPTABLE);
    }
   
	/*
     * Handle EmptyResultDataAccessException. This handler is called when no record found by database operation.
     * 
     * @param request HttpServletRequest
     * @param ex      EmptyResultDataAccessException
     * @return        ResponseEntity
	 */    
    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseEntity<Object> handleEmptyResultDataAccessException(HttpServletRequest request, EmptyResultDataAccessException ex) {
    	 ErrorResponse errorResponse = new ErrorResponse();
    	 
         errorResponse.setTitle("No record");
         errorResponse.setType("EmptyResultDataAccessException");
         errorResponse.setTimestamp(new Date());
         errorResponse.setMethod(request.getMethod());
         errorResponse.setDetail("No record found");
         errorResponse.setDebugMessage(ex.getMessage());
         
         return buildResponseEntity(errorResponse, HttpStatus.NOT_FOUND);
    }

	/*
     * Handle ResourceAccessException. This handler is called when the user is not authorized to access API.
     * 
     * @param request HttpServletRequest
     * @param ex      IllegalArgumentException
     * @return        ResponseEntity
	 */
    @ExceptionHandler(ResourceAccessException.class)
    public ResponseEntity<Object> handleResourceAccessException(HttpServletRequest request, ResourceAccessException ex) {
    	 ErrorResponse errorResponse = new ErrorResponse();
    	 
         errorResponse.setTitle("Unauthorized Exception");
         errorResponse.setType("ResourceAccessException");
         errorResponse.setTimestamp(new Date());
         errorResponse.setMethod(request.getMethod());
         errorResponse.setDetail("User not authorized to access resource.");
         errorResponse.setDebugMessage(ex.getMessage());
         
         return buildResponseEntity(errorResponse, HttpStatus.UNAUTHORIZED);
    }

    /*
     * Handle IllegalArgumentException. This handler is called when invalid arguments are used in the API request.
     * 
     * @param request HttpServletRequest
     * @param ex      IllegalArgumentException
     * @return        ResponseEntity
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleIllegalArgumentException(HttpServletRequest request, IllegalArgumentException ex) {
    	 ErrorResponse errorResponse = new ErrorResponse();
    	 
         errorResponse.setTitle("Validation Errors");
         errorResponse.setType("IllegalArgumentException");
         errorResponse.setTimestamp(new Date());
         errorResponse.setMethod(request.getMethod());
         errorResponse.setDetail("Invalid argument found in the request.");
         errorResponse.setDebugMessage(ex.getMessage());

         return buildResponseEntity(errorResponse, HttpStatus.BAD_REQUEST);
    }
    


    /*
     * Handle HttpClientException. This handler is called when call to RCC API engine was unsuccessful.
     * 
     * @param request HttpServletRequest
     * @param ex      HttpClientException
     * @return        ResponseEntity
     */
    @ExceptionHandler(HttpClientException.class)
    public ResponseEntity<Object> handleHttpClientException(HttpServletRequest request, HttpClientException ex) throws Exception {
    	ObjectMapper mapper = new ObjectMapper();
    	ErrorResponse errorResponse = mapper.readValue(ex.getMessage(), ErrorResponse.class);
    	
    	errorResponse.setDetail("Exception response from RCC API Engine.");
    	errorResponse.setTitle("RCC API Engine Exception");
    	errorResponse.setType("HttpClientException");
    	
        return ResponseEntity
                .status(ex.getHttpStatus())
                .body(errorResponse);
    }
    
    private ResponseEntity<Object> buildResponseEntity(ErrorResponse errorResponse, HttpStatus httpStatus) {
        return ResponseEntity
                .status(httpStatus)
                .body(errorResponse);
    }
}