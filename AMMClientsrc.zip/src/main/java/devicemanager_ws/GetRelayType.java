
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetRelayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetRelayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RelayType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RelayTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RelayTypeConfig" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetRelayType", propOrder = {
    "relayTypeConfig"
})
public class GetRelayType
    extends RelayType
{

    @XmlElement(name = "RelayTypeConfig")
    protected RelayTypeConfig relayTypeConfig;

    /**
     * Gets the value of the relayTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link RelayTypeConfig }
     *     
     */
    public RelayTypeConfig getRelayTypeConfig() {
        return relayTypeConfig;
    }

    /**
     * Sets the value of the relayTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelayTypeConfig }
     *     
     */
    public void setRelayTypeConfig(RelayTypeConfig value) {
        this.relayTypeConfig = value;
    }

}
