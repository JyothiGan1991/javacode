
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 *               Date is a string containing the date, formatted as
 *               yyyy-MM-ddTHH:mm:ss.(SSS)?((+|-)tt:tt).
 *               This conforms to ISO 8601.
 *               
 *               For example:
 *               2005-12-15T13:35:03
 *               2005-12-15T13:35:03-08:00
 *               2005-12-15T13:35:03.123
 *               2005-12-15T13:35:03.123-08:00
 *               
 *               Localized date is a string containing the 
 *               date formatted for the user's locale.
 *               The formatting is the Java default for the locale
 *               for the MT installation.
 *             
 * 
 * <p>Java class for TimestampType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TimestampType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LocalizedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TimestampType", propOrder = {
    "date",
    "localizedDate"
})
public class TimestampType {

    @XmlElement(name = "Date", required = true)
    protected String date;
    @XmlElement(name = "LocalizedDate", required = true)
    protected String localizedDate;

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(String value) {
        this.date = value;
    }

    /**
     * Gets the value of the localizedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedDate() {
        return localizedDate;
    }

    /**
     * Sets the value of the localizedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedDate(String value) {
        this.localizedDate = value;
    }

}
