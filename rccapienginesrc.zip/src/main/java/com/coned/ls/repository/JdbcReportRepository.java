package com.coned.ls.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Configuration
@PropertySource("file:${query.file.path}/db-queries.properties")
public class JdbcReportRepository implements ReportRepository {
	private static final Logger logger = LoggerFactory.getLogger(JdbcReportRepository.class);
	ObjectName[] atnProviders = null;
	ObjectName mBeanTypeService = null;

	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	@Autowired
	private Environment env;

	public List<Map<String, Object>> getCWRData(Map<String, Object> payload) {
		logger.debug("---------------------- START - getCWRData() ------------------------");
		try {
//			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			String event_name = (String) payload.get("eventName");
//			allFailedEvts.put("event_name", event_name);
			String boro_muni = (String) payload.get("boroMuni");
//			allFailedEvts.put("boro_muni", boro_muni);
			logger.debug("boro_muni? "+boro_muni+" event_name? "+event_name);
//			String qstr = "SELECT COUNT(*) FROM ami_load_shedding.LS_FINALIZE_EVENT_LIST fin WHERE fin.event_name='"+event_name+"' AND fin.boro_muni='"+boro_muni+"'";
//			logger.debug("qstr? " + qstr);
//			int total_meters = oracleJdbcTemplate.queryForObject(qstr, Integer.class);

//			allFailedEvts.put("meter_count", total_meters);
			
            String qstr = env.getProperty("CUSTOMER_WARNING_REPORT");
			
			logger.debug("qstr? " + qstr);
			
			NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(oracleJdbcTemplate.getDataSource());
			MapSqlParameterSource params = new MapSqlParameterSource();
			
			params.addValue("eventName", event_name);
			params.addValue("boroMuni",boro_muni);
			
			
			List<Map<String, Object>> rows = namedParamTemplate.queryForList(qstr, params);
			logger.debug("NumOfFailedMeters ? " + rows.size());

			
//			allFailedEvts.put("exception_count", rows.size());
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map row : rows) {
				Map<String, Object> events = new HashMap();
				events.put("name", (String) row.get("Customer_name"));
				events.put("telephone", (String) row.get("phone1"));
				events.put("building_num", (String) row.get("building_num"));
				events.put("service_address", (String) row.get("service_address"));
				events.put("boro_muni", (String) row.get("boro_muni"));
				events.put("critical", "");
				
				events.put("weighted_count", 1);
				events.put("account_number", (String) row.get("account_number"));
				events.put("meter_number", (String) row.get("meter_number"));
				events.put("restore_date", "");
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
//			allFailedEvts.put("meters", result);
			logger.debug(" -- CWRData size: " + rows.size());
			logger.debug("---------------------- END - getCWRData() ------------------------");
			return result;
		} catch (Exception e) {
			logger.error("**Exception getCWRData(): " + e);
		}
		return null;
	}
	public List<Map<String, Object>> getCDRData(Map<String, Object> payload) {
		logger.debug("---------------------- START - getCDRData() ------------------------");
		try {
//			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			String event_name = (String) payload.get("eventName");
//			allFailedEvts.put("event_name", event_name);
			String boro_muni = (String) payload.get("boroMuni");
//			allFailedEvts.put("boro_muni", boro_muni);
			logger.debug("boro_muni"+boro_muni+" event_name? "+event_name);
//			String qstr = "SELECT COUNT(*) FROM ami_load_shedding.ls_execute_event_list fin WHERE fin.event_name='"+event_name+"' AND fin.boro_muni='"+boro_muni+"'";
			
//			logger.debug("qstr? " + qstr);
//			int total_meters = oracleJdbcTemplate.queryForObject(qstr, Integer.class);

//			allFailedEvts.put("meter_count", total_meters);
			
		/*	String qstr = "SELECT DISTINCT mel.Customer_name,mel.phone1, mel.building_num, mel.service_address, mel.boro_muni,'' AS Critical, 1 AS \"Weighted Count\" , mel.account_number, mel.meter_number "
					+ "FROM ami_load_shedding.ls_execute_event_list fin "
					+ "INNER JOIN ami_load_shedding.ls_execute_event_list_details find ON find.boro_muni = fin.boro_muni AND find.event_name = fin.event_name "
					+ "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.boro_muni = fin.boro_muni AND mel.event_name = fin.event_name AND mel.meter_number = fin.meter_number "
					+ "WHERE fin.event_name='"+event_name+"' AND fin.boro_muni='"+boro_muni+"'";
			
			logger.debug("qstr? " + qstr);
			List<Map<String, Object>> rows = oracleJdbcTemplate.queryForList(qstr);
			logger.debug("NumOfFailedMeters ? " + rows.size()); */
			
			String qstr = env.getProperty("CUSTOMER_DISCONNECT_REPORT");
			
			logger.debug("qstr? " + qstr);
			
			NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(oracleJdbcTemplate.getDataSource());
			MapSqlParameterSource params = new MapSqlParameterSource();
			
			params.addValue("eventName", event_name);
			params.addValue("boroMuni",boro_muni);
			
			
			List<Map<String, Object>> rows = namedParamTemplate.queryForList(qstr, params);
			logger.debug("NumOfFailedMeters ? " + rows.size());
			
//			allFailedEvts.put("exception_count", rows.size());
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map row : rows) {
				
				Map<String, Object> events = new HashMap();
				events.put("name", (String) row.get("Customer_name"));
				events.put("telephone", (String) row.get("phone1"));
				events.put("building_num", (String) row.get("building_num"));
				events.put("service_address", (String) row.get("service_address"));
				events.put("boro_muni", (String) row.get("boro_muni"));
				events.put("critical", "");
				
				events.put("weighted_count", 1);
				events.put("account_number", (String) row.get("account_number"));
				events.put("meter_number", (String) row.get("meter_number"));
				events.put("restore_date", "");
				events = replaceNullValues(events, "");		
				result.add(events);
			}
//			allFailedEvts.put("meters", result);
			logger.debug(" -- CDRData size: " + rows.size());
			logger.debug("---------------------- END - getCDRData() ------------------------");
//			return allFailedEvts;
			return result;
		} catch (Exception e) {
			logger.error("**Exception getCDRData(): " + e);
		}
		return null;
	}
	/*
		public List<Map<String, Object>> getCRRData(Map<String, Object> payload) {
		logger.debug("---------------------- START - getCRRData() ------------------------");
		try {
//			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			String event_name = (String) payload.get("eventName");
//			allFailedEvts.put("event_name", event_name);
			String boro_muni = (String) payload.get("boroMuni");
//			allFailedEvts.put("boro_muni", boro_muni);
			String sub_event_name = (String) payload.get("subEventName");
//			allFailedEvts.put("sub_event_name", sub_event_name);
			logger.debug("boro_muni"+boro_muni+" event_name? "+event_name);
//			String qstr = "SELECT COUNT(*) FROM ami_load_shedding.ls_execute_event_list_connect fin WHERE fin.event_name='"+event_name+"' AND fin.boro_muni='"+boro_muni+"' AND fin.sub_event_name='"+sub_event_name+"'";
			
//			logger.debug("qstr? " + qstr);
//			int total_meters = oracleJdbcTemplate.queryForObject(qstr, Integer.class);

//			allFailedEvts.put("meter_count", total_meters);
			
			String qstr = "SELECT DISTINCT mel.Customer_name,mel.phone1, mel.building_num, mel.service_address, mel.boro_muni,'' AS Critical, 1 AS \"Weighted Count\" , "
					+ "mel.account_number, mel.meter_number, msv.req_status "
					+ "FROM ami_load_shedding.lsb_meter_status_vw msv "
					+ "INNER JOIN ami_load_shedding.ls_execute_event_list_details find ON find.boro_muni = msv.boro_muni AND find.event_name = msv.event_name AND find.sub_event = msv.sub_event_name "
					+ "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.boro_muni = msv.boro_muni AND mel.event_name = msv.event_name AND mel.meter_number = msv.meter_number "
					+ "INNER JOIN ami_load_shedding.ls_execute_event_list_connect fin ON msv.boro_muni = fin.boro_muni  AND msv.event_name = fin.event_name AND msv.sub_event_name = fin.sub_event_name "
					+ "WHERE fin.boro_muni='"+boro_muni+"' AND fin.event_name='"+event_name+"' AND fin.sub_event_name='"+sub_event_name+"' AND find.event_type='C' AND msv.req_status='C' AND msv.request_type IN (2)";
			
			logger.debug("qstr? " + qstr);
			List<Map<String, Object>> rows = oracleJdbcTemplate.queryForList(qstr);
			logger.debug("NumOfFailedMeters ? " + rows.size());
			
//			allFailedEvts.put("exception_count", rows.size());
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map row : rows) {
				
				Map<String, Object> events = new HashMap();
				events.put("name", (String) row.get("Customer_name"));
				events.put("telephone", (String) row.get("phone1"));
				events.put("building_num", (String) row.get("building_num"));
				events.put("service_address", (String) row.get("service_address"));
				events.put("boro_muni", (String) row.get("boro_muni"));
				events.put("critical", "");
				
				events.put("weighted_count", 1);
				events.put("account_number", (String) row.get("account_number"));
				events.put("meter_number", (String) row.get("meter_number"));
				events.put("restore_date", "");
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
//			allFailedEvts.put("meters", result);
			logger.debug(" -- CRRData size: " + rows.size());
			logger.debug("---------------------- END - getCRRData() ------------------------");
//			return allFailedEvts;
			return result;
		} catch (Exception e) {
			logger.error("**Exception getCRRData(): " + e);
		}
		return null;
	}
	public Map<String, Object> getCERData(Map<String, Object> payload) {
		logger.debug("---------------------- START - getCERData() ------------------------");
		try {
			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			int req_type = 2;
			int opp_req_type = 1;
			String event_type = "C";
			String opp_event_type = "D";
			String event_name = (String) payload.get("eventName");
			allFailedEvts.put("event_name", event_name);
			String boro_muni = (String) payload.get("boroMuni");
			allFailedEvts.put("boro_muni", boro_muni);
			logger.debug("boro_muni"+boro_muni+" event_name? "+event_name);
			String qstr = "SELECT COUNT(*) FROM ami_load_shedding.ls_execute_event_list_connect eel WHERE eel.event_name='"+event_name+"' AND eel.boro_muni='"+boro_muni+"'";
			
			logger.debug("qstr? " + qstr);
			int total_meters = oracleJdbcTemplate.queryForObject(qstr, Integer.class);

			allFailedEvts.put("meter_count", total_meters);
			
			qstr = "SELECT DISTINCT msv.meter_number, msv.prv_cmd_status AS conn_prv_cmd_status, "
					+ "msv.meter_status as conn_meter_status, exc.execute_time AS conn_execute_time, "
					+ "mel.account_number, mel.building_num, mel.service_address, mel.cust_zip_code, "
					+ "disc_prv_cmd_status, disc_meter_status, disc_execute_time   "
					+ "FROM ami_load_shedding.LSB_METER_STATUS_VW msv  "
					+ "INNER JOIN ami_load_shedding.LS_EXECUTE_EVENT_LIST_DETAILS exc ON exc.boro_muni = msv.boro_muni AND exc.event_name = msv.event_name AND exc.sub_event = msv.sub_event_name "
					+ "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.boro_muni = msv.boro_muni AND mel.event_name = msv.event_name AND mel.meter_number = msv.meter_number "
					+ "LEFT JOIN (SELECT msv2.event_name, msv2.boro_muni, msv2.meter_number, msv2.prv_cmd_status AS disc_prv_cmd_status, "
					+ "msv2.meter_status AS disc_meter_status, exc2.execute_time as disc_execute_time "
					+ "FROM ami_load_shedding.LSB_METER_STATUS_VW msv2 "
					+ "INNER JOIN ami_load_shedding.LS_EXECUTE_EVENT_LIST_DETAILS exc2 ON exc2.event_name = msv2.event_name "
					+ "WHERE msv2.request_type IN ("+opp_req_type+") AND exc2.event_type='"+opp_event_type+"') sq "
					+ "ON sq.event_name=mel.event_name "
					+ "AND sq.boro_muni=mel.boro_muni AND sq.meter_number = mel.meter_number "
					+ "WHERE msv.req_status <> 'C' AND msv.request_type IN ("+req_type+") AND exc.event_type='"+event_type+"' AND "
					+ "msv.event_name='"+event_name+"' AND msv.boro_muni='"+boro_muni+"'";
			
			logger.debug("qstr? " + qstr);
			List<Map<String, Object>> rows = oracleJdbcTemplate.queryForList(qstr);
			logger.debug("Total_Exe_Meters:"+total_meters+ "NumOfFailedMeters ? " + rows.size());
			
			allFailedEvts.put("exception_count", rows.size());
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map row : rows) {
				Map<String, Object> events = new HashMap();
				events.put("meter_number", (String) row.get("meter_number"));
				events.put("prv_cmd_status", (String) row.get("conn_prv_cmd_status"));
				events.put("meter_status", (String) row.get("conn_meter_status"));

				Date executeTime = (Date) row.get("conn_execute_time");
				String executeTimeStr = "";
				if (executeTime != null)
					executeTimeStr = executeTime.toString();

				events.put("execute_time", executeTimeStr);
				events.put("account_number", (String) row.get("account_number"));
				events.put("building_num", (String) row.get("building_num"));

				events.put("service_address", (String) row.get("service_address"));
				events.put("cust_zip_code", (String) row.get("cust_zip_code"));
				
				events.put("disc_prv_cmd_status", (String) row.get("disc_prv_cmd_status"));
				events.put("disc_meter_status", (String) row.get("disc_meter_status"));
				executeTime = (Date) row.get("disc_execute_time");
				executeTimeStr = "";
				if (executeTime != null)
					executeTimeStr = executeTime.toString();
				events.put("disc_execute_time", executeTimeStr);
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
			allFailedEvts.put("meters", result);
			logger.debug(" -- CERData size: " + rows.size());
			logger.debug("---------------------- END - getCERData() ------------------------");
			return allFailedEvts;
		} catch (Exception e) {
			logger.error("**Exception getCERData(): " + e);
		}
		return null;
	} */
	
	public List<Map<String, Object>> getCRRData(String event_name,String boro_muni,String sub_event_name) {
		logger.debug("---------------------- START - getCRRData() ------------------------");
		try {
			
			String qstr = env.getProperty("CUSTOMER_RESTORE_REPORT");
			
			logger.debug("qstr? " + qstr);
			
			NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(oracleJdbcTemplate.getDataSource());
			MapSqlParameterSource params = new MapSqlParameterSource();
			logger.debug("Params are event name: " + event_name + " boro muni: "+ boro_muni + " sub event name: "+sub_event_name);
			params.addValue("event_name", event_name);
			params.addValue("boro_muni",boro_muni);
			params.addValue("sub_event_name",sub_event_name);
			
			List<Map<String, Object>> rows = namedParamTemplate.queryForList(qstr, params);
			logger.debug("NumOfCustomerRestore ? " + rows.size());
	
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map<String,Object> row : rows) {
				
				Map<String, Object> events = new HashMap<String,Object>();
				events.put("name", (String) row.get("Customer_name"));
				events.put("telephone", (String) row.get("phone1"));
				events.put("building_num", (String) row.get("building_num"));
				events.put("service_address", (String) row.get("service_address"));
				events.put("boro_muni", (String) row.get("boro_muni"));
				events.put("critical", "");
				
				events.put("weighted_count", 1);
				events.put("account_number", (String) row.get("account_number"));
				events.put("meter_number", (String) row.get("meter_number"));
				events.put("restore_date", "");
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
			logger.debug(" -- CRRData size: " + rows.size());
			logger.debug("---------------------- END - getCRRData() ------------------------");
			return result;
		} catch (Exception e) {
			logger.error("**Exception getCRRData(): " + e);
		}
		return null;
	}
	public Map<String, Object> getCERData(String event_name,String boro_muni) {
		logger.debug("---------------------- START - getCERData() ------------------------");
		try {
			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			allFailedEvts.put("event_name", event_name);
			allFailedEvts.put("boro_muni", boro_muni);
			logger.debug("boro_muni"+boro_muni+" event_name? "+event_name);
					
			NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(oracleJdbcTemplate.getDataSource());
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("event_name", event_name);
			params.addValue("boro_muni",boro_muni);
			
			int total_meters = namedParamTemplate.queryForObject(env.getProperty("GET_COUNT_CER"), params, Integer.class);
			
			allFailedEvts.put("meter_count", total_meters);
			
			List<Map<String, Object>> rows =  namedParamTemplate.queryForList(env.getProperty("CUSTOMER_EXCEPTION_REPORT"), params);					
			logger.debug("Total_Exe_Meters:"+total_meters+ "NumOfFailedMeters ? " + rows.size());
			
			allFailedEvts.put("exception_count", rows.size());
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map<String,Object> row : rows) {
				Map<String, Object> events = new HashMap<String, Object>();
				events.put("meter_number", (String) row.get("meter_number"));
				Date executeTime = (Date) row.get("conn_request_time");
				String executeTimeStr = "";
				if (executeTime != null)
					executeTimeStr = executeTime.toString();

				events.put("execute_time", executeTimeStr);
				
				Date disc_request_time = (Date) row.get("disc_request_time");
				String discTimeStr = "";
				if (disc_request_time != null)
					discTimeStr = disc_request_time.toString();

				events.put("disc_execute_time", discTimeStr);
				
				events.put("account_number", (String) row.get("account_number"));
				events.put("building_num", (String) row.get("building_num"));

				events.put("service_address", (String) row.get("service_address"));
				events.put("cust_zip_code", (String) row.get("cust_zip_code"));
				events.put("disc_operation_status", "");
				events.put("disc_meter_status", "");
				events.put("conn_meter_status", "");
				events.put("conn_operation_status", "");
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
			allFailedEvts.put("meters", result);
			logger.debug(" -- CERData size: " + rows.size());
			logger.debug("---------------------- END - getCERData() ------------------------");
			return allFailedEvts;
		} catch (Exception e) {
			logger.error("**Exception getCERData(): " + e);
		}
		return null;
	}
	
	public Map<String, Object> getCMRData(String event_name,String boro_muni) {
		logger.debug("---------------------- START - getCMRData() ------------------------");
		try {
			
			Map<String, Object> allFailedEvts = new HashMap<String, Object>();

			allFailedEvts.put("eventName", event_name);
			allFailedEvts.put("boroMuni", boro_muni);
			
			NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(oracleJdbcTemplate.getDataSource());
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("event_name", event_name);
			params.addValue("boro_muni",boro_muni);
			
			logger.debug("Params for CMR are event name: " + event_name + " boro muni: "+ boro_muni );			
			String qstr = env.getProperty("CONNECTED_METER_REPORT");			
			logger.debug("qstr? " + qstr);
			
			List<Map<String, Object>> rows =  namedParamTemplate.queryForList(qstr, params);			
			logger.debug("NumOfConecteddMeters ? " + rows.size());
			
			allFailedEvts.put("exceptionCount", rows.size());
			List<Map<String, Object>> responseMeters = new ArrayList<Map<String, Object>>();
					
			for (Map<String,Object> row : rows) {
				Map<String, Object> events = new HashMap<String, Object>();				
				
				events.put("customerZipCode", (String) row.get("customerZipCode"));
				events.put("demand", (String) row.get("demand"));
				events.put("buildingNumber", (String) row.get("buildingNumber"));
				events.put("feeder", (String) row.get("feeder"));
				events.put("transformer", (String) row.get("transformer"));
				events.put("structureName", (String) row.get("structureName"));
				events.put("serviceAddress", (String) row.get("serviceAddress"));
				events.put("eventName", (String) row.get("eventName"));				
				events.put("accountNumber", (String) row.get("accountNumber"));
				events.put("network", (String) row.get("network"));
				events.put("meterNumber", (String) row.get("meterNumber"));
				events.put("status", (String) row.get("status"));
				events.put("subEvent", (String) row.get("subEvent"));
				
				Date insertTime = (Date) row.get("insertTime");
				String insertTimeStr = "";
				if (insertTime != null)
					insertTimeStr = insertTime.toString();

				events.put("insertTime", insertTimeStr);
				
				events = replaceNullValues(events, "");
				responseMeters.add(events);
			}
			
			allFailedEvts.put("meters", responseMeters);

			logger.debug(" -- CMRData size: " + rows.size());
			logger.debug("---------------------- END - getCMRData() ------------------------");

			return allFailedEvts;
		} catch (Exception e) {
			logger.error("**Exception getCMRData(): " + e);
		}
		return null;
	}
	
	public static <T, K> Map<K, T> replaceNullValues(Map<K, T> map, T defaultValue) {
  
        map = map.entrySet()
                  .stream()
                  .map(entry -> {
                      if (entry.getValue() == null)
                          entry.setValue(defaultValue);
                      return entry;
                  })
                  .collect(Collectors.toMap(Map.Entry::getKey,
                                            Map.Entry::getValue));
        return map;
    }
	
	
	public List<Map<String, Object>> getEvents(String report_name) {
		logger.debug("---------------------- START - getEvents() ------------------------");
		try {
			String qstr = "SELECT distinct boro_muni, event_name "
					+ "FROM AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_DETAILS " 
					+ "WHERE event_type='C' AND EXECUTE_TIME >= current_timestamp - 15 "
					+ "Order by boro_muni, event_name";
			
			switch (report_name.toLowerCase()) {
	            case "cwr":
	            	qstr = "SELECT DISTINCT boro_muni, event_name "
	            			+ "FROM ami_load_shedding.ls_finalize_event_list_details ORDER BY boro_muni, event_name";
	                break;
	            case "cdr":
	            	qstr = "SELECT DISTINCT boro_muni, event_name FROM ami_load_shedding.ls_execute_event_list_details "
	            			+ "ORDER BY boro_muni, event_name";
	                break;
	            case "crr":
	            	return getSubEvents();
			}
			logger.debug("qstr? " + qstr);
			List<Map<String, Object>> rows = oracleJdbcTemplate.queryForList(qstr);
			
			logger.debug("NumOfFailedEvents ? " + rows.size());	
			
			Map allFailedEvts = new HashMap();
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			for (Map row : rows) {
				Map<String, Object> events = new HashMap();
				events.put("boro", (String) row.get("boro_muni"));
				Map evn = new HashMap();
				evn.put("eventName", (String) row.get("event_name"));
				events.put("eventinfo", evn);
				result.add(events);
			}
			Map<String, List<Object>> byEventList = result.stream()
				    .collect(Collectors.groupingBy(map -> map.get("boro").toString(),
				                                   Collectors.mapping(map -> map.get("eventinfo"),
				                                                      Collectors.toList())));
			
			String[] keys = new String[byEventList.size()];
			Object[] values = new Object[byEventList.size()];
			int index = 0;
			List<Map<String, Object>> allevents = new ArrayList<Map<String, Object>>();
			Map<String, Object> map = new HashMap<String, Object>();
			for (Entry<String, List<Object>> mapEntry : byEventList.entrySet()) {
				map = new HashMap<String, Object>();
				keys[index] = mapEntry.getKey();
				map.put("boroughName", keys[index]);
				values[index] = mapEntry.getValue();
				map.put("events", values[index]);
				allevents.add(map);
				index++;
			}
			
			logger.debug(" -- Events size: " + rows.size());
			logger.debug("---------------------- END - getEvents() ------------------------");
			return allevents;
		} catch (Exception e) {
			logger.debug("**Exception getEvents() - " + e);
		}
		return null;
	}
	
	
	public List getSubEvents() {
		logger.debug("---------------------- START - getSubEvents() ------------------------");
		try {
			String qstr = "SELECT distinct boro_muni, event_name, sub_event, execute_time "
					+ "FROM AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_DETAILS "
					+ "WHERE event_type='C' AND EXECUTE_TIME >= current_timestamp - 15 "
					+ "GROUP BY boro_muni, event_name, sub_event, execute_time  "
					+ "ORDER BY boro_muni, event_name, sub_event, execute_time";					
			
			logger.debug("qstr? " + qstr);
			List<Map<String, Object>> rows = oracleJdbcTemplate.queryForList(qstr);
			
			logger.debug("NumOfFailedEvents ? " + rows.size());	
			
			Map allFailedEvts = new HashMap();
			List<Map<String, Object>> result = new ArrayList<Map<String, Object>>(rows.size());
			String event_name = "";
			List subevn = null;
			Map evn = null;
			for (Map row : rows) {
					Map<String, Object> events = new HashMap();
					events.put("boro", (String) row.get("boro_muni"));
					
					if(event_name.equals("") || !event_name.equals((String) row.get("event_name"))) {
						evn = new HashMap();
						evn.put("eventName",  (String) row.get("event_name"));
						
						subevn = new ArrayList();
					}
					Map subentmap = new HashMap();
						subentmap.put("subEventName", (String) row.get("sub_event"));
							
					subevn.add(subentmap);
					evn.put("subEvents", subevn);
					events.put("eventinfo", evn);
					if(event_name.equals("") || !event_name.equals((String) row.get("event_name"))) {
						event_name = (String) row.get("event_name");
						result.add(events);
					}
			}
			Map<String, List<Object>> byEventList = result.stream()
				    .collect(Collectors.groupingBy(map -> map.get("boro").toString(),
				                                   Collectors.mapping(map -> map.get("eventinfo"),
				                                                      Collectors.toList())));
			
			String[] keys = new String[byEventList.size()];
			Object[] values = new Object[byEventList.size()];
			int index = 0;
			List<Map<String, Object>> allevents = new ArrayList<Map<String, Object>>();
			Map<String, Object> map = new HashMap<String, Object>();
			for (Entry<String, List<Object>> mapEntry : byEventList.entrySet()) {
				map = new HashMap<String, Object>();
				keys[index] = mapEntry.getKey();
				map.put("boroughName", keys[index]);
				values[index] = mapEntry.getValue();
				map.put("events", values[index]);
				allevents.add(map);
				index++;
			}
			
			logger.debug(" -- Events size: " + rows.size());
			logger.debug("---------------------- END - getSubEvents() ------------------------");
			return allevents;
		} catch (Exception e) {
			logger.debug("**Exception getSubEvents() - " + e);
		}
		return null;
	}
	
	
}