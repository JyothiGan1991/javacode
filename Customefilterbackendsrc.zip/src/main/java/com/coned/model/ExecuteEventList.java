package com.coned.model;

import java.sql.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_execute_event_list", schema = "AMI_LOAD_SHEDDING")
public class ExecuteEventList {

	@Id
	@JsonIgnore
	@Column(name = "fk_meter_event_load_id")
	private Long id;

	@Column(name = "event_name")
	private String eventName;

	@Column(name = "boro_muni")
	private String borough;

	@Column(name = "meter_number")
	private String meterNumber;

	public String getMeterNumber() {
		return meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public ExecuteEventList() {

	}

	public ExecuteEventList(Long id, String eventname, String borough, String meterNumber) {
		this.id = id;
		this.eventName = eventname;
		this.borough = borough;
		this.meterNumber = meterNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEventname() {
		return eventName;
	}

	public void setEventname(String eventname) {
		this.eventName = eventname;
	}

	public String getBorough() {
		return borough;
	}

	public void setBoromuni(String borough) {
		this.borough = borough;
	}

	@Override
	public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", borough=" + borough + ", meterNumber=" + meterNumber + "]";
	}
}
