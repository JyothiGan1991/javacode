/*package com.coned.ls.repository;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.MeterRejectResponseMapper;
//import com.coned.ls.service.MetersEventRejectService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ApiEngineApplication.class)
public class MeterEventRejectRepositoryTest {

	
	
	@Autowired
	private MetersEventRejectRepository metersEventRejectRepository;
	
	@Autowired
	private MetersEventRejectService metersEventRejectService;
	
	
	@Test
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, value="oracleTx")
	@Rollback(true)
	public void rejectMeterEventList() throws MeterRejectException{
		//MeterRejectResponseMapper rejectMeterEventList = metersEventRejectRepository.rejectMeterEventList("A", "SheepsheadBaySampleData7.27.20-1703");
		//System.out.println(rejectMeterEventList.toString());
	}
}
*/



/*package com.coned.ls.repository;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

//import com.coned.ls.controller.AOCCDisconnectController;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.mapper.MeterRejectResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={MetersEventRejectRepository.class})
@AutoConfigureMockMvc
public class MeterEventRejectRepositoryTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private JdbcMetersEventRejectRepository jdbcMetersRejectRepo;
	
	private MockMvc mockMvc;
	
	MeterEventFinalize meterEventFinalize;
	
	@Mock
	protected JdbcTemplate oracleJdbcTemplate;	

		
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300","Success",true);	
	}
	
	@Test
	public void rejectMeterEventList() throws Exception {
		MeterRejectResponseMapper expected  = new MeterRejectResponseMapper();
		expected.setMessage("Test");
		expected.setSuccess(true);
		String borough = "B";
		String eventName = "SheepsheadBaySampleData7.27.20-1300";
		ReflectionTestUtils.setField(jdbcMetersRejectRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		Mockito.when(jdbcMetersRejectRepo.rejectMeterEventList(borough,eventName)).thenReturn(expected);
		Assert.assertEquals(expected.getMessage(), "Test");
		Assert.assertTrue(expected.isSuccess());
	}
}*/