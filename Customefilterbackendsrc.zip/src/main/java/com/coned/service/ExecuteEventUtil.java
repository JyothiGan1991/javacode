package com.coned.service;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.coned.jpa.controller.FinalizeEventListDetailsController;
import com.coned.model.ExecuteEventListDetails;
import com.coned.util.AOCCWebUtil;

@Service
public class ExecuteEventUtil {
	
	@Autowired
	AOCCWebUtil webutil;
	
	@Value("${aocc.remotews.url}")
    private String REMOTEJOB_URL;
	
//	private String REMOTEJOB_URL = System.getProperty("aocc.remotejob.url");
	
	@Value("${app.profile}")
    private String APP_PROFILE;
	
	private static final Logger logger = LoggerFactory.getLogger(FinalizeEventListDetailsController.class);
	@PersistenceContext
	private EntityManager em;

	Optional<ExecuteEventListDetails> findExeById(Long eventid) {
		Optional<ExecuteEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT fk_finalized_event_id, execute_time,boro_muni,event_name,operator_ad_id,event_type FROM "
					+ "ami_load_shedding.ls_execute_event_list_details WHERE fk_finalized_event_id=" + eventid;
			logger.debug("findExeById - Query? " + qstr);
			ExecuteEventListDetails event = (ExecuteEventListDetails) em
					.createNativeQuery(qstr, ExecuteEventListDetails.class).getSingleResult();
			logger.debug("ExecuteEventUtil -> findExeById " + event);
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findExeById() " + e);
		}
		return opt;
	}
	
	Optional<ExecuteEventListDetails> findExeByIdAndSubEvnt(Long eventid, String action, String subeventname) {
		Optional<ExecuteEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT fk_finalized_event_id, execute_time,boro_muni,event_name,operator_ad_id,event_type FROM "
					+ "ami_load_shedding.ls_execute_event_list_details WHERE fk_finalized_event_id=" + eventid;
			
			if(action != null) {
				if(action.equals("D"))
					qstr += " AND event_type='"+action+"'";
				if(action.equals("C"))
					qstr += " AND event_type='"+action+"'"+" AND sub_event='"+subeventname+"'";
			}
			logger.debug("findExeByIdAndSubEvnt - Query? " + qstr);
			ExecuteEventListDetails event = (ExecuteEventListDetails) em
					.createNativeQuery(qstr, ExecuteEventListDetails.class).getSingleResult();
			logger.debug("ExecuteEventUtil -> findExeByIdAndSubEvnt " + event);
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findExeByIdAndSubEvnt() " + e);
		}
		return opt;
	}
	
	public boolean callRemoteJob(Long eventid, String action, String subEventName) {
		boolean isJobSucess = false;
		try {
			Optional<ExecuteEventListDetails> optExe = findExeByIdAndSubEvnt(eventid, action, subEventName);
			logger.debug("---------------------** REMOTEJOB_URL callRemoteJob Start** ------------- " + optExe.isPresent()+" profile? "+APP_PROFILE);
			String eventname = "";
			if (optExe.isPresent()) {
				ExecuteEventListDetails exeEventDet = optExe.get();
				String borough = exeEventDet.getBorough();
				eventname = exeEventDet.getEventname();
				logger.debug("---- callRemoteJob() -> borough " + borough + " Eventname: " + eventname
						+ " subEventName: " + subEventName);
				
//				String exeEventDate = exeEventDet.getExecuteDateTime().toString();
				String exeEventDate = exeEventDet.getExecuteDateTime().format(DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss"));
				String exeEventDateStr = exeEventDate.replace("T", " ");
				int eventidI = eventid.intValue();
				String reqBody = "{" + "\"eventName\":\"" + eventname + "\"," 
						+ "\"boro\":\"" + borough + "\","
						+ "\"eventId\":" + eventidI + ","
						+ "\"eventType\":\"" + action + "\"," 
						+ "\"eventTime\":\"" + exeEventDateStr + "\","
						+ "\"isGetStatus\":false" + "}";
				if (action.equals("C")) {
					reqBody = "{" + "\"eventName\":\"" + eventname + "\"," 
							+ "\"subEventName\":\"" + subEventName + "\"," 
							+ "\"boro\":\"" + borough + "\","
							+ "\"eventId\":" + eventidI + ","
							+ "\"eventType\":\"" + action + "\"," 
							+ "\"eventTime\":\"" + exeEventDateStr + "\","
							+ "\"isGetStatus\":false" + "}";
				}
				logger.debug("------ reqBody ------- " + reqBody);
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<String> entity = new HttpEntity<String>(reqBody, headers);
				ResponseEntity<String> result = null;
				try {
					HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
							.getRequest();
					logger.debug("webutil.getUrl? "+webutil.getUrl(request)+" REMOTEJOB_URL? "+REMOTEJOB_URL);
					String wsurl = webutil.getUrl(request)+REMOTEJOB_URL;
//					wsurl = "http://hesomsdev1.conedison.net:9022"+REMOTEJOB_URL;
					logger.debug("wsurl? "+wsurl);
					
					result = restTemplate.exchange(wsurl, HttpMethod.POST, entity, String.class);
					logger.debug("--> remoteJob response:" + result+" httpCode: " + result.getStatusCode());
				} catch (Exception e) {
					logger.error(" **JSONException -> callRemoteJob(): " + e);
				}
				if (result != null && result.getStatusCode() == HttpStatus.CREATED) {
					isJobSucess = true;
					JSONObject jsonResponse = null;
						jsonResponse = new JSONObject(result.getBody());
						boolean isSucess = jsonResponse.getBoolean("success");
						logger.debug("--> remoteJob - isSucessFull? " + isSucess);
						String msg = jsonResponse.getString("message");
						logger.debug("--> remoteJob - message: " + msg);
				} else {
					// Delete from execute_details and execute_list
					String qstr = "";
					if (!eventname.equals("")) {
						if (action.equals("D")) {
							qstr = "DELETE FROM ami_load_shedding.ls_execute_event_list " + "WHERE EVENT_NAME ='"
									+ eventname + "'";
						} else if (action.equals("C")) {
							qstr = "DELETE FROM ami_load_shedding.ls_execute_event_list_connect " + "WHERE EVENT_NAME ='"
									+ eventname + "' AND sub_event_name='" + subEventName + "'";
						}
						int res = executeQuery(qstr);
						logger.debug("---DELETE FROM ls_execute_event_list -> Result: " + res);
					}
					if (action.equals("D")) {
						qstr = "DELETE FROM ami_load_shedding.ls_execute_event_list_details "
								+ "WHERE fk_finalized_event_id =" + eventid;
					} else if (action.equals("C")) {
						qstr = "DELETE FROM ami_load_shedding.ls_execute_event_list_details "
								+ "WHERE fk_finalized_event_id = " + eventid + " AND sub_event='" + subEventName
								+ "'";
					}
					int res = executeQuery(qstr);
					logger.debug("---DELETE FROM ls_execute_event_details -> Result: " + res);
					
					if (action.equals("D")) {
						qstr = "DELETE FROM ami_load_shedding.LS_AOCC_EXECUTE_REMOTEJOB_FAIL " + "WHERE action= '"+action+ "' AND event_id=" + eventid;
					} else if (action.equals("C")) {
						qstr = "DELETE FROM ami_load_shedding.LS_AOCC_EXECUTE_REMOTEJOB_FAIL " + "WHERE action='"+action+ "' AND event_id=" + eventid+ " AND sub_event_name='" + subEventName+ "'";
					}
					res = executeQuery(qstr);
					logger.debug("---DELETE FROM ls_aocc_execute_remotejob_fail -> Result: " + res);
					
					
					if (action.equals("D")) {
						qstr = "DELETE FROM ami_load_shedding.ls_aocc_execute_event " + "WHERE action='"+action+ "' AND event_id=" + eventid;
					} else if (action.equals("C")) {
						qstr = "DELETE FROM ami_load_shedding.ls_aocc_execute_event " + "WHERE action='"+action+ "' AND event_id=" + eventid+ " AND sub_event_name='" + subEventName+ "'";
					}
					res = executeQuery(qstr);
					logger.debug("---DELETE FROM ls_aocc_execute_event -> Result: " + res);
				}
			}
			logger.debug("---------------------callRemoteJob End ------------- ");
		} catch (Exception e) {
			logger.error(" **Exception -> callRemoteJob(): " + e);
		}
		return isJobSucess;
	}

	public int executeQuery(String qstr) {
		int res = 0;
		try {
			logger.debug(" exectueQuery -> query: " + qstr);
			Query q = em.createNativeQuery(qstr);
			res = q.executeUpdate();
		} catch (Exception e) {
			logger.error("**Exception -> exectueQuery: " + e);
		}
		return res;
	}
}
