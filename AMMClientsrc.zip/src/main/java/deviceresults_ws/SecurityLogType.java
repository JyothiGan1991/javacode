
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SecurityLogType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SecurityLogType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DataTimeZone" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="LogRead" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}LogReadType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="GatewaySerialNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="GatewayName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceMacID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobId" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="JobName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CustomerID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SecurityLogType", propOrder = {
    "dataTimeZone",
    "logRead"
})
public class SecurityLogType {

    @XmlElement(name = "DataTimeZone")
    protected TimeZoneType dataTimeZone;
    @XmlElement(name = "LogRead", required = true)
    protected List<LogReadType> logRead;
    @XmlAttribute(name = "GatewaySerialNumber", required = true)
    protected String gatewaySerialNumber;
    @XmlAttribute(name = "GatewayName", required = true)
    protected String gatewayName;
    @XmlAttribute(name = "DeviceMacID", required = true)
    protected String deviceMacID;
    @XmlAttribute(name = "DeviceName", required = true)
    protected String deviceName;
    @XmlAttribute(name = "JobId", required = true)
    protected long jobId;
    @XmlAttribute(name = "JobName", required = true)
    protected String jobName;
    @XmlAttribute(name = "CustomerID")
    protected String customerID;

    /**
     * Gets the value of the dataTimeZone property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getDataTimeZone() {
        return dataTimeZone;
    }

    /**
     * Sets the value of the dataTimeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setDataTimeZone(TimeZoneType value) {
        this.dataTimeZone = value;
    }

    /**
     * Gets the value of the logRead property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logRead property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogRead().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LogReadType }
     * 
     * 
     */
    public List<LogReadType> getLogRead() {
        if (logRead == null) {
            logRead = new ArrayList<LogReadType>();
        }
        return this.logRead;
    }

    /**
     * Gets the value of the gatewaySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewaySerialNumber() {
        return gatewaySerialNumber;
    }

    /**
     * Sets the value of the gatewaySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewaySerialNumber(String value) {
        this.gatewaySerialNumber = value;
    }

    /**
     * Gets the value of the gatewayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayName() {
        return gatewayName;
    }

    /**
     * Sets the value of the gatewayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayName(String value) {
        this.gatewayName = value;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMacID() {
        return deviceMacID;
    }

    /**
     * Sets the value of the deviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMacID(String value) {
        this.deviceMacID = value;
    }

    /**
     * Gets the value of the deviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Sets the value of the deviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Gets the value of the jobId property.
     * 
     */
    public long getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     */
    public void setJobId(long value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the jobName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the value of the jobName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerID(String value) {
        this.customerID = value;
    }

}
