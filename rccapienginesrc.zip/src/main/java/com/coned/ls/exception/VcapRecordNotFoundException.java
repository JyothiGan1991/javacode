package com.coned.ls.exception;

public class VcapRecordNotFoundException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;

	public VcapRecordNotFoundException() {
		super();
	}

	public VcapRecordNotFoundException(final String message) {
		super(message);
	}
}
