package com.coned.ls.controller;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.rest.RestClientBuilder;
import com.coned.ls.service.ReportService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ReportControllerTest {
	@InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	ReportController reportController;

	@Mock
	private ReportService reportService;

	@Before
	public void setup() throws Exception {
		reportController = new ReportController();
		System.out.println("@Before annotation method is being called ....");
		ReflectionTestUtils.setField(reportController, "reportService", reportService);
	}

	@Test
	public void getEvents() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		String report_name = "cdr";
		Mockito.when(reportService.getEvents(report_name)).thenReturn(result);
		
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getEvents(report_name);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void getCDR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		Map<String, Object> payload = new HashMap<String, Object>();
		
		Mockito.when(reportService.getCDR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCDR(request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void getCWR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		Map<String, Object> payload = new HashMap<String, Object>();
		
		Mockito.when(reportService.getCWR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCWR(request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void getCRR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		Map<String, Object> payload = new HashMap<String, Object>();
		
		Mockito.when(reportService.getCRR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCRR(request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void getCER() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		Map<String, Object> payload = new HashMap<String, Object>();
		
		Mockito.when(reportService.getCER(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = reportController.getCER(request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
}