
package deviceresults_ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the deviceresults_ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetMeterReadResultsByDeviceID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetMeterReadResultsByDeviceID");
    private final static QName _MeterReadResults_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "MeterReadResults");
    private final static QName _GetMeterReadResultsByJobID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetMeterReadResultsByJobID");
    private final static QName _GetTotalCountForMeterReadResultsByJobID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetTotalCountForMeterReadResultsByJobID");
    private final static QName _GetPingResultsByJobID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetPingResultsByJobID");
    private final static QName _TotalCount_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "TotalCount");
    private final static QName _PingResults_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "PingResults");
    private final static QName _GetRemoteProvisioningResultsByJobID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetRemoteProvisioningResultsByJobID");
    private final static QName _RemoteProvisioningResults_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "RemoteProvisioningResults");
    private final static QName _ErrorCodeFault_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "ErrorCodeFault");
    private final static QName _ArbitraryMeterCommandResults_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "ArbitraryMeterCommandResults");
    private final static QName _GetArbitraryMeterCommandResultsByJobID_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", "GetArbitraryMeterCommandResultsByJobID");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: deviceresults_ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CachedResultsType }
     * 
     */
    public CachedResultsType createCachedResultsType() {
        return new CachedResultsType();
    }

    /**
     * Create an instance of {@link JobIDType }
     * 
     */
    public JobIDType createJobIDType() {
        return new JobIDType();
    }

    /**
     * Create an instance of {@link TotalCountType }
     * 
     */
    public TotalCountType createTotalCountType() {
        return new TotalCountType();
    }

    /**
     * Create an instance of {@link ActivationStatusType }
     * 
     */
    public ActivationStatusType createActivationStatusType() {
        return new ActivationStatusType();
    }

    /**
     * Create an instance of {@link ApprovalStatusType }
     * 
     */
    public ApprovalStatusType createApprovalStatusType() {
        return new ApprovalStatusType();
    }

    /**
     * Create an instance of {@link CronJobTypeType }
     * 
     */
    public CronJobTypeType createCronJobTypeType() {
        return new CronJobTypeType();
    }

    /**
     * Create an instance of {@link DayType }
     * 
     */
    public DayType createDayType() {
        return new DayType();
    }

    /**
     * Create an instance of {@link DeviceTypeType }
     * 
     */
    public DeviceTypeType createDeviceTypeType() {
        return new DeviceTypeType();
    }

    /**
     * Create an instance of {@link ExecutionStatusType }
     * 
     */
    public ExecutionStatusType createExecutionStatusType() {
        return new ExecutionStatusType();
    }

    /**
     * Create an instance of {@link JobSubTypeType }
     * 
     */
    public JobSubTypeType createJobSubTypeType() {
        return new JobSubTypeType();
    }

    /**
     * Create an instance of {@link JobTypeType }
     * 
     */
    public JobTypeType createJobTypeType() {
        return new JobTypeType();
    }

    /**
     * Create an instance of {@link MeterReadTypeType }
     * 
     */
    public MeterReadTypeType createMeterReadTypeType() {
        return new MeterReadTypeType();
    }

    /**
     * Create an instance of {@link DeviceCapabilityType }
     * 
     */
    public DeviceCapabilityType createDeviceCapabilityType() {
        return new DeviceCapabilityType();
    }

    /**
     * Create an instance of {@link MonthType }
     * 
     */
    public MonthType createMonthType() {
        return new MonthType();
    }

    /**
     * Create an instance of {@link NotificationTypeType }
     * 
     */
    public NotificationTypeType createNotificationTypeType() {
        return new NotificationTypeType();
    }

    /**
     * Create an instance of {@link PositionType }
     * 
     */
    public PositionType createPositionType() {
        return new PositionType();
    }

    /**
     * Create an instance of {@link PriorityType }
     * 
     */
    public PriorityType createPriorityType() {
        return new PriorityType();
    }

    /**
     * Create an instance of {@link ProvisioningActionType }
     * 
     */
    public ProvisioningActionType createProvisioningActionType() {
        return new ProvisioningActionType();
    }

    /**
     * Create an instance of {@link ScheduleType }
     * 
     */
    public ScheduleType createScheduleType() {
        return new ScheduleType();
    }

    /**
     * Create an instance of {@link TaskStatusType }
     * 
     */
    public TaskStatusType createTaskStatusType() {
        return new TaskStatusType();
    }

    /**
     * Create an instance of {@link TimeZoneType }
     * 
     */
    public TimeZoneType createTimeZoneType() {
        return new TimeZoneType();
    }

    /**
     * Create an instance of {@link TOUTierWeekdayType }
     * 
     */
    public TOUTierWeekdayType createTOUTierWeekdayType() {
        return new TOUTierWeekdayType();
    }

    /**
     * Create an instance of {@link UIQDeviceStateType }
     * 
     */
    public UIQDeviceStateType createUIQDeviceStateType() {
        return new UIQDeviceStateType();
    }

    /**
     * Create an instance of {@link UtilDeviceStateType }
     * 
     */
    public UtilDeviceStateType createUtilDeviceStateType() {
        return new UtilDeviceStateType();
    }

    /**
     * Create an instance of {@link WeekdayType }
     * 
     */
    public WeekdayType createWeekdayType() {
        return new WeekdayType();
    }

    /**
     * Create an instance of {@link DefinedLocationType }
     * 
     */
    public DefinedLocationType createDefinedLocationType() {
        return new DefinedLocationType();
    }

    /**
     * Create an instance of {@link DeviceSubTypeType }
     * 
     */
    public DeviceSubTypeType createDeviceSubTypeType() {
        return new DeviceSubTypeType();
    }

    /**
     * Create an instance of {@link MeterModeType }
     * 
     */
    public MeterModeType createMeterModeType() {
        return new MeterModeType();
    }

    /**
     * Create an instance of {@link WANType }
     * 
     */
    public WANType createWANType() {
        return new WANType();
    }

    /**
     * Create an instance of {@link GetMeterReadResultsByDeviceIDType }
     * 
     */
    public GetMeterReadResultsByDeviceIDType createGetMeterReadResultsByDeviceIDType() {
        return new GetMeterReadResultsByDeviceIDType();
    }

    /**
     * Create an instance of {@link MeterReadResultsType }
     * 
     */
    public MeterReadResultsType createMeterReadResultsType() {
        return new MeterReadResultsType();
    }

    /**
     * Create an instance of {@link GetMeterReadResultsByJobIDType }
     * 
     */
    public GetMeterReadResultsByJobIDType createGetMeterReadResultsByJobIDType() {
        return new GetMeterReadResultsByJobIDType();
    }

    /**
     * Create an instance of {@link GetTotalCountForMeterReadResultsByJobIDType }
     * 
     */
    public GetTotalCountForMeterReadResultsByJobIDType createGetTotalCountForMeterReadResultsByJobIDType() {
        return new GetTotalCountForMeterReadResultsByJobIDType();
    }

    /**
     * Create an instance of {@link GetPingResultsByJobIDType }
     * 
     */
    public GetPingResultsByJobIDType createGetPingResultsByJobIDType() {
        return new GetPingResultsByJobIDType();
    }

    /**
     * Create an instance of {@link PingResultsType }
     * 
     */
    public PingResultsType createPingResultsType() {
        return new PingResultsType();
    }

    /**
     * Create an instance of {@link GetRemoteProvisioningResultsByJobIDType }
     * 
     */
    public GetRemoteProvisioningResultsByJobIDType createGetRemoteProvisioningResultsByJobIDType() {
        return new GetRemoteProvisioningResultsByJobIDType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningResultsType }
     * 
     */
    public RemoteProvisioningResultsType createRemoteProvisioningResultsType() {
        return new RemoteProvisioningResultsType();
    }

    /**
     * Create an instance of {@link ErrorCodeFaultType }
     * 
     */
    public ErrorCodeFaultType createErrorCodeFaultType() {
        return new ErrorCodeFaultType();
    }

    /**
     * Create an instance of {@link ArbitraryMeterCommandResultsType }
     * 
     */
    public ArbitraryMeterCommandResultsType createArbitraryMeterCommandResultsType() {
        return new ArbitraryMeterCommandResultsType();
    }

    /**
     * Create an instance of {@link GetArbitraryMeterCommandResultsByJobIDType }
     * 
     */
    public GetArbitraryMeterCommandResultsByJobIDType createGetArbitraryMeterCommandResultsByJobIDType() {
        return new GetArbitraryMeterCommandResultsByJobIDType();
    }

    /**
     * Create an instance of {@link ArbitraryCommandResultsByJobSearchParametersType }
     * 
     */
    public ArbitraryCommandResultsByJobSearchParametersType createArbitraryCommandResultsByJobSearchParametersType() {
        return new ArbitraryCommandResultsByJobSearchParametersType();
    }

    /**
     * Create an instance of {@link ArbitraryCommandResultsSortMapType }
     * 
     */
    public ArbitraryCommandResultsSortMapType createArbitraryCommandResultsSortMapType() {
        return new ArbitraryCommandResultsSortMapType();
    }

    /**
     * Create an instance of {@link ChannelType }
     * 
     */
    public ChannelType createChannelType() {
        return new ChannelType();
    }

    /**
     * Create an instance of {@link CommandResultType }
     * 
     */
    public CommandResultType createCommandResultType() {
        return new CommandResultType();
    }

    /**
     * Create an instance of {@link DeviceItemType }
     * 
     */
    public DeviceItemType createDeviceItemType() {
        return new DeviceItemType();
    }

    /**
     * Create an instance of {@link DeviceListType }
     * 
     */
    public DeviceListType createDeviceListType() {
        return new DeviceListType();
    }

    /**
     * Create an instance of {@link DevicePingType }
     * 
     */
    public DevicePingType createDevicePingType() {
        return new DevicePingType();
    }

    /**
     * Create an instance of {@link ExecuteProcedureType }
     * 
     */
    public ExecuteProcedureType createExecuteProcedureType() {
        return new ExecuteProcedureType();
    }

    /**
     * Create an instance of {@link GenericMeterReadElementType }
     * 
     */
    public GenericMeterReadElementType createGenericMeterReadElementType() {
        return new GenericMeterReadElementType();
    }

    /**
     * Create an instance of {@link GenericMeterReadRecordType }
     * 
     */
    public GenericMeterReadRecordType createGenericMeterReadRecordType() {
        return new GenericMeterReadRecordType();
    }

    /**
     * Create an instance of {@link GenericMeterReadSortMapType }
     * 
     */
    public GenericMeterReadSortMapType createGenericMeterReadSortMapType() {
        return new GenericMeterReadSortMapType();
    }

    /**
     * Create an instance of {@link GenericMeterReadType }
     * 
     */
    public GenericMeterReadType createGenericMeterReadType() {
        return new GenericMeterReadType();
    }

    /**
     * Create an instance of {@link IntervalReadType }
     * 
     */
    public IntervalReadType createIntervalReadType() {
        return new IntervalReadType();
    }

    /**
     * Create an instance of {@link IntervalSortMapType }
     * 
     */
    public IntervalSortMapType createIntervalSortMapType() {
        return new IntervalSortMapType();
    }

    /**
     * Create an instance of {@link LogReadType }
     * 
     */
    public LogReadType createLogReadType() {
        return new LogReadType();
    }

    /**
     * Create an instance of {@link LongKeyCachedResultsType }
     * 
     */
    public LongKeyCachedResultsType createLongKeyCachedResultsType() {
        return new LongKeyCachedResultsType();
    }

    /**
     * Create an instance of {@link MeterConnectionStatusType }
     * 
     */
    public MeterConnectionStatusType createMeterConnectionStatusType() {
        return new MeterConnectionStatusType();
    }

    /**
     * Create an instance of {@link MeterReadByDeviceSearchParametersType }
     * 
     */
    public MeterReadByDeviceSearchParametersType createMeterReadByDeviceSearchParametersType() {
        return new MeterReadByDeviceSearchParametersType();
    }

    /**
     * Create an instance of {@link MeterReadByJobSearchParametersType }
     * 
     */
    public MeterReadByJobSearchParametersType createMeterReadByJobSearchParametersType() {
        return new MeterReadByJobSearchParametersType();
    }

    /**
     * Create an instance of {@link PingByJobSearchParametersType }
     * 
     */
    public PingByJobSearchParametersType createPingByJobSearchParametersType() {
        return new PingByJobSearchParametersType();
    }

    /**
     * Create an instance of {@link PingSortMapType }
     * 
     */
    public PingSortMapType createPingSortMapType() {
        return new PingSortMapType();
    }

    /**
     * Create an instance of {@link PingType }
     * 
     */
    public PingType createPingType() {
        return new PingType();
    }

    /**
     * Create an instance of {@link ProvisioningCommandStatusType }
     * 
     */
    public ProvisioningCommandStatusType createProvisioningCommandStatusType() {
        return new ProvisioningCommandStatusType();
    }

    /**
     * Create an instance of {@link ReadTableType }
     * 
     */
    public ReadTableType createReadTableType() {
        return new ReadTableType();
    }

    /**
     * Create an instance of {@link ReadTableOffsetType }
     * 
     */
    public ReadTableOffsetType createReadTableOffsetType() {
        return new ReadTableOffsetType();
    }

    /**
     * Create an instance of {@link RegisterReadSortMapType }
     * 
     */
    public RegisterReadSortMapType createRegisterReadSortMapType() {
        return new RegisterReadSortMapType();
    }

    /**
     * Create an instance of {@link RegisterReadSourceType }
     * 
     */
    public RegisterReadSourceType createRegisterReadSourceType() {
        return new RegisterReadSourceType();
    }

    /**
     * Create an instance of {@link RegisterReadType }
     * 
     */
    public RegisterReadType createRegisterReadType() {
        return new RegisterReadType();
    }

    /**
     * Create an instance of {@link RegisterType }
     * 
     */
    public RegisterType createRegisterType() {
        return new RegisterType();
    }

    /**
     * Create an instance of {@link MaxDemandsType }
     * 
     */
    public MaxDemandsType createMaxDemandsType() {
        return new MaxDemandsType();
    }

    /**
     * Create an instance of {@link CoincidenceType }
     * 
     */
    public CoincidenceType createCoincidenceType() {
        return new CoincidenceType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningByJobSearchParametersType }
     * 
     */
    public RemoteProvisioningByJobSearchParametersType createRemoteProvisioningByJobSearchParametersType() {
        return new RemoteProvisioningByJobSearchParametersType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningDataTypeType }
     * 
     */
    public RemoteProvisioningDataTypeType createRemoteProvisioningDataTypeType() {
        return new RemoteProvisioningDataTypeType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningErrorStatusType }
     * 
     */
    public RemoteProvisioningErrorStatusType createRemoteProvisioningErrorStatusType() {
        return new RemoteProvisioningErrorStatusType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningResultType }
     * 
     */
    public RemoteProvisioningResultType createRemoteProvisioningResultType() {
        return new RemoteProvisioningResultType();
    }

    /**
     * Create an instance of {@link RemoteProvisioningSortMapType }
     * 
     */
    public RemoteProvisioningSortMapType createRemoteProvisioningSortMapType() {
        return new RemoteProvisioningSortMapType();
    }

    /**
     * Create an instance of {@link ResultDataType }
     * 
     */
    public ResultDataType createResultDataType() {
        return new ResultDataType();
    }

    /**
     * Create an instance of {@link RouteHopType }
     * 
     */
    public RouteHopType createRouteHopType() {
        return new RouteHopType();
    }

    /**
     * Create an instance of {@link SecurityLogSortMapType }
     * 
     */
    public SecurityLogSortMapType createSecurityLogSortMapType() {
        return new SecurityLogSortMapType();
    }

    /**
     * Create an instance of {@link SecurityLogType }
     * 
     */
    public SecurityLogType createSecurityLogType() {
        return new SecurityLogType();
    }

    /**
     * Create an instance of {@link StatusFlagTypeWithDesc }
     * 
     */
    public StatusFlagTypeWithDesc createStatusFlagTypeWithDesc() {
        return new StatusFlagTypeWithDesc();
    }

    /**
     * Create an instance of {@link StringKeyCachedResultsType }
     * 
     */
    public StringKeyCachedResultsType createStringKeyCachedResultsType() {
        return new StringKeyCachedResultsType();
    }

    /**
     * Create an instance of {@link TierType }
     * 
     */
    public TierType createTierType() {
        return new TierType();
    }

    /**
     * Create an instance of {@link TimeRangeType }
     * 
     */
    public TimeRangeType createTimeRangeType() {
        return new TimeRangeType();
    }

    /**
     * Create an instance of {@link TimestampType }
     * 
     */
    public TimestampType createTimestampType() {
        return new TimestampType();
    }

    /**
     * Create an instance of {@link WriteTableOffsetType }
     * 
     */
    public WriteTableOffsetType createWriteTableOffsetType() {
        return new WriteTableOffsetType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMeterReadResultsByDeviceIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetMeterReadResultsByDeviceIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetMeterReadResultsByDeviceID")
    public JAXBElement<GetMeterReadResultsByDeviceIDType> createGetMeterReadResultsByDeviceID(GetMeterReadResultsByDeviceIDType value) {
        return new JAXBElement<GetMeterReadResultsByDeviceIDType>(_GetMeterReadResultsByDeviceID_QNAME, GetMeterReadResultsByDeviceIDType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeterReadResultsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link MeterReadResultsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "MeterReadResults")
    public JAXBElement<MeterReadResultsType> createMeterReadResults(MeterReadResultsType value) {
        return new JAXBElement<MeterReadResultsType>(_MeterReadResults_QNAME, MeterReadResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMeterReadResultsByJobIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetMeterReadResultsByJobIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetMeterReadResultsByJobID")
    public JAXBElement<GetMeterReadResultsByJobIDType> createGetMeterReadResultsByJobID(GetMeterReadResultsByJobIDType value) {
        return new JAXBElement<GetMeterReadResultsByJobIDType>(_GetMeterReadResultsByJobID_QNAME, GetMeterReadResultsByJobIDType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTotalCountForMeterReadResultsByJobIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTotalCountForMeterReadResultsByJobIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetTotalCountForMeterReadResultsByJobID")
    public JAXBElement<GetTotalCountForMeterReadResultsByJobIDType> createGetTotalCountForMeterReadResultsByJobID(GetTotalCountForMeterReadResultsByJobIDType value) {
        return new JAXBElement<GetTotalCountForMeterReadResultsByJobIDType>(_GetTotalCountForMeterReadResultsByJobID_QNAME, GetTotalCountForMeterReadResultsByJobIDType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPingResultsByJobIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetPingResultsByJobIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetPingResultsByJobID")
    public JAXBElement<GetPingResultsByJobIDType> createGetPingResultsByJobID(GetPingResultsByJobIDType value) {
        return new JAXBElement<GetPingResultsByJobIDType>(_GetPingResultsByJobID_QNAME, GetPingResultsByJobIDType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TotalCountType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link TotalCountType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "TotalCount")
    public JAXBElement<TotalCountType> createTotalCount(TotalCountType value) {
        return new JAXBElement<TotalCountType>(_TotalCount_QNAME, TotalCountType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PingResultsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PingResultsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "PingResults")
    public JAXBElement<PingResultsType> createPingResults(PingResultsType value) {
        return new JAXBElement<PingResultsType>(_PingResults_QNAME, PingResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRemoteProvisioningResultsByJobIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRemoteProvisioningResultsByJobIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetRemoteProvisioningResultsByJobID")
    public JAXBElement<GetRemoteProvisioningResultsByJobIDType> createGetRemoteProvisioningResultsByJobID(GetRemoteProvisioningResultsByJobIDType value) {
        return new JAXBElement<GetRemoteProvisioningResultsByJobIDType>(_GetRemoteProvisioningResultsByJobID_QNAME, GetRemoteProvisioningResultsByJobIDType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoteProvisioningResultsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoteProvisioningResultsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "RemoteProvisioningResults")
    public JAXBElement<RemoteProvisioningResultsType> createRemoteProvisioningResults(RemoteProvisioningResultsType value) {
        return new JAXBElement<RemoteProvisioningResultsType>(_RemoteProvisioningResults_QNAME, RemoteProvisioningResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorCodeFaultType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ErrorCodeFaultType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "ErrorCodeFault")
    public JAXBElement<ErrorCodeFaultType> createErrorCodeFault(ErrorCodeFaultType value) {
        return new JAXBElement<ErrorCodeFaultType>(_ErrorCodeFault_QNAME, ErrorCodeFaultType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArbitraryMeterCommandResultsType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ArbitraryMeterCommandResultsType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "ArbitraryMeterCommandResults")
    public JAXBElement<ArbitraryMeterCommandResultsType> createArbitraryMeterCommandResults(ArbitraryMeterCommandResultsType value) {
        return new JAXBElement<ArbitraryMeterCommandResultsType>(_ArbitraryMeterCommandResults_QNAME, ArbitraryMeterCommandResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetArbitraryMeterCommandResultsByJobIDType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetArbitraryMeterCommandResultsByJobIDType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", name = "GetArbitraryMeterCommandResultsByJobID")
    public JAXBElement<GetArbitraryMeterCommandResultsByJobIDType> createGetArbitraryMeterCommandResultsByJobID(GetArbitraryMeterCommandResultsByJobIDType value) {
        return new JAXBElement<GetArbitraryMeterCommandResultsByJobIDType>(_GetArbitraryMeterCommandResultsByJobID_QNAME, GetArbitraryMeterCommandResultsByJobIDType.class, null, value);
    }

}
