package com.coned.ls.controller;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.Stack;

import javax.security.auth.login.LoginContext;


import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.login.CustomLoginConfig;
import com.coned.ls.login.SampleCallbackHandler;
import com.coned.ls.mapper.LoginResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class BaseControllerTest {
	
	@Rule
	public MockitoRule rule = MockitoJUnit.rule().silent();
	
	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private HttpServletRequest request;
	private MockMvc mockMvc;

	@InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	@InjectMocks
	BaseController baseController;

	@Mock
	RESTActionExecutor restActionExecutor;

	@Mock
	LoginContext lc;
	
	
	

	@Test(expected = AssertionError.class)
	public void logout() {
		OperatorLoginDetail detail = new OperatorLoginDetail();
		String apiKey = "abhvksbck8dhjsi";
		String username = "BUDIDHAK";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("adid", "BUDIDHAK");
		ResponseEntity<OperatorLoginDetail> result = new ResponseEntity<OperatorLoginDetail>(detail, HttpStatus.OK);
		Mockito.when(restActionExecutor.persistAPIKey(username, apiKey, "logout")).thenReturn(detail);
		ResponseEntity<OperatorLoginDetail> actual = baseController.logout(request);
		Assert.assertEquals(result.getBody(), actual.getBody());
	}

	@Test(expected = AssertionError.class)
	public void login() throws Exception {
		LoginResponseMapper mapper = new LoginResponseMapper();
		String password = "Wonderland@123";
		String username = "BUDIDHAK";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("adid", "BUDIDHAK");
		ResponseEntity<LoginResponseMapper> result = new ResponseEntity<LoginResponseMapper>(mapper, HttpStatus.OK);
		Mockito.when(restActionExecutor.isOperatorAuthorized(username, "RCC")).thenReturn(true);
		Mockito.doNothing().when(lc).login();
		ResponseEntity<LoginResponseMapper> actual = baseController.login(username, password, request);
		Assert.assertEquals(result.getBody(), actual.getBody());
	}

	/*@Test
	public void loginTest() throws Exception {
		LoginResponseMapper mapper = new LoginResponseMapper();
		String apiKey = "abhvksbck8dhjsi";
		mapper.setToken(apiKey);
		String password = "Wonderland@123";
		String username = "BUDIDHAK";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("adid", "BUDIDHAK");
		LoginContext lc = Mockito.mock(LoginContext.class);
		ResponseEntity<LoginResponseMapper> result = new ResponseEntity<LoginResponseMapper>(mapper, new HttpHeaders(),
				HttpStatus.OK);
		Mockito.when(new LoginContext("MyApp", null,
				new SampleCallbackHandler(username, password, "t3://localhost:7001?"), new CustomLoginConfig()))
				.thenReturn(lc);
		Mockito.when(new LoginContext(Mockito.anyString())).thenReturn(lc);
		Mockito.when(restActionExecutor.isOperatorAuthorized(username, "RCC")).thenReturn(true);
		Mockito.doNothing().when(lc).login();
		ResponseEntity<LoginResponseMapper> actual = baseController.login(username, password, request);
		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}*/

	@Test(expected=Exception.class)
	public void testLogin() throws Exception {
		String password = "Wonderland@123";
		String username = "BUDIDHAK";
		String apiKey = "abhvksbck8dhjsi";
		String login = "login";

		MockHttpServletRequest requestMock = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		// HttpSession session =request.getSession();
		LoginResponseMapper mapper = new LoginResponseMapper();
		mapper.setToken(apiKey);
		mapper.setAuthenticated(true);
		mapper.setMessage("success");

		ResponseEntity<LoginResponseMapper> expectedResponse = new ResponseEntity<>(mapper, null, HttpStatus.OK);
		// Mockito.when(request.getSession(false)).thenReturn(session);
		Mockito.when(restActionExecutor.isOperatorAuthorized(username, "RCC")).thenReturn(true);
		Mockito.when(restActionExecutor.persistAPIKey(username, apiKey, login)).thenReturn(getOperatorLoginDetail());

		Mockito.when(baseController.login(username, password, request)).thenReturn(expectedResponse);
		ResponseEntity<LoginResponseMapper> actual = baseController.login(username, password, request);
		Assert.assertEquals(expectedResponse.getStatusCode(), actual.getStatusCode());
	}

	public OperatorLoginDetail getOperatorLoginDetail() {

		OperatorLoginDetail res = new OperatorLoginDetail();
		res.setAdid("test");
		res.setApiKey("test");
		res.setApiKeyStatus(1);

		return res;
	}

	@Test(expected=Exception.class)
	public void testLogout() throws Exception {

		String username = "BUDIDHAK";
		String apiKey = "d5a21c6acfd3fa5d92c08732105acd5256c47a82c5f676067a172c95cd757ec2";

		HttpHeaders headers = Mockito.mock(HttpHeaders.class);
		headers.add("Authorization", "d5a21c6acfd3fa5d92c08732105acd5256c47a82c5f676067a172c95cd757ec2-BUDIDHAK");

		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(username);
		operatorLoginDetail.setApiKey(apiKey);
		operatorLoginDetail.setLoginTimeStamp(new Date());
		operatorLoginDetail.setRole("RCC");
		
		ResponseEntity<OperatorLoginDetail> entity=new ResponseEntity<OperatorLoginDetail>(operatorLoginDetail,HttpStatus.OK);
		

		ResponseEntity<OperatorLoginDetail> expected = new ResponseEntity<OperatorLoginDetail>(entity.getBody(), headers,
				HttpStatus.OK);

		Mockito.when(request.getHeader("Authorization"))
				.thenReturn("d5a21c6acfd3fa5d92c08732105acd5256c47a82c5f676067a172c95cd757ec2-BUDIDHAK");

		Mockito.when(restActionExecutor.persistAPIKey(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(entity.getBody());
		Mockito.when(baseController.logout(request)).thenReturn(expected);
		ResponseEntity<OperatorLoginDetail> response = baseController.logout(request);
		Assert.assertEquals(expected.getStatusCode(), response.getStatusCode());

	}
	
	@Test(expected=AssertionError.class)
	public void isEmptyOrNullTest(){
		Stack emptyStack = new Stack();
		  assertFalse(emptyStack.isEmpty());
		}
	}
