
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkBaseDeviceType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UiqDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType"/&gt;
 *         &lt;element name="InsertTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UpdateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastCommTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastDataReadCommTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastCROCTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastReadByCROC" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RetiredTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NetDeviceID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="RFChannel" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicTypeConfig" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicSoftwareTypeConfig" minOccurs="0"/&gt;
 *         &lt;element name="BatteryInfoType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BatteryInfoType" minOccurs="0"/&gt;
 *         &lt;element name="ParentGatewayMacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParentGatewayName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParentGatewaySerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParentGatewayID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ParentDeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParentDeviceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ParentDeviceID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ParentDeviceSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetDeviceType", propOrder = {
    "uiqDeviceState",
    "insertTime",
    "updateTime",
    "lastCommTime",
    "lastDataReadCommTime",
    "lastCROCTime",
    "lastReadByCROC",
    "retiredTime",
    "guid",
    "netDeviceID",
    "rfChannel",
    "ipAddress",
    "nicTypeConfig",
    "nicSoftwareTypeConfig",
    "batteryInfoType",
    "parentGatewayMacID",
    "parentGatewayName",
    "parentGatewaySerialNumber",
    "parentGatewayID",
    "parentDeviceMacID",
    "parentDeviceName",
    "parentDeviceID",
    "parentDeviceSerialNumber",
    "locationID",
    "servicePointID"
})
public class GetDeviceType
    extends NetworkBaseDeviceType
{

    @XmlElement(name = "UiqDeviceState", required = true)
    protected UIQDeviceStateType uiqDeviceState;
    @XmlElement(name = "InsertTime")
    protected String insertTime;
    @XmlElement(name = "UpdateTime")
    protected String updateTime;
    @XmlElement(name = "LastCommTime")
    protected String lastCommTime;
    @XmlElement(name = "LastDataReadCommTime")
    protected String lastDataReadCommTime;
    @XmlElement(name = "LastCROCTime")
    protected String lastCROCTime;
    @XmlElement(name = "LastReadByCROC")
    protected Boolean lastReadByCROC;
    @XmlElement(name = "RetiredTime")
    protected String retiredTime;
    @XmlElement(name = "GUID", required = true)
    protected String guid;
    @XmlElement(name = "NetDeviceID")
    protected long netDeviceID;
    @XmlElement(name = "RFChannel")
    protected Integer rfChannel;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "NicTypeConfig")
    protected NicTypeConfig nicTypeConfig;
    @XmlElement(name = "NicSoftwareTypeConfig")
    protected NicSoftwareTypeConfig nicSoftwareTypeConfig;
    @XmlElement(name = "BatteryInfoType")
    protected BatteryInfoType batteryInfoType;
    @XmlElement(name = "ParentGatewayMacID")
    protected String parentGatewayMacID;
    @XmlElement(name = "ParentGatewayName")
    protected String parentGatewayName;
    @XmlElement(name = "ParentGatewaySerialNumber")
    protected String parentGatewaySerialNumber;
    @XmlElement(name = "ParentGatewayID")
    protected Long parentGatewayID;
    @XmlElement(name = "ParentDeviceMacID")
    protected String parentDeviceMacID;
    @XmlElement(name = "ParentDeviceName")
    protected String parentDeviceName;
    @XmlElement(name = "ParentDeviceID")
    protected Long parentDeviceID;
    @XmlElement(name = "ParentDeviceSerialNumber")
    protected String parentDeviceSerialNumber;
    @XmlElement(name = "LocationID")
    protected Long locationID;
    @XmlElement(name = "ServicePointID")
    protected Long servicePointID;

    /**
     * Gets the value of the uiqDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUiqDeviceState() {
        return uiqDeviceState;
    }

    /**
     * Sets the value of the uiqDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUiqDeviceState(UIQDeviceStateType value) {
        this.uiqDeviceState = value;
    }

    /**
     * Gets the value of the insertTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertTime() {
        return insertTime;
    }

    /**
     * Sets the value of the insertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertTime(String value) {
        this.insertTime = value;
    }

    /**
     * Gets the value of the updateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateTime() {
        return updateTime;
    }

    /**
     * Sets the value of the updateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateTime(String value) {
        this.updateTime = value;
    }

    /**
     * Gets the value of the lastCommTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastCommTime() {
        return lastCommTime;
    }

    /**
     * Sets the value of the lastCommTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastCommTime(String value) {
        this.lastCommTime = value;
    }

    /**
     * Gets the value of the lastDataReadCommTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastDataReadCommTime() {
        return lastDataReadCommTime;
    }

    /**
     * Sets the value of the lastDataReadCommTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastDataReadCommTime(String value) {
        this.lastDataReadCommTime = value;
    }

    /**
     * Gets the value of the lastCROCTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastCROCTime() {
        return lastCROCTime;
    }

    /**
     * Sets the value of the lastCROCTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastCROCTime(String value) {
        this.lastCROCTime = value;
    }

    /**
     * Gets the value of the lastReadByCROC property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLastReadByCROC() {
        return lastReadByCROC;
    }

    /**
     * Sets the value of the lastReadByCROC property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLastReadByCROC(Boolean value) {
        this.lastReadByCROC = value;
    }

    /**
     * Gets the value of the retiredTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetiredTime() {
        return retiredTime;
    }

    /**
     * Sets the value of the retiredTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetiredTime(String value) {
        this.retiredTime = value;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGUID() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGUID(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the netDeviceID property.
     * 
     */
    public long getNetDeviceID() {
        return netDeviceID;
    }

    /**
     * Sets the value of the netDeviceID property.
     * 
     */
    public void setNetDeviceID(long value) {
        this.netDeviceID = value;
    }

    /**
     * Gets the value of the rfChannel property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRFChannel() {
        return rfChannel;
    }

    /**
     * Sets the value of the rfChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRFChannel(Integer value) {
        this.rfChannel = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the nicTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NicTypeConfig }
     *     
     */
    public NicTypeConfig getNicTypeConfig() {
        return nicTypeConfig;
    }

    /**
     * Sets the value of the nicTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicTypeConfig }
     *     
     */
    public void setNicTypeConfig(NicTypeConfig value) {
        this.nicTypeConfig = value;
    }

    /**
     * Gets the value of the nicSoftwareTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NicSoftwareTypeConfig }
     *     
     */
    public NicSoftwareTypeConfig getNicSoftwareTypeConfig() {
        return nicSoftwareTypeConfig;
    }

    /**
     * Sets the value of the nicSoftwareTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicSoftwareTypeConfig }
     *     
     */
    public void setNicSoftwareTypeConfig(NicSoftwareTypeConfig value) {
        this.nicSoftwareTypeConfig = value;
    }

    /**
     * Gets the value of the batteryInfoType property.
     * 
     * @return
     *     possible object is
     *     {@link BatteryInfoType }
     *     
     */
    public BatteryInfoType getBatteryInfoType() {
        return batteryInfoType;
    }

    /**
     * Sets the value of the batteryInfoType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatteryInfoType }
     *     
     */
    public void setBatteryInfoType(BatteryInfoType value) {
        this.batteryInfoType = value;
    }

    /**
     * Gets the value of the parentGatewayMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentGatewayMacID() {
        return parentGatewayMacID;
    }

    /**
     * Sets the value of the parentGatewayMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentGatewayMacID(String value) {
        this.parentGatewayMacID = value;
    }

    /**
     * Gets the value of the parentGatewayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentGatewayName() {
        return parentGatewayName;
    }

    /**
     * Sets the value of the parentGatewayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentGatewayName(String value) {
        this.parentGatewayName = value;
    }

    /**
     * Gets the value of the parentGatewaySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentGatewaySerialNumber() {
        return parentGatewaySerialNumber;
    }

    /**
     * Sets the value of the parentGatewaySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentGatewaySerialNumber(String value) {
        this.parentGatewaySerialNumber = value;
    }

    /**
     * Gets the value of the parentGatewayID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getParentGatewayID() {
        return parentGatewayID;
    }

    /**
     * Sets the value of the parentGatewayID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setParentGatewayID(Long value) {
        this.parentGatewayID = value;
    }

    /**
     * Gets the value of the parentDeviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceMacID() {
        return parentDeviceMacID;
    }

    /**
     * Sets the value of the parentDeviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceMacID(String value) {
        this.parentDeviceMacID = value;
    }

    /**
     * Gets the value of the parentDeviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceName() {
        return parentDeviceName;
    }

    /**
     * Sets the value of the parentDeviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceName(String value) {
        this.parentDeviceName = value;
    }

    /**
     * Gets the value of the parentDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getParentDeviceID() {
        return parentDeviceID;
    }

    /**
     * Sets the value of the parentDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setParentDeviceID(Long value) {
        this.parentDeviceID = value;
    }

    /**
     * Gets the value of the parentDeviceSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceSerialNumber() {
        return parentDeviceSerialNumber;
    }

    /**
     * Sets the value of the parentDeviceSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceSerialNumber(String value) {
        this.parentDeviceSerialNumber = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the servicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServicePointID() {
        return servicePointID;
    }

    /**
     * Sets the value of the servicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServicePointID(Long value) {
        this.servicePointID = value;
    }

}
