package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SimpleJdbcCallFactory;

import jakarta.activation.DataSource;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { OpenEventRepository.class })
@AutoConfigureMockMvc
public class OpenEventRepositoryTmpTest {

	@Autowired
	private WebApplicationContext wac;
	@Mock
	JndiDataSourceLookup test;

	@MockBean
	@Qualifier("lsarccds")
	private DataSource dataSource;

	@Mock
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	@Mock
	@Qualifier("starJdbcTemplate")
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	private SimpleJdbcCall simpleJdbcCall;

	@InjectMocks
	JdbcOpenEventRepositoryTmp openEventRepository;
	
	@Mock
	private SimpleJdbcCallFactory simpleJdbcCallFactory;

	private MockMvc mockMvc;

	private OpenEvent openEvent;

	@Mock
	ResultSet rs;

	@Test
	@Before
	public void setup() throws SQLException {
		ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		openEvent = new OpenEvent();
		DataSource mockedDataSrc = Mockito.mock(DataSource.class);
		this.oracleJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.sqlServerJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.starJdbcTemplate = Mockito.mock(JdbcTemplate.class);
		this.simpleJdbcCall = Mockito.mock(SimpleJdbcCall.class);

	}


	@SuppressWarnings("unchecked")
	@Test
	public void getNewAndActiveBoroughtest() throws SQLException {
		List<String> activeBoroughList = new ArrayList<>();
		// activeBoroughList.add("B");
		// activeBoroughList.add("M");

		List<String> newBoroughList = new ArrayList<>();
		// newBoroughList.add("B");
		// newBoroughList.add("M");

		List<String> newActiveBorough = new ArrayList<>();
		// newBoroughList.add("B");
		// newBoroughList.add("M");

		Mockito.when(rs.getString(Mockito.anyString())).thenReturn("B");
		Mockito.when(sqlServerJdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class),
				Mockito.any(RowMapper.class))).thenReturn(newBoroughList);
		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class)))
				.thenReturn(activeBoroughList);
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(newActiveBorough);
		List<String> actual = openEventRepository.getNewAndActiveBorough();
		Assert.assertEquals(newActiveBorough.size(), actual.size());

	}

	@Test
	public void getNewAndActiveEventTest() {
		List<String> eventName = new ArrayList<>();
		// eventName.add("SheepsheadBaySampleData7.27.20-1300");

		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class))).thenReturn(eventName);
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(eventName);
		List<String> actual = openEventRepository.getNewAndActiveEvent();
		Assert.assertEquals(eventName.size(), actual.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getNewAndActiveEventByBoroughtest() {

		List<String> eventName = new ArrayList<>();
		ReflectionTestUtils.setField(openEventRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		eventName.add("SheepsheadBaySampleData7.27.20-1300");
		Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(), Mockito.any(Object[].class),
				Mockito.any(RowMapper.class))).thenReturn(eventName);
		Mockito.when(openEventRepository.getNewAndActiveEventByBorough("borough")).thenReturn(eventName);
		List<String> actual = openEventRepository.getNewAndActiveEventByBorough("borough");
		Assert.assertEquals(eventName.size(), actual.size());
	}

}

	
