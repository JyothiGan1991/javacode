package com.coned.ls.domain;

/**
 * 
 * Class to store meter search details.
 *
 */
public class MeterSearch {

	private String borough;
	private String event;
	private String subEvent;
	private String meters;

	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getSubEvent() {
		return subEvent;
	}
	public void setSubEvent(String subEvent) {
		this.subEvent = subEvent;
	}
	public String getMeters() {
		return meters;
	}
	public void setMeters(String meters) {
		this.meters = meters;
	}
}
