@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package devicemanager_ws;
