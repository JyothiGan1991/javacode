/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author talatis
 */
public class AnnotationAttributesThread extends Thread {

    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(AnnotationAttributesThread.class);
    
    AnnotationAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;
        this.assetToQuery = assetToQuery;
    }

    @Override
    public void run() {

        //System.out.println("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {

            String annotationQuery = "SELECT description, GeometryType(geom.geom) geomType, ST_X(geom) xValue, ST_Y(geom) yValue, rotation, pfid \n" +
            "  FROM ed.geom where pfid in (" + assetToQuery + ");";

            //System.out.println(annotationQuery);
            
            try (ResultSet rs = connectionGeomStmt.executeQuery(annotationQuery)) {

                while (rs.next()) {
                    int fid = rs.getInt("pfid");
                    //System.out.println(fid);
                    Asset asset = assetMaster.get(fid);
                    if (asset != null) {
                        
                        double pointX = rs.getFloat("xValue");
                        double pointY = rs.getFloat("yValue");
                        String annotationGeometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                        asset.setNmsGeomAttributes("annotationGeometry", annotationGeometry);
                        
                        String geomType = rs.getString("geomType");
                        asset.setNmsGeomAttributes("annotationGeomType", geomType);
                        
                        String description = rs.getString("description");
                        asset.setNmsGeomAttributes("annotationText", description);
                        
                        double rotation = rs.getFloat("rotation"); 
                        DecimalFormat myFormatter = new DecimalFormat("#.##");
                        asset.setNmsGeomAttributes("annotationRotation", myFormatter.format(rotation));
                        
                    }
                }
                
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }
}




