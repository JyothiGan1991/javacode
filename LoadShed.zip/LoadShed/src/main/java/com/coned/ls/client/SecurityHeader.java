package com.coned.ls.client;

import java.io.IOException;

import javax.xml.soap.MimeHeaders;
import javax.xml.transform.TransformerException;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.transport.TransportConstants;

/**
 * The Class SecurityHeader.
 */
public class SecurityHeader implements WebServiceMessageCallback {

	@Override
	public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
		SaajSoapMessage soapMessage = (SaajSoapMessage) message;
		// soapMessage
		// .setSoapAction("urn:com:ssn:schema:service:v2.2:DeviceManager/DeviceManagerPortType/FindDeviceRequest");
		MimeHeaders headers = soapMessage.getSaajMessage().getMimeHeaders();
		// headers.addHeader(TransportConstants.HEADER_CONTENT_TYPE,
		// "application/soap+xml;charset=UTF-8");
		headers.addHeader(TransportConstants.HEADER_CONTENT_TYPE, "text/xml;charset=UTF-8");
	}
}
