/*package com.coned.ls.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.OpenEvent;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class OpenEventRepositoryTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	@MockBean
	private OpenEventRepository openEventRepository;
	 
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
		
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		openEvent = new  OpenEvent();
	}
	
	@Test
	public void testEvent(){
		List<String> eventName = new ArrayList<>();
		eventName.add("SheepsheadBaySampleData7.27.20-1300");
		openEvent.setEventName(eventName);
	    Assert.assertEquals(eventName.get(0), openEvent.getEventName().get(0));
	}
	
	@Test
	public void testGetEventList(){
		Set<String> eventName = new HashSet<>();
		eventName.add("SheepsheadBaySampleData7.27.20-1300");
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(eventName);
		
	}
	
}
*/