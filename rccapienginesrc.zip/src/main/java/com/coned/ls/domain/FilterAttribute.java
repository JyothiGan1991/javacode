package com.coned.ls.domain;

import java.util.List;

public class FilterAttribute {

	private String filterAttribute;
	private boolean isSuccess;

	
	
	public String getFilterAttribute() {
		return filterAttribute;
	}

	public void setFilterAttribute(String filterAttribute) {
		this.filterAttribute = filterAttribute;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
}
