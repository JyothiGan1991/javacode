/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author talatis
 */
public class CompoundCurveThread extends Thread {

    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(CompoundCurveThread.class);
    
    CompoundCurveThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;
        this.assetToQuery = assetToQuery;
    }

    @Override
    public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {

           /* String compoundCurveQuery = "SELECT ST_AsText(ST_CurveToLine(a.geom)) geom, fid\n"
                   + "  FROM ( SELECT (ST_Dump(geom)).geom AS geom , fid\n"
                   + "         FROM ed.geom where featuretypeid = 105 and geometryType(geom) != 'LINESTRING' and fid in (" + assetToQuery + ")  \n"
                   + "        ) AS a  "; */
            
            String compoundCurveQuery = "SELECT ST_AsText(ST_CurveToLine(a.geom)) geom, fid\n"
                    + "  FROM ( SELECT st_curvetoline(geom) AS geom , fid\n"
                    + "         FROM ed.geom where featuretypeid = 105 and geometryType(geom) != 'LINESTRING' and fid in (" + assetToQuery + ")  \n"
                    + "        ) AS a  ";


                 //logger.info(compoundCurveQuery);
            
            try (ResultSet rs = connectionGeomStmt.executeQuery(compoundCurveQuery)) {
                int prevfid = 0;
                String lineGeometry = "";
                if (rs.next()) {
                    prevfid = rs.getInt("fid");
                    lineGeometry = rs.getString("geom");
                    lineGeometry = lineGeometry.replaceFirst("LINESTRING", "");
                    lineGeometry = lineGeometry.replace(",", "),(");
                    lineGeometry = lineGeometry.replace(" ", ",");
                }

                while (rs.next()) {
                    int currentfid = rs.getInt("fid");
                    //logger.info(currentfid);
                    if (prevfid == currentfid) {
                        String currentGeom;
                        currentGeom = rs.getString("geom");
                        currentGeom = currentGeom.replaceFirst("LINESTRING", "");
                        currentGeom = currentGeom.replace(",", "),(");
                        currentGeom = currentGeom.replace(" ", ",");
                        lineGeometry += currentGeom;
                    } else {
                        Asset asset = assetMaster.get(prevfid);
                        if (asset != null) {
                            asset.setNmsGeomAttributes("geometry", lineGeometry);
                            asset.setNmsGeomAttributes("geomType", "LINESTRING");
                            asset.setGeomType("LINESTRING");
                            //logger.info("AssetId=" + asset.getAssetId() + "GeomType=" + asset.getGeomType() + " this was for compound curve");
                        } else {
                            logger.info("couldnt find asset for fid=" + prevfid);
                        }
                        prevfid = currentfid;
                        lineGeometry = "";
                        lineGeometry = rs.getString("geom");
                        lineGeometry = lineGeometry.replaceFirst("LINESTRING", "");
                        lineGeometry = lineGeometry.replace(",", "),(");
                        lineGeometry = lineGeometry.replace(" ", ",");

                    }
                }
                
                Asset asset = assetMaster.get(prevfid);
                if (asset != null) {
                            asset.setNmsGeomAttributes("geometry", lineGeometry);
                            asset.setNmsGeomAttributes("geomType", "LINESTRING");
                            asset.setGeomType("LINESTRING");
                            //logger.info("AssetId=" + asset.getAssetId() + "GeomType=" + asset.getGeomType() + " this was for compound curve");
                } 
                
                }

            String compoundGeomArrtibQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,geom.rotation,asset.circuit,asset.subseg,asset.mainline  from ed.geom geom, nrgcore.nrgfeaturetypedef def , asset_ed.ed_primary asset\n"
                    + "where geom.featuretypeid = def.featuretypeid\n"
                    + "and geom.fid = asset.fid\n"
                    + "and geom.featuretypeid = 105 and geometryType(geom) != 'LINESTRING' and  geom.fid in (" + assetToQuery + ")";
            
            try (ResultSet rs = connectionGeomStmt.executeQuery(compoundGeomArrtibQuery)) {
                while (rs.next()) {
                    int fid = rs.getInt("fid");
                    //logger.info(fid);
                    Asset asset = assetMaster.get(fid);
                    if (asset != null) {

                        asset.setNmsAttributes("fid", String.valueOf(fid));

                        String circuit = rs.getString("circuit");   
                        if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                             circuit = "L6-00/00-34";
                        }                        
                        asset.setCircuit(circuit);
                        asset.setNmsGeomAttributes("circuit", circuit);

                        int ftypeid = rs.getInt("featuretypeid");
                        asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                        String featuretypename = rs.getString("featuretypename");
                        asset.setNmsAttributes("featuretypename", featuretypename);
                        asset.setAssetType(featuretypename);

                        /*
                        String attributes = rs.getString("attributes");
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            if (val.length == 2) {
                                asset.setNmsAttributes(val[0], val[1]);
                            } else {
                                logger.info(" not enough attribute values");
                                logger.info(attributes);
                            }
                        }
                        */
                        
                        String subSeg = rs.getString("subseg");
                        asset.setNmsAttributes("subSegment", subSeg);
                        
                        double rotation = rs.getFloat("rotation");
                        asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                        String mainline = rs.getString("mainline");
                        asset.setNmsAttributes("mainline", mainline);

                    }

                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }
}
