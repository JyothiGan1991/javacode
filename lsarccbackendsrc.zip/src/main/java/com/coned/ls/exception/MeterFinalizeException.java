package com.coned.ls.exception;

/**
 * 
 * Class to store exception details occurred during finalization.
 *
 */
public class MeterFinalizeException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public MeterFinalizeException() {
		super();
	}

	public MeterFinalizeException(final String message, final int exceptionCode) {
		super(message);
		
	}
	
	
}
