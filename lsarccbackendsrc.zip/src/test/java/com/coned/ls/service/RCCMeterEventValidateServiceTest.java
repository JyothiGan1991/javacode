package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)
public class RCCMeterEventValidateServiceTest {

	@InjectMocks
	MeterEventValidateService meterEventValidateService;
	
	@Mock
	RESTActionExecutor restActionExecutor;
	
    @Test
    public void getValidateMeterTest()
    {
    	List<String> events = new ArrayList<String>();

    	MeterValidateResponseMapper meterValidateRes = new MeterValidateResponseMapper();
    	meterValidateRes.setBorough("B");
    	meterValidateRes.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	meterValidateRes.setPageNumber(1);
    	meterValidateRes.setPageSize(100);
    	
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		
		List<MeterEventLoad> meterEventLoads = new ArrayList<>();
		meterEventLoads.add(meterEventLoadB);
		
		meterValidateRes.setMeterEventLoads(meterEventLoads);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("B");
		meterOpenEvent.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(100);

		Mockito.when(restActionExecutor.getValidateMeter(meterOpenEvent)).thenReturn(ResponseEntity.ok().body(meterValidateRes));
   	
		ResponseEntity<MeterValidateResponseMapper> resEntity = meterEventValidateService.getValidateMeters(meterOpenEvent);
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().getMeterEventLoads().size(), 1);
		Assert.assertEquals(resEntity.getBody().getMeterEventLoads().get(0).getFeeder(), "3220");
    }	
    
    @Test
    public void getInvalidateMeters(){
    	MeterValidateResponseMapper meterValidateRes = new MeterValidateResponseMapper();
    	meterValidateRes.setBorough("B");
    	meterValidateRes.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	meterValidateRes.setPageNumber(1);
    	meterValidateRes.setPageSize(100);
    	
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		
		List<MeterEventLoad> meterEventLoads = new ArrayList<>();
		meterEventLoads.add(meterEventLoadB);
		
		meterValidateRes.setMeterEventLoads(meterEventLoads);

		Mockito.when(restActionExecutor.getInvalidateMeter("B", "BoroughHall.01.12/10/20-01:22:01.AUTO", 1, 100)).thenReturn((meterValidateRes));
   	
		MeterValidateResponseMapper resEntity = meterEventValidateService.getInvalidateMeters("B", "BoroughHall.01.12/10/20-01:22:01.AUTO", 1, 100);
   	
		Assert.assertEquals(resEntity.getMeterEventLoads().size(), 1);
		Assert.assertEquals(resEntity.getMeterEventLoads().get(0).getFeeder(), "3220");
    }
    
    @Test
    public void searchMeter(){
    	MeterValidateResponseMapper meterValidateRes = new MeterValidateResponseMapper();
    	meterValidateRes.setBorough("B");
    	meterValidateRes.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	meterValidateRes.setPageNumber(1);
    	meterValidateRes.setPageSize(100);
    	
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		
		List<MeterEventLoad> meterEventLoads = new ArrayList<>();
		meterEventLoads.add(meterEventLoadB);
		
		meterValidateRes.setMeterEventLoads(meterEventLoads);

		MeterSearch ms = new MeterSearch();
		Mockito.when(restActionExecutor.searchMeter(ms)).thenReturn((meterValidateRes));
   	
		MeterValidateResponseMapper resEntity = meterEventValidateService.searchMeter(ms);
   	
		Assert.assertEquals(resEntity.getMeterEventLoads().size(), 1);
		Assert.assertEquals(resEntity.getMeterEventLoads().get(0).getFeeder(), "3220");
    }
    
    @Test
    public void getLockedStatusByBoroughAndEventNameTest(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
		Mockito.when(restActionExecutor.getLockedStatusByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = meterEventValidateService.getLockedStatusByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK");
		Assert.assertEquals(mlsp.getMessage(),response.getMessage());
    }
    
    @Test
    public void  getFieldValuesByBoroughAndEventNameTest(){
    	List<String> fields = new ArrayList<String>();
    	
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(fields, HttpStatus.OK);
    	
		Mockito.when(restActionExecutor.getFieldValuesByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","sub_event")).thenReturn((response));
		ResponseEntity<List<String>> actual = meterEventValidateService.getFieldValuesByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","sub_event");
		Assert.assertEquals(response.getBody(),actual.getBody());
    }
    @Test(expected = IllegalArgumentException.class)
    public void  getInvalidFieldValuesByBoroughAndEventNameTest(){
    	List<String> fields = new ArrayList<String>();
    	
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(fields, HttpStatus.OK);
    	
		Mockito.when(restActionExecutor.getFieldValuesByBoroughAndEventName(null,null,null)).thenReturn((response));
		ResponseEntity<List<String>> actual = meterEventValidateService.getFieldValuesByBoroughAndEventName(null,null,null);
		Assert.assertEquals(response.getBody(),actual.getBody());
    }
    
    @Test
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doNothing().when(restActionExecutor).unlockEvents(adid);
	    //assertEquals(0, rccConnectController.unlockEvents(request));
		meterEventValidateService.unlockEvents(adid);
	}
	
    
}
