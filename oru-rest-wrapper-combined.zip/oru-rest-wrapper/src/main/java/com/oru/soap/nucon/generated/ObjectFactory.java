
package com.oru.soap.nucon.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oru.soap.nucon.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetElectricInfoByAccount_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByAccount");
    private final static QName _GetElectricInfoByAccountResponse_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByAccountResponse");
    private final static QName _GetElectricInfoByPremise_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByPremise");
    private final static QName _GetElectricInfoByPremiseResponse_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByPremiseResponse");
    private final static QName _GetElectricInfoByXYCoordinates_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByXYCoordinates");
    private final static QName _GetElectricInfoByXYCoordinatesResponse_QNAME = new QName("http://oss.oru.com/", "getElectricInfoByXYCoordinatesResponse");
    private final static QName _LocateInNRGViewer_QNAME = new QName("http://oss.oru.com/", "locateInNRGViewer");
    private final static QName _LocateInNRGViewerResponse_QNAME = new QName("http://oss.oru.com/", "locateInNRGViewerResponse");
    private final static QName _SendToNRG_QNAME = new QName("http://oss.oru.com/", "sendToNRG");
    private final static QName _SendToNRGResponse_QNAME = new QName("http://oss.oru.com/", "sendToNRGResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oru.soap.nucon.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetElectricInfoByAccount }
     * 
     */
    public GetElectricInfoByAccount createGetElectricInfoByAccount() {
        return new GetElectricInfoByAccount();
    }

    /**
     * Create an instance of {@link GetElectricInfoByAccountResponse }
     * 
     */
    public GetElectricInfoByAccountResponse createGetElectricInfoByAccountResponse() {
        return new GetElectricInfoByAccountResponse();
    }

    /**
     * Create an instance of {@link GetElectricInfoByPremise }
     * 
     */
    public GetElectricInfoByPremise createGetElectricInfoByPremise() {
        return new GetElectricInfoByPremise();
    }

    /**
     * Create an instance of {@link GetElectricInfoByPremiseResponse }
     * 
     */
    public GetElectricInfoByPremiseResponse createGetElectricInfoByPremiseResponse() {
        return new GetElectricInfoByPremiseResponse();
    }

    /**
     * Create an instance of {@link GetElectricInfoByXYCoordinates }
     * 
     */
    public GetElectricInfoByXYCoordinates createGetElectricInfoByXYCoordinates() {
        return new GetElectricInfoByXYCoordinates();
    }

    /**
     * Create an instance of {@link GetElectricInfoByXYCoordinatesResponse }
     * 
     */
    public GetElectricInfoByXYCoordinatesResponse createGetElectricInfoByXYCoordinatesResponse() {
        return new GetElectricInfoByXYCoordinatesResponse();
    }

    /**
     * Create an instance of {@link LocateInNRGViewer }
     * 
     */
    public LocateInNRGViewer createLocateInNRGViewer() {
        return new LocateInNRGViewer();
    }

    /**
     * Create an instance of {@link LocateInNRGViewerResponse }
     * 
     */
    public LocateInNRGViewerResponse createLocateInNRGViewerResponse() {
        return new LocateInNRGViewerResponse();
    }

    /**
     * Create an instance of {@link SendToNRG }
     * 
     */
    public SendToNRG createSendToNRG() {
        return new SendToNRG();
    }

    /**
     * Create an instance of {@link SendToNRGResponse }
     * 
     */
    public SendToNRGResponse createSendToNRGResponse() {
        return new SendToNRGResponse();
    }

    /**
     * Create an instance of {@link ElectricInfo }
     * 
     */
    public ElectricInfo createElectricInfo() {
        return new ElectricInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByAccount }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByAccount }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByAccount")
    public JAXBElement<GetElectricInfoByAccount> createGetElectricInfoByAccount(GetElectricInfoByAccount value) {
        return new JAXBElement<GetElectricInfoByAccount>(_GetElectricInfoByAccount_QNAME, GetElectricInfoByAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByAccountResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByAccountResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByAccountResponse")
    public JAXBElement<GetElectricInfoByAccountResponse> createGetElectricInfoByAccountResponse(GetElectricInfoByAccountResponse value) {
        return new JAXBElement<GetElectricInfoByAccountResponse>(_GetElectricInfoByAccountResponse_QNAME, GetElectricInfoByAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByPremise }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByPremise }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByPremise")
    public JAXBElement<GetElectricInfoByPremise> createGetElectricInfoByPremise(GetElectricInfoByPremise value) {
        return new JAXBElement<GetElectricInfoByPremise>(_GetElectricInfoByPremise_QNAME, GetElectricInfoByPremise.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByPremiseResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByPremiseResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByPremiseResponse")
    public JAXBElement<GetElectricInfoByPremiseResponse> createGetElectricInfoByPremiseResponse(GetElectricInfoByPremiseResponse value) {
        return new JAXBElement<GetElectricInfoByPremiseResponse>(_GetElectricInfoByPremiseResponse_QNAME, GetElectricInfoByPremiseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByXYCoordinates }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByXYCoordinates }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByXYCoordinates")
    public JAXBElement<GetElectricInfoByXYCoordinates> createGetElectricInfoByXYCoordinates(GetElectricInfoByXYCoordinates value) {
        return new JAXBElement<GetElectricInfoByXYCoordinates>(_GetElectricInfoByXYCoordinates_QNAME, GetElectricInfoByXYCoordinates.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByXYCoordinatesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElectricInfoByXYCoordinatesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "getElectricInfoByXYCoordinatesResponse")
    public JAXBElement<GetElectricInfoByXYCoordinatesResponse> createGetElectricInfoByXYCoordinatesResponse(GetElectricInfoByXYCoordinatesResponse value) {
        return new JAXBElement<GetElectricInfoByXYCoordinatesResponse>(_GetElectricInfoByXYCoordinatesResponse_QNAME, GetElectricInfoByXYCoordinatesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocateInNRGViewer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LocateInNRGViewer }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "locateInNRGViewer")
    public JAXBElement<LocateInNRGViewer> createLocateInNRGViewer(LocateInNRGViewer value) {
        return new JAXBElement<LocateInNRGViewer>(_LocateInNRGViewer_QNAME, LocateInNRGViewer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocateInNRGViewerResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LocateInNRGViewerResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "locateInNRGViewerResponse")
    public JAXBElement<LocateInNRGViewerResponse> createLocateInNRGViewerResponse(LocateInNRGViewerResponse value) {
        return new JAXBElement<LocateInNRGViewerResponse>(_LocateInNRGViewerResponse_QNAME, LocateInNRGViewerResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendToNRG }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendToNRG }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "sendToNRG")
    public JAXBElement<SendToNRG> createSendToNRG(SendToNRG value) {
        return new JAXBElement<SendToNRG>(_SendToNRG_QNAME, SendToNRG.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendToNRGResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendToNRGResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://oss.oru.com/", name = "sendToNRGResponse")
    public JAXBElement<SendToNRGResponse> createSendToNRGResponse(SendToNRGResponse value) {
        return new JAXBElement<SendToNRGResponse>(_SendToNRGResponse_QNAME, SendToNRGResponse.class, null, value);
    }

}
