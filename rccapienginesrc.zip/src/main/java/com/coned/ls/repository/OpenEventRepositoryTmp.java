package com.coned.ls.repository;

import java.util.List;

/**
 * 
 * Interface for Open Evevnt repository class.
 *
 */
public interface OpenEventRepositoryTmp {
	
	// RCC Disconnect
	public List<String> getNewAndActiveBorough();
	public List<String> getNewAndActiveEvent();
	public List<String> getNewAndActiveEventByBorough(final String borough);

}