package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

/**
 * 
 * Service class for RCC Disconnect and RCC Connect.
 *
 */
@Component
public class OpenEventService {

	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	RESTActionExecutorConnect restActionExecutorConnect = new  RESTActionExecutorConnect();
	
	/*
	 * This method read list of borough or event names for RCC Disconnect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getBoroughAndEventName(final String fields){
		return restActionExecutor.getBoroughAndEventName(fields);
	}
	
	/*
	 * This method read list of open events by borough for RCC Disconnect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getOpenEvent(final String fields){
		return restActionExecutor.getOpenEvent(fields);
	}
	
	/*
	 * This method read list of borough or event for RCC Connect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getBoroughAndEventNameForConnect(final String fields){
		return restActionExecutorConnect.getBoroughAndEventNameForConnect(fields);
	}
	
	/*
	 * This method read list of open events by borough for RCC Connect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getOpenEventForConnect(final String fields){
		return restActionExecutorConnect.getOpenEventForConnect(fields);
	}
	
	/*
	 * Method to read list of sub borough for RCC Connect.
	 * 
	 * @param  fields String
     * @return 		  ResponseEntity<List<String>> 
	 */
	public ResponseEntity<List<String>> getSubFinalizeBorough(final String fields){
		return restActionExecutorConnect.getSubFinalizeBorough(fields);
	}
	
	/*
	 * Method to read list of sub event for RCC Connect.
	 * 
	 * @param  fields String
     * @return 		  ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubFinalizeEvent(final String fields){
		return restActionExecutorConnect.getSubFinalizeEvent(fields);
	}
	
	/*
	 * Method to read list of sub event by borough for RCC Connect.
	 * 
	 * @param  borough String
     * @return 		   ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(final String borough){
		return restActionExecutorConnect.getSubEventNameBySubBorough(borough);
	}
	
	/*
	 * Method to read list of Sub Event names for the event for RCC Connect.
	 * 
	 * @param  borough   String
	 * @param  eventName String
     * @return 			 ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubFinalizeEventByEventAndBorough(final String borough, final String eventName){
		return restActionExecutorConnect.getSubFinalizeEventByEventAndBorough(borough, eventName);
	}
}
