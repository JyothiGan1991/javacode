package com.oru.poe.rest.service;

import com.oru.poe.rest.dto.IncidentCountRequest;
import com.oru.poe.rest.dto.IsGasMainRequest;
import com.oru.poe.rest.dto.VerifyPoleRequest;
import com.oru.poe.rest.exception.SoapServiceException;
import com.oru.poe.soap.generated.POEServiceException_Exception;
import com.oru.poe.soap.generated.POEWebServicesSEI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PoeSoapService {

    private static final Logger log = LoggerFactory.getLogger(PoeSoapService.class);

    private final POEWebServicesSEI soapClient;

    public PoeSoapService(POEWebServicesSEI soapClient) {
        this.soapClient = soapClient;
    }

    /**
     * Calls SOAP isGasMain operation.
     */
    public boolean isGasMain(IsGasMainRequest request) {
        log.debug("Calling SOAP isGasMain with premise={}, radius={}", request.getPremise(), request.getRadius());
        try {
            boolean result = soapClient.isGasMain(request.getPremise(), request.getRadius());
            log.debug("SOAP isGasMain returned: {}", result);
            return result;
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on isGasMain: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call isGasMain SOAP service: " + e.getMessage(), e);
        }
    }

    /**
     * Calls SOAP verifyPole operation.
     */
    public boolean verifyPole(VerifyPoleRequest request) {
        log.debug("Calling SOAP verifyPole with x={}, y={}", request.getX(), request.getY());
        try {
            boolean result = soapClient.verifyPole(request.getX(), request.getY());
            log.debug("SOAP verifyPole returned: {}", result);
            return result;
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on verifyPole: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call verifyPole SOAP service: " + e.getMessage(), e);
        }
    }

    /**
     * Calls SOAP incidentCount operation.
     */
    public int incidentCount(IncidentCountRequest request) {
        log.debug("Calling SOAP incidentCount with startDate={}, startTime={}, endDate={}, endTime={}",
                request.getStartDate(), request.getStartTime(), request.getEndDate(), request.getEndTime());
        try {
            int result = soapClient.incidentCount(
                    request.getStartDate(),
                    request.getStartTime(),
                    request.getEndDate(),
                    request.getEndTime());
            log.debug("SOAP incidentCount returned: {}", result);
            return result;
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on incidentCount: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call incidentCount SOAP service: " + e.getMessage(), e);
        }
    }
}
