
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReplaceLocationReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReplaceLocationReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Device" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceIdentifier"/&gt;
 *         &lt;element name="Note" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OldUtilServicePtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OldServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NewLocationInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateDeviceLocationType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReplaceLocationReqType", propOrder = {
    "device",
    "note",
    "oldUtilServicePtID",
    "oldServiceType",
    "newLocationInfo"
})
public class ReplaceLocationReqType {

    @XmlElement(name = "Device", required = true)
    protected DeviceIdentifier device;
    @XmlElement(name = "Note")
    protected String note;
    @XmlElement(name = "OldUtilServicePtID")
    protected String oldUtilServicePtID;
    @XmlElement(name = "OldServiceType")
    protected String oldServiceType;
    @XmlElement(name = "NewLocationInfo", required = true)
    protected UpdateDeviceLocationType newLocationInfo;

    /**
     * Gets the value of the device property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceIdentifier }
     *     
     */
    public DeviceIdentifier getDevice() {
        return device;
    }

    /**
     * Sets the value of the device property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceIdentifier }
     *     
     */
    public void setDevice(DeviceIdentifier value) {
        this.device = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the oldUtilServicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldUtilServicePtID() {
        return oldUtilServicePtID;
    }

    /**
     * Sets the value of the oldUtilServicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldUtilServicePtID(String value) {
        this.oldUtilServicePtID = value;
    }

    /**
     * Gets the value of the oldServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldServiceType() {
        return oldServiceType;
    }

    /**
     * Sets the value of the oldServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldServiceType(String value) {
        this.oldServiceType = value;
    }

    /**
     * Gets the value of the newLocationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateDeviceLocationType }
     *     
     */
    public UpdateDeviceLocationType getNewLocationInfo() {
        return newLocationInfo;
    }

    /**
     * Sets the value of the newLocationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateDeviceLocationType }
     *     
     */
    public void setNewLocationInfo(UpdateDeviceLocationType value) {
        this.newLocationInfo = value;
    }

}
