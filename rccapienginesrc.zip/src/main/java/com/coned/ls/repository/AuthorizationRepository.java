package com.coned.ls.repository;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;

/**
 * 
 * Interface for Authorization Repository.
 *
 */
public interface AuthorizationRepository {
	public boolean isOperatorAuthorized(final String operatorADID, final String role) throws OperatorAuthorizationException;
	public OperatorLoginDetail persistApi(final OperatorLoginDetail operatorLoginDetail) throws OperatorAuthorizationException;
	public OperatorLoginDetail getOperatorLoginDetail(final String adid,final String role) throws OperatorAuthorizationException;
	public boolean isAPIEndpointAuthorizeed(final String adid,final String apiKey, final int apiKeyStatus, final int loginStatus) throws OperatorAuthorizationException;
}
