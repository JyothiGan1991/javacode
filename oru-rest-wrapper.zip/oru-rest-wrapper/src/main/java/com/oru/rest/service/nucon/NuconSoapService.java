package com.oru.rest.service.nucon;

import com.oru.rest.dto.AccountRequest;
import com.oru.rest.dto.ElectricInfoDto;
import com.oru.rest.dto.LocateInNrgViewerRequest;
import com.oru.rest.dto.PremiseRequest;
import com.oru.rest.dto.SendToNrgRequest;
import com.oru.rest.dto.XYCoordinatesRequest;
import com.oru.rest.exception.SoapServiceException;
import com.oru.soap.nucon.generated.ElectricInfo;
import com.oru.soap.nucon.generated.NuconWS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class NuconSoapService {

    private static final Logger log = LoggerFactory.getLogger(NuconSoapService.class);
    private final NuconWS soapClient;

    public NuconSoapService(NuconWS soapClient) {
        this.soapClient = soapClient;
    }

    public ElectricInfoDto getElectricInfoByAccount(AccountRequest request) {
        log.debug("SOAP getElectricInfoByAccount account={}", request.getAccount());
        try {
            return toDto(soapClient.getElectricInfoByAccount(request.getAccount()));
        } catch (Exception e) {
            throw new SoapServiceException("Failed getElectricInfoByAccount: " + e.getMessage(), e);
        }
    }

    public ElectricInfoDto getElectricInfoByPremise(PremiseRequest request) {
        log.debug("SOAP getElectricInfoByPremise premise={}", request.getPremise());
        try {
            return toDto(soapClient.getElectricInfoByPremise(request.getPremise()));
        } catch (Exception e) {
            throw new SoapServiceException("Failed getElectricInfoByPremise: " + e.getMessage(), e);
        }
    }

    public ElectricInfoDto getElectricInfoByXYCoordinates(XYCoordinatesRequest request) {
        log.debug("SOAP getElectricInfoByXY x={}, y={}", request.getX(), request.getY());
        try {
            return toDto(soapClient.getElectricInfoByXYCoordinates(request.getX(), request.getY()));
        } catch (Exception e) {
            throw new SoapServiceException("Failed getElectricInfoByXYCoordinates: " + e.getMessage(), e);
        }
    }

    public void sendToNRG(SendToNrgRequest request) {
        log.debug("SOAP sendToNRG");
        try {
            soapClient.sendToNRG(request.getArg0(), request.getArg1(), request.getArg2());
        } catch (Exception e) {
            throw new SoapServiceException("Failed sendToNRG: " + e.getMessage(), e);
        }
    }

    public void locateInNRGViewer(LocateInNrgViewerRequest request) {
        log.debug("SOAP locateInNRGViewer");
        try {
            soapClient.locateInNRGViewer(request.getArg0(), request.getArg1(), request.getArg2(), request.getArg3());
        } catch (Exception e) {
            throw new SoapServiceException("Failed locateInNRGViewer: " + e.getMessage(), e);
        }
    }

    private ElectricInfoDto toDto(ElectricInfo info) {
        if (info == null) return null;
        ElectricInfoDto dto = new ElectricInfoDto();
        dto.setPartiality(info.getPartiality());
        dto.setCircuit(info.getCircuit());
        dto.setCode(info.getCode());
        dto.setHgridX(info.getHgridX());
        dto.setHgridY(info.getHgridY());
        dto.setInvolt(info.getInvolt());
        dto.setKva1(info.getKVA1());
        dto.setKva2(info.getKVA2());
        dto.setKva3(info.getKVA3());
        dto.setKyBa(info.getKyBa());
        dto.setKyPremNo(info.getKyPremNo());
        dto.setPhase(info.getPhase());
        dto.setPhase3(info.getPhase3());
        dto.setSegment(info.getSegment());
        dto.setService(info.getService());
        dto.setServpoleX(info.getServpoleX());
        dto.setServpoleY(info.getServpoleY());
        dto.setTranGridX(info.getTranGridX());
        dto.setTranGridY(info.getTranGridY());
        dto.setTransformer(info.getTransformer());
        dto.setTranstype(info.getTranstype());
        return dto;
    }
}
