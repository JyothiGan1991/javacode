
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DemandResetFailureFileSegmentingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DemandResetFailureFileSegmentingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="NumberDevices" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="MaxFileSizeInMB" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="MaxLinesPerFile" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DemandResetFailureFileSegmentingType", propOrder = {
    "numberDevices",
    "maxFileSizeInMB",
    "maxLinesPerFile"
})
public class DemandResetFailureFileSegmentingType {

    @XmlElement(name = "NumberDevices")
    protected Integer numberDevices;
    @XmlElement(name = "MaxFileSizeInMB")
    protected Integer maxFileSizeInMB;
    @XmlElement(name = "MaxLinesPerFile")
    protected Integer maxLinesPerFile;

    /**
     * Gets the value of the numberDevices property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberDevices() {
        return numberDevices;
    }

    /**
     * Sets the value of the numberDevices property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberDevices(Integer value) {
        this.numberDevices = value;
    }

    /**
     * Gets the value of the maxFileSizeInMB property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxFileSizeInMB() {
        return maxFileSizeInMB;
    }

    /**
     * Sets the value of the maxFileSizeInMB property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxFileSizeInMB(Integer value) {
        this.maxFileSizeInMB = value;
    }

    /**
     * Gets the value of the maxLinesPerFile property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxLinesPerFile() {
        return maxLinesPerFile;
    }

    /**
     * Sets the value of the maxLinesPerFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxLinesPerFile(Integer value) {
        this.maxLinesPerFile = value;
    }

}
