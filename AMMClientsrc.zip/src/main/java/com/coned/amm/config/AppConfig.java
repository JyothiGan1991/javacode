package com.coned.amm.config;

import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import devicemanager_ws.DeviceManagerPortType;
import devicemanager_ws.DeviceManagerService;
import devicemanager_ws.DeviceSearchParametersType;
import devicemanager_ws.ErrorCodeFault;
import devicemanager_ws.FindBaseDeviceType;
import devicemanager_ws.FindDeviceReqType;
import devicemanager_ws.FindDeviceResponse;
import devicemanager_ws.FindDeviceResponseType;
import deviceresults_ws.DeviceResultsPortType;
import deviceresults_ws.DeviceResultsService;
import jobmanager_ws.JobManagerPortType;
import jobmanager_ws.JobManagerService;

@Configuration
@Import(RSMConfig.class)
public class AppConfig {
	private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);

	@Autowired
	RSMConfig config;

	private void populateDMPBindingProvider(DeviceManagerPortType dip) {
		((BindingProvider) dip).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				config.getDeviceManagerUri());
		((BindingProvider) dip).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, config.getUsername());
		((BindingProvider) dip).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, config.getPassword());
	}

	@Bean(name = "deviceManagerService")
	public DeviceManagerPortType deviceManagerService() {
		DeviceManagerService dms = new DeviceManagerService();
		DeviceManagerPortType dip = dms.getDeviceManagerPort();
		logger.info("Before setting the service URI and credentails");
		// Set Webservice credentials
		populateDMPBindingProvider(dip);
		logger.info("After setting the service URI with user "+ config.getUsername() +" in DeviceManagerPortType Binding Provider");
		return dip;
	}

	@Bean(name = "jobManagerService")
	public JobManagerPortType jobManagerService() {
		JobManagerService dms = new JobManagerService();
		JobManagerPortType jip = dms.getJobManagerPort();

		((BindingProvider) jip).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				config.getJobManagerUri());
		((BindingProvider) jip).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, config.getUsername());
		((BindingProvider) jip).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, config.getPassword());
		logger.info("After setting the service URI with user "+ config.getUsername() +" in JobManagerPortType Binding Provider");
		return jip;
	}

	@Bean(name = "deviceResultsService")
	public DeviceResultsPortType deviceResultsService() {
		DeviceResultsService drs = new DeviceResultsService();
		DeviceResultsPortType drp = drs.getDeviceResults();
		((BindingProvider) drp).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				config.getDeviceResultsUri());
		((BindingProvider) drp).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, config.getUsername());
		((BindingProvider) drp).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, config.getPassword());
		logger.info("After setting the service URI with user "+ config.getUsername() +" in DeviceResultsPortType Binding Provider");
		return drp;
	}
	
	
}
