package com.coned.aoccws.beans;

public class AoccResponse {
	private Boolean success;
	
	private String message;

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public AoccResponse(Boolean success, String message) {
		super();
		this.success = success;
		this.message = message;
	}

	public AoccResponse() {
		// TODO Auto-generated constructor stub
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "AoccResponse [success=" + success + ", message=" + message + "]";
	}	
	
}
