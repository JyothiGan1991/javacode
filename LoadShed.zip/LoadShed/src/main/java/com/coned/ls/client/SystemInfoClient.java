/*
 * package com.coned.ls.client;
 * 
 * import javax.xml.soap.SOAPException;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.ws.client.core.WebServiceTemplate; import
 * org.springframework.ws.client.core.support.WebServiceGatewaySupport; import
 * org.springframework.ws.client.support.interceptor.ClientInterceptor;
 * 
 * import com.coned.ls.CustomInterceptor; import
 * com.ssn.schema.service.v2_2.systeminfo.EmptyType;
 * 
 * public class SystemInfoClient extends WebServiceGatewaySupport { private
 * static final Logger logger = LoggerFactory.getLogger(SystemInfoClient.class);
 * 
 * public Object test() throws SOAPException { EmptyType type = new EmptyType();
 * 
 * WebServiceTemplate webServiceTemplate = getWebServiceTemplate(); // register
 * the LogHttpHeaderClientInterceptor ClientInterceptor[] interceptors = new
 * ClientInterceptor[] { new CustomInterceptor() };
 * webServiceTemplate.setInterceptors(interceptors);
 * 
 * logger.info("DefaultUri " + webServiceTemplate.getDefaultUri());
 * logger.info("MESSAGE_TRACING_LOG_CATEGORY " +
 * webServiceTemplate.MESSAGE_TRACING_LOG_CATEGORY); logger.info("Interceptors "
 * + webServiceTemplate.getInterceptors()); logger.info("" +
 * webServiceTemplate.getMarshaller()); logger.info("" +
 * webServiceTemplate.getUnmarshaller()); logger.info("" +
 * webServiceTemplate.getMessageSenders());
 * 
 * 
 * return webServiceTemplate.marshalSendAndReceive(
 * "https://mt.devl01.con.ssnsgs.net:3009/amm/webservice/v2_4/SystemInfoPort",
 * new systemInfo_ws.ObjectFactory().createGetUIQVersion(type), new
 * SecurityHeader());
 * 
 * 
 * return webServiceTemplate.marshalSendAndReceive(
 * "https://mt.devl01.con.ssnsgs.net:3009/amm/webservice/v2_4/SystemInfoPort",
 * type, new SecurityHeader());
 * 
 * } }
 */