
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TimeZoneType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TimeZoneType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneTypeEnum"/&gt;
 *         &lt;element name="StandardizedName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocalizedValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TimeZoneType", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd", propOrder = {
    "name",
    "standardizedName",
    "localizedValue"
})
public class TimeZoneType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected TimeZoneTypeEnum name;
    @XmlElement(name = "StandardizedName")
    protected String standardizedName;
    @XmlElement(name = "LocalizedValue")
    protected String localizedValue;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneTypeEnum }
     *     
     */
    public TimeZoneTypeEnum getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneTypeEnum }
     *     
     */
    public void setName(TimeZoneTypeEnum value) {
        this.name = value;
    }

    /**
     * Gets the value of the standardizedName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandardizedName() {
        return standardizedName;
    }

    /**
     * Sets the value of the standardizedName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandardizedName(String value) {
        this.standardizedName = value;
    }

    /**
     * Gets the value of the localizedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedValue() {
        return localizedValue;
    }

    /**
     * Sets the value of the localizedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedValue(String value) {
        this.localizedValue = value;
    }

}
