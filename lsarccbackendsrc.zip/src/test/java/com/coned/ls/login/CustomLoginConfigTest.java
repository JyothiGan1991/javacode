package com.coned.ls.login;
import javax.security.auth.login.AppConfigurationEntry;


import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class CustomLoginConfigTest {
	@Rule
	public MockitoRule rule = MockitoJUnit.rule().silent();
	
	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private HttpServletRequest request;
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@InjectMocks
	CustomLoginConfig customLoginConfig;

   @Test
   public void getAppConfigurationEntry(){
	 // static void setFinalStatic(CustomLoginConfig.class.getDeclaredField("APP_NAME"), "MyApp");
	   //ReflectionTestUtils.setField(CustomLoginConfig, "APP_NAME", "MyApp");
	   AppConfigurationEntry[] configArr = customLoginConfig.getAppConfigurationEntry("MyApp");
	   Assert.assertNotNull(configArr);
   }
}
