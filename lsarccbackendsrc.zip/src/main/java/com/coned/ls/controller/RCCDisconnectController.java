package com.coned.ls.controller;

import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventFinalizeService;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.utility.DateUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller to implement Rest Api's for RCC Disconnect.
 * 
 */
@RestController
@RequestMapping("/lsa-rcc-disconnect")
public class RCCDisconnectController {
	
	private static final Logger LOGGER = LogManager.getLogger(RCCDisconnectController.class);

	@Autowired
	private MeterEventFinalizeService meterEventFinalizeService;
	
	@Autowired
	private OpenEventService openEventService;
	
	@Autowired
	private MeterEventValidateService meterEventValidateService;
	
    /*
     * API will return list of borough if the value of parameter is boro or list of event names if 
     * the value is event_name. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields  	Valid input for this parameter are boro and event_name. 
     * @return 				 	ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/meters")
	public ResponseEntity<List<String>> getBoroughAndEventName(@RequestParam(name = "fields") String fields){
		LOGGER.info(String.format("Request for list of borough or event names"));
		
		if ((fields.equalsIgnoreCase("boro") || fields.equalsIgnoreCase("event_name"))) {
			return openEventService.getBoroughAndEventName(fields);
		} else {
			throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
		}
	}

    /*
     * API to return list of event names for given borough.
     * 
     * @PathVariable borough 	Name of the borough. 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/meters/{borough}")
	public ResponseEntity<List<String>> getEventNameByBorough(@PathVariable(name = "borough") String borough){
		LOGGER.info(String.format("Request for open event by borough : %s", borough));
		
		return openEventService.getOpenEvent(borough);
	}

    /*
     * API to return list of meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @RequestBody meterOpenEvent  MeterOpenEvent 
     * @return 						ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@PostMapping("/events/meters")
	public ResponseEntity<MeterValidateResponseMapper> getValidateMeter(HttpServletRequest request, @RequestBody MeterOpenEvent meterOpenEvent ) {	
		long processStartTime = DateUtils.processStartTime();
		
		LOGGER.info(String.format("Request for list of meters created for borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == adid || adid.equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		
		if(null==meterOpenEvent || isEmptyOrNull(meterOpenEvent.getBorough()) || isEmptyOrNull(meterOpenEvent.getEventName())){
			MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
			meterValidateResponseMapper.setMessage("Invalid paramter passed");
			return ResponseEntity.status(701).body(meterValidateResponseMapper);
		}
		
		int startRowIndex =  meterOpenEvent.getStartRowIndex() == 0 ? 1 : meterOpenEvent.getStartRowIndex();
		int batchSize =  meterOpenEvent.getBatchSize() == 0 ? 500 : meterOpenEvent.getBatchSize();
		
		meterOpenEvent.setBatchSize(batchSize);
		meterOpenEvent.setStartRowIndex(startRowIndex);
		meterOpenEvent.setAdid(adid);
		meterOpenEvent.setFromDate(DateUtils.get3DaysOldDateAsString());
		meterOpenEvent.setToDate(DateUtils.getCurrentDateAsString());

		ResponseEntity<MeterValidateResponseMapper> response = meterEventValidateService.getValidateMeters(meterOpenEvent);

		if(!response.getBody().isValidResponse() && !response.getBody().getIsEventFinalized()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
		}

		LOGGER.info(String.format("LogWriter ----> RCC Valid Meters Response Before UI : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return response;
	}

    /*
     * API to finalize the list of meters for disconnect.
     * 
     * @RequestBody meterEventFinalize  MeterEventFinalize 
     * @return 							ResponseEntity<String>  
     *                         
     */
	@PostMapping("/events/finalize/meters")
	public ResponseEntity<String> finalizeValidateMeters(HttpServletRequest request, @RequestBody MeterEventFinalize meterEventFinalize) throws Exception {
		//LOGGER.info(String.format("Request for finalizing the list of meters created for borough : %s", meterEventFinalize.getBorough(), " eventName : %s", meterEventFinalize.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return meterEventFinalizeService.finalizeValidateMeter(meterEventFinalize, adid);
	}

    /*
     * API to search list of meters.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@PostMapping("/events/search/meters")
	public ResponseEntity<MeterValidateResponseMapper> searchMeter(@RequestBody MeterSearch meterSearch) throws Exception {
		LOGGER.info(String.format("Request for searching list of meters created for borough : %s", meterSearch.getBorough(), " eventName : %s", meterSearch.getEvent()));

		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		
		if(null != meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			meterValidateResponseMapper = meterEventValidateService.searchMeter(meterSearch);
		}else{
			throw new IllegalArgumentException();
		}

		if(!meterValidateResponseMapper.isValidResponse()){
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(meterValidateResponseMapper);
		}
		
		return ResponseEntity.ok().body(meterValidateResponseMapper);
	}	

    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/meters/fields/{borough}")
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		LOGGER.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));
		
		return meterEventValidateService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
	}

    /*
     * API to return locked status of the event.
     * 
     * @RequestParam borough  	String
     * @RequestParam eventName  String
     * @return 					MeterLockedStatusResponseMapper  
     *                         
     */
	@GetMapping("/events/status/meters")
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(HttpServletRequest request, @RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName){
		LOGGER.info(String.format("Request for locked status of the event by borough : %s", borough, " eventName : %s", eventName));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return meterEventValidateService.getLockedStatusByBoroughAndEventName(borough, eventName, adid);
	}
	
	public boolean isEmptyOrNull(String string){
		return (isNull(string) || isEmpty(string));
	}
	
	public boolean isNull(final String string){
		return (null==string);
	}
	
	public boolean isEmpty(final String string){
		return (string.trim().length()<=0);
	}
	
    /*
     * API to unlock events.
     * 
     * @Param request  	HttpServletRequest
     * @return 			void  
     *                         
     */
	@PutMapping("/events/status/meters")
	public void unlockEvents(HttpServletRequest request) {
		LOGGER.info(String.format("Request for unlocking the events"));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		meterEventValidateService.unlockEvents(adid);
	}
}
