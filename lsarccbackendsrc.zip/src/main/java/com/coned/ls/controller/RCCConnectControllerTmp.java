package com.coned.ls.controller;

import java.util.ArrayList;
import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventFinalizeService;
import com.coned.ls.service.MeterEventFinalizeServiceTmp;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.OpenEventServiceTmp;
import com.coned.ls.utility.DateUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller to implement Rest Api's for RCC Connect data setting.
 * 
 */
@RestController
@RequestMapping("/lsa-rcc-connect-tmp")
public class RCCConnectControllerTmp {
	
	private static final Logger LOGGER = LogManager.getLogger(RCCConnectControllerTmp.class);

	@Autowired
	private MeterEventFinalizeServiceTmp meterEventFinalizeService;
	
	@Autowired
	private OpenEventServiceTmp openEventServiceTmp;
	
	@GetMapping("/events/active/meters")
	public ResponseEntity<List<String>> getBoroughAndEventName(@RequestParam(name = "fields") String fields){
		LOGGER.info(String.format("Request for list of borough or event names"));
		
		if ((fields.equalsIgnoreCase("boro") || fields.equalsIgnoreCase("event_name"))) {
			return openEventServiceTmp.getBoroughAndEventName(fields);
		} else {
			throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
		}
	}

	@GetMapping("/events/active/meters/{borough}")
	public ResponseEntity<List<String>> getEventNameByBorough(@PathVariable(name = "borough") String borough){
		LOGGER.info(String.format("Request for open event by borough : %s", borough));
		
		return openEventServiceTmp.getOpenEvent(borough);
	}
	
	@GetMapping("/event/meter/data")
	public ResponseEntity<String> finalizeValidateMeters(HttpServletRequest request, @RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName) throws Exception {
		LOGGER.info(String.format("1------ Request for locked status of the event by borough : %s", borough, " eventName : %s", eventName));
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		meterEventFinalize.setBorough(borough);
		meterEventFinalize.setEventName(eventName);
		meterEventFinalize.setIsSelectAll(true);
		List<String> listOfMeters = new ArrayList<String>();
		meterEventFinalize.setListOfMeters(listOfMeters);
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return meterEventFinalizeService.finalizeValidateMeterTmp(meterEventFinalize, adid);
	}
   

}
