
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JobSubTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="JobSubTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_SEARCH_CACHE"/>
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_EXPORT_DATA"/>
 *     &lt;enumeration value="JOB_OP_CRON_JOB_UPDATE"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SEC_LOG_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_TASK_STATS_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_POP_DAILY_RSR_SUM"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_GAP_FILL"/>
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_RECOVERY"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_NETWORK_STATUS"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_METER_SEC_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_ARCHIVE_JOBS"/>
 *     &lt;enumeration value="JOB_OP_CRON_BILL_CYCLE_SUMMARY"/>
 *     &lt;enumeration value="JOB_OP_CRON_UNFILL_GAP_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_NET_BACKBONE_HST"/>
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_RECOVERY"/>
 *     &lt;enumeration value="JOB_OP_CRON_CMD_QUEUE_RETRY"/>
 *     &lt;enumeration value="JOB_OP_CRON_RSND_FAIL_NP_RES"/>
 *     &lt;enumeration value="JOB_OP_CRON_ITVL_SUCCESS_PROC"/>
 *     &lt;enumeration value="JOB_OP_CRON_HEALTH_FLAG_EVENT"/>
 *     &lt;enumeration value="JOB_OP_CRON_DAY_START_PROC"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_NEW_ROUTES"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_INS_ROUTES"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_ROUTES_LAST"/>
 *     &lt;enumeration value="JOB_OP_CRON_SCHED_SUM_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_EVENT_LOG_GAP_FILL"/>
 *     &lt;enumeration value="JOB_OP_CRON_SET_UNREACHABLE"/>
 *     &lt;enumeration value="JOB_OP_CRON_RESET_UNREACHABLE"/>
 *     &lt;enumeration value="JOB_OP_CRON_ALARM_COUNTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_UNSCHED_METER_CNT"/>
 *     &lt;enumeration value="JOB_OP_CRON_TABLE_3_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_ERR_HIST_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_CARDINALITY_STATS"/>
 *     &lt;enumeration value="JOB_OP_CRON_ALL_OUTAGES_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_INFER_OUTAGES_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_LATENCY_RPT"/>
 *     &lt;enumeration value="JOB_OP_CRON_DEV_STATE_SNAPSHOT"/>
 *     &lt;enumeration value="JOB_OP_CRON_GEN_READ_SUCCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_RESOLVE_EVENTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DEVICE_CACHE"/>
 *     &lt;enumeration value="JOB_OP_CRON_ADD_PARTITIONS"/>
 *     &lt;enumeration value="JOB_OP_CRON_REMOVE_PARTITIONS"/>
 *     &lt;enumeration value="JOB_OP_CRON_NETSTATUS_COUNTS"/>
 *     &lt;enumeration value="JOB_OP_CRON_RMT_PROV_PROCESS"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DB"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_ADVANCED_METER"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_EVENT"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_DEVICE"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_ARB_METER_CMD"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_POWER_QUALITY"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_GENERIC"/>
 *     &lt;enumeration value="JOB_OP_EXPORT_DMD_RESET_FAILS"/>
 *     &lt;enumeration value="JOB_OP_LP_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_READ"/>
 *     &lt;enumeration value="JOB_OP_SECLOG_READ"/>
 *     &lt;enumeration value="JOB_OP_CONS_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_RST_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_RST_READ"/>
 *     &lt;enumeration value="JOB_OP_NCC_DL"/>
 *     &lt;enumeration value="JOB_OP_NCC_REG"/>
 *     &lt;enumeration value="JOB_OP_NCC_EL"/>
 *     &lt;enumeration value="JOB_OP_IMU_PROXY_READ"/>
 *     &lt;enumeration value="JOB_OP_NEW_DATA_READ"/>
 *     &lt;enumeration value="JOB_OP_METER_EL_READ"/>
 *     &lt;enumeration value="JOB_OP_ERR_HIST_READ"/>
 *     &lt;enumeration value="JOB_OP_NIC_NEW_DATA_READ"/>
 *     &lt;enumeration value="JOB_OP_PING_GW_APP"/>
 *     &lt;enumeration value="JOB_OP_PING_GW_NET"/>
 *     &lt;enumeration value="JOB_OP_PING_DEV_APP"/>
 *     &lt;enumeration value="JOB_OP_PING_DEV_NET"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ARM"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_GET_STATUS"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_RESET_TS"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_PPM"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_PPM"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_PP_BALNCE"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DLP"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DLP"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_DLP_PROPS"/>
 *     &lt;enumeration value="JOB_OP_PROV_SET_LIMITER_PROPS"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_LOCK"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_LOCK"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L1"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L1"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L2"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L2"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ACT_ESCC"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DEACT_ESCC"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_ESCC"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_ESCC"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_ESCC_PROP"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_BOOST"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_BOOST"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_GROUP_CONFIG"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_BROADCAST"/>
 *     &lt;enumeration value="JOB_OP_PROV_SET_IGNORE_TAMPER"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_CLEAR_TAMPER"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DS"/>
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DS"/>
 *     &lt;enumeration value="JOB_OP_BRDG_NTFCTN_LINK_STATE"/>
 *     &lt;enumeration value="JOB_OP_ZB_METER_READ"/>
 *     &lt;enumeration value="JOB_OP_ITRON_IMU_PROXY_READ"/>
 *     &lt;enumeration value="JOB_OP_DEV_PROG_READ"/>
 *     &lt;enumeration value="JOB_OP_DEMAND_RESET"/>
 *     &lt;enumeration value="JOB_OP_GENERIC_METER_READ"/>
 *     &lt;enumeration value="JOB_OP_CRON_IMU_PREPROCESS"/>
 *     &lt;enumeration value="JOB_OP_REG_PREV_SESN_READ"/>
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_SEGMENT_DB"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "JobSubTypeEnumeration")
@XmlEnum
public enum JobSubTypeEnumeration {

    JOB_OP_CRON_CLEAR_SEARCH_CACHE("JOB_OP_CRON_CLEAR_SEARCH_CACHE"),
    JOB_OP_CRON_CLEAR_EXPORT_DATA("JOB_OP_CRON_CLEAR_EXPORT_DATA"),
    JOB_OP_CRON_JOB_UPDATE("JOB_OP_CRON_JOB_UPDATE"),
    JOB_OP_CRON_INTERVAL_PROCESS("JOB_OP_CRON_INTERVAL_PROCESS"),
    JOB_OP_CRON_REGISTER_PROCESS("JOB_OP_CRON_REGISTER_PROCESS"),
    JOB_OP_CRON_SEC_LOG_PROCESS("JOB_OP_CRON_SEC_LOG_PROCESS"),
    JOB_OP_CRON_TASK_STATS_PROCESS("JOB_OP_CRON_TASK_STATS_PROCESS"),
    JOB_OP_CRON_POP_DAILY_RSR_SUM("JOB_OP_CRON_POP_DAILY_RSR_SUM"),
    JOB_OP_CRON_INTERVAL_GAP_FILL("JOB_OP_CRON_INTERVAL_GAP_FILL"),
    JOB_OP_CRON_INTERVAL_RECOVERY("JOB_OP_CRON_INTERVAL_RECOVERY"),
    JOB_OP_CRON_GEN_NETWORK_STATUS("JOB_OP_CRON_GEN_NETWORK_STATUS"),
    JOB_OP_CRON_GEN_METER_SEC_RPT("JOB_OP_CRON_GEN_METER_SEC_RPT"),
    JOB_OP_CRON_ARCHIVE_JOBS("JOB_OP_CRON_ARCHIVE_JOBS"),
    JOB_OP_CRON_BILL_CYCLE_SUMMARY("JOB_OP_CRON_BILL_CYCLE_SUMMARY"),
    JOB_OP_CRON_UNFILL_GAP_PROCESS("JOB_OP_CRON_UNFILL_GAP_PROCESS"),
    JOB_OP_CRON_NET_BACKBONE_HST("JOB_OP_CRON_NET_BACKBONE_HST"),
    JOB_OP_CRON_REGISTER_RECOVERY("JOB_OP_CRON_REGISTER_RECOVERY"),
    JOB_OP_CRON_CMD_QUEUE_RETRY("JOB_OP_CRON_CMD_QUEUE_RETRY"),
    JOB_OP_CRON_RSND_FAIL_NP_RES("JOB_OP_CRON_RSND_FAIL_NP_RES"),
    JOB_OP_CRON_ITVL_SUCCESS_PROC("JOB_OP_CRON_ITVL_SUCCESS_PROC"),
    JOB_OP_CRON_HEALTH_FLAG_EVENT("JOB_OP_CRON_HEALTH_FLAG_EVENT"),
    JOB_OP_CRON_DAY_START_PROC("JOB_OP_CRON_DAY_START_PROC"),
    JOB_OP_CRON_SYNC_NEW_ROUTES("JOB_OP_CRON_SYNC_NEW_ROUTES"),
    JOB_OP_CRON_SYNC_INS_ROUTES("JOB_OP_CRON_SYNC_INS_ROUTES"),
    JOB_OP_CRON_SYNC_ROUTES_LAST("JOB_OP_CRON_SYNC_ROUTES_LAST"),
    JOB_OP_CRON_SCHED_SUM_PROCESS("JOB_OP_CRON_SCHED_SUM_PROCESS"),
    JOB_OP_CRON_EVENT_LOG_GAP_FILL("JOB_OP_CRON_EVENT_LOG_GAP_FILL"),
    JOB_OP_CRON_SET_UNREACHABLE("JOB_OP_CRON_SET_UNREACHABLE"),
    JOB_OP_CRON_RESET_UNREACHABLE("JOB_OP_CRON_RESET_UNREACHABLE"),
    JOB_OP_CRON_ALARM_COUNTS("JOB_OP_CRON_ALARM_COUNTS"),
    JOB_OP_CRON_UNSCHED_METER_CNT("JOB_OP_CRON_UNSCHED_METER_CNT"),
    JOB_OP_CRON_TABLE_3_PROCESS("JOB_OP_CRON_TABLE_3_PROCESS"),
    JOB_OP_CRON_ERR_HIST_PROCESS("JOB_OP_CRON_ERR_HIST_PROCESS"),
    JOB_OP_CRON_CARDINALITY_STATS("JOB_OP_CRON_CARDINALITY_STATS"),
    JOB_OP_CRON_ALL_OUTAGES_RPT("JOB_OP_CRON_ALL_OUTAGES_RPT"),
    JOB_OP_CRON_INFER_OUTAGES_RPT("JOB_OP_CRON_INFER_OUTAGES_RPT"),
    JOB_OP_CRON_GEN_LATENCY_RPT("JOB_OP_CRON_GEN_LATENCY_RPT"),
    JOB_OP_CRON_DEV_STATE_SNAPSHOT("JOB_OP_CRON_DEV_STATE_SNAPSHOT"),
    JOB_OP_CRON_GEN_READ_SUCCESS("JOB_OP_CRON_GEN_READ_SUCCESS"),
    JOB_OP_CRON_RESOLVE_EVENTS("JOB_OP_CRON_RESOLVE_EVENTS"),
    JOB_OP_CRON_SYNC_DEVICE_CACHE("JOB_OP_CRON_SYNC_DEVICE_CACHE"),
    JOB_OP_CRON_ADD_PARTITIONS("JOB_OP_CRON_ADD_PARTITIONS"),
    JOB_OP_CRON_REMOVE_PARTITIONS("JOB_OP_CRON_REMOVE_PARTITIONS"),
    JOB_OP_CRON_NETSTATUS_COUNTS("JOB_OP_CRON_NETSTATUS_COUNTS"),
    JOB_OP_CRON_RMT_PROV_PROCESS("JOB_OP_CRON_RMT_PROV_PROCESS"),
    JOB_OP_CRON_SYNC_DB("JOB_OP_CRON_SYNC_DB"),
    JOB_OP_EXPORT_ADVANCED_METER("JOB_OP_EXPORT_ADVANCED_METER"),
    JOB_OP_EXPORT_EVENT("JOB_OP_EXPORT_EVENT"),
    JOB_OP_EXPORT_DEVICE("JOB_OP_EXPORT_DEVICE"),
    JOB_OP_EXPORT_ARB_METER_CMD("JOB_OP_EXPORT_ARB_METER_CMD"),
    JOB_OP_EXPORT_POWER_QUALITY("JOB_OP_EXPORT_POWER_QUALITY"),
    JOB_OP_EXPORT_GENERIC("JOB_OP_EXPORT_GENERIC"),
    JOB_OP_EXPORT_DMD_RESET_FAILS("JOB_OP_EXPORT_DMD_RESET_FAILS"),
    JOB_OP_LP_READ("JOB_OP_LP_READ"),
    JOB_OP_REGISTER_CURR_READ("JOB_OP_REGISTER_CURR_READ"),
    JOB_OP_SECLOG_READ("JOB_OP_SECLOG_READ"),
    JOB_OP_CONS_READ("JOB_OP_CONS_READ"),
    JOB_OP_REGISTER_CURR_RST_READ("JOB_OP_REGISTER_CURR_RST_READ"),
    JOB_OP_REGISTER_SELF_READ("JOB_OP_REGISTER_SELF_READ"),
    JOB_OP_REGISTER_SELF_RST_READ("JOB_OP_REGISTER_SELF_RST_READ"),
    JOB_OP_NCC_DL("JOB_OP_NCC_DL"),
    JOB_OP_NCC_REG("JOB_OP_NCC_REG"),
    JOB_OP_NCC_EL("JOB_OP_NCC_EL"),
    JOB_OP_IMU_PROXY_READ("JOB_OP_IMU_PROXY_READ"),
    JOB_OP_NEW_DATA_READ("JOB_OP_NEW_DATA_READ"),
    JOB_OP_METER_EL_READ("JOB_OP_METER_EL_READ"),
    JOB_OP_ERR_HIST_READ("JOB_OP_ERR_HIST_READ"),
    JOB_OP_NIC_NEW_DATA_READ("JOB_OP_NIC_NEW_DATA_READ"),
    JOB_OP_PING_GW_APP("JOB_OP_PING_GW_APP"),
    JOB_OP_PING_GW_NET("JOB_OP_PING_GW_NET"),
    JOB_OP_PING_DEV_APP("JOB_OP_PING_DEV_APP"),
    JOB_OP_PING_DEV_NET("JOB_OP_PING_DEV_NET"),
    JOB_OP_PROVISION_ARM("JOB_OP_PROVISION_ARM"),
    JOB_OP_PROVISION_CONNECT("JOB_OP_PROVISION_CONNECT"),
    JOB_OP_PROVISION_DISCONNECT("JOB_OP_PROVISION_DISCONNECT"),
    JOB_OP_PROVISION_GET_STATUS("JOB_OP_PROVISION_GET_STATUS"),
    JOB_OP_PROVISION_RESET_TS("JOB_OP_PROVISION_RESET_TS"),
    JOB_OP_PROVISION_ENABLE_PPM("JOB_OP_PROVISION_ENABLE_PPM"),
    JOB_OP_PROVISION_DISABLE_PPM("JOB_OP_PROVISION_DISABLE_PPM"),
    JOB_OP_PROVISION_SET_PP_BALNCE("JOB_OP_PROVISION_SET_PP_BALNCE"),
    JOB_OP_PROVISION_ENABLE_DLP("JOB_OP_PROVISION_ENABLE_DLP"),
    JOB_OP_PROVISION_DISABLE_DLP("JOB_OP_PROVISION_DISABLE_DLP"),
    JOB_OP_PROVISION_SET_DLP_PROPS("JOB_OP_PROVISION_SET_DLP_PROPS"),
    JOB_OP_PROV_SET_LIMITER_PROPS("JOB_OP_PROV_SET_LIMITER_PROPS"),
    JOB_OP_PROVISION_ENABLE_LOCK("JOB_OP_PROVISION_ENABLE_LOCK"),
    JOB_OP_PROVISION_DISABLE_LOCK("JOB_OP_PROVISION_DISABLE_LOCK"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L1")
    JOB_OP_PROVISION_CONNECT_L_1("JOB_OP_PROVISION_CONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L1")
    JOB_OP_PROVISION_DISCONNECT_L_1("JOB_OP_PROVISION_DISCONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L2")
    JOB_OP_PROVISION_CONNECT_L_2("JOB_OP_PROVISION_CONNECT_L2"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L2")
    JOB_OP_PROVISION_DISCONNECT_L_2("JOB_OP_PROVISION_DISCONNECT_L2"),
    JOB_OP_PROVISION_ACT_ESCC("JOB_OP_PROVISION_ACT_ESCC"),
    JOB_OP_PROVISION_DEACT_ESCC("JOB_OP_PROVISION_DEACT_ESCC"),
    JOB_OP_PROVISION_ENABLE_ESCC("JOB_OP_PROVISION_ENABLE_ESCC"),
    JOB_OP_PROVISION_DISABLE_ESCC("JOB_OP_PROVISION_DISABLE_ESCC"),
    JOB_OP_PROVISION_SET_ESCC_PROP("JOB_OP_PROVISION_SET_ESCC_PROP"),
    JOB_OP_PROVISION_ENABLE_BOOST("JOB_OP_PROVISION_ENABLE_BOOST"),
    JOB_OP_PROVISION_DISABLE_BOOST("JOB_OP_PROVISION_DISABLE_BOOST"),
    JOB_OP_PROVISION_GROUP_CONFIG("JOB_OP_PROVISION_GROUP_CONFIG"),
    JOB_OP_PROVISION_BROADCAST("JOB_OP_PROVISION_BROADCAST"),
    JOB_OP_PROV_SET_IGNORE_TAMPER("JOB_OP_PROV_SET_IGNORE_TAMPER"),
    JOB_OP_PROVISION_CLEAR_TAMPER("JOB_OP_PROVISION_CLEAR_TAMPER"),
    JOB_OP_PROVISION_ENABLE_DS("JOB_OP_PROVISION_ENABLE_DS"),
    JOB_OP_PROVISION_DISABLE_DS("JOB_OP_PROVISION_DISABLE_DS"),
    JOB_OP_BRDG_NTFCTN_LINK_STATE("JOB_OP_BRDG_NTFCTN_LINK_STATE"),
    JOB_OP_ZB_METER_READ("JOB_OP_ZB_METER_READ"),
    JOB_OP_ITRON_IMU_PROXY_READ("JOB_OP_ITRON_IMU_PROXY_READ"),
    JOB_OP_DEV_PROG_READ("JOB_OP_DEV_PROG_READ"),
    JOB_OP_DEMAND_RESET("JOB_OP_DEMAND_RESET"),
    JOB_OP_GENERIC_METER_READ("JOB_OP_GENERIC_METER_READ"),
    JOB_OP_CRON_IMU_PREPROCESS("JOB_OP_CRON_IMU_PREPROCESS"),
    JOB_OP_REG_PREV_SESN_READ("JOB_OP_REG_PREV_SESN_READ"),
    JOB_OP_CRON_SYNC_SEGMENT_DB("JOB_OP_CRON_SYNC_SEGMENT_DB"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    JobSubTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JobSubTypeEnumeration fromValue(String v) {
        for (JobSubTypeEnumeration c: JobSubTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
