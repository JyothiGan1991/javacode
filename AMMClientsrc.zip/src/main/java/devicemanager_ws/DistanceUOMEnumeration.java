
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DistanceUOMEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DistanceUOMEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MI"/&gt;
 *     &lt;enumeration value="KM"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DistanceUOMEnumeration")
@XmlEnum
public enum DistanceUOMEnumeration {

    MI("MI"),
    KM("KM"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DistanceUOMEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DistanceUOMEnumeration fromValue(String v) {
        for (DistanceUOMEnumeration c: DistanceUOMEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
