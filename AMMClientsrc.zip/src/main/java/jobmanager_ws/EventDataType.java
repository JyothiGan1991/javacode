
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EventDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EventDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="OneTime" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EventExportOneTimeType"/&gt;
 *           &lt;element name="Recurring" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EventExportRecurringType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="FileSegmenting" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EventFileSegmentingType" minOccurs="0"/&gt;
 *         &lt;element name="OutputFormat" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EventOutputFormatTypeEnum"/&gt;
 *         &lt;element name="ViewSingleEventURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EventDataType", propOrder = {
    "oneTime",
    "recurring",
    "fileSegmenting",
    "outputFormat",
    "viewSingleEventURL"
})
public class EventDataType {

    @XmlElement(name = "OneTime")
    protected EventExportOneTimeType oneTime;
    @XmlElement(name = "Recurring")
    protected EventExportRecurringType recurring;
    @XmlElement(name = "FileSegmenting")
    protected EventFileSegmentingType fileSegmenting;
    @XmlElement(name = "OutputFormat", required = true)
    @XmlSchemaType(name = "string")
    protected EventOutputFormatTypeEnum outputFormat;
    @XmlElement(name = "ViewSingleEventURL")
    protected String viewSingleEventURL;

    /**
     * Gets the value of the oneTime property.
     * 
     * @return
     *     possible object is
     *     {@link EventExportOneTimeType }
     *     
     */
    public EventExportOneTimeType getOneTime() {
        return oneTime;
    }

    /**
     * Sets the value of the oneTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventExportOneTimeType }
     *     
     */
    public void setOneTime(EventExportOneTimeType value) {
        this.oneTime = value;
    }

    /**
     * Gets the value of the recurring property.
     * 
     * @return
     *     possible object is
     *     {@link EventExportRecurringType }
     *     
     */
    public EventExportRecurringType getRecurring() {
        return recurring;
    }

    /**
     * Sets the value of the recurring property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventExportRecurringType }
     *     
     */
    public void setRecurring(EventExportRecurringType value) {
        this.recurring = value;
    }

    /**
     * Gets the value of the fileSegmenting property.
     * 
     * @return
     *     possible object is
     *     {@link EventFileSegmentingType }
     *     
     */
    public EventFileSegmentingType getFileSegmenting() {
        return fileSegmenting;
    }

    /**
     * Sets the value of the fileSegmenting property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventFileSegmentingType }
     *     
     */
    public void setFileSegmenting(EventFileSegmentingType value) {
        this.fileSegmenting = value;
    }

    /**
     * Gets the value of the outputFormat property.
     * 
     * @return
     *     possible object is
     *     {@link EventOutputFormatTypeEnum }
     *     
     */
    public EventOutputFormatTypeEnum getOutputFormat() {
        return outputFormat;
    }

    /**
     * Sets the value of the outputFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventOutputFormatTypeEnum }
     *     
     */
    public void setOutputFormat(EventOutputFormatTypeEnum value) {
        this.outputFormat = value;
    }

    /**
     * Gets the value of the viewSingleEventURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getViewSingleEventURL() {
        return viewSingleEventURL;
    }

    /**
     * Sets the value of the viewSingleEventURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setViewSingleEventURL(String value) {
        this.viewSingleEventURL = value;
    }

}
