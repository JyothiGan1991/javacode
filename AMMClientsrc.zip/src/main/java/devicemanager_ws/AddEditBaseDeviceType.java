
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="Relay" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditRelayTypeReq"/&gt;
 *           &lt;element name="Meter" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditMeterTypeReq"/&gt;
 *           &lt;element name="Gateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditGatewayTypeReq"/&gt;
 *           &lt;element name="IMU" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditIMUTypeReq"/&gt;
 *           &lt;element name="WaterModule" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditIMUTypeReq"/&gt;
 *           &lt;element name="Bridge" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditBridgeTypeReq"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditBaseDeviceType", propOrder = {
    "relay",
    "meter",
    "gateway",
    "imu",
    "waterModule",
    "bridge"
})
@XmlSeeAlso({
    EditDeviceReqType.class,
    AddDeviceReqType.class
})
public class AddEditBaseDeviceType {

    @XmlElement(name = "Relay")
    protected AddEditRelayTypeReq relay;
    @XmlElement(name = "Meter")
    protected AddEditMeterTypeReq meter;
    @XmlElement(name = "Gateway")
    protected AddEditGatewayTypeReq gateway;
    @XmlElement(name = "IMU")
    protected AddEditIMUTypeReq imu;
    @XmlElement(name = "WaterModule")
    protected AddEditIMUTypeReq waterModule;
    @XmlElement(name = "Bridge")
    protected AddEditBridgeTypeReq bridge;

    /**
     * Gets the value of the relay property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditRelayTypeReq }
     *     
     */
    public AddEditRelayTypeReq getRelay() {
        return relay;
    }

    /**
     * Sets the value of the relay property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditRelayTypeReq }
     *     
     */
    public void setRelay(AddEditRelayTypeReq value) {
        this.relay = value;
    }

    /**
     * Gets the value of the meter property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditMeterTypeReq }
     *     
     */
    public AddEditMeterTypeReq getMeter() {
        return meter;
    }

    /**
     * Sets the value of the meter property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditMeterTypeReq }
     *     
     */
    public void setMeter(AddEditMeterTypeReq value) {
        this.meter = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditGatewayTypeReq }
     *     
     */
    public AddEditGatewayTypeReq getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditGatewayTypeReq }
     *     
     */
    public void setGateway(AddEditGatewayTypeReq value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the imu property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditIMUTypeReq }
     *     
     */
    public AddEditIMUTypeReq getIMU() {
        return imu;
    }

    /**
     * Sets the value of the imu property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditIMUTypeReq }
     *     
     */
    public void setIMU(AddEditIMUTypeReq value) {
        this.imu = value;
    }

    /**
     * Gets the value of the waterModule property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditIMUTypeReq }
     *     
     */
    public AddEditIMUTypeReq getWaterModule() {
        return waterModule;
    }

    /**
     * Sets the value of the waterModule property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditIMUTypeReq }
     *     
     */
    public void setWaterModule(AddEditIMUTypeReq value) {
        this.waterModule = value;
    }

    /**
     * Gets the value of the bridge property.
     * 
     * @return
     *     possible object is
     *     {@link AddEditBridgeTypeReq }
     *     
     */
    public AddEditBridgeTypeReq getBridge() {
        return bridge;
    }

    /**
     * Sets the value of the bridge property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddEditBridgeTypeReq }
     *     
     */
    public void setBridge(AddEditBridgeTypeReq value) {
        this.bridge = value;
    }

}
