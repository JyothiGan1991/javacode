package com.coned.ls.login;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

/**
 * An implementation of the JAAS CallbackHandler interface that 
 * handles NameCallbacks, PasswordCallback, TextInputCallback. 
 *
 */
public class SampleCallbackHandler implements javax.security.auth.callback.CallbackHandler{

	private String userid;
	private String password;
	
	public SampleCallbackHandler(String userid, String password){
		this.userid = userid;
		this.password = password;
	}

    /*
     * Handles the specified set of callbacks.
     *
     * @param callbacks the callbacks to handle
     */
	@Override
	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
		for (int i = 0; i < callbacks.length; i++) {
			if (callbacks[i] instanceof TextOutputCallback){
				TextOutputCallback toc = (TextOutputCallback)callbacks[i];
			} else if (callbacks[i] instanceof NameCallback) {
				// If username not supplied, set the userid.
				NameCallback nc = (NameCallback)callbacks[i];
				nc.setName(userid);
			} else if (callbacks[i] instanceof PasswordCallback) {
				// If password not supplied, set the password.
				PasswordCallback pc = (PasswordCallback)callbacks[i];
				pc.setPassword(password.toCharArray());
			} else {}
		}
	}
}
