package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.controller.AuthenticationController;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.AuthorizationRepository;
import com.coned.ls.repository.JdbcAuthorizationRepository;
import com.coned.ls.repository.OpenEventRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={OpenEventService.class})
@AutoConfigureMockMvc
public class OpenEventServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private OpenEventService openEventService = new OpenEventServiceImpl();
	
	@Mock
	private OpenEventRepository openEventRepository;
	
	@Mock
	private AuthenticationController authController;
	
	@Mock
	private AuthorizationService authService = new AuthorizationServiceImpl();
	
	@Mock
	private AuthorizationRepository  authorizationRepository;// = new JdbcAuthorizationRepository();
	
	@Mock
	private JdbcAuthorizationRepository jdbcAuthRepository;
	
	@Mock
	protected JdbcTemplate oracleJdbcTemplate;
	
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	private MeterEventLoad  meterEventLoad;
	
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		meterEventLoad = meterEventLoadC;
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
	}
	
	@Test
	public void getOpenEventTest(){
		List<String> borough = new ArrayList<String>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(borough, HttpStatus.OK);
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		ResponseEntity<List<String>> result = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getNewAndActiveEvent(){
		List<String> eventname = new ArrayList<String>();
		eventname.add("SheepsheadBaySampleData7.27.20-1300");
		eventname.add("Flatbush.23.11/08/20-23:24:06.KUMARM");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(eventname, HttpStatus.OK);
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(eventname);
		ResponseEntity<List<String>> result = openEventService.getNewAndActiveEvent();
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getNewAndActiveEventByBorough(){
		List<String> eventName = new ArrayList<String>();
		eventName.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		eventName.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		eventName.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(eventName, HttpStatus.OK);
		Mockito.when(openEventRepository.getNewAndActiveEventByBorough(Mockito.anyString())).thenReturn(eventName);
		ResponseEntity<List<String>> result = openEventService.getNewAndActiveEventByBorough(Mockito.anyString());
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getSubFinalizeBoroughtest(){
		List<String> borough = new ArrayList<String>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(borough, HttpStatus.OK);
		Mockito.when(openEventRepository.getSubFinalizeBorough()).thenReturn(borough);
		ResponseEntity<List<String>> result = openEventService.getSubFinalizeBorough();
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getSubFinalizeEventTest(){
		List<String> eventName = new ArrayList<String>();
		eventName.add("SheepsheadBaySampleData7.27.20-1300");
		eventName.add("Flatbush.23.11/08/20-23:24:06.KUMARM");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(eventName, HttpStatus.OK);
		Mockito.when(openEventRepository.getSubFinalizeEvent()).thenReturn(eventName);
		ResponseEntity<List<String>> result = openEventService.getSubFinalizeEvent();
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getSubFinalizeEventByBoroughTest(){
		List<String> borough = new ArrayList<String>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(borough, HttpStatus.OK);
		Mockito.when(openEventRepository.getSubFinalizeEventByBorough(Mockito.anyString())).thenReturn(borough);
		ResponseEntity<List<String>> result = openEventService.getSubFinalizeEventByBorough(Mockito.anyString());
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getSubFinalizeEventByEventAndBoroughTest(){
		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,HttpStatus.OK);
		Mockito.when(openEventRepository.getSubFinalizeEventByEventAndBorough(borough, eventName)).thenReturn(expectedEventNameList);
		ResponseEntity<List<String>> response = openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName);
		Assert.assertEquals(result.getBody().size(), response.getBody().size());
		
	}
	
		@Test
		public void getExecuteBoroughTest(){
			List<String> borough = new ArrayList<String>();
			borough.add("B");
			borough.add("G");
			borough.add("E");
			borough.add("A");
			ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(borough, HttpStatus.OK);
			Mockito.when(openEventRepository.getExecuteBorough()).thenReturn(borough);
			ResponseEntity<List<String>> result = openEventService.getExecuteBorough();
			Assert.assertEquals(mockData.getBody().size(), result.getBody().size());
		}
		
		@Test
		public void getExecuteEventTest(){
			List<String> eventlist = new ArrayList<String>();
			eventlist.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
			eventlist.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
			eventlist.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
			ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(eventlist, HttpStatus.OK);
			Mockito.when(openEventRepository.getExecuteEvent()).thenReturn(eventlist);
			ResponseEntity<List<String>> result = openEventService.getExecuteEvent();
			Assert.assertEquals(mockData.getBody().size(), result.getBody().size());
		}
		
		@Test
		public void getExecuteEventByBoroughTest(){
			List<String> eventlist = new ArrayList<String>();
			eventlist.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
			eventlist.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
			eventlist.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
			ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(eventlist, HttpStatus.OK);
			Mockito.when(openEventRepository.getExecuteEventByBorough("B")).thenReturn(eventlist);
			ResponseEntity<List<String>> result = openEventService.getExecuteEventByBorough("B");
			Assert.assertEquals(mockData.getBody().size(), result.getBody().size());
		}


	/*@Test
	public void getOpenEventException(){
		Set<String> borough = new HashSet<>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		Set<String> responseBorough = new HashSet<>();
		responseBorough.add("A");
		borough.clear();
		Set<String> openEvent2 = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(openEvent2, borough);
	}
	
	
	@Test
	public void getOpenEventForEventTest(){
		Set<String> borough = new HashSet<>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		Set<String> openEvent2 = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(openEvent2, borough);
	}
	
	@Test
	public void getOpenEventForEventException(){
		Set<String> event = new HashSet<>();
		event.add("SheepsheadBaySampleData7.27.20-1701");event.add("SheepsheadBaySampleData7.27.20-1703");event.add("SheepsheadBaySampleData7.27.20-1704");
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(event);
		Set<String> responseEvent = new HashSet<>();
		responseEvent.add("SheepsheadBaySampleData7.27.20-1701");
		Set<String> openEvent2 = openEventService.getNewAndActiveEvent();
		Assert.assertEquals(openEvent2, openEvent2);
	}*/
	


}

