package com.coned.ls.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)

public class RESTActionExecutorTest {

	@InjectMocks
	private RESTActionExecutor restActionExecutor;

	@Mock
	private RestTemplate restTemplate;
	
	 //RestTemplate restTemplate = new RestTemplate();

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(restActionExecutor, "restTemplate", restTemplate);
		RestClientBuilder.baseURL = "http://172.16.81.109:7001/rcc-api";
	}

	@Test
	public void getOpenEvent() {
		final String value = "Test";
		ResponseEntity<List<String>> response = restActionExecutor.getOpenEvent(value);
		Assert.assertNotNull(response);
	}

	@Test
	public void getOpenEventTmp() {
		final String value = "Test";
		ResponseEntity<List<String>> response = restActionExecutor.getOpenEventTmp(value);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void getBoroughAndEventNameWithResponseBody() {
		// final String value ="Test";
		List<String> list = new ArrayList<String>();
		list.add("Test");
		ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.OK);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		String fields = "B";
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/open/meters?fields=" + fields);
		Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {
		})).thenReturn(actual);
		ResponseEntity<List<String>> response = restActionExecutor.getBoroughAndEventName("B");
		Assert.assertNotNull(response);
	}
	
	@Test
	public void getBoroughAndEventName() {
		// final String value ="Test";
		List<String> list = new ArrayList<String>();
		ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.NO_CONTENT);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		String fields = "B";
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/open/meters?fields=" + fields);
		Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {
		})).thenReturn(actual);
		ResponseEntity<List<String>> response = restActionExecutor.getBoroughAndEventName("B");
		Assert.assertNotNull(response);
	}

	@Test
	public void getBoroughAndEventNameTmp() {
		// final String value ="Test";
		List<String> list = new ArrayList<String>();
		ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.NO_CONTENT);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		String fields = "B";
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect-tmp/events/open/meters?fields=" + fields);
		Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {
		})).thenReturn(actual);
		ResponseEntity<List<String>> response = restActionExecutor.getBoroughAndEventNameTmp("B");
		Assert.assertNotNull(response);
	}
/*@Test
	public void getValidateMeter() {
		MeterValidateResponseMapper mvrp = new MeterValidateResponseMapper();
		mvrp.setBorough("P");
		ResponseEntity<MeterValidateResponseMapper> expected = new ResponseEntity<MeterValidateResponseMapper>(mvrp,
				HttpStatus.OK);

		final String borough = "Test";
		final String eventName = "Test";
		final int startRowIndex = 1;
		final int batchSize = 10;
		final String filterList = "Test";
		final String sortList = "Test";
		final String adid = "Test";

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough=" + borough);
		stringBuilder.append("&eventName=" + eventName);
		stringBuilder.append("&startRowIndex=" + String.valueOf(startRowIndex));
		stringBuilder.append("&batchSize=" + String.valueOf(batchSize));
		stringBuilder.append("&filterList=" + String.valueOf(filterList));
		stringBuilder.append("&sortList=" + String.valueOf(sortList));
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/meters?", stringBuilder.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("adid", "Test");

		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		Mockito.when(restTemplate.postForEntity(uri, entity, MeterValidateResponseMapper.class))
				.thenReturn(expected);

		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("Test");
		meterOpenEvent.setEventName("Test");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(10);
		meterOpenEvent.setAdid("Test");
		//meterOpenEvent.set
		
		ResponseEntity<MeterValidateResponseMapper> response = restActionExecutor.getValidateMeter(meterOpenEvent);
		Assert.assertEquals(response,expected);
	}*/


	@Test
	public void getUsers() {
		List<Object> ls = new ArrayList<Object>();
		ResponseEntity<List<Object>> responseEntity = new ResponseEntity<List<Object>>(ls, HttpStatus.OK);
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/users");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		
	   Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<Object>>() {})).thenReturn(responseEntity);
	   ResponseEntity<List<Object>> response = restActionExecutor.getUsers();
		Assert.assertNotNull(response);
	}
	
	@Test
	public void listLDAPUser() {
		Map<String, Object> ls = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> responseEntity = new ResponseEntity<Map<String, Object>>(ls, HttpStatus.OK);
		
		String username = "TESTUSER";
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/adusers/" + username);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		
		 Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<Map<String, Object>>() {})).thenReturn(responseEntity);
			ResponseEntity<Map<String, Object>> response = restActionExecutor.listLDAPUser("TESTUSER");
				Assert.assertNotNull(response);
	}
	
	@Test
	public void createUser() {
		Map<String, Object> ls = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> responseEntity = new ResponseEntity<Map<String, Object>>(ls, HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();

		URI uri = RestClientBuilder.customBuildURI("/rcc/um/users");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
	
		Mockito.when(restTemplate.postForEntity(uri, entity, (Class<Map<String, Object>>) (Class) Map.class)).thenReturn(responseEntity);
		ResponseEntity<Map<String, Object>> response = restActionExecutor.createUser(payload);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void updateUser() {
		Map<String, Object> ls = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> responseEntity = new ResponseEntity<Map<String, Object>>(ls, HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		String username = "TESTUSER";
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/users/" + username);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);

		Mockito.when(restTemplate.exchange(uri, HttpMethod.PUT, entity, new ParameterizedTypeReference<Map<String, Object>>() {})).thenReturn(responseEntity);
		ResponseEntity<Map<String, Object>> response = restActionExecutor.updateUser(username, payload);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void deleteUser() {
		Map<String, Object> ls = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> responseEntity = new ResponseEntity<Map<String, Object>>(ls, HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		String username = "TESTUSER";
		String updatedBy = "UPDATEDBYUSER";
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/users/" + username+"?updatedBy="+updatedBy);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		Mockito.when(restTemplate.exchange(uri, HttpMethod.DELETE, entity, new ParameterizedTypeReference<Map<String, Object>>() {})).thenReturn(responseEntity);
		ResponseEntity<Map<String, Object>> response = restActionExecutor.deleteUser(username, updatedBy);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void getFieldValuesByBoroughAndEventName() {
		List<String> ls = new ArrayList<String>();
		ResponseEntity<List<String>> responseEntity = new ResponseEntity<List<String>>(ls, HttpStatus.OK);
		StringBuilder stringBuilder = new StringBuilder();
		String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		stringBuilder.append("eventName="+eventName);
		String fieldName = "B";
		stringBuilder.append("&fieldName="+fieldName);
		String borough= "B";
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/meters/fields/" + borough + "?", stringBuilder.toString());
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	   Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(responseEntity);
	ResponseEntity<List<String>> response = restActionExecutor.getFieldValuesByBoroughAndEventName("B", "BoroughHall.01.12/10/20-01:22:01.AUTO",
			"B");
		Assert.assertNotNull(response);
	}

	@Test
	public void getInvalidateMeter() {
		MeterValidateResponseMapper response = new MeterValidateResponseMapper();

		String borough = "B";
		String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		StringBuilder stringBuilder = new StringBuilder();
		int startRowIndex = 1;
		int batchSize = 100;
		stringBuilder.append("borough=" + borough);
		stringBuilder.append("&eventName=" + eventName);
		stringBuilder.append("&startRowIndex=" + String.valueOf(startRowIndex));
		stringBuilder.append("&batchSize=" + String.valueOf(batchSize));
		ReflectionTestUtils.setField(restActionExecutor, "restTemplate", restTemplate);
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/invalid/meters?", stringBuilder.toString());
		Mockito.when(restTemplate.getForObject(uri, MeterValidateResponseMapper.class)).thenReturn(response);
		MeterValidateResponseMapper result = restActionExecutor.getInvalidateMeter("B",
				"BoroughHall.01.12/10/20-01:22:01.AUTO", 1, 100);
		Assert.assertNotNull(result);
	}

	@Test
	public void finalizeValidateMeters() {
		MeterEventFinalize mef = new MeterEventFinalize();
		ResponseEntity<String> meterEventFinalize = new ResponseEntity<String>("Test", HttpStatus.OK);
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/finalize/meters");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("adid", "BUDIDHAK");
		HttpEntity<Object> entity = new HttpEntity<Object>(meterEventFinalize, headers);
		ReflectionTestUtils.setField(restActionExecutor, "restTemplate", restTemplate);
		Mockito.when(restTemplate.postForEntity(uri, entity, String.class)).thenReturn(meterEventFinalize);
		ResponseEntity<String> response = restActionExecutor.finalizeValidateMeters(mef, "BUDIDHAK");
		Assert.assertNull(response);
	}

	@Test
	public void finalizeValidateMetersTmp() {
		MeterEventFinalize mef = new MeterEventFinalize();
		ResponseEntity<String> meterEventFinalize = new ResponseEntity<String>("Test", HttpStatus.OK);
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect-tmp/events/finalize/meters");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("adid", "BUDIDHAK");
		HttpEntity<Object> entity = new HttpEntity<Object>(meterEventFinalize, headers);
		ReflectionTestUtils.setField(restActionExecutor, "restTemplate", restTemplate);
		Mockito.when(restTemplate.postForEntity(uri, entity, String.class)).thenReturn(meterEventFinalize);
		ResponseEntity<String> response = restActionExecutor.finalizeValidateMetersTmp(mef, "BUDIDHAK");
		Assert.assertNull(response);
	}
	
	@Test
	public void isOperatorAuthorized() throws ResourceAccessException {
		OperatorDetail operatorDetail = new OperatorDetail();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("adid=" + "BUDIDHAK");
		stringBuilder.append("&role=" + "RCC");

		URI uri = RestClientBuilder.customBuildURI("/operator/auth?", stringBuilder.toString());
		Mockito.when(restTemplate.getForObject(uri, OperatorDetail.class)).thenReturn(operatorDetail);
		boolean response = restActionExecutor.isOperatorAuthorized("BUDIDHAK", "RCC");
		Assert.assertNotNull(response);
	}

	/*@Test
	public void persistAPIKey() throws URISyntaxException {
		
      
		final String adid = "BUDIDHAK";
		final String apiKey = "74da7a34b8b391425ab24494a7afe337d4606ad4c818990f6e0b2e9672013214";
		final String type = "login";
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(adid.toUpperCase());
		operatorLoginDetail.setApiKey(apiKey);
		operatorLoginDetail.setLoginTimeStamp(new Date());
		operatorLoginDetail.setRole("RCC");
		operatorLoginDetail.setApiKeyStatus(13);
		operatorLoginDetail.setLoginStatus(10);
		OperatorLoginDetail operatorLoginDetails = new OperatorLoginDetail();
		operatorLoginDetails.setAdid(adid);
		operatorLoginDetails.setApiKey(apiKey);
		operatorLoginDetails.setApiKeyStatus(13);
		operatorLoginDetails.setLoginTimeStamp(new Date());
		operatorLoginDetails.setLoginStatus(10);
		operatorLoginDetails.setResponseStatus(true);
		operatorLoginDetails.setRole("test");
		operatorLoginDetails.setUserRoleId(10);
		ResponseEntity<OperatorLoginDetail> postForEntity = new ResponseEntity<OperatorLoginDetail>(operatorLoginDetails,HttpStatus.OK);
		URI uri = RestClientBuilder.customBuildURI("/operator/auth/persistApi/");
		
		Mockito.when(restTemplate.postForEntity(uri,operatorLoginDetail,OperatorLoginDetail.class)).thenReturn(postForEntity);
		//Mockito.when(postForEntity.getBody()).thenReturn(postForEntity.getBody());
		OperatorLoginDetail response = restActionExecutor.persistAPIKey(adid, apiKey,type);
		Assert.assertNotNull(response);
	}*/

	/*@Test
	public void getOperatorLoginDetail() {
		
		final String adid ="BUDIDHAK";
		
		OperatorLoginDetail operatorLoginDetailReq = new OperatorLoginDetail();
		operatorLoginDetailReq.setAdid("BUDIDHAK");
		operatorLoginDetailReq.setRole("RCC");
		
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid("BUDIDHAK");
		operatorLoginDetail.setRole("RCC");
		operatorLoginDetail.setUserRoleId(2);
	    operatorLoginDetail.setLoginTimeStamp(new Date());
		operatorLoginDetail.setApiKey("test");
		operatorLoginDetail.setApiKeyStatus(13);
		operatorLoginDetail.setLoginStatus(10);
		operatorLoginDetail.setResponseStatus(true);
		URI uri = RestClientBuilder.customBuildURI("/operator/principal/");
		ResponseEntity<OperatorLoginDetail> postForEntity = new ResponseEntity<OperatorLoginDetail>(operatorLoginDetail,
				HttpStatus.OK);
		postForEntity.getBody();
		Mockito.when(restTemplate.postForEntity(uri, operatorLoginDetailReq, OperatorLoginDetail.class))
				.thenReturn(postForEntity);
		OperatorLoginDetail response = restActionExecutor.getOperatorLoginDetail(adid);
		Assert.assertNull(response);
		Assert.assertEquals(response.getClass(), postForEntity.getClass());

	}*/

	/*@Test
	public void isAPIEndpointAuthorized() throws OperatorAuthorizationException {
		final String adid = "BUDIDHAK";
		final String apiKey = "74da7a34b8b391425ab24494a7afe337d4606ad4c818990f6e0b2e9672013214";
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(adid);
		operatorLoginDetail.setApiKey(apiKey);
		operatorLoginDetail.setApiKeyStatus(13);
		operatorLoginDetail.setLoginStatus(10);
		// boolean isAPIEndpointAuthorized = true;
		URI uri = RestClientBuilder.customBuildURI("/operator/principal/permission/");
		OperatorDetail operatorDetail = new OperatorDetail();
		operatorDetail.setAuthenticate(true);
		operatorDetail.setMessage("SUCCESS");
		ResponseEntity<OperatorDetail> postForEntity = new ResponseEntity<OperatorDetail>(operatorDetail,
				HttpStatus.OK);
		Mockito.when(restTemplate.postForEntity(uri, operatorLoginDetail, OperatorDetail.class))
				.thenReturn(postForEntity);
		boolean response = restActionExecutor.isAPIEndpointAuthorized("BUDIDHAK",
				"74da7a34b8b391425ab24494a7afe337d4606ad4c818990f6e0b2e9672013214", 13, 10);
		Assert.assertNotNull(response);
		// Assert.assertEquals(response., postForEntity);
	}*/

	@Test
	public void getLockedStatusByBoroughAndEventName() {
		StringBuilder stringBuilder = new StringBuilder();
		String borough = "B";
		String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		stringBuilder.append("borough=" + borough);
		stringBuilder.append("&eventName=" + eventName);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("adid", "BUDIDHAK");
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		MeterLockedStatusResponseMapper mlsrm = new MeterLockedStatusResponseMapper();
		ResponseEntity<MeterLockedStatusResponseMapper> actual = new ResponseEntity<MeterLockedStatusResponseMapper>(
				mlsrm, HttpStatus.OK);
		mlsrm.setMessage("SUCCESS");
		mlsrm.setStatus(true);
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/status/meters?", stringBuilder.toString());
		Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, MeterLockedStatusResponseMapper.class))
				.thenReturn(actual);
		MeterLockedStatusResponseMapper response = restActionExecutor.getLockedStatusByBoroughAndEventName("B",
				"BoroughHall.01.12/10/20-01:22:01.AUTO", "BUDIDHAK");
		Assert.assertEquals(response.getMessage(), mlsrm.getMessage());
	}

	@Test
	public void searchMeter() {
		MeterValidateResponseMapper merp = new MeterValidateResponseMapper();
		MeterSearch meterSearch = new MeterSearch();
		ResponseEntity<MeterValidateResponseMapper> result = new ResponseEntity<MeterValidateResponseMapper>(merp,
				HttpStatus.OK);
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/search/meters");
		Mockito.when(restTemplate.postForEntity(uri, meterSearch, MeterValidateResponseMapper.class))
				.thenReturn(result);
		// meterValidateResponseMapper = postForEntity.getBody();
		MeterValidateResponseMapper response = restActionExecutor.searchMeter(meterSearch);
		Assert.assertNotNull(response);

	}
	@Test
	public void unlockEvents(){
		restActionExecutor.unlockEvents("BUDIDHAK");
	}
}
