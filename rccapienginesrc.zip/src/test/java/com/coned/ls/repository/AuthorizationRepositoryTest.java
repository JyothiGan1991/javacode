package com.coned.ls.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.domain.SimpleJdbcCallFactory;
import com.coned.ls.exception.OperatorAuthorizationException;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { AuthorizationRepository.class })
@AutoConfigureMockMvc
public class AuthorizationRepositoryTest {
	
	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Autowired
	private WebApplicationContext wac;

	@InjectMocks
	private JdbcAuthorizationRepository jdbcAuthRepo;
	
	private MockMvc mockMvc;

	OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
	
	@Mock
	private SimpleJdbcCallFactory simpleJdbcCallFactory;
	
	@Mock
	private SimpleJdbcCall simpleJdbcCall;



	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcAuthRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		operatorLoginDetail.setAdid("test");
		operatorLoginDetail.setApiKey("xyz");
		operatorLoginDetail.setApiKeyStatus(11);
		operatorLoginDetail.setLoginStatus(12);
		operatorLoginDetail.setRole("RCC");
		operatorLoginDetail.setRoleId(2);
		operatorLoginDetail.setUserRoleId(2);
		
	}
	
	@Test
	public void isOperatorAuthorized(){
		Mockito.when(oracleJdbcTemplate.queryForObject("SELECT COUNT(UPPER(U.USER_AD_ID)) FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?",  new Object[]{"testUser","RCC"}, Integer.class)).thenReturn(1);
		boolean isOperatorAuthorized = jdbcAuthRepo.isOperatorAuthorized("testUser","RCC");
		Assert.assertEquals(true, isOperatorAuthorized);
	}
	
	@Test(expected=OperatorAuthorizationException.class)
	public void isOperatorAuthorized2(){
		Mockito.when(oracleJdbcTemplate.queryForObject("SELECT COUNT(UPPER(U.USER_AD_ID)) FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?",  new Object[]{"testUser","RCC"}, Integer.class)).thenReturn(0);
		boolean isOperatorAuthorized = jdbcAuthRepo.isOperatorAuthorized("testUser","RCC");
		Assert.assertEquals(true, isOperatorAuthorized);
	}

	@Test(expected=OperatorAuthorizationException.class)
	public void persistApi(){
		final String SELECT_SQL = "SELECT URM.USER_ROLE_ID FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?";
        Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{operatorLoginDetail.getAdid(), operatorLoginDetail.getRole()}, Integer.class)).thenReturn(2);
		OperatorLoginDetail resp = jdbcAuthRepo.persistApi(operatorLoginDetail);
		Assert.assertNotNull(resp);
	}
	
	@Test(expected=OperatorAuthorizationException.class)
	public void persistApi2(){
		operatorLoginDetail.setApiKeyStatus(12);
		operatorLoginDetail.setLoginStatus(11);
		final String SELECT_SQL = "SELECT URM.USER_ROLE_ID FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?";
        Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{operatorLoginDetail.getAdid(), operatorLoginDetail.getRole()}, Integer.class)).thenReturn(2);
		OperatorLoginDetail resp = jdbcAuthRepo.persistApi(operatorLoginDetail);
		Assert.assertNotNull(resp);
	}
	
	
	@Test
	public void unlockEvents(){
		//Mockito.doNothing().when(oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{"Test"}));
		ReflectionTestUtils.invokeMethod(jdbcAuthRepo, "unlockEvents", "Test");
	}
	
	@Test
	public void updateExistingLogin() {
		ReflectionTestUtils.invokeMethod(jdbcAuthRepo, "updateExistingLogin", 2);
	}
	
	//@Test
	public void getOperatorLoginDetail() {
		
		OperatorLoginDetail resp = jdbcAuthRepo.getOperatorLoginDetail("Test" , "Test");
		Assert.assertNotNull(resp);
	}
	
	@Test
	public void isAPIEndpointAuthorizeed(){
		String SELECT_SQL = "SELECT count(ul.api_key) from LS_USER_LOGIN ul inner join LS_USER_ROLE_MAPPING urm on urm.user_role_id = ul.fk_user_role_id inner join ls_user lu on UPPER(lu.user_ad_id) = UPPER(urm.fk_user_ad_id) where ul.api_key = ? and ul.api_key_status = ? and ul.user_login_status = ? and UPPER(lu.user_ad_id) = UPPER(?)";
		Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{"Test", 11, 10, "Test",}, Integer.class)).thenReturn(1);
		boolean resp = jdbcAuthRepo.isAPIEndpointAuthorizeed("Test", "Test", 11, 10);
		Assert.assertEquals(true, resp);		
	}
	
	@Test
	public void isAPIEndpointAuthorizeed2(){
		String SELECT_SQL = "SELECT count(ul.api_key) from LS_USER_LOGIN ul inner join LS_USER_ROLE_MAPPING urm on urm.user_role_id = ul.fk_user_role_id inner join ls_user lu on UPPER(lu.user_ad_id) = UPPER(urm.fk_user_ad_id) where ul.api_key = ? and ul.api_key_status = ? and ul.user_login_status = ? and UPPER(lu.user_ad_id) = UPPER(?)";
		Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{"Test", 11, 10, "Test",}, Integer.class)).thenReturn(0);
		boolean resp = jdbcAuthRepo.isAPIEndpointAuthorizeed("Test", "Test", 11, 10);
		Assert.assertEquals(false, resp);		
	}
	
	@SuppressWarnings("deprecation")
	@Test(expected = IllegalStateException.class)
	public void getOperatorLoginDetailTest() {
		OperatorLoginDetail operatorLoginDetail= new OperatorLoginDetail();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Map<String, Object> map = new HashMap<>();

		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("BORO_MUNI", "Test");
		list.add(lList);
		map.put("BORO", list);
		Mockito.when(simpleJdbcCall.execute()).thenReturn(map);	
		operatorLoginDetail = jdbcAuthRepo.getOperatorLoginDetail("Test","Test");
		Assert.assertNotNull(operatorLoginDetail);
	}
}
