package com.coned.jpa.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PersistenceUnit;
import jakarta.persistence.Query;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.coned.model.ExecuteEventListDetails;
import com.coned.model.FinalizeSubEventListDetails;
import com.coned.model.FinalizeSubEventListDetails;
import com.coned.model.RejectEventListDetails;
import com.coned.service.ExecuteEventUtil;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.FinalizeSubEventListDetailsRepository;
import com.coned.jpa.repository.FinalizeSubEventListDetailsRepository;

@RestController
@CrossOrigin
public class FinalizeSubEventListDetailsController {

	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";
	private static String FINALIZE = "finalize";
	private static String EXECUTE = "execute";
	private static String REJECT = "reject";

	private static final Logger logger = LoggerFactory.getLogger(FinalizeSubEventListDetailsController.class);

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	@Autowired
	private FinalizeSubEventListDetailsRepository finRep;

	@Autowired
	ExecuteEventUtil eutil;

	@PersistenceContext
	private EntityManager em;

	@GetMapping("/connect/events")
	public List getFinalizedSubEventListDetails() {
		List allevents = null;
		try {
		long time = System.currentTimeMillis();
		String qstr = "SELECT finalized_event_id, event_name, sub_event_name, boro_muni, sub_event_time, count_of_meter "
				+ "FROM ami_load_shedding.ls_finalize_sub_event_list_det "
				+ "ORDER BY finalized_event_id, boro_muni, event_name, sub_event_time";
		List<FinalizeSubEventListDetails> events = em.createNativeQuery(qstr, FinalizeSubEventListDetails.class)
				.getResultList();
		logger.debug("----events---- " + events.toString());
		logger.debug("{}: {} ms ", "TimeTrack--> ExecuteTime - /connect/events", System.currentTimeMillis() - time);

		Map<String, List<FinalizeSubEventListDetails>> byEventList = events.stream()
				.collect(Collectors.groupingBy(FinalizeSubEventListDetails::getBorough));

		byEventList.forEach((k, v) -> logger.debug("DeptId:" + k + "   " + ((List<FinalizeSubEventListDetails>) v)
				.stream().map(m -> m.getEventName() + " - " + m.getSubEventName()).collect(Collectors.joining(","))));
		logger.debug("{}: {} ms ", "TimeTrack-->  GroupByTime-----/connect/events", System.currentTimeMillis() - time);
		String[] keys = new String[byEventList.size()];
		Object[] values = new Object[byEventList.size()];
		int index = 0;
		allevents = new ArrayList();
		Map map = new HashMap();
		logger.debug("TOTAL EVENTS? "+byEventList.size());
		for (Entry<String, List<FinalizeSubEventListDetails>> mapEntry : byEventList.entrySet()) {
			map = new HashMap();
			keys[index] = mapEntry.getKey();
			String boroname = keys[index];
			map.put("boroughName", boroname);
			logger.debug("----mapEntry---- " + mapEntry.getValue().toString());
			values[index] = mapEntry.getValue();

			List<FinalizeSubEventListDetails> finSubLst = (List<FinalizeSubEventListDetails>) values[index];

			Map<String, List<FinalizeSubEventListDetails>> bySubEventMap = finSubLst.stream()
					.collect(Collectors.groupingBy(FinalizeSubEventListDetails::getEventName));
			logger.debug("borough: "+boroname+" - bySubEventMap.size(): "+bySubEventMap.size());
			Map<String, Object> bySubEventListSub = new HashMap<String, Object>();
			/*long[] ids = finSubLst.stream().mapToLong(FinalizeSubEventListDetails::getId).toArray();
			long id = finSubLst.stream().map(FinalizeSubEventListDetails::getId).findFirst().get();
			
			bySubEventListSub.put("id", id);*/
			
//			String ename = finSubLst.stream().map(FinalizeSubEventListDetails::getEventName).findFirst().get();
			List<String> enames = finSubLst.stream().map(FinalizeSubEventListDetails::getEventName).distinct().collect(Collectors.toList());
			logger.debug("borough: "+boroname+" #OfEvents: "+enames.size());
			List fsublist = new ArrayList();
			List allfsublist = new ArrayList();
			String tename = "";
			Map<String, List> subEvents = new HashMap<String, List>();
	        for (String ename : enames) {
	        	List eventlist = bySubEventMap.get(ename);
				FinalizeSubEventListDetails feventlistdet = (FinalizeSubEventListDetails) eventlist.get(0);
	        	
				/*logger.debug("EventName? "+ename
						+" -- subEventnames: "+bySubEventMap.get(ename)
						+"id: "+feventlistdet.getId());*/
				if( !tename.equals("") && !tename.equals(ename)) {
					//logger.debug("------ Next event adding into borough ---- ");
					bySubEventListSub = new HashMap<String, Object>();
				}
				tename = ename;
				bySubEventListSub.put("id", feventlistdet.getId());
				bySubEventListSub.put("eventName", ename);
				bySubEventListSub.put("subEvents", eventlist);	

				allfsublist.add(bySubEventListSub);
			}
	        map.put("events", allfsublist);
			allevents.add(map);
			index++;
		}
		time = System.currentTimeMillis() - time;
		logger.debug("{}: {} ms ", "TimeTrack-->  Total /connect/events", time);
		} catch (Exception e) {
			logger.error("** Exception -> FinalizeSubEventListDetailsController - getFinalizedSubEvetDetails(): "+e);
		}
		return allevents;
	}

	Optional<FinalizeSubEventListDetails> findFinById(Long eventid, String subeventname) {
		Optional<FinalizeSubEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT finalized_event_id, event_name, sub_event_name, boro_muni, sub_event_time, count_of_meter FROM "
					+ "ami_load_shedding.ls_finalize_sub_event_list_det WHERE finalized_event_id=" + eventid
					+ " AND sub_event_name='" + subeventname + "' AND ROWNUM = 1";
			logger.debug("findFinById " + qstr);
			FinalizeSubEventListDetails event = (FinalizeSubEventListDetails) em
					.createNativeQuery(qstr, FinalizeSubEventListDetails.class).getSingleResult();
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findFinById() " + e);
		}
		return opt;
	}

	Optional<ExecuteEventListDetails> findExeById(Long eventid, String subeventname) {
		Optional<ExecuteEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT fk_finalized_event_id, execute_time,boro_muni,event_name, operator_ad_id, event_type FROM "
					+ "ami_load_shedding.ls_execute_event_list_details WHERE fk_finalized_event_id=" + eventid
					+ " AND sub_event='" + subeventname + "' AND ROWNUM = 1";
			logger.debug("findExeById " + qstr);
			ExecuteEventListDetails event = (ExecuteEventListDetails) em
					.createNativeQuery(qstr, ExecuteEventListDetails.class).getSingleResult();
			logger.debug("FinalizeSubEventListDeytailsController -> findExeById " + event);
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findExeById() " + e);
		}
		return opt;
	}

	public Map<String, Object> findEvent(Long eventid, String subeventname) {
		long time = System.currentTimeMillis();
		Optional<FinalizeSubEventListDetails> optFin = findFinById(eventid, subeventname);
		Optional<ExecuteEventListDetails> optExe = findExeById(eventid, subeventname);
		logger.debug("{}: {} ms ", "TimeTrack-->  1-- findEvent(): ", System.currentTimeMillis() - time);
		logger.debug("Found in Finalize_Event? ------- " + "Eventid? " + eventid + " isPresent? " + optFin.isPresent());

		boolean foundEvnt = false;
		Map eventDetails = new HashMap();
		if (optExe.isPresent()) {
			foundEvnt = true;
			ExecuteEventListDetails exeEventDetails = optExe.get();
			eventDetails.put("id", exeEventDetails.getId());
			eventDetails.put("eventName", exeEventDetails.getEventname());
			eventDetails.put("eventDateTime", exeEventDetails.getExecuteDateTime());
			eventDetails.put("operator", exeEventDetails.getOperatorAdId());
			eventDetails.put("status", EXECUTE);
		} else if (optFin.isPresent()) {
			foundEvnt = true;
			FinalizeSubEventListDetails finEventDetails = optFin.get();
			eventDetails.put("id", finEventDetails.getId());
			eventDetails.put("eventName", finEventDetails.getEventName());
			eventDetails.put("subEventName", finEventDetails.getSubEventName());
			eventDetails.put("numberOfFinalizedMeters", finEventDetails.getNumberOfFinalizedMeters());
			eventDetails.put("eventDateTime", finEventDetails.getSubEventTime());
			eventDetails.put("boroMuni", finEventDetails.getBorough());
			eventDetails.put("status", FINALIZE);
		}
		/*
		 * if (!foundEvnt) throw new ResourceMissingException("Event not found :: " +
		 * eventid);
		 */
		time = System.currentTimeMillis() - time;
		logger.debug("{}: {} ms ", "TimeTrack-->  End--- findEvent() ", time);
		return eventDetails;
	}

	@GetMapping("/connect/events/{id}/{subeventname}")
	public ResponseEntity<Map<String, Object>> getFinalizedEventListDetailsById(
			@PathVariable(value = "id") Long eventid, @PathVariable(value = "subeventname") String subeventname)
			throws ResourceMissingException {
		long time = System.currentTimeMillis();
		Map eventDetails = findEvent(eventid, subeventname);
		if (eventDetails.isEmpty())
			throw new ResourceMissingException("Sub Event not found :: " + eventid + " -> " + subeventname);
		time = System.currentTimeMillis() - time;
		logger.debug("{}: {} ms ", "TimeTrack-->  Total: /connect/events/{id}/{subeventname}", time);
		return ResponseEntity.ok().body(eventDetails);
	}

	@Autowired
	FinalizeSubEventListDetailsController selfFinCntr;

	@PostMapping("/connect/events")
	@CrossOrigin
	@Transactional
	public Map<String, Object> connectEventQ(@RequestBody Map<String, Object> payload) throws ResourceMissingException {
		logger.debug("---------------------- START - connectEventQ ------------------------");
		Long eventid = Long.valueOf((Integer) payload.get("id"));
		String subeventname = (String) payload.get("subEventName");

		logger.debug(" --- eventid: " + eventid + " subeventname: " + subeventname);
		Map<String, Object> statusMap = findEvent(eventid, subeventname);
		Map<String, Object> response = new HashMap<>();
		logger.debug(" --- status? " + statusMap.get("status") + " action? " + payload.get("action"));
		if (statusMap.isEmpty()) {
			response.put("result", FAILED);
			response.put("status", "other");
			throw new ResourceMissingException("SubEvent Not Found!!");
		} else if (statusMap.get("status").equals(EXECUTE)) {
			response.put("result", FAILED);
			response.put("status", EXECUTE);
		} else if (statusMap.get("status").equals(FINALIZE)) {
			response.put("result", FAILED);
			response.put("status", OTHER);
			/********************************************************************************************/
			String action = (String) payload.get("action");
			String op_adid = (String) payload.get("userId");
			String qstr = "";
			Query q = null;
			int res = 0;
			boolean deleteFinRec = false;
			if (action.equalsIgnoreCase(EXECUTE)) {
				selfFinCntr.saveExeAction(payload);
				String boroMuni = (String) statusMap.get("boroMuni");
				
				
				deleteFinRec = eutil.callRemoteJob(eventid, "C", subeventname);
				if (deleteFinRec) {
					/*qstr = "DELETE FROM ami_load_shedding.ls_finalize_sub_event_list " + " WHERE EVENT_NAME = ("
							+ "SELECT DISTINCT EVENT_NAME FROM ami_load_shedding.ls_finalize_sub_event_list_det "
							+ "WHERE finalized_event_id = " + eventid + ")" + " AND BORO_MUNI = ("
							+ "SELECT DISTINCT BORO_MUNI FROM ami_load_shedding.ls_finalize_sub_event_list_det "
							+ "WHERE finalized_event_id = " + eventid + ")" + " AND SUB_EVENT_NAME = '"
							+ subeventname + "'";*/
					qstr = "DELETE FROM ami_load_shedding.ls_finalize_sub_event_list " 
							+ "WHERE fk_finalized_event_id = " + eventid + " AND boro_muni= '" + boroMuni + "' AND SUB_EVENT_NAME = '" + subeventname + "'";
					res = eutil.executeQuery(qstr);
					logger.debug("---DELETE FROM ls_finalize_sub_event_list -> Result: " + res);

					qstr = "DELETE FROM ami_load_shedding.ls_finalize_sub_event_list_det "
							+ "WHERE finalized_event_id = " + eventid + " AND sub_event_name='" + subeventname
							+ "'";
					res = eutil.executeQuery(qstr);
					logger.debug("---DELETE FROM ls_finalize_sub_event_list_det -> Result: " + res);

					qstr = "DELETE FROM ami_load_shedding.ls_aocc_execute_event " + "WHERE action= 'C' AND event_id =" + eventid + " AND sub_event_name='" + subeventname +"'";
					res = eutil.executeQuery(qstr);
					logger.debug("---DELETE FROM ls_aocc_execute_event -> Result: " + res);
					
					response.put("result", SUCCESS);
					response.put("status", "");
					logger.debug("---------------------- END - connectEventQ ------------------------");
				}
			}
		} // end of else

		return response;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public boolean saveExeAction(Map<String, Object> payload) throws ResourceMissingException {
		logger.debug("---------------------- START - saveExeAction ------------------------");
		Long eventid = Long.valueOf((Integer) payload.get("id"));
		String subeventname = (String) payload.get("subEventName");
		logger.debug(" --- eventid: " + eventid + " subeventname: " + subeventname);
		Map<String, Object> statusMap = findEvent(eventid, subeventname);
		logger.debug(" --- status? " + statusMap.get("status") + " action? " + payload.get("action"));
		boolean success = false;
		/********************************************************************************************/
		String action = (String) payload.get("action");
		String op_adid = (String) payload.get("userId");
		String qstr = "";
		Query q = null;
		int res = 0;
		qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list_details "
				+ "(fk_finalized_event_id, event_name, sub_event, boro_muni, execute_time, EVENT_TYPE, OPERATOR_AD_ID)  "
				+ "SELECT finalized_event_id, event_name, sub_event_name, boro_muni," + "current_timestamp, 'C','" + op_adid
				+ "' " + " FROM ami_load_shedding.ls_finalize_sub_event_list_det " + "WHERE finalized_event_id= "
				+ eventid + " AND sub_event_name='" + subeventname + "'";
		res = eutil.executeQuery(qstr);
		logger.debug("---INSERT INFO ls_execute_event_list_details -> Result: " + res);

		qstr = "INSERT INTO ami_load_shedding.ls_aocc_execute_event "
				+ "(event_id, event_name, sub_event_name, boro_muni, action) "
				+ "SELECT finalized_event_id, event_name, sub_event_name, boro_muni, 'C' "
				+ " FROM ami_load_shedding.ls_finalize_sub_event_list_det " + "WHERE finalized_event_id ="+ eventid + " AND sub_event_name='" + subeventname + "'";
		res = eutil.executeQuery(qstr);
		logger.debug("---INSERT INFO ls_aocc_execute_event -> Result: " + res);
				
		qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list_connect "
				+ "(fk_meter_event_load_id, event_name, boro_muni, sub_event_name, meter_number) "
				+ "SELECT l.fk_meter_event_load_id, l.event_name, l.boro_muni, l.sub_event_name, m.meter_number "
				+ "FROM ami_load_shedding.ls_finalize_sub_event_list l "
				+ "INNER JOIN ami_load_shedding.ls_finalize_sub_event_list_det d " + "ON d.event_name = l.event_name "
				+ "AND d.boro_muni  = l.boro_muni AND d.sub_event_name=l.sub_event_name "
				+ "INNER JOIN ami_load_shedding.ls_meter_event_load m "
				+ "ON m.meter_event_load_id = l.fk_meter_event_load_id " + "WHERE d.finalized_event_id= " + eventid
				+ " AND d.sub_event_name='" + subeventname + "'";
		res = eutil.executeQuery(qstr);
		logger.debug("---INSERT INFO ls_execute_event_list_connect -> Result: " + res);
		logger.debug("---------------------- END - saveExeAction ------------------------");
		success = true;
		return success;
	}

	/*public int executeQuery(String qstr) {
		int res = 0;
		try {
			logger.debug(" FinalizeSubEventListDetailsController -> query: " + qstr);
			Query q = em.createNativeQuery(qstr);
			res = q.executeUpdate();
		} catch (Exception e) {
			logger.error("**Exception -> FinalizeSubEventListDetailsController -> executeQuery(): " + e);
		}
		return res;
	}*/

	/*
	 * @PostMapping("/connect/subevents") public ResponseEntity<Map<String, Object>>
	 * getFinalizedSubEventListDetailsById(@RequestBody Map<String, Object> payload)
	 * throws ResourceMissingException { long time = System.currentTimeMillis();
	 * Long eventid = Long.valueOf((Integer) payload.get("id")); String subeventname
	 * = (String) payload.get("subeventname");
	 * 
	 * logger.debug(" --- eventid: " + eventid+" subeventname: "+subeventname); Map
	 * eventDetails = findEvent(eventid, subeventname); if (eventDetails.isEmpty())
	 * throw new ResourceMissingException("Event not found :: " + eventid); time =
	 * System.currentTimeMillis() - time; logger.debug("{}: {} ms ",
	 * "TimeTrack-->  Total: /connect/events/{id}", time); return
	 * ResponseEntity.ok().body(eventDetails); }
	 */
}
