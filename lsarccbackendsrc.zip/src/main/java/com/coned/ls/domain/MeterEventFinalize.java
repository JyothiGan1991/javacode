package com.coned.ls.domain;

import java.util.Date;
import java.util.List;

/**
 * 
 * Domain class to store finalized event details.
 *
 */
public class MeterEventFinalize{
	
	private long countOfMeters;
	private Date finalizeTime;
	private String operatorAdId;
	private String borough;
	private String eventName;
	private String message;
	private boolean isValid;
	private String subEventName;
	private List<String> listOfMeters;
	private String meters;
	private boolean isSelectAll;
	private String filterList;
	
	private int selectAllAction;
	
	public MeterEventFinalize() {
		super();
	}
	public MeterEventFinalize(long countOfMeters, Date finalizeTime,
			String operatorAdId, String borough, String eventName) {
		super();
		this.countOfMeters = countOfMeters;
		this.finalizeTime = finalizeTime;
		this.operatorAdId = operatorAdId;
		this.borough = borough;
		this.eventName = eventName;
	}
	
	
	public MeterEventFinalize(long countOfMeters, Date finalizeTime,
			String operatorAdId, String borough, String eventName,
			String message, boolean isValid) {
		super();
		this.countOfMeters = countOfMeters;
		this.finalizeTime = finalizeTime;
		this.operatorAdId = operatorAdId;
		this.borough = borough;
		this.eventName = eventName;
		this.message = message;
		this.isValid = isValid;
	}
	public long getCountOfMeters() {
		return countOfMeters;
	}
	public void setCountOfMeters(long countOfMeters) {
		this.countOfMeters = countOfMeters;
	}
	public Date getFinalizeTime() {
		return finalizeTime;
	}
	public void setFinalizeTime(Date finalizeTime) {
		this.finalizeTime = finalizeTime;
	}
	public String getOperatorAdId() {
		return operatorAdId;
	}
	public void setOperatorAdId(String operatorAdId) {
		this.operatorAdId = operatorAdId;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValid() {
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	public String getMeters() {
		return meters;
	}
	public void setMeters(String meters) {
		this.meters = meters;
	}
	public String getSubEventName() {
		return subEventName;
	}
	public void setSubEventName(String subEventName) {
		this.subEventName = subEventName;
	}
		
	public List<String> getListOfMeters() {
		return listOfMeters;
	}
	public void setListOfMeters(List<String> listOfMeters) {
		this.listOfMeters = listOfMeters;
	}
	public boolean getIsSelectAll() {
		return isSelectAll;
	}
	public void setIsSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}
	
	
	public String getFilterList() {
		return filterList;
	}
	public void setFilterList(String filterList) {
		this.filterList = filterList;
	}
	public int getSelectAllAction() {
		return selectAllAction;
	}
	public void setSelectAllAction(int selectAllAction) {
		this.selectAllAction = selectAllAction;
	}
	public MeterEventFinalize(long countOfMeters, Date finalizeTime,
			String operatorAdId, String borough, String eventName,
			String subEventName) {
		super();
		this.countOfMeters = countOfMeters;
		this.finalizeTime = finalizeTime;
		this.operatorAdId = operatorAdId;
		this.borough = borough;
		this.eventName = eventName;
		this.subEventName = subEventName;
	}
	@Override
	public String toString() {
		return "MeterEventFinalize [countOfMeters=" + countOfMeters
				+ ", finalizeTime=" + finalizeTime + ", operatorAdId="
				+ operatorAdId + ", borough=" + borough + ", eventName="
				+ eventName + ", message=" + message + ", isValid=" + isValid
				+ "]";
	}
}
