package com.coned.ls.login;
import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;


import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class SampleCallbackHandlerTest {
	@Rule
	public MockitoRule rule = MockitoJUnit.rule().silent();
	
	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private HttpServletRequest request;
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@InjectMocks
	SampleCallbackHandler sampleCallbackHandler;

	
	@Test
	public void HandleTest() {
		TextOutputCallback tocb = new TextOutputCallback(1, "INFORMATION");
		//Callback cb = tocb;
		Callback[] callbacks = new Callback[1];
		callbacks[0] =  tocb;
		
		try {
			sampleCallbackHandler.handle(callbacks);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedCallbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void HandleTest2() {
		NameCallback tocb = new NameCallback( "INFORMATION");
		//Callback cb = tocb;
		Callback[] callbacks = new Callback[1];
		callbacks[0] =  tocb;
		
		try {
			sampleCallbackHandler.handle(callbacks);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedCallbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void HandleTest3() {
		PasswordCallback pcb = new PasswordCallback( "Enter the password",true);
		Callback[] callbacks = new Callback[1];
		callbacks[0] =  pcb;
		
		try {
			ReflectionTestUtils.setField(sampleCallbackHandler, "password", "password");
			//pcb.setPassword(password.toCharArray());
			sampleCallbackHandler.handle(callbacks);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedCallbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
