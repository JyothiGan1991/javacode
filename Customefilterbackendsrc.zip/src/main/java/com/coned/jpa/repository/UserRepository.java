package com.coned.jpa.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coned.model.User;
import com.coned.model.Role;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	List<User> findByRoleId(Long roleId);
	List<User> findByUsernameContaining(String username);
	Optional<User> findByUsername(String username);
	Optional<User> findByIdAndRoleId(Long id, Long roleId);
}