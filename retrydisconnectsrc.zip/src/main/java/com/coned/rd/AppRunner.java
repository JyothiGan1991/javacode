package com.coned.rd;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.coned.rd.beans.Event;
import com.coned.rd.service.RetryService;

@Component
public class AppRunner implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

	@Autowired
	private RetryService serv;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * Callback used to run the bean.
	 * 
	 * @param args incoming main method arguments
	 * @throws Exception on error
	 */
	@Override
	public void run(String... args) throws Exception {
		processEvents();
		// Thread.sleep(300000);
	}

	/**
	 * Fetch the events that has failed meters and push for retry process
	 **/
	private void processEvents() {
		try {
			Collection<Event> eventList = serv.calculateTimeouts();

			/** extract the events that are marked for retry **/
			List<Event> retryEventList = eventList.stream().filter(e -> e.isRetry()).collect(Collectors.toList());
			logger.debug("Events that are marked for retry {}", retryEventList);
			logger.info("Events list size [{}] marked for retry", retryEventList.size());

			/**
			 * Fetch the failed meters for the events that are ready for retry and push them
			 * for disconnect retry
			 **/
			serv.getFailedMeters(retryEventList, restTemplate);
		} catch (

		Exception e) {
			logger.error(" ", e);
		}
	}

}
