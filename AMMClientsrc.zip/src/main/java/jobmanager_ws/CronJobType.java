
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CronJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CronJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CronJobType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}CronJobTypeType"/&gt;
 *         &lt;element name="Parameter" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ParameterType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CronJobType", propOrder = {
    "cronJobType",
    "parameter"
})
public class CronJobType {

    @XmlElement(name = "CronJobType", required = true)
    protected CronJobTypeType cronJobType;
    @XmlElement(name = "Parameter")
    protected List<ParameterType> parameter;

    /**
     * Gets the value of the cronJobType property.
     * 
     * @return
     *     possible object is
     *     {@link CronJobTypeType }
     *     
     */
    public CronJobTypeType getCronJobType() {
        return cronJobType;
    }

    /**
     * Sets the value of the cronJobType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CronJobTypeType }
     *     
     */
    public void setCronJobType(CronJobTypeType value) {
        this.cronJobType = value;
    }

    /**
     * Gets the value of the parameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ParameterType }
     * 
     * 
     */
    public List<ParameterType> getParameter() {
        if (parameter == null) {
            parameter = new ArrayList<ParameterType>();
        }
        return this.parameter;
    }

}
