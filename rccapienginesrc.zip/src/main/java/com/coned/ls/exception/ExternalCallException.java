package com.coned.ls.exception;

import java.util.Date;

public class ExternalCallException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public ExternalCallException() {
		super();
	}
	
	public ExternalCallException(String message) {
		super(message);
		
	}
	public ExternalCallException(String message,Throwable cause) {
		   super(message,cause);
		}
}
