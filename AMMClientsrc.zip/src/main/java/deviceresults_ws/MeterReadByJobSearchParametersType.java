
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterReadByJobSearchParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterReadByJobSearchParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JobID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RunID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MeterDataType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}MeterDataTypeEnumeration" minOccurs="0"/&gt;
 *         &lt;element name="LPSetId" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterReadByJobSearchParametersType", propOrder = {
    "jobID",
    "deviceMacID",
    "runID",
    "meterDataType",
    "lpSetId"
})
public class MeterReadByJobSearchParametersType {

    @XmlElement(name = "JobID")
    protected long jobID;
    @XmlElement(name = "DeviceMacID")
    protected List<String> deviceMacID;
    @XmlElement(name = "RunID")
    protected Long runID;
    @XmlElement(name = "MeterDataType")
    @XmlSchemaType(name = "string")
    protected MeterDataTypeEnumeration meterDataType;
    @XmlElement(name = "LPSetId", type = Long.class)
    protected List<Long> lpSetId;

    /**
     * Gets the value of the jobID property.
     * 
     */
    public long getJobID() {
        return jobID;
    }

    /**
     * Sets the value of the jobID property.
     * 
     */
    public void setJobID(long value) {
        this.jobID = value;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the runID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRunID() {
        return runID;
    }

    /**
     * Sets the value of the runID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRunID(Long value) {
        this.runID = value;
    }

    /**
     * Gets the value of the meterDataType property.
     * 
     * @return
     *     possible object is
     *     {@link MeterDataTypeEnumeration }
     *     
     */
    public MeterDataTypeEnumeration getMeterDataType() {
        return meterDataType;
    }

    /**
     * Sets the value of the meterDataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterDataTypeEnumeration }
     *     
     */
    public void setMeterDataType(MeterDataTypeEnumeration value) {
        this.meterDataType = value;
    }

    /**
     * Gets the value of the lpSetId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lpSetId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLPSetId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getLPSetId() {
        if (lpSetId == null) {
            lpSetId = new ArrayList<Long>();
        }
        return this.lpSetId;
    }

}
