
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningModeStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RemoteProvisioningModeStatusType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}RemoteProvisioningModeStatusTypeEnum"/&gt;
 *         &lt;element name="LocalizedValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RemoteProvisioningModeStatusType", propOrder = {
    "name",
    "localizedValue"
})
public class RemoteProvisioningModeStatusType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected RemoteProvisioningModeStatusTypeEnum name;
    @XmlElement(name = "LocalizedValue")
    protected String localizedValue;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusTypeEnum }
     *     
     */
    public RemoteProvisioningModeStatusTypeEnum getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusTypeEnum }
     *     
     */
    public void setName(RemoteProvisioningModeStatusTypeEnum value) {
        this.name = value;
    }

    /**
     * Gets the value of the localizedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedValue() {
        return localizedValue;
    }

    /**
     * Sets the value of the localizedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedValue(String value) {
        this.localizedValue = value;
    }

}
