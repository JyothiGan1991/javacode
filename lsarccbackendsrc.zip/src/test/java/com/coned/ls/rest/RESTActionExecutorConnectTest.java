package com.coned.ls.rest;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)

public class RESTActionExecutorConnectTest {
	
	@InjectMocks
	private RESTActionExecutorConnect restActionExecutorConnect;
	
	@Mock
	private RestTemplate restTemplate;
	
	@Test
	@Before
	public void setup() {
	 ReflectionTestUtils.setField(restActionExecutorConnect, "restTemplate", restTemplate);
	 RestClientBuilder.baseURL = "http://172.16.81.109:7001/rcc-api";
	}
	 
	 @Test
	    public void getBoroughAndEventNameForConnect(){
		 List<String> list = new ArrayList<String>();
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.OK);
		 HttpHeaders headers = new HttpHeaders();
		 headers.setContentType(MediaType.APPLICATION_JSON);
		  HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		 String fields = "B";
		 URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/meters?fields="+fields);
		 Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual);
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getBoroughAndEventNameForConnect("B");
	      Assert.assertNotNull(response);
		 
	 }
	 
	 @Test
	    public void getBoroughAndEventNameForConnect2(){
		 List<String> list = new ArrayList<String>();
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.NO_CONTENT);
		 HttpHeaders headers = new HttpHeaders();
		 headers.setContentType(MediaType.APPLICATION_JSON);
		  HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		 String fields = "B";
		 URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/meters?fields="+fields);
		 Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual);
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getBoroughAndEventNameForConnect("B");
	      Assert.assertNotNull(response);
		 
	 }
	 
	 @Test
	    public void getOpenEventForConnect(){
	      final String value ="Test";
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getOpenEventForConnect(value);
	      Assert.assertNotNull(response);
		}
	 
	 @Test
	    public void getValidMetersForConnect(){
		 MeterEventResponseMapper mvrp = new MeterEventResponseMapper();
			mvrp.setBorough("P");
			mvrp.setMessage("SUCCESS");
			mvrp.setCountOfMeters(10);
			mvrp.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
			List<MeterEventLoad> meterEventLoads = new ArrayList<>();
			mvrp.setMeterEventLoads(meterEventLoads);
			ResponseEntity<MeterEventResponseMapper>  expected = new ResponseEntity<MeterEventResponseMapper>(mvrp, HttpStatus.OK);
			
			final String borough = "Test";
			final String eventName = "Test";
			final int startRowIndex = 1;
			final int batchSize = 10;
			final String filterList = "Test";
	        final String sortList = "Test";
	        final String adid = "Test";
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("borough="+borough);
			stringBuilder.append("&eventName="+eventName);
			stringBuilder.append("&startRowIndex="+String.valueOf(startRowIndex));
			stringBuilder.append("&batchSize="+String.valueOf(batchSize));
			stringBuilder.append("&filterList="+String.valueOf(filterList));
			stringBuilder.append("&sortList="+String.valueOf(sortList));
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/meters?", stringBuilder.toString());
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", "Test");
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
			Mockito.when( restTemplate.exchange(uri, HttpMethod.GET, entity, MeterEventResponseMapper.class)).thenReturn(expected);
			
			MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
			meterOpenEvent.setBorough("M");
			meterOpenEvent.setEventName("QRST");
			meterOpenEvent.setStartRowIndex(1);
			meterOpenEvent.setBatchSize(500);
			meterOpenEvent.setAdid("Test");
			
		   ResponseEntity<MeterEventResponseMapper> response = restActionExecutorConnect.getValidMetersForConnect(meterOpenEvent);
		  // Assert.assertNotNull(response.getBody());
		}
	 
	 @Test
	    public void getConnectdMeters(){
		 MeterEventResponseMapper mvrp = new MeterEventResponseMapper();
			mvrp.setBorough("P");
			mvrp.setMessage("SUCCESS");
			mvrp.setCountOfMeters(10);
			mvrp.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
			ResponseEntity<MeterEventResponseMapper>  expected = new ResponseEntity<MeterEventResponseMapper>(mvrp, HttpStatus.OK);

			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/meters");
			
			MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
			
			meterOpenEvent.setBorough("P");
			meterOpenEvent.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
			meterOpenEvent.setStartRowIndex(1);
			meterOpenEvent.setBatchSize(10);
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterOpenEvent, headers);

		    ReflectionTestUtils.setField(restActionExecutorConnect, "restTemplate", restTemplate);

			Mockito.when(restTemplate.postForEntity(uri, entity, MeterEventResponseMapper.class)).thenReturn(expected);

		   ResponseEntity<MeterEventResponseMapper> response = restActionExecutorConnect.getConnectdMeters(meterOpenEvent);
		   Assert.assertNotNull(response.getBody());
		}
	 @Test
	    public void finalizeSubEventMeter(){
		 MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
	    SubEvent subEvent = new SubEvent();
	    subEvent.setBorough("B");
	    subEvent.setEvent("BoroughHall.01.12/10/20-01:22:01.AUTO");
	    subEvent.setSubEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
	    subEvent.setIsSelectAll(true);
	    subEvent.setIsCreateSubEvent(true);
	    subEvent.setExclude(true);
	    subEvent.setPageNumber(1);
	    subEvent.setPageSize(100);
	    mfrp.setMessage("SUCCESS");
		mfrp.setResult(true);
	    
	    ResponseEntity<MeterFinalizeResponseMapper>meterEventFinalize = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp, HttpStatus.OK);
	    URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/finalize-sub/meters/");
		ReflectionTestUtils.setField(restActionExecutorConnect, "restTemplate", restTemplate);
		Mockito.when( restTemplate.postForEntity(uri, subEvent, MeterFinalizeResponseMapper.class)).thenReturn(meterEventFinalize);
		 //ResponseEntity<MeterFinalizeResponseMapper> response= restActionExecutorConnect.finalizeSubEventMeter(subEvent,"Test");
		  // Assert.assertEquals(response.getBody(), meterEventFinalize.getBody());
	    }
	 
	 @Test
	    public void getSubEventSuffix(){
		 Long value = new Long(0);
		 ResponseEntity<Long> actual = new ResponseEntity<Long>(value,HttpStatus.OK);
		 final String borough = "B";
		 final String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		 final String items = "Test";
		 StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("borough="+borough);
			stringBuilder.append("&eventName="+eventName);
			stringBuilder.append("&items="+items);
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		ReflectionTestUtils.setField(restActionExecutorConnect, "restTemplate", restTemplate);
	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	    URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/finalize/sub-event/suffix?", stringBuilder.toString());
		Mockito.when( restTemplate.exchange(uri, HttpMethod.GET, entity, Long.class)).thenReturn(actual);
		ResponseEntity<Long>  response= restActionExecutorConnect.getSubEventSuffix("B","BoroughHall.01.12/10/20-01:22:01.AUTO","Test");
		//Assert.assertEquals(response.getBody().longValue(), actual.getBody().longValue());
		Assert.assertNotNull(response);
	    }
	 
	 @Test
	    public void getSubFinalizeBorough(){
		 List<String> value = new ArrayList<String>();
		 value.isEmpty();
		ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(value, HttpStatus.OK);
	      final String fields ="Test";
	       URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/sub-event/meters?fields="+fields);
		   HttpHeaders headers = new HttpHeaders();
		   headers.setContentType(MediaType.APPLICATION_JSON);
	       HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		   Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual); 
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getSubFinalizeBorough(fields);
	      //Assert.assertNotNull(response);
	      Assert.assertEquals(response.getBody(), actual.getBody());
		}
	 
	 @Test
	    public void getSubFinalizeEvent(){
		 List<String> value = new ArrayList<String>();
		 value.isEmpty();
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(value, HttpStatus.OK);
	      final String fields ="Test";
	      URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/sub-event/meters?fields="+fields);
		   HttpHeaders headers = new HttpHeaders();
		   headers.setContentType(MediaType.APPLICATION_JSON);
	       HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		   Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual); 
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getSubFinalizeEvent(fields);
	      //Assert.assertNotNull(response);
	      Assert.assertEquals(response.getBody(), actual.getBody());
	 }
	 
	 @Test
	    public void getSubFinalizeEventByEventAndBorough(){
		 final String borough = "B";
		 final String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		 final String items = "Test";
		 List<String> value = new ArrayList<String>();
		 value.isEmpty();
		 StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("borough="+borough);
			stringBuilder.append("&eventName="+eventName);
			stringBuilder.append("&items="+items);
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(value, HttpStatus.OK);
	      URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/finalize/sub-event/meters?", stringBuilder.toString());
		   HttpHeaders headers = new HttpHeaders();
		   headers.setContentType(MediaType.APPLICATION_JSON);
	       HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		   Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual);
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getSubFinalizeEventByEventAndBorough("B","BoroughHall.01.12/10/20-01:22:01.AUTO");
	      Assert.assertNotNull(response);
	      //Assert.assertEquals(response.getBody(), actual.getBody());
	 }
	 
	 @Test
	    public void getSubEventMeters(){
		 MeterEventResponseMapper mvrp = new MeterEventResponseMapper();
			mvrp.setBorough("P");
			mvrp.setMessage("SUCCESS");
			mvrp.setCountOfMeters(10);
			mvrp.setEventName("BoroughHall.01.12/10/20-01:22:01.AUTO");
			List<MeterEventLoad> meterEventLoads = new ArrayList<>();
			mvrp.setMeterEventLoads(meterEventLoads);
			
			final String borough = "Test";
			final String eventName = "Test";
			final String subEventName = "Test";
			final int startRowIndex = 1;
			final int batchSize = 10;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("borough="+borough);
			stringBuilder.append("&eventName="+eventName);
			stringBuilder.append("&subEventName="+subEventName);
			stringBuilder.append("&startRowIndex="+String.valueOf(startRowIndex));
			stringBuilder.append("&batchSize="+String.valueOf(batchSize));
		    URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/sub-event/meters?", stringBuilder.toString());
			Mockito.when(restTemplate.getForObject(uri, MeterEventResponseMapper.class)).thenReturn(mvrp);
			
			MeterEventResponseMapper response = restActionExecutorConnect.getSubEventMeters("Test","Test","Test",1,10);
		   Assert.assertNotNull(response);
		}
	 
	 @Test
	    public void searchMeter() {
		 MeterEventResponseMapper merp = new MeterEventResponseMapper();
	    	ResponseEntity<MeterEventResponseMapper> actual = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
	    	MeterSearch meterSearch = new MeterSearch();
	    	URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/search/meters");
	    	Mockito.when(restTemplate.postForEntity(uri, meterSearch, MeterEventResponseMapper.class)).thenReturn(actual);
			//meterValidateResponseMapper = postForEntity.getBody();
	    	 ResponseEntity<MeterEventResponseMapper> response = restActionExecutorConnect.searchMeter(meterSearch);
	    	Assert.assertNotNull(response);
	    	
	    }
	 
	 @Test
	    public void searchMeterConnected() {
		 MeterEventResponseMapper merp = new MeterEventResponseMapper();
	    	ResponseEntity<MeterEventResponseMapper> actual = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
	    	MeterSearch meterSearch = new MeterSearch();
	    	URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/search/meters");
	    	Mockito.when(restTemplate.postForEntity(uri, meterSearch, MeterEventResponseMapper.class)).thenReturn(actual);
			//meterValidateResponseMapper = postForEntity.getBody();
	    	 ResponseEntity<MeterEventResponseMapper> response = restActionExecutorConnect.searchMeterConnected(meterSearch);
	    	Assert.assertNotNull(response);
	    }
	 
	 @Test
	    public void getSubEventMetersTest() {
		 MeterEventResponseMapper merp = new MeterEventResponseMapper();
	    	ResponseEntity<MeterEventResponseMapper> actual = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
	    	SubEvent subEvent = new SubEvent();
	    	URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/sub-event/meters");
	    	Mockito.when(restTemplate.postForEntity(uri, subEvent, MeterEventResponseMapper.class)).thenReturn(actual);
			//meterValidateResponseMapper = postForEntity.getBody();
	    	 ResponseEntity<MeterEventResponseMapper> response = restActionExecutorConnect.getSubEventMeters(subEvent);
	    	Assert.assertNotNull(response);
	    	
	    }
	 
	 @Test
	    public void getFieldValuesByBoroughAndEventName(){
		 List<String> list = new ArrayList<String>();
		 final String fieldName = "Test";
		 final String eventName = "Test";
		 final String borough = "B";
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.OK);
		 StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("eventName="+eventName);
			stringBuilder.append("&fieldName="+fieldName);
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/meters/fields/" + borough + "?", stringBuilder.toString());
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		 Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual);
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getFieldValuesByBoroughAndEventName("B","Test", "Test");
	      Assert.assertNotNull(response);
		 
	 }

	 @Test
	    public void getConnectedMetersFieldValuesByBoroughAndEventName(){
		 List<String> list = new ArrayList<String>();
		 final String fieldName = "Test";
		 final String eventName = "Test";
		 final String borough = "B";
		 ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(list, HttpStatus.OK);
		 StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("eventName="+eventName);
			stringBuilder.append("&fieldName="+fieldName);
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/meters/fields/" + borough + "?", stringBuilder.toString());
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		 Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual);
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getConnectedMetersFieldValuesByBoroughAndEventName("B","Test", "Test");
	      Assert.assertNotNull(response);
	 }
	 
	 @Test
	    public void isEventLocked() { 
		 final String eventName = "BoroughHall.01.12/10/20-01:22:01.AUTO";
		 final String borough = "B";
		 StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("borough="+borough);
			stringBuilder.append("&eventName="+eventName);	
				URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/status/meters?", stringBuilder.toString());
				
				HttpHeaders headers = new HttpHeaders();
			    headers.setContentType(MediaType.APPLICATION_JSON);
			    headers.set("adid", "BUDIDHAK");
			    
			 HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	    	MeterLockedStatusResponseMapper mlsrm = new MeterLockedStatusResponseMapper();
	    	ResponseEntity<MeterLockedStatusResponseMapper> actual = new ResponseEntity<MeterLockedStatusResponseMapper>(mlsrm,HttpStatus.OK);
	    	mlsrm.setMessage("SUCCESS");
	    	mlsrm.setStatus(true);
	    	Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, MeterLockedStatusResponseMapper.class)).thenReturn(actual);
	    	MeterLockedStatusResponseMapper response = restActionExecutorConnect.isEventLocked("B", "BoroughHall.01.12/10/20-01:22:01.AUTO","BUDIDHAK");
	    	Assert.assertEquals(response.getMessage(),mlsrm.getMessage());
	    }
	 
	 @Test
	    public void getSubEventNameBySubBorough(){
		 List<String> value = new ArrayList<String>();
		ResponseEntity<List<String>> actual = new ResponseEntity<List<String>>(value, HttpStatus.OK);
	      final String borough ="Test";
	      Map<String, String> params = new HashMap<String, String>();
			params.put("borough", borough);
		URI uri = RestClientBuilder.buildURI("/rcc/connect/events/open/sub-event/meters/{borough}", params);
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		   Mockito.when( restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {})).thenReturn(actual); 
	      ResponseEntity<List<String>> response = restActionExecutorConnect.getSubEventNameBySubBorough(borough);
	      //Assert.assertNotNull(response);
	      Assert.assertEquals(response.getBody(), actual.getBody());
		}
	 
	 /*
	 @Test
		public void unlockEvents(){
			restActionExecutorConnect.unlockEvents("BUDIDHAK");
		}
	 */

	 @Test
		public void unlockEvents(){
			URI uri = RestClientBuilder.customBuildURI("/events/status/meters");
				
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("adid", "BUDIDHAK");
			HttpEntity<Object> entity = new HttpEntity<Object>(headers);

			Mockito.doNothing().when(restTemplate).put(uri, entity);
			
		    restActionExecutorConnect.unlockEvents("BUDIDHAK");
		}
	}
	
	