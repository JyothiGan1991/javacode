package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.Meter;

public class MeterRowMapper implements RowMapper<Meter> {

	@Override
	public Meter mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Meter(rs.getBigDecimal(1), rs.getString(2), rs.getString(3));
	}
}
