
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetMeterReadResultsByJobIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetMeterReadResultsByJobIDType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterReadByJobSearchParametersType"/&gt;
 *           &lt;element name="CachedResults" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}StringKeyCachedResultsType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="NumberRows" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="IntervalSortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}IntervalSortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="SecurityLogSortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}SecurityLogSortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="RegisterReadSortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RegisterReadSortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="GenericMeterReadSortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}GenericMeterReadSortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="GenericMeterReadFormat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetMeterReadResultsByJobIDType", propOrder = {
    "searchParameters",
    "cachedResults",
    "numberRows",
    "intervalSortMap",
    "securityLogSortMap",
    "registerReadSortMap",
    "genericMeterReadSortMap",
    "genericMeterReadFormat"
})
public class GetMeterReadResultsByJobIDType {

    @XmlElement(name = "SearchParameters")
    protected MeterReadByJobSearchParametersType searchParameters;
    @XmlElement(name = "CachedResults")
    protected StringKeyCachedResultsType cachedResults;
    @XmlElement(name = "NumberRows")
    protected int numberRows;
    @XmlElement(name = "IntervalSortMap")
    protected List<IntervalSortMapType> intervalSortMap;
    @XmlElement(name = "SecurityLogSortMap")
    protected List<SecurityLogSortMapType> securityLogSortMap;
    @XmlElement(name = "RegisterReadSortMap")
    protected List<RegisterReadSortMapType> registerReadSortMap;
    @XmlElement(name = "GenericMeterReadSortMap")
    protected List<GenericMeterReadSortMapType> genericMeterReadSortMap;
    @XmlElement(name = "GenericMeterReadFormat")
    protected String genericMeterReadFormat;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link MeterReadByJobSearchParametersType }
     *     
     */
    public MeterReadByJobSearchParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterReadByJobSearchParametersType }
     *     
     */
    public void setSearchParameters(MeterReadByJobSearchParametersType value) {
        this.searchParameters = value;
    }

    /**
     * Gets the value of the cachedResults property.
     * 
     * @return
     *     possible object is
     *     {@link StringKeyCachedResultsType }
     *     
     */
    public StringKeyCachedResultsType getCachedResults() {
        return cachedResults;
    }

    /**
     * Sets the value of the cachedResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringKeyCachedResultsType }
     *     
     */
    public void setCachedResults(StringKeyCachedResultsType value) {
        this.cachedResults = value;
    }

    /**
     * Gets the value of the numberRows property.
     * 
     */
    public int getNumberRows() {
        return numberRows;
    }

    /**
     * Sets the value of the numberRows property.
     * 
     */
    public void setNumberRows(int value) {
        this.numberRows = value;
    }

    /**
     * Gets the value of the intervalSortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the intervalSortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIntervalSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IntervalSortMapType }
     * 
     * 
     */
    public List<IntervalSortMapType> getIntervalSortMap() {
        if (intervalSortMap == null) {
            intervalSortMap = new ArrayList<IntervalSortMapType>();
        }
        return this.intervalSortMap;
    }

    /**
     * Gets the value of the securityLogSortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the securityLogSortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecurityLogSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SecurityLogSortMapType }
     * 
     * 
     */
    public List<SecurityLogSortMapType> getSecurityLogSortMap() {
        if (securityLogSortMap == null) {
            securityLogSortMap = new ArrayList<SecurityLogSortMapType>();
        }
        return this.securityLogSortMap;
    }

    /**
     * Gets the value of the registerReadSortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registerReadSortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegisterReadSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegisterReadSortMapType }
     * 
     * 
     */
    public List<RegisterReadSortMapType> getRegisterReadSortMap() {
        if (registerReadSortMap == null) {
            registerReadSortMap = new ArrayList<RegisterReadSortMapType>();
        }
        return this.registerReadSortMap;
    }

    /**
     * Gets the value of the genericMeterReadSortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the genericMeterReadSortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGenericMeterReadSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GenericMeterReadSortMapType }
     * 
     * 
     */
    public List<GenericMeterReadSortMapType> getGenericMeterReadSortMap() {
        if (genericMeterReadSortMap == null) {
            genericMeterReadSortMap = new ArrayList<GenericMeterReadSortMapType>();
        }
        return this.genericMeterReadSortMap;
    }

    /**
     * Gets the value of the genericMeterReadFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGenericMeterReadFormat() {
        return genericMeterReadFormat;
    }

    /**
     * Sets the value of the genericMeterReadFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGenericMeterReadFormat(String value) {
        this.genericMeterReadFormat = value;
    }

}
