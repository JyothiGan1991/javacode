package com.coned.ls.repository;

import java.util.List;

import com.coned.ls.domain.MetersEventLoad;

/**
 * 
 * Interface for Meter Event load repository class.
 *
 */
public interface MetersEventLoadRepository {

	List<MetersEventLoad> findAll();
}
