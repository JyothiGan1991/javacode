package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coned.model.RejectEventList;

@Repository
public interface RejectEventListRepository extends JpaRepository<RejectEventList, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
}