
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WeekdayEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WeekdayEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="WEEKDAY_SUNDAY"/>
 *     &lt;enumeration value="WEEKDAY_MONDAY"/>
 *     &lt;enumeration value="WEEKDAY_TUESDAY"/>
 *     &lt;enumeration value="WEEKDAY_WEDNESDAY"/>
 *     &lt;enumeration value="WEEKDAY_THURSDAY"/>
 *     &lt;enumeration value="WEEKDAY_FRIDAY"/>
 *     &lt;enumeration value="WEEKDAY_SATURDAY"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WeekdayEnumeration")
@XmlEnum
public enum WeekdayEnumeration {

    WEEKDAY_SUNDAY("WEEKDAY_SUNDAY"),
    WEEKDAY_MONDAY("WEEKDAY_MONDAY"),
    WEEKDAY_TUESDAY("WEEKDAY_TUESDAY"),
    WEEKDAY_WEDNESDAY("WEEKDAY_WEDNESDAY"),
    WEEKDAY_THURSDAY("WEEKDAY_THURSDAY"),
    WEEKDAY_FRIDAY("WEEKDAY_FRIDAY"),
    WEEKDAY_SATURDAY("WEEKDAY_SATURDAY"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    WeekdayEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WeekdayEnumeration fromValue(String v) {
        for (WeekdayEnumeration c: WeekdayEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
