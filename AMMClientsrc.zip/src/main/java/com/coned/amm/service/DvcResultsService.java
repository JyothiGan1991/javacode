package com.coned.amm.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coned.amm.config.AppConfig;

import deviceresults_ws.DeviceResultsPortType;
import deviceresults_ws.ErrorCodeFault;
import deviceresults_ws.GetRemoteProvisioningResultsByJobIDType;
import deviceresults_ws.RemoteProvisioningByJobSearchParametersType;
import deviceresults_ws.RemoteProvisioningResultsType;

@Service
public class DvcResultsService {
	private static final Logger logger = LoggerFactory.getLogger(JMService.class);
	// private static final String DR_URL =
	// "https://mt.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/DeviceResultsPort";

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private DeviceResultsPortType deviceResultsService;

	public Optional<Object> getSwitchStatusResults(long jobId) {
		GetRemoteProvisioningResultsByJobIDType rprj = new GetRemoteProvisioningResultsByJobIDType();
		RemoteProvisioningByJobSearchParametersType searchParam = new RemoteProvisioningByJobSearchParametersType();
		searchParam.setJobID(jobId);
		rprj.setSearchParameters(searchParam);
		rprj.setNumberRows(1);

		//DeviceResultsPortType drp = deviceResultsService();
		try {
			 RemoteProvisioningResultsType response;
			if (this.deviceResultsService != null) {
				response = this.deviceResultsService.getRemoteProvisioningResultsByJobID(rprj);
			} else {
				response = this.appConfig.deviceResultsService().getRemoteProvisioningResultsByJobID(rprj);
			}

			//RemoteProvisioningResultsType response = drp.getRemoteProvisioningResultsByJobID(rprj);
			logger.info("Switch results for Job id[" + jobId + "]: " + response);
		/*	RemoteProvisioningResultType rprt = response.getRemoteProvisioningResult().get(0);
			ProvisioningCommandStatusEnumeration statusEnum = rprt.getProvisioningCommandStatus().getName();
			logger.info("Provisioning Command Status " + statusEnum);
			logger.info("Meter Connection Status" + rprt.getMeterConnectionStatus().getName());*/

			return Optional.of(response);
			/*
			 * if (statusEnum.equals(ProvisioningCommandStatusEnumeration.GMI_RSM_SUCCESS))
			 * // save the status to the table return Optional.of(statusEnum); else { // Re-
			 * Try save the status to the table }
			 */

		} catch (ErrorCodeFault errorCodeFault) {
			logger.error("Error response from AMM for Switch Status results operation; " + errorCodeFault);
			return Optional.of(errorCodeFault);
		}
	}

	/*private DeviceResultsPortType deviceResultsService() {
		DeviceResultsService drs = new DeviceResultsService();
		DeviceResultsPortType drp = drs.getDeviceResults();

		((BindingProvider) drp).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				config.getDeviceResultsUri());
		((BindingProvider) drp).getRequestContext().put(BindingProvider.USERNAME_PROPERTY, config.getUsername());
		((BindingProvider) drp).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, config.getPassword());
		return drp;
	}*/
}
