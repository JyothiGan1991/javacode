
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddRemoteProvisioningJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddRemoteProvisioningJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JobInfo" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}JobInfoType"/&gt;
 *         &lt;element name="RemoteProvisioningJob" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}RemoteProvisioningJobType"/&gt;
 *         &lt;element name="Schedule" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ScheduleChoiceType"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="AutoActivate" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddRemoteProvisioningJobType", propOrder = {
    "jobInfo",
    "remoteProvisioningJob",
    "schedule"
})
@XmlSeeAlso({
    EditRemoteProvisioningJobType.class
})
public class AddRemoteProvisioningJobType {

    @XmlElement(name = "JobInfo", required = true)
    protected JobInfoType jobInfo;
    @XmlElement(name = "RemoteProvisioningJob", required = true)
    protected RemoteProvisioningJobType remoteProvisioningJob;
    @XmlElement(name = "Schedule", required = true)
    protected ScheduleChoiceType schedule;
    @XmlAttribute(name = "AutoActivate")
    protected Boolean autoActivate;

    /**
     * Gets the value of the jobInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JobInfoType }
     *     
     */
    public JobInfoType getJobInfo() {
        return jobInfo;
    }

    /**
     * Sets the value of the jobInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JobInfoType }
     *     
     */
    public void setJobInfo(JobInfoType value) {
        this.jobInfo = value;
    }

    /**
     * Gets the value of the remoteProvisioningJob property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningJobType }
     *     
     */
    public RemoteProvisioningJobType getRemoteProvisioningJob() {
        return remoteProvisioningJob;
    }

    /**
     * Sets the value of the remoteProvisioningJob property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningJobType }
     *     
     */
    public void setRemoteProvisioningJob(RemoteProvisioningJobType value) {
        this.remoteProvisioningJob = value;
    }

    /**
     * Gets the value of the schedule property.
     * 
     * @return
     *     possible object is
     *     {@link ScheduleChoiceType }
     *     
     */
    public ScheduleChoiceType getSchedule() {
        return schedule;
    }

    /**
     * Sets the value of the schedule property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScheduleChoiceType }
     *     
     */
    public void setSchedule(ScheduleChoiceType value) {
        this.schedule = value;
    }

    /**
     * Gets the value of the autoActivate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isAutoActivate() {
        if (autoActivate == null) {
            return false;
        } else {
            return autoActivate;
        }
    }

    /**
     * Sets the value of the autoActivate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAutoActivate(Boolean value) {
        this.autoActivate = value;
    }

}
