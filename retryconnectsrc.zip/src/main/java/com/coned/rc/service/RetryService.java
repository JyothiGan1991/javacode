package com.coned.rc.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.coned.rc.beans.Event;
import com.coned.rc.beans.Meter;
import com.coned.rc.dao.RetryDaoImpl;

@Service
public class RetryService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${time_zone}")
	private String timeZone;

	@Value("${retry_max_cnt}")
	private int retryCnt;

	@Value("${retry_timeout_baselimit}")
	private int retryBaseLimit;

	@Value("${retry_timeout_min}")
	private int retryMinTime;

	@Value("${retry_timeout_max}")
	private int retryMaxTime;

	@Value("${aocc_register_url}")
	private String uri;

	@Autowired
	protected RetryDaoImpl dao;

	/**
	 * Fetch events in the past 10 days, calculate the timeouts and mark the events
	 * for retry based on timeout
	 * 
	 * @return the collection of Events
	 **/
	public Collection<Event> calculateTimeouts() {
		try {
			List<Event> eventList = dao.getEvents();

			if (eventList != null && !eventList.isEmpty()) {
				logger.debug("Event List {}", eventList);
				logger.info("Event List size {}", eventList.size());

				List<BigDecimal> ids = eventList.stream().map(Event::getRequestId).collect(Collectors.toList());
				logger.info("Request id List {}", ids);

				Map<BigDecimal, Integer> meterCountmap = dao.getMeterCount(ids);

				if (meterCountmap != null && !meterCountmap.isEmpty()) {
					logger.debug(" Meter count map  [" + meterCountmap + "]");

					for (Event event : eventList) {

						Integer count = meterCountmap.get(event.getRequestId());

						event.setMeterCount(count);

						/**
						 * If meter count >5000, set the timeout to 10 mins, otherwise set it to 5 mins
						 **/

						int timeOutInMins = count > retryBaseLimit ? retryMaxTime : retryMinTime;
						ZonedDateTime expTime = event.getEventTime()
								.plus(Duration.of(timeOutInMins, ChronoUnit.MINUTES));

						event.setTimeout(timeOutInMins);
						event.setExpireTime(expTime);

						ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of(timeZone));
						logger.debug("current time {}, expire time {}, compare {}", currentTime, expTime,
								currentTime.isAfter(expTime));

						event.setRetry(currentTime.isAfter(expTime) ? true : false);
					}
				}
				logger.debug("Event List after populating the event time and the meter count {}", eventList);
				return eventList;

			}
		} catch (Exception e) {
			logger.error("Error fetching the events and calculating the time outs", e);
		}
		return Collections.emptyList();

	}

	/**
	 * Fetch the list of failed meters associated to the events marked for retry.
	 * 
	 * @param retryEventList the list of retry Events
	 * @param restTemplate the rest template
	 * @return the list of events
	 **/
	public List<Event> getFailedMeters(List<Event> retryEventList, RestTemplate restTemplate) {
		try {

			if (retryEventList != null && !retryEventList.isEmpty()) {
				logger.debug("Event List {}", retryEventList);
				logger.info("Event List size {}", retryEventList.size());

				List<BigDecimal> ids = retryEventList.stream().map(Event::getRequestId).collect(Collectors.toList());
				logger.info("Request id List {}", ids);

				List<Meter> failedMeterList = dao.getFailedMeters(ids);
				logger.info("Failed Meters {}", failedMeterList);

				if (failedMeterList != null && !failedMeterList.isEmpty()) {
					Map<BigDecimal, List<Meter>> temp = failedMeterList.stream()
							.collect(Collectors.groupingBy(Meter::getRequestId));
					logger.debug("Failed Meter map{}", temp);

					for (Event event : retryEventList) {
						if (temp.get(event.getRequestId()) != null) {
							List<Meter> tempList = temp.get(event.getRequestId());
							List<String> mList = tempList.stream().map(Meter::getMeter).collect(Collectors.toList());
							event.setMeterList(mList);
						}
					}
					logger.info("Failed events list size is [{}], after setting the Failed meters in the main object",
							retryEventList.size());
				}

				/** remove the event with null meter list **/
				List<Event> finalList = retryEventList.stream().filter(d -> d.getMeterList() != null)
						.collect(Collectors.toList());
				logger.info("Failed events list size is [{}], after excluding the events with empty meter list ",
						finalList.size());
				logger.debug("Failed events list [{}], after excluding the events with empty meter list ", finalList);

				// make api call
				retryEvents(finalList, restTemplate);

			}
		} catch (Exception e) {
			logger.error("Error fetching the failed meters", e);
		}
		return Collections.emptyList();

	}

	/**
	 * Traverse the list of retry events, Verify the retry count of each event and
	 * push them for disconnect retry.
	 * 
	 * @param retryEventList the list of retry Events
	 * @param restTemplate the rest template
	 **/
	protected void retryEvents(List<Event> retryEventList, RestTemplate restTemplate) {
		try {
			if (retryEventList != null && !retryEventList.isEmpty()) {
				for (Event req : retryEventList) {
					try {
						// Get retry count
						int count = dao.getRetryCount(req.getEventName(), req.getSubEventName(), req.getBoro());

						if (count <= retryCnt) {
							persisteRetry(restTemplate, req);
						} else {
							logger.warn("Retry limit reached for event {} and boro {}", req.getEventName(),
									req.getBoro());
						}
					} catch (Exception e) {
						logger.error("Error saving the Event {}", req);
						logger.error("" + e);
					}
				}

			}
		} catch (Exception e) {
			logger.error("Error pushing the events for retry", e);
		}
	}

	private void persisteRetry(RestTemplate restTemplate, Event req) {
		/**
		 * persist the status of the event, no of retries and timeouts to status table
		 **/
		int rows = dao.saveRetry(req);

		if (rows == 1) {
			logger.info("Successfully inserted [" + rows
					+ "] records to AMI_LOAD_SHEDDING.LSB_CONN_RETRY table.");

			try {

				logger.info("Before invoking the post request for Event {} ", req);
				// rest api call
				ResponseEntity<String> result = restTemplate.postForEntity(uri, req, String.class);
				logger.info(" API response : " + result);

				if (result != null && result.getStatusCode() == HttpStatus.CREATED) {
					logger.info(
							"The event is registered SUCCESSFULLY for connect retry with status {} ",
							result);
					// Update the entry
					dao.updateRetry(req, "C");

				} else {
					logger.info("The event FAILED to register for connect retry with status {} ",
							result);
					// Update the entry
					dao.updateRetry(req, "F");
				}
			} catch (Exception e) {
				logger.error("Error invoking the post request for Event {}", req);
				logger.error("" + e);
				// Update the entry
				dao.updateRetry(req, "F");
			}
		}
	}
}