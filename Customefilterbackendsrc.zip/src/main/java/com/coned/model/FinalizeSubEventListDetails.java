package com.coned.model;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_finalize_sub_event_list_det", schema = "AMI_LOAD_SHEDDING")
@IdClass(FinalizeSubEventId.class)
public class FinalizeSubEventListDetails {

	@Id
	@JsonIgnore
	@Column(name = "finalized_event_id")
	private Long id;

	@JsonIgnore
	@Column(name = "event_name")
	private String eventName;

	@Id
	@Column(name = "sub_event_name")
	private String subEventName;

	@JsonIgnore
	@Column(name = "boro_muni")
	private String borough;

	@Column(name = "sub_event_time")
	private LocalDateTime subEventTime;

	@Column(name = "count_of_meter")
	private Long numberOfFinalizedMeters;

	public FinalizeSubEventListDetails() {

	}

	public FinalizeSubEventListDetails(Long id, String eventName, String subEventName, String borough,
			LocalDateTime subEventTime) {

		this.eventName = eventName;
		this.subEventName = subEventName;
		this.borough = borough;
		this.subEventTime = subEventTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEventName() {
		return eventName;
	}

	public Long getNumberOfFinalizedMeters() {
		return numberOfFinalizedMeters;
	}

	public void setNumberOfFinalizedMeters(Long numberOfFinalizedMeters) {
		this.numberOfFinalizedMeters = numberOfFinalizedMeters;
	}

	public void setEventName(String eventname) {
		this.eventName = eventname;
	}

	public String getSubEventName() {
		return subEventName;
	}

	public void setSubEventName(String subeventname) {
		this.subEventName = subeventname;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	public LocalDateTime getSubEventTime() {
		return subEventTime;
	}

	public void setSubEventTime(LocalDateTime subEventTime) {
		this.subEventTime = subEventTime;
	}

	@Override
	public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", subEventName=" + subEventName + ", subEventTime=" + subEventTime + "]";
//		return "FinalizedSubEvent [id=" + id + ", eventName=" + eventName + ", subEventName=" + subEventName + "]";
	}
}
