package com.coned.ls.domain;

public class MeterEventLoadIdAndDemand {

	private long meterEventLoadId;		
	private String demand;
	
	public long getMeterEventLoadId() {
		return meterEventLoadId;
	}
	public void setMeterEventLoadId(long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}
	public String getDemand() {
		return demand;
	}
	public void setDemand(String demand) {
		this.demand = demand;
	}
	
	@Override
	public String toString() {
		return "MeterEventLoadIdAndDemand [meterEventLoadId=" + meterEventLoadId + ", demand=" + demand + "]";
	}
}
