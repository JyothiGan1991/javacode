
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericMeterReadSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericMeterReadSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="MeterReadTime"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "GenericMeterReadSortColumnEnumeration")
@XmlEnum
public enum GenericMeterReadSortColumnEnumeration {

    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("MeterReadTime")
    METER_READ_TIME("MeterReadTime");
    private final String value;

    GenericMeterReadSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static GenericMeterReadSortColumnEnumeration fromValue(String v) {
        for (GenericMeterReadSortColumnEnumeration c: GenericMeterReadSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
