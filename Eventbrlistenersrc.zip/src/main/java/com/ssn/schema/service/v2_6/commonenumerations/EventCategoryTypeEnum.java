
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EventCategoryTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="EventCategoryTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EVENT_CAT_METER_READ"/>
 *     &lt;enumeration value="EVENT_CAT_METER_COMM"/>
 *     &lt;enumeration value="EVENT_CAT_DEVICE_PING"/>
 *     &lt;enumeration value="EVENT_CAT_DEVICE_CONFIG"/>
 *     &lt;enumeration value="EVENT_CAT_NIC_EVENT"/>
 *     &lt;enumeration value="EVENT_CAT_METER_EVENT"/>
 *     &lt;enumeration value="EVENT_CAT_UIQ_PROCESS"/>
 *     &lt;enumeration value="EVENT_CAT_DEVICE_REG"/>
 *     &lt;enumeration value="EVENT_CAT_IMU_EVENT"/>
 *     &lt;enumeration value="EVENT_CAT_UIQ_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_GATEWAY_STATUS"/>
 *     &lt;enumeration value="EVENT_CAT_JOB"/>
 *     &lt;enumeration value="EVENT_CAT_DBMS"/>
 *     &lt;enumeration value="EVENT_CAT_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_BILLING_CYCLE_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_DEVICE_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_LOCATION_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_ROUTE_IMPORT"/>
 *     &lt;enumeration value="EVENT_CAT_DEVICE_ROUTE"/>
 *     &lt;enumeration value="EVENT_CAT_EXPORT"/>
 *     &lt;enumeration value="EVENT_CAT_REMOTE_SIGNALING"/>
 *     &lt;enumeration value="EVENT_CAT_ZIGBEE_METER_EVENT"/>
 *     &lt;enumeration value="EVENT_CAT_ITRON_IMU_EVENT"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "EventCategoryTypeEnum")
@XmlEnum
public enum EventCategoryTypeEnum {

    EVENT_CAT_METER_READ("EVENT_CAT_METER_READ"),
    EVENT_CAT_METER_COMM("EVENT_CAT_METER_COMM"),
    EVENT_CAT_DEVICE_PING("EVENT_CAT_DEVICE_PING"),
    EVENT_CAT_DEVICE_CONFIG("EVENT_CAT_DEVICE_CONFIG"),
    EVENT_CAT_NIC_EVENT("EVENT_CAT_NIC_EVENT"),
    EVENT_CAT_METER_EVENT("EVENT_CAT_METER_EVENT"),
    EVENT_CAT_UIQ_PROCESS("EVENT_CAT_UIQ_PROCESS"),
    EVENT_CAT_DEVICE_REG("EVENT_CAT_DEVICE_REG"),
    EVENT_CAT_IMU_EVENT("EVENT_CAT_IMU_EVENT"),
    EVENT_CAT_UIQ_IMPORT("EVENT_CAT_UIQ_IMPORT"),
    EVENT_CAT_GATEWAY_STATUS("EVENT_CAT_GATEWAY_STATUS"),
    EVENT_CAT_JOB("EVENT_CAT_JOB"),
    EVENT_CAT_DBMS("EVENT_CAT_DBMS"),
    EVENT_CAT_IMPORT("EVENT_CAT_IMPORT"),
    EVENT_CAT_BILLING_CYCLE_IMPORT("EVENT_CAT_BILLING_CYCLE_IMPORT"),
    EVENT_CAT_DEVICE_IMPORT("EVENT_CAT_DEVICE_IMPORT"),
    EVENT_CAT_LOCATION_IMPORT("EVENT_CAT_LOCATION_IMPORT"),
    EVENT_CAT_ROUTE_IMPORT("EVENT_CAT_ROUTE_IMPORT"),
    EVENT_CAT_DEVICE_ROUTE("EVENT_CAT_DEVICE_ROUTE"),
    EVENT_CAT_EXPORT("EVENT_CAT_EXPORT"),
    EVENT_CAT_REMOTE_SIGNALING("EVENT_CAT_REMOTE_SIGNALING"),
    EVENT_CAT_ZIGBEE_METER_EVENT("EVENT_CAT_ZIGBEE_METER_EVENT"),
    EVENT_CAT_ITRON_IMU_EVENT("EVENT_CAT_ITRON_IMU_EVENT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    EventCategoryTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EventCategoryTypeEnum fromValue(String v) {
        for (EventCategoryTypeEnum c: EventCategoryTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
