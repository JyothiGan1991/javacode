
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AppLevelDevicePingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AppLevelDevicePingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="DeviceGroupID" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DeviceSearchKey" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="NumberPings" type="{http://www.w3.org/2001/XMLSchema}int" default="1" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AppLevelDevicePingType", propOrder = {
    "deviceGroupID",
    "deviceMacID",
    "deviceSearchKey"
})
public class AppLevelDevicePingType {

    @XmlElement(name = "DeviceGroupID", type = Long.class)
    protected List<Long> deviceGroupID;
    @XmlElement(name = "DeviceMacID")
    protected List<String> deviceMacID;
    @XmlElement(name = "DeviceSearchKey", type = Long.class)
    protected List<Long> deviceSearchKey;
    @XmlAttribute(name = "NumberPings")
    protected Integer numberPings;

    /**
     * Gets the value of the deviceGroupID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceGroupID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceGroupID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceGroupID() {
        if (deviceGroupID == null) {
            deviceGroupID = new ArrayList<Long>();
        }
        return this.deviceGroupID;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the deviceSearchKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceSearchKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceSearchKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceSearchKey() {
        if (deviceSearchKey == null) {
            deviceSearchKey = new ArrayList<Long>();
        }
        return this.deviceSearchKey;
    }

    /**
     * Gets the value of the numberPings property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getNumberPings() {
        if (numberPings == null) {
            return  1;
        } else {
            return numberPings;
        }
    }

    /**
     * Sets the value of the numberPings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberPings(Integer value) {
        this.numberPings = value;
    }

}
