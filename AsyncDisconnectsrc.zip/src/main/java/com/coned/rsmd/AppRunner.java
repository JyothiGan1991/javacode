package com.coned.rsmd;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.coned.rsmd.domain.Meter;
import com.coned.rsmd.service.DisconnectService;
import com.coned.rsmd.service.Task;

@Component
public class AppRunner implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

	@Value("${thread_pool_size}")
	private int poolSize;

	@Value("${meter_chunk_size}")
	private int chunkSize;

	@Value("${thread_termination}")
	private long duration;

	@Value("${amm_disconnect_meter}")
	private String disconnect_meter_url;

	@Autowired
	private DisconnectService disconnService;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public void run(String... args) throws Exception {
		while (true) {
			try {
				executable();
			} catch (Exception e) {
				logger.error(" ", e);
			}
		}
	}

	/**
	 * Fetch the meters that need to be disconnected. Invoke the RSM disconnect
	 * operation and capture the job id.	 * 
	 */
	private void executable() {
		try {
			List<Meter> disconMetersList = disconnService.pendingMeters();

			if (disconMetersList.size() > 0) {

				logger.info("Meter List size {}", disconMetersList.size());

				// Split the meter list into sublist based on the pool size
				Collection<List<Meter>> groups = disconnService.splitListBySize(disconMetersList, chunkSize);
				logger.info("Chunk List size {}", groups.size());

				List<Future<Meter>> groupJobidList = new ArrayList<Future<Meter>>();

				ExecutorService threadPool = Executors.newFixedThreadPool(poolSize);
				logger.info("Executor Service is created with thread pool of size {}", poolSize);

				// Traverse through the group of sublist
				for (List<Meter> group : groups) {
					long start = System.currentTimeMillis();
					try {
						// submit a call for each element separately
						groupJobidList.addAll(executeWithCallable(threadPool, group));
						// Print elapsed time
						logger.info("Elapsed time to disconnect meter list of size {} was {} millis", group.size(),
								System.currentTimeMillis() - start);

					} catch (InterruptedException e) {
						logger.error("Error executing the threads in parallel;", e);
					}

				}
				// Shutdown the Executor Service
				awaitTerminationAfterShutdown(threadPool);

				if (groupJobidList.size() > 0) {
					List<Meter> jobIdList = groupJobidList.stream().map(g -> {
						try {
							return g.get();
						} catch (InterruptedException | ExecutionException e1) {
							logger.error("", e1);
						}
						return null;
					}).collect(Collectors.toList());

					logger.debug("Job Id List size : " + jobIdList);

					logger.info("Job Id List size before removing null or empty objects: " + jobIdList.size());
					jobIdList.removeIf(Objects::isNull);
					logger.info("Job Id List size after removing null or empty objects: " + jobIdList.size());

					if (jobIdList.size() > 0) {
						try {
							disconnService.processJobs(jobIdList);
						} catch (Exception e) {
							logger.error("Error saving the meters to the respective tables; ", e);
						}
					}
				}
			} else {
				disconnService.processMetersWithNullMacAddr();
			}
		} catch (Exception e) {
			logger.error("Error processing the meters ", e);
		}
	}

	/**
	 * @param threadPool           the executor service
	 * @param disconnectMetersList the disconnect meter list
	 * @return the list of future meter objects
	 * @throws InterruptedException
	 */
	private List<Future<Meter>> executeWithCallable(ExecutorService threadPool, List<Meter> disconnectMetersList)
			throws InterruptedException {
		// First, create a list with all tasks we want to execute in parallel
		List<Task> taskList = new ArrayList<>(disconnectMetersList.size());

		for (Meter m : disconnectMetersList) {
			Task task = new Task(m, disconnect_meter_url, restTemplate);
			taskList.add(task);
		}

		// Execute all tasks and get reference to Future objects
		List<Future<Meter>> jobIdList = null;

		// call invokeAll to execute all tasks and wait for them to complete
		jobIdList = threadPool.invokeAll(taskList);

		// executorService.shutdown();
		return jobIdList;
	}

	/**
	 * shutdown the executor service
	 * 
	 * @param threadPool
	 */
	public void awaitTerminationAfterShutdown(ExecutorService threadPool) {
		threadPool.shutdown();
		logger.info("Gracefully shutdown the ExecutorService. ");
		try {
			if (!threadPool.awaitTermination(duration, TimeUnit.SECONDS)) {
				threadPool.shutdownNow();
			}
		} catch (InterruptedException ex) {
			threadPool.shutdownNow();
			Thread.currentThread().interrupt();
		}
	}
}
