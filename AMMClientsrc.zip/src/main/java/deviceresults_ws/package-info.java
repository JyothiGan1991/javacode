@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.5:DeviceResults.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package deviceresults_ws;
