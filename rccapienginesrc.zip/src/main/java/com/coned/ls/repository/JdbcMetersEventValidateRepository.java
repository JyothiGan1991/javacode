package com.coned.ls.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.mapper.NewEventListRowMapper;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for RCC Disconnect.
 *
 */
@Repository
public class JdbcMetersEventValidateRepository  implements MeterEventValidateRepository{

	private static final Logger LOGGER = LogManager.getLogger(JdbcMetersEventValidateRepository.class);
	
	@Autowired Environment environment; 
	 
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	@Autowired
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	
	@Autowired
	@Qualifier("starJdbcTemplate")
	protected JdbcTemplate starJdbcTemplate;
	
	@Autowired
	@Qualifier("oracleCommonJdbcTemplate")
	protected JdbcTemplate oracleCommonJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;

    /*
     * Method to read new events from the VCAP.
     * 
     * @Param borough    				  String
     * @Param eventName  				  String
     * @Param pageNumber 				  int
     * @Param batchSize  				  int
     * @Param fromDate   				  String
     * @Param toDate     				  String
     * @Param meterValidateResponseMapper MeterValidateResponseMapper
     * 
     * @return 				  	 		  MeterValidateResponseMapper 
     *                         
     */
	private MeterValidateResponseMapper getNewEventFromVCAP(final String borough, final String eventName,final int pageNumber, final int batchSize,final String fromDate, final String toDate, MeterValidateResponseMapper meterValidateResponseMapper) throws VcapRecordNotFoundException, MeterValidateException{
		
		int begin  = (pageNumber-1)*batchSize; 

		List<MeterEventLoad> newEventList = getMeterEventLoad(borough, eventName, pageNumber, batchSize, fromDate, toDate);
		if(!newEventList.isEmpty()){
			long processStartTime = DateUtils.processStartTime();
			
			String totalCountQuery = "SELECT COUNT(mel.Meter) FROM ami_meters_event_load mel WHERE mel.Boro = ? AND mel.EventName = ? AND mel.InsertTime >= ? and mel.InsertTime < ?";
			Integer totalCount = (Integer)sqlServerJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName, fromDate, toDate}, Integer.class);
			
			LOGGER.info(String.format("LogWriter ----> VCAP Meter Count : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
			
			Integer totalCountInt = 0;
			if(null!= totalCount){
				totalCountInt = Integer.valueOf(totalCount.toString());
			}
			
			meterValidateResponseMapper.setTotalRecord(totalCountInt);
			meterValidateResponseMapper.setMeterEventLoads(newEventList);
			meterValidateResponseMapper.setRemainingRow(getRemainingRowToBeFetch(totalCountInt,newEventList.size(),begin));
		}else{
			throw new VcapRecordNotFoundException("No record found with Borough "+borough+" and Event name "+eventName+" in VCAP database");
		}
		
		return meterValidateResponseMapper;
	}
	
    /*
     * Method to read data from VCAP.
     * 
     * @Param borough    				  String
     * @Param eventName  				  String
     * @Param pageNumber 				  int
     * @Param batchSize  				  int
     * @Param fromDate   				  String
     * @Param toDate     				  String
     * @Param meterValidateResponseMapper MeterValidateResponseMapper
     * 
     * @return 				  	 		  MeterValidateResponseMapper 
     *                         
     */
	private List<MeterEventLoad> getMeterEventLoad(final String borough, final String eventName,final int pageNumber, final int batchSize, String fromDate, final String toDate) {
		
		long processStartTime = DateUtils.processStartTime();
		int begin  = (pageNumber-1)*batchSize; 
		
        Calendar cal = Calendar.getInstance();
        DateFormat newDateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00.000");
        cal.setTime(new Date());
        cal.add(Calendar.DATE, - 180);
        Date todate1 = cal.getTime();    
        fromDate = newDateFormat.format(todate1);

        String query = "SELECT mel.Account,mel.Boro,mel.BuildingNum,mel.ZipCode,mel.CustomerName,mel.Demand,mel.EventName,mel.Feeder,mel.FeederNetworkAbbr,mel.InsertTime,mel.Meter,mel.MeterType,mel.Network,mel.NetworkAbbr,mel.Phone1,mel.Phone2,mel.SDPID,mel.ServiceAddress,mel.Xfr,mel.StructName FROM ami_meters_event_load mel WHERE mel.Boro = ? AND mel.EventName = ? AND mel.InsertTime >= ? and mel.InsertTime < ?  Order By mel.Boro, mel.EventName, mel.Meter OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
		List<MeterEventLoad> meterEventLoadList = sqlServerJdbcTemplate.query(query, new Object[]{borough, eventName,fromDate,toDate,begin,batchSize},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();

				meterEventLoad.setAccountNumber(rs.getString("Account"));
				meterEventLoad.setBorough(rs.getString("Boro"));
				meterEventLoad.setBuildingNumber(rs.getString("BuildingNum"));
				meterEventLoad.setCustomerName(rs.getString("CustomerName"));
				meterEventLoad.setCustomerZipCode(rs.getString("ZipCode"));
				meterEventLoad.setDemand(rs.getString("Demand"));
				meterEventLoad.setEventName(rs.getString("EventName"));
				meterEventLoad.setFeeder(rs.getString("Feeder"));
				meterEventLoad.setFeederNetworkAbbr(rs.getString("FeederNetworkAbbr"));
				meterEventLoad.setVcapInsertDateTime(rs.getTimestamp("InsertTime"));
				meterEventLoad.setMeterNumber(rs.getString("Meter"));
				meterEventLoad.setMeterType(rs.getString("MeterType"));
				meterEventLoad.setNetwork(rs.getString("Network"));
				meterEventLoad.setNetworkAbbr(rs.getString("NetworkAbbr"));
				meterEventLoad.setPhone1(rs.getString("Phone1"));
				meterEventLoad.setPhone2(rs.getString("Phone2"));
				meterEventLoad.setSdpid(rs.getString("SDPID"));
				meterEventLoad.setServiceAddress(rs.getString("ServiceAddress"));
				meterEventLoad.setTransformer(rs.getString("Xfr"));
				meterEventLoad.setStructureName(rs.getString("StructName"));

				return meterEventLoad;
			}
        });
		LOGGER.info(String.format("LogWriter ----> VCAP Meter Data : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return meterEventLoadList;
	}

    /*
     * Method to read remaining row to fetch count from the database.
     * 
     * @Param totalCountInt    int
     * @Param newEventListSize int
     * @Param begin 		   int
     * 
     * @return 				   int 
     *                         
     */
	private int getRemainingRowToBeFetch(final int totalCountInt,	final int newEventListSize, final int begin) {
		int totalFetch = begin + newEventListSize;
		int remaining =  ( totalCountInt - totalFetch );
		return remaining = ( remaining > 0 ) ? remaining : 0; 
	}

    /*
     * Method to read valid meters details from LSDB.
     * 
     * @Param borough    				  String
     * @Param eventName  				  String
     * @Param pageNumber 				  int
     * @Param batchSize  				  int
     * @Param fromDate   				  String
     * @Param toDate     				  String
     * @Param meterValidateResponseMapper MeterValidateResponseMapper
     * 
     * @return 				  	 		  MeterValidateResponseMapper 
     *                         
     */
	private MeterValidateResponseMapper getValidateMeterEventList(final String borough, final String eventName,final int pageNumber, final int batchSize,  final String filterList, final String sortList){

		long processStartTime = DateUtils.processStartTime();
		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
		int begin  = (pageNumber-1)*batchSize+1; 
		int end  = pageNumber*batchSize;
		
		String query = "select * from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,vel.building_num,vel.service_address,vel.cust_zip_code,mel.meter_number,vel.account_number,mel.network,mel.FK_EVENT_STATUS,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.TRANSFORMER,mel.STRUCTURE from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? "+filterList+" "+sortList+") t1 where rownum<=?) where rn>=?";
		LOGGER.info("ValidateMeterEventList : "+query);
		List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName,end,begin},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setEventStatus(rs.getInt("FK_EVENT_STATUS"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
				meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
				return meterEventLoad;
			}
        });
		
		if(!meterEventLoadList.isEmpty()){
			meterValidateResponseMapper.setMeterEventLoads(meterEventLoadList);
			meterValidateResponseMapper.setBorough(borough);
			meterValidateResponseMapper.setEventName(eventName);
			meterValidateResponseMapper.setPageNumber(pageNumber);
			meterValidateResponseMapper.setPageSize(batchSize);
			meterValidateResponseMapper.setRecordOffsetRange("[ "+begin+"-"+end+" ]");
			MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
			meterValidateResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
			meterValidateResponseMapper.setNetwork(meterEventLoad.getNetwork());
			int totalCount = totalCount(borough, eventName);
			meterValidateResponseMapper.setTotalRecord(totalCount);
			int totalValidRecord = getValidTotalRecord(borough, eventName);
			meterValidateResponseMapper.setTotalValidRecord(totalValidRecord);
			meterValidateResponseMapper.setTotalKVA(getValidTotalKVA(borough, eventName, filterList));
			meterValidateResponseMapper.setValidResponse(true);

			if (null == filterList || filterList.equals("")) {
				meterValidateResponseMapper.setCountOfMeters(totalValidRecord);
			} else {
				String countQuery = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? "+filterList;
				Integer countOfMeters = (Integer)oracleJdbcTemplate.queryForObject(countQuery,  new Object[]{borough, eventName}, Integer.class);
				meterValidateResponseMapper.setCountOfMeters(countOfMeters);
				meterValidateResponseMapper.setMeterEventLoadIds(getMeterEventLoadIds(borough, eventName, filterList, sortList));
			}
		}
		
		LOGGER.info(String.format("LogWriter ----> Valid Meter Event List : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		
		return meterValidateResponseMapper;
	}

    /*
     * Method to read list of meter load id's from the LSDB.
     * 
     * @Param borough    String
     * @Param eventName  String
     * @Param filterList String
     * @Param sortList   String
     * 
     * @return 			 List<MeterEventLoadIdAndDemand> 
     *                         
     */
	private List<MeterEventLoadIdAndDemand> getMeterEventLoadIds(final String borough, final String eventName, final String filterList, final String sortList) {
		String query = "select mel.METER_EVENT_LOAD_ID, demand from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? "+filterList+" "+sortList;
		List<MeterEventLoadIdAndDemand> meterEventLoadIdList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName},new RowMapper<MeterEventLoadIdAndDemand>() {
			@Override
			public MeterEventLoadIdAndDemand mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoadIdAndDemand meterEventIdAndKva = new MeterEventLoadIdAndDemand();
				meterEventIdAndKva.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventIdAndKva.setDemand(rs.getString("demand"));
				return meterEventIdAndKva;
			}
        });
		
		return meterEventLoadIdList;
	}
	
    /*
     * Method to build filter and sort query.
     * 
     * @Param filterList    String
     * @Param sortList  	String
	 *
     * @return 			 	String 
     *                         
     */
	private String buildFilterAndOrderQuery(final String filterList, final String sortList) {
		StringBuffer filterAndOrderQuery = new StringBuffer("");
		
		if (!filterList.equals("null") && !filterList.equals("")) {
			String[] filterFields = filterList.split(",");

			for (String filterField : filterFields) {
				String[] filterFieldInfo = filterField.split(":");
				
				filterAndOrderQuery.append(" AND ");
				filterAndOrderQuery.append("mel." + getDatabaseFieldName(filterFieldInfo[0]));
				filterAndOrderQuery.append(" IN (");
				
				String[] filterFieldValues = filterFieldInfo[1].split("-");
				boolean isFirstFilterField = true;
				for (String filterFieldValue : filterFieldValues) {
					if (isFirstFilterField)
						isFirstFilterField = false;
					else
						filterAndOrderQuery.append(", ");
					
					filterAndOrderQuery.append("'");
					
					if (filterFieldInfo[0].equals("serviceAddress")) {
						filterAndOrderQuery.append(filterFieldValue.replaceAll("%20", " "));
					} else {
						filterAndOrderQuery.append(filterFieldValue);
					}
					
					filterAndOrderQuery.append("'");
				}
				filterAndOrderQuery.append(") ");
			}
		}
		
		if (!sortList.equals("null") && !sortList.equals("")) {
			filterAndOrderQuery.append(" ORDER BY ");
			
			String[] sortFields = sortList.split(",");
			boolean isFirstSortField = true;
			for (String sortField : sortFields) {
				String[] sortFieldInfo = sortField.split(":");
				
				if (isFirstSortField)
					isFirstSortField = false;
				else
					filterAndOrderQuery.append(", ");
				
				filterAndOrderQuery.append("mel." + getDatabaseFieldName(sortFieldInfo[0]));
				filterAndOrderQuery.append(" ");
				
				if (sortFieldInfo[1].startsWith("ASC"))
					filterAndOrderQuery.append("ASC");
				else 
					filterAndOrderQuery.append("DESC");
			}
		}
		
		return filterAndOrderQuery.toString();
	}

    /*
     * Method to check event is locked.
     * 
     * @Param borough   String
     * @Param eventName String
     * @Param adid  	String
	 *
     * @return 			MeterValidateResponseMapper
     *                         
     */
	public MeterValidateResponseMapper isEventLocked(String borough, final String eventName, final String adid) {
		
		long processStartTime = DateUtils.processStartTime();
		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Integer CountOfOperator = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
		
		String lockOperatorADID = "";
		if (CountOfOperator > 0) {
			String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
			
			lockOperatorADID = oracleJdbcTemplate.queryForObject(operatorADIDQuery,  new Object[]{borough, eventName}, String.class);
		
			if(!adid.equals(lockOperatorADID)) {
				CountOfOperator = 2;
			}
		} else {
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 7, OPERATOR_AD_ID = ? WHERE BORO_MUNI = ? AND EVENT_NAME = ?", new Object[]{adid, borough, eventName});
		}
		
		if(CountOfOperator == 2){
			meterValidateResponseMapper.setIsEventLocked(true);
			meterValidateResponseMapper.setMessage("This event is locked. User "+lockOperatorADID+" is currently working on this event.");
		}else {
			meterValidateResponseMapper.setIsEventLocked(false);
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI != ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{borough, adid});
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI = ? AND EVENT_NAME != ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{borough, eventName, adid});
		}
		
		LOGGER.info(String.format("LogWriter ----> Is Event Locked: %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return meterValidateResponseMapper;
    }
	
    /*
     * Method to check event is finalized.
     * 
     * @Param borough   String
     * @Param eventName String
	 *
     * @return 			MeterValidateResponseMapper
     *                         
     */
	public MeterValidateResponseMapper isEventFinalized(String borough, final String eventName) {
		
		long processStartTime = DateUtils.processStartTime();
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();

		String totalCountQuery = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_EVENT_LIST_DETAILS WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Integer countOfEvent = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);

		if (countOfEvent > 0) {
			meterValidateResponseMapper.setIsEventFinalized(true);
			meterValidateResponseMapper.setMessage("This event is already finalized.");	
		} else {
			meterValidateResponseMapper.setIsEventFinalized(false);
		}
		LOGGER.info(String.format("LogWriter ----> Is Event Finalized : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return meterValidateResponseMapper;
	}

    /*
     * Method to find total count of the event created for disconnect.
     * 
     * @Param borough   String
     * @Param eventName String
	 *
     * @return 			int
     *                         
     */
	private int totalCount(String borough, final String eventName) {
		String totalCountQuery = "SELECT bem.total_row_count FROM LS_BOROUGH_EVENT_MAPPING bem WHERE bem.boro_muni = ? AND bem.event_name = ?";
		return oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
    }

    /*
     * Method to find total valid record of the event created for disconnect.
     * 
     * @Param borough   String
     * @Param eventName String
	 *
     * @return 			int
     *                         
     */
	private int getValidTotalRecord(final String borough, final String eventName) {
		//String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ";
		long processStartTime = DateUtils.processStartTime();
		String query = "select count(vel.FK_METER_EVENT_LOAD_ID) from ls_validate_event_list vel where vel.boro_muni= ? and vel.event_name = ? ";
		Integer queryForObject = oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class);
		LOGGER.info(String.format("LogWriter ----> getValidTotalRecord : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return queryForObject;
    }
	
    /*
     * Method to find total KVA of the meters in the event created for disconnect.
     * 
     * @Param borough   		  String
     * @Param eventName 		  String
     * @Param filterAndOrderQuery String
	 *
     * @return 					  String
     *                         
     */
	private String getValidTotalKVA(final String borough, final String eventName, String filterAndOrderQuery) {
		long processStartTime = DateUtils.processStartTime();
		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? " + filterAndOrderQuery;
		String queryForObject = oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},String.class);
		LOGGER.info(String.format("LogWriter ----> getValidTotalKVA : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return queryForObject; 
    }
	
    /*
     * Method to search for a list of meters in the event created for disconnect.
     * 
     * @Param meterSearch MeterSearch
	 *
     * @return 			  MeterValidateResponseMapper
     *                         
     */
	public MeterValidateResponseMapper searchMeters(final MeterSearch meterSearch){
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		List<MeterEventLoad> meterEventLoadList = new ArrayList<MeterEventLoad>();
		
		Double selectedKVA = new Double(0);
		int countOfMeter = 0;
		String[] meterArry = meterSearch.getMeters().split(",");
		for (int bgn=0; bgn<meterArry.length; bgn+=900) {
	    	StringBuffer metersStr = new StringBuffer();
	    	boolean isFirst = true;
	    	int end = bgn+900 < meterArry.length ? bgn+900 : meterArry.length;
	    	for (int indx=bgn; indx<end; indx++) {
	    		if (isFirst) {
	    			metersStr.append(meterArry[indx]);
	    			isFirst = false;
	    		} else {
	    			metersStr.append(", " + meterArry[indx]);
	    		}
	    	}

			String query = "select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,vel.building_num,vel.service_address,vel.cust_zip_code,mel.meter_number,vel.account_number,mel.network,mel.FK_EVENT_STATUS,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME, mel.transformer, mel.structure from LS_METER_EVENT_LOAD mel INNER JOIN ls_validate_event_list vel ON vel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID where mel.boro_muni = ? and mel.event_name = ? and  mel.meter_number IN (" +  metersStr.toString() + ") ORDER BY mel.meter_number";

			LOGGER.info(String.format("Query for searchMeters - %s", query));

			List<MeterEventLoad> meterEventLoadLst = oracleJdbcTemplate.query(query, new Object[]{meterSearch.getBorough(), meterSearch.getEvent()},new RowMapper<MeterEventLoad>() {
				@Override
				public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
					MeterEventLoad meterEventLoad = new MeterEventLoad();
					meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
					meterEventLoad.setBorough(rs.getString("boro_muni"));
					meterEventLoad.setEventName(rs.getString("event_name"));
					meterEventLoad.setDemand(rs.getString("demand"));
					meterEventLoad.setFeeder(rs.getString("feeder"));
					meterEventLoad.setBuildingNumber(rs.getString("building_num"));
					meterEventLoad.setServiceAddress(rs.getString("service_address"));
					meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
					meterEventLoad.setMeterNumber(rs.getString("meter_number"));
					meterEventLoad.setAccountNumber(rs.getString("account_number"));
					meterEventLoad.setNetwork(rs.getString("network"));
					meterEventLoad.setEventStatus(rs.getInt("FK_EVENT_STATUS"));
					meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
					meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
					meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
					return meterEventLoad;
				}
	        });
			
			String totKva = getValidSearchedTotalKVA(meterSearch.getBorough(), meterSearch.getEvent(), metersStr.toString());
			if (totKva != null)
				selectedKVA += Double.parseDouble(totKva);
			
			countOfMeter += getCountOfMeters(meterSearch.getBorough(), meterSearch.getEvent(),  metersStr.toString());

			meterEventLoadList.addAll(meterEventLoadLst);
		}
		
		if(!meterEventLoadList.isEmpty()){
			meterValidateResponseMapper.setMeterEventLoads(meterEventLoadList);
			meterValidateResponseMapper.setValidResponse(true);
			meterValidateResponseMapper.setBorough(meterSearch.getBorough());
			meterValidateResponseMapper.setEventName(meterSearch.getEvent());
			meterValidateResponseMapper.setNetwork(meterEventLoadList.get(0).getNetwork());
			meterValidateResponseMapper.setInsertTime(meterEventLoadList.get(0).getVcapInsertTime());
			
			Integer totalCount = totalSearchCount(meterSearch.getBorough(), meterSearch.getEvent());
			meterValidateResponseMapper.setTotalRecord(totalCount.intValue());
			
			Integer totalValidRecord = getValidSearchTotalRecord(meterSearch.getBorough(), meterSearch.getEvent());
			meterValidateResponseMapper.setTotalValidRecord(totalValidRecord.intValue());
			meterValidateResponseMapper.setTotalKVA(Double.toString(selectedKVA));
			meterValidateResponseMapper.setCountOfMeters(countOfMeter);
		}

		return meterValidateResponseMapper;
	}

    /*
     * Method to load the data from VCAP to LSDB.
     * 
     * @Param borough   String
     * @Param eventName String
     * @Param fromDate  String
     * @Param toDate    String
     * @Param adid      String
	 *
     * @return 			boolean
     *                         
     */
	@Override
	public boolean pushMeterEventFromVcapToLS(final String borough, final String eventName, final String fromDate, final String toDate, final String adid) throws MeterValidateException, VcapRecordNotFoundException {
		long processStartTime = DateUtils.processStartTime();
		
		int loclBatchSize = 10000;
		int localPage = 1;
		boolean flag = true;
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setValidResponse(true);
		
		try{
			while(!verifyNewEventEntryInLS(borough, eventName)){
				meterValidateResponseMapper = getNewEventFromVCAP(borough, eventName,localPage, loclBatchSize,fromDate,toDate,meterValidateResponseMapper);

				if(null!=meterValidateResponseMapper && !meterValidateResponseMapper.getMeterEventLoads().isEmpty()){
					if(isInsertBoroughAndEventName(borough, eventName,meterValidateResponseMapper.getTotalRecord(), meterValidateResponseMapper.getMeterEventLoads().size(), meterValidateResponseMapper.getRemainingRow(), adid)){
						if(batchInsertMeterEventLoad(meterValidateResponseMapper.getMeterEventLoads(), loclBatchSize, adid) > 0){
							localPage = localPage+1;
						}
					}
				}
			}
		}catch(MeterValidateException ex){
			flag = false;
			LOGGER.error(ex.getMessage(), ex);
		}catch(Exception ex){
			flag = false;
			LOGGER.error(ex.getMessage(), ex);
		}
		LOGGER.info(String.format("LogWriter ----> pushMeterEventFromVcapToLS : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return flag;
	}
	
    /*
     * Method to load the data from VCAP to LSDB.
     * 
     * @Param meterEventLoadNewEvents List<MeterEventLoad>
     * @Param batchSize 			  int
     * @Param adid  				  String
	 *
     * @return 						  int
     *                         
     */
	public int batchInsertMeterEventLoad(List<MeterEventLoad> meterEventLoadNewEvents, int batchSize, String adid) {
		long processStartTime = DateUtils.processStartTime();
		int batchSizeResult = 0;
	
		try {
			oracleJdbcTemplate.batchUpdate("INSERT INTO LS_METER_EVENT_LOAD (METER_TYPE,DEMAND,BORO_MUNI,NETWORK,FEEDER,FEEDER_NETWORK_ABBR,SDPID,"
					+ "METER_NUMBER,ACCOUNT_NUMBER,CUSTOMER_NAME,PHONE1,CUST_ZIP_CODE,BUILDING_NUM,PHONE2,SERVICE_ADDRESS,"
					+ "EVENT_NAME,VCAP_INSERT_TIME,OPERATOR_AD_ID,TRANSFORMER,STRUCTURE,NETWORK_ABBR,FK_EVENT_STATUS,INSERT_TIME)  "
					+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
				new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						MeterEventLoad meterEventLoad = meterEventLoadNewEvents.get(i);
	                	ps.setString(1, meterEventLoad.getMeterType());
	                    ps.setString(2, meterEventLoad.getDemand());
	                    ps.setString(3, meterEventLoad.getBorough());
	                    ps.setString(4, meterEventLoad.getNetwork());
	                    ps.setString(5, meterEventLoad.getFeeder());
	                    ps.setString(6, meterEventLoad.getFeederNetworkAbbr());
	                    ps.setString(7, meterEventLoad.getSdpid());
	                    ps.setString(8, meterEventLoad.getMeterNumber());
	                    ps.setString(9, meterEventLoad.getAccountNumber());
	                    ps.setString(10, meterEventLoad.getCustomerName());
	                    ps.setString(11, meterEventLoad.getPhone1());
	                    ps.setString(12, meterEventLoad.getCustomerZipCode());
	                    ps.setString(13, meterEventLoad.getBuildingNumber());
	                    ps.setString(14, meterEventLoad.getPhone2());
	                    ps.setString(15, meterEventLoad.getServiceAddress());
	                    ps.setString(16, meterEventLoad.getEventName());
	                    ps.setDate(17, new java.sql.Date(meterEventLoad.getVcapInsertDateTime().getTime()));
	                    ps.setString(18, adid);
	                    ps.setString(19, meterEventLoad.getTransformer());
	                    ps.setString(20, meterEventLoad.getStructureName());ps.setString(21, meterEventLoad.getNetworkAbbr());
	                    ps.setInt(22, 5);ps.setDate(23, new java.sql.Date(new Date().getTime()));
	                }
					@Override
					public int getBatchSize() {
						return meterEventLoadNewEvents.size();
					}
				});
				
				batchSizeResult = batchSize;
				
				LOGGER.info(String.format("LogWriter ----> Insert Meter Event Load -1 : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
				
				return batchSizeResult;
		}catch(Exception sqlEx){
			batchSizeResult = 0;
			LOGGER.error("SQLException Ouured: "+sqlEx.toString());
		}

		LOGGER.info(String.format("LogWriter ----> Insert Meter Event Load -2 : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		
		
        return batchSizeResult;
    }

    /*
     * Method to insert or update borough event map table.
     * 
     * @Param borough       String
     * @Param eventName     String
     * @Param totalROwCount int
     * @Param nextFetchSize int
     * @Param remainingRow 	int
     * @Param adid  		String
	 *
     * @return 				int
     *                         
     */
	public boolean isInsertBoroughAndEventName(String borough, final String eventName,final int totalROwCount, final int nextFetchSize, final int remainingRow, final String adid) throws MeterValidateException {
		long processStartTime = DateUtils.processStartTime();
		
		boolean result = false;
		try{
			simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_INS_UDT_BORO_ENT_MAP").returningResultSet("SP_INS_UDT_BORO_ENT_MAP",new NewEventListRowMapper());
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("Borough", borough);
			inParamMap.put("Event", eventName);	
			inParamMap.put("OpeartorADID", adid);	
			inParamMap.put("TotalRowCount", totalROwCount);
			inParamMap.put("NextFetchSize", nextFetchSize);
			inParamMap.put("RemainingRowToBeFetch", remainingRow);
					
			SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
			result = true;
			
		}catch(Exception ex){
			throw new MeterValidateException();
		}
		LOGGER.info(String.format("LogWriter ----> Boro Event Mapping Insert/Update : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return result;
	}
	
    /*
     * Method to read the remaining count of the event from database.
     * 
     * @Param borough       String
     * @Param eventName     String
	 *
     * @return 				int
     *                         
     */
	private int getBoroughAndEventName(String borough, final String eventName) {
		 return oracleJdbcTemplate.queryForObject("SELECT COUNT(EVENT_NAME) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND REMAINING_ROW_COUNT = 0",  new Object[]{borough, eventName}, Integer.class);
    }
	
    /*
     * Method to check new event in the LSDB.
     * 
     * @Param borough       String
     * @Param eventName     String
	 *
     * @return 				boolean
     *                         
     */
	public boolean verifyNewEventEntryInLS(final String borough, final String eventName){
		long processStartTime = DateUtils.processStartTime();
		
		if(getBoroughAndEventName(borough, eventName)> 0){
			return true;
		}
		LOGGER.info(String.format("LogWriter ----> verifyNewEventEntryInLS : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return false;
	}
	
    /*
     * Method to read list of valid meters in LSDB created for event.
     * 
     * @Param borough       String
     * @Param eventName     String
     * @Param startRowIndex int
     * @Param batchSize     int
     * @Param filterList    String
     * @Param sortList      String
     * 
     * @return 				MeterValidateResponseMapper
     *                         
     */
	@Override
	public MeterValidateResponseMapper getValidateMeterList(final String borough, final String eventName, final int startRowIndex, final int batchSize, final String filterList, final String sortList) throws MeterValidateException {
		return getValidateMeterEventList(borough, eventName, startRowIndex, batchSize, filterList, sortList);
	}
	
    /*
     * Method to populate meter validate response.
     * 
     * @Param borough    String
     * @Param eventName  String
     * @Param pageNumber int
     * @Param batchSize  int
     * @Param fromDate   String
     * @Param toDate     String
     * 
     * @return 			 MeterValidateResponseMapper
     *                         
     */
	@Override
	public MeterValidateResponseMapper getValidateMeter(final String borough, final String eventName,int pageNumber, final int batchSize,final String fromDate, final String toDate)throws MeterValidateException,VcapRecordNotFoundException{
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setValidResponse(true);
		return meterValidateResponseMapper;
	}

    /*
     * Method to validate meters with Start Db.
     * 
     * @Param borough    String
     * @Param eventName  String
     * 
     * @return 			 boolean
     *                         
     */
	@Override
	@Transactional(rollbackFor = Exception.class, value="oracleCommonTx")
	public boolean validateMeterEventWithStar(String borough, String eventName) {
		long processStartTime = DateUtils.processStartTime();
		boolean flag = false;
		try{
			validateMeters(borough,eventName);
		}catch(Exception ex){
			flag = false;
			LOGGER.error(ex.getMessage(), ex);
		}
		LOGGER.info(String.format("LogWriter ----> Validate with Star and Insert in LSDB : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return flag;
	}

    /*
     * Method to validate meters with Start Db.
     * 
     * @Param borough    String
     * @Param eventName  String
     * 
     * @return 			 boolean
     *                         
     */	
	private boolean validateMeters(final String borough, final String eventName) {
		try{
			oracleCommonJdbcTemplate.execute("insert into AMI_LOAD_SHEDDING.ls_validate_event_list (FK_METER_EVENT_LOAD_ID,BORO_MUNI,EVENT_NAME,METER_NUMBER,ACCOUNT_NUMBER,BUILDING_NUM,CUSTOMER_NAME,CUST_ZIP_CODE,PHONE1,PHONE2,SERVICE_ADDRESS) select ls.meter_event_load_id,ls.boro_muni,ls.event_name,ls.meter_number,cust.cust_account_number,cust.cust_bill_addr_1,cust.cust_name,cust.cust_bill_postcode_1,cust.cust_home_phone,cust.customer_cell,cust.cust_bill_addr_3 || ' ' ||cust.cust_bill_Addr_4 as street from AMI_LOAD_SHEDDING.ls_meter_event_load ls, cesconed.cu_meters cu, cesconed.cu_customers cust, cesconed.cu_service_points sp, cesconed.cu_service_locations sl where ls.boro_muni = ? AND ls.event_name = ?  and cu.meter_id = sp.meter_id and sp.serv_loc_id= sl.serv_loc_id and cust.cust_id= sp.cust_id and (sl.serv_life_support = '0' and sl.serv_priority = '0') and ls.meter_number = cu.meter_no and cu.meter_amr_enabled='Y' and cu.death is null and sp.death is null and sl.death is null and cust.death is null ",(PreparedStatementCallback<Boolean>) ps -> {
	            ps.setString(1, borough);
	            ps.setString(2, eventName);
	            return ps.execute();
	        });
		}catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return false;               
	}
	
    /*
     * Method to find total count of the meters created for the event.
     * 
     * @Param borough    String
     * @Param eventName  String
     * 
     * @return 			 Integer
     *                         
     */	
	private Integer totalSearchCount(final String borough, final String eventName) {
		String totalCountQuery = "select count(*) from LS_METER_EVENT_LOAD mel where mel.boro_muni = ? and mel.event_name = ?";
		return oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
    }	

    /*
     * Method to find total count of valid meters created for the event.
     * 
     * @Param borough    String
     * @Param eventName  String
     * 
     * @return 			 Integer
     *                         
     */	
	private Integer getValidSearchTotalRecord(final String borough, final String eventName) {
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ?";
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class);
    }
	
    /*
     * Method to find total KVA of valid meters created for the event.
     * 
     * @Param borough    String
     * @Param eventName  String
     * @Param meters  	 String
     * 
     * @return 			 String
     *                         
     */	
	private String getValidSearchedTotalKVA(final String borough, final String eventName, String meters) {
		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and mel.meter_number IN (" +  meters + ") ";
		LOGGER.info(String.format("Query for getValidSearchedTotalKVA - %s", query));
		
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},String.class);
    }
	
    /*
     * Method to find count of the meters.
     * 
     * @Param borough    String
     * @Param eventName  String
     * @Param meters  	 String
     * 
     * @return 			 String
     *                         
     */	
	private Integer getCountOfMeters(final String borough, final String eventName, String meters) {
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and  mel.meter_number IN (" +  meters + ")";
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class);
    }
	
    /*
     * Method to find list of values for given field.
     * 
     * @Param borough    String
     * @Param eventName  String
     * @Param fieldName  String
     * 
     * @return 			 List<String>
     *                         
     */	
	@Override
	public List<String> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) throws IllegalArgumentException {
		
		LOGGER.info("fieldName : "+fieldName);
		String query = "";
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code"})
		        .collect(Collectors.toList());
		
		if(fieldsFromVEL.contains(fieldName))
				{
			query="select * from (select t1.* from (select distinct NVL(vel." + fieldName + ", 'No Data') " + fieldName + " from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ORDER BY " + fieldName + " ASC) t1)";
		}else{
			query = "select * from (select t1.* from (select distinct NVL(mel." + fieldName + ", 'No Data') " + fieldName + " from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ORDER BY " + fieldName + " ASC) t1)";
		}
		List<String> fieldValueList= new ArrayList<String>();
		try{
		fieldValueList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString(fieldName));
			}
        });	
		}
		catch(Exception e){
			LOGGER.error("error while fetching the filtering results for some event: ", e);
		}
		LOGGER.info("Filtering field results:, "+ fieldValueList);
		return fieldValueList;
	}
	
    /*
     * Method to find name of the database field.
	 *
     * @Param fieldName  String
     * 
     * @return 			 String
     *                         
     */	
	private String getDatabaseFieldName(String fieldName) {
		String dbFieldName = "";
		switch(fieldName) {
			case "meterEventLoadId" :
				dbFieldName = "METER_EVENT_LOAD_ID";
				break;
			case "borough" :
				dbFieldName = "boro_muni";
				break;
			case "eventName" :
				dbFieldName = "event_name";
				break;
			case "demand" :
				dbFieldName = "demand";
				break;
			case "feeder" :
				dbFieldName = "feeder";
				break;
			case "buildingNumber" :
				dbFieldName = "building_num";
				break;
			case "serviceAddress" :
				dbFieldName = "service_address";
				break;
			case "customerZipCode" :
				dbFieldName = "cust_zip_code";
				break;
			case "meterNumber" :
				dbFieldName = "meter_number";
				break;
			case "accountNumber" :
				dbFieldName = "account_number";
				break;	
			case "network" :
				dbFieldName = "network";
				break;
			case "eventStatus" :
				dbFieldName = "FK_EVENT_STATUS";
				break;
			case "vcapInsertTime" :
				dbFieldName = "VCAP_INSERT_TIME";
				break;
			case "transformer" :
				dbFieldName = "TRANSFORMER";	
				break;
			case "structureName" :
				dbFieldName = "STRUCTURE";
		}
		
		return dbFieldName;
	}

    /*
     * Method to find list of invalid meters created for the evevnt.
	 *
     * @Param borough        String
     * @Param eventName      String
     * @Param startRowIndex  int
     * @Param batchSize      int
     * 
     * @return 			     MeterValidateResponseMapper
     *                         
     */	
	@Override
	public MeterValidateResponseMapper getInValidateMeterList(final String borough, final String eventName, final int startRowIndex, final int batchSize) {
	
		long processStartTime = DateUtils.processStartTime();
		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
		int begin  = (startRowIndex-1)*batchSize+1; 
		int end  = startRowIndex*batchSize;
		
		String query = "select * from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,mel.building_num,mel.service_address,mel.cust_zip_code,mel.meter_number,mel.account_number,mel.network,mel.FK_EVENT_STATUS,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME  from AMI_LOAD_SHEDDING.ls_meter_event_load mel where NOT EXISTS(select VEL.FK_METER_EVENT_LOAD_ID from AMI_LOAD_SHEDDING.ls_validate_event_list VEL where mel.meter_event_load_id = VEL.FK_METER_EVENT_LOAD_ID and VEL.event_name = ? AND VEL.BORO_MUNI = ?) AND mel.event_name = ? AND mel.BORO_MUNI = ?) t1 where rownum<=?) where rn>=?";
	    List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{eventName,borough,eventName,borough,end,begin},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setEventStatus(rs.getInt("FK_EVENT_STATUS"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				return meterEventLoad;
			}
        });
		if(!meterEventLoadList.isEmpty()){
			meterValidateResponseMapper.setMeterEventLoads(meterEventLoadList);
			meterValidateResponseMapper.setBorough(borough);
			meterValidateResponseMapper.setEventName(eventName);
			meterValidateResponseMapper.setPageNumber(startRowIndex);
			meterValidateResponseMapper.setPageSize(batchSize);
			meterValidateResponseMapper.setRecordOffsetRange("[ "+begin+"-"+end+" ]");
			MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
			meterValidateResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
			meterValidateResponseMapper.setNetwork(meterEventLoad.getNetwork());
			int totalInvalidRecord = getTotalInvalidRecord(borough, eventName);
			meterValidateResponseMapper.setTotalInvalidRecord(totalInvalidRecord);
			meterValidateResponseMapper.setValidResponse(true);
		}
		
		long processEndTime = DateUtils.processEndTime();
		
		LOGGER.info(String.format("*******************VALIDATED METER EVENT LIST %s",DateUtils.processResponseTime(processStartTime, processEndTime)));
		
		return meterValidateResponseMapper;
	}
	
    /*
     * Method to find total invalid meters count.
	 *
     * @Param borough   String
     * @Param eventName String
     * 
     * @return 			MeterValidateResponseMapper
     *                         
     */	
	private int getTotalInvalidRecord(final String borough, final String eventName) {
		String query = "select count(mel.METER_EVENT_LOAD_ID) from AMI_LOAD_SHEDDING.ls_meter_event_load mel where NOT EXISTS(select VEL.FK_METER_EVENT_LOAD_ID from AMI_LOAD_SHEDDING.ls_validate_event_list VEL where mel.meter_event_load_id = VEL.FK_METER_EVENT_LOAD_ID and VEL.event_name = ? AND VEL.BORO_MUNI = ?) AND mel.event_name = ? AND mel.BORO_MUNI = ? group by mel.event_name";
	    return oracleJdbcTemplate.queryForObject(query, new Object[]{eventName, borough,eventName, borough},Integer.class);
    }
	
	public boolean isEmptyOrNull(String string){
		return (isNull(string) || isEmpty(string));
	}
	
	public boolean isNull(final String string){
		return (null==string);
	}
	
	public boolean isEmpty(final String string){
		return (string.trim().length()<=0);
	}
	
    /*
     * Method to read locked status of the event from database.
	 *
     * @Param borough   String
     * @Param eventName String
     * @Param adid      String
     * 
     * @return 			MeterValidateResponseMapper
     *                         
     */	
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(final String borough, final String eventName, final String adid) {
		MeterLockedStatusResponseMapper meterLockedStatusResponseMapper = new MeterLockedStatusResponseMapper(); 

		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Integer countOfOperator = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
		
		String lockOperatorADID = "";
		if (countOfOperator > 0) {
			String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
			lockOperatorADID = oracleJdbcTemplate.queryForObject(operatorADIDQuery,  new Object[]{borough, eventName}, String.class);
			
			if(!adid.equals(lockOperatorADID)) {
				meterLockedStatusResponseMapper.setStatus(true);
				meterLockedStatusResponseMapper.setMessage("This event is locked. User "+lockOperatorADID+" is currently working on this event.");
				
				return meterLockedStatusResponseMapper;
			}
		} 

		meterLockedStatusResponseMapper.setStatus(false);
		meterLockedStatusResponseMapper.setMessage("This event is not locked.");

		return meterLockedStatusResponseMapper;
	}
	
    /*
     * Method to unlocked the event.
	 *
     * @Param adid String
     * 
     * @return 	   void
     *                         
     */	
	public void unlockEvents(final String adid) {
		oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE OPERATOR_AD_ID = ?", new Object[]{adid});
	}
}