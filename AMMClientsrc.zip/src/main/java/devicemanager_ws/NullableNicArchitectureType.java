
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NullableNicArchitectureType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NullableNicArchitectureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NicArchitecture" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicArchitectureType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Null" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NullableNicArchitectureType", propOrder = {
    "nicArchitecture"
})
public class NullableNicArchitectureType {

    @XmlElement(name = "NicArchitecture")
    protected NicArchitectureType nicArchitecture;
    @XmlAttribute(name = "Null")
    protected Boolean _null;

    /**
     * Gets the value of the nicArchitecture property.
     * 
     * @return
     *     possible object is
     *     {@link NicArchitectureType }
     *     
     */
    public NicArchitectureType getNicArchitecture() {
        return nicArchitecture;
    }

    /**
     * Sets the value of the nicArchitecture property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicArchitectureType }
     *     
     */
    public void setNicArchitecture(NicArchitectureType value) {
        this.nicArchitecture = value;
    }

    /**
     * Gets the value of the null property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isNull() {
        if (_null == null) {
            return false;
        } else {
            return _null;
        }
    }

    /**
     * Sets the value of the null property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNull(Boolean value) {
        this._null = value;
    }

}
