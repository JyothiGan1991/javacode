
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WeekdayEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WeekdayEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="WEEKDAY_SUNDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_MONDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_TUESDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_WEDNESDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_THURSDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_FRIDAY"/&gt;
 *     &lt;enumeration value="WEEKDAY_SATURDAY"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "WeekdayEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum WeekdayEnumeration {

    WEEKDAY_SUNDAY("WEEKDAY_SUNDAY"),
    WEEKDAY_MONDAY("WEEKDAY_MONDAY"),
    WEEKDAY_TUESDAY("WEEKDAY_TUESDAY"),
    WEEKDAY_WEDNESDAY("WEEKDAY_WEDNESDAY"),
    WEEKDAY_THURSDAY("WEEKDAY_THURSDAY"),
    WEEKDAY_FRIDAY("WEEKDAY_FRIDAY"),
    WEEKDAY_SATURDAY("WEEKDAY_SATURDAY"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    WeekdayEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WeekdayEnumeration fromValue(String v) {
        for (WeekdayEnumeration c: WeekdayEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
