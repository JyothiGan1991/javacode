package com.coned.ls.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.controller.RCCConnectControllerTmp;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.repository.MetersEventFinalizeRepository;
import com.coned.ls.repository.MetersEventFinalizeRepositoryTmp;

/**
 * 
 * Service class for Meters Event Finalize for RCC Disconnect.
 *
 */
@Service("metersEventFinalizeServiceTmp")
public class MetersEventFinalizeServiceTmpImpl  implements MetersEventFinalizeServiceTmp{

	@Autowired
	private MetersEventFinalizeRepositoryTmp  metersEventFinalizeRepository;

	private static final Logger LOGGER = LogManager.getLogger(MetersEventFinalizeServiceTmpImpl.class);
	
	@Override
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeMeterEvent(final MeterEventFinalize meterEventFinalize, final String adid) throws MeterFinalizeException{
		LOGGER.debug(" 3----- MetersEventFinalizeServiceTmpImpl ");
		MeterFinalizeResponseMapper finalizeMeterEventList = new MeterFinalizeResponseMapper();
		
		finalizeMeterEventList = metersEventFinalizeRepository.finalizeMeterEvent(meterEventFinalize, adid);
		
		if(finalizeMeterEventList.isResult()){
			finalizeMeterEventList.setMessage("SUCCESS");
			return ResponseEntity.status(HttpStatus.CREATED).body(finalizeMeterEventList);
		}else{
			return ResponseEntity.status(finalizeMeterEventList.getStatusCode()).body(finalizeMeterEventList);
		}
	}
}
