
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServicePtTransformerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServicePtTransformerType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransformerID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DevicePtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DeviceCtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServicePtTransformerType", propOrder = {
    "transformerID",
    "utilTransformerID",
    "utilTransformerType",
    "utilTransformerName",
    "devicePtRatio",
    "deviceCtRatio"
})
public class ServicePtTransformerType {

    @XmlElement(name = "TransformerID")
    protected Long transformerID;
    @XmlElement(name = "UtilTransformerID")
    protected String utilTransformerID;
    @XmlElement(name = "UtilTransformerType")
    protected String utilTransformerType;
    @XmlElement(name = "UtilTransformerName")
    protected String utilTransformerName;
    @XmlElement(name = "DevicePtRatio")
    protected Double devicePtRatio;
    @XmlElement(name = "DeviceCtRatio")
    protected Double deviceCtRatio;

    /**
     * Gets the value of the transformerID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTransformerID() {
        return transformerID;
    }

    /**
     * Sets the value of the transformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTransformerID(Long value) {
        this.transformerID = value;
    }

    /**
     * Gets the value of the utilTransformerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerID() {
        return utilTransformerID;
    }

    /**
     * Sets the value of the utilTransformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerID(String value) {
        this.utilTransformerID = value;
    }

    /**
     * Gets the value of the utilTransformerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerType() {
        return utilTransformerType;
    }

    /**
     * Sets the value of the utilTransformerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerType(String value) {
        this.utilTransformerType = value;
    }

    /**
     * Gets the value of the utilTransformerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerName() {
        return utilTransformerName;
    }

    /**
     * Sets the value of the utilTransformerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerName(String value) {
        this.utilTransformerName = value;
    }

    /**
     * Gets the value of the devicePtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDevicePtRatio() {
        return devicePtRatio;
    }

    /**
     * Sets the value of the devicePtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDevicePtRatio(Double value) {
        this.devicePtRatio = value;
    }

    /**
     * Gets the value of the deviceCtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDeviceCtRatio() {
        return deviceCtRatio;
    }

    /**
     * Sets the value of the deviceCtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDeviceCtRatio(Double value) {
        this.deviceCtRatio = value;
    }

}
