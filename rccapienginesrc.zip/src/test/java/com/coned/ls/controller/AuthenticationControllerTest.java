package com.coned.ls.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.AuthorizationService;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AuthenticationController.class)
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class,
		DataSourceTransactionManagerAutoConfiguration.class })
@WebMvcTest(AuthenticationController.class)

public class AuthenticationControllerTest {

	@Autowired
	private WebApplicationContext wac;

	private MockMvc mockMvc;
	
	@MockBean
	private AuthorizationService authenticationService;

	@InjectMocks
	private AuthenticationController authenticationController;

	@Test
	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		authenticationController = new AuthenticationController();
		System.out.println("@Before annotation method is being called ....");

		ReflectionTestUtils.setField(authenticationController, "authenticationService", authenticationService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

	@Test
	public void isOperatorAuthorized() {

		OperatorDetail detail = new OperatorDetail();
		detail.setAuthenticate(true);
		detail.setMessage("SUCCESS");
		Mockito.when(authenticationService.isOperatorAuthorized("BUDIDHAK", "RCC")).thenReturn(true);
		// Mockito.when(authenticationController.isOperatorAuthorized("BUDIDHAK",
		// "RCC")).thenReturn(detail);
		OperatorDetail actual = authenticationController.isOperatorAuthorized("BUDIDHAK", "RCC");
		Assert.assertEquals(detail.getMessage(), actual.getMessage());
	}

	@Test(expected = OperatorAuthorizationException.class)
	public void isOperatorAuthorizedWithOperatorAuthorizationException() {

		OperatorDetail detail = new OperatorDetail();
		detail.setAuthenticate(false);
		detail.setMessage("ACCESS_DENIED");
		Mockito.when(authenticationService.isOperatorAuthorized("xyd", "ACC")).thenReturn(false);
		Mockito.when(authenticationController.isOperatorAuthorized("xyz", "ACC")).thenReturn(detail);
		OperatorDetail actual = authenticationController.isOperatorAuthorized("xyz", "ACC");
		Assert.assertEquals(detail.getMessage(), actual.getMessage());
	}

	@Test
	public void persistApiTest() {

		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid("RCC");
		operatorLoginDetail.setApiKey("apiKey");
		operatorLoginDetail.setLoginStatus(10);

		Mockito.when(authenticationService.persistApi(operatorLoginDetail)).thenReturn(operatorLoginDetail);
		OperatorLoginDetail actual = authenticationController.persistApi(operatorLoginDetail);
		Assert.assertEquals(operatorLoginDetail.getLoginStatus(), actual.getLoginStatus());

	}

	@Test
	public void getOperatorLoginDetailTest() {

		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid("RCC");
		operatorLoginDetail.setApiKey("apiKey");
		operatorLoginDetail.setLoginStatus(10);
		operatorLoginDetail.setApiKeyStatus(13);
		operatorLoginDetail.setResponseStatus(true);

		Mockito.when(authenticationService.getOperatorLoginDetail("BUDIDHAK", "RCC")).thenReturn(operatorLoginDetail);
		Mockito.when(authenticationController.getOperatorLoginDetail(operatorLoginDetail)).thenReturn(operatorLoginDetail);
		OperatorLoginDetail actual = authenticationController.getOperatorLoginDetail(operatorLoginDetail);
		Assert.assertEquals(operatorLoginDetail.getLoginStatus(), actual.getLoginStatus());

	}
	
	@Test
	public void isAPIEndpointAuthorizeedTest() {

		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid("BUDIDHAK");
		operatorLoginDetail.setApiKey("apiKey");
		operatorLoginDetail.setLoginStatus(10);
		operatorLoginDetail.setApiKeyStatus(13);

		OperatorDetail expected = new OperatorDetail(); 
		expected.setAuthenticate(false);
		expected.setMessage("ACCESS_DENIED");

		Mockito.when(authenticationService.isAPIEndpointAuthorizeed("BUDIDHAK", "RCC", 10, 13)).thenReturn(false);
		// Mockito.when(authenticationController.isAPIEndpointAuthorizeed(operatorLoginDetail)).thenReturn(expected);
		OperatorDetail response = authenticationController.isAPIEndpointAuthorizeed(operatorLoginDetail);
		Assert.assertEquals(expected.isAuthenticate(), response.isAuthenticate());
	}
}
