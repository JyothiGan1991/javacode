package com.coned.ls.mapper;

import java.util.Date;
import java.util.List;

import com.coned.ls.domain.MeterEventLoad;

/**
 * 
 * Class to return connect request response.
 *
 */
public class MeterConnectResponseMapper {

	private List<MeterEventLoad> meterEventLoads;
	private int pageNumber;
	private int pageSize;
	private long totalRecord;
	private long totalMeterCount;
	private String recordOffsetRange;
	private Date insertTime;
	private String borough;
	private String eventName;
	private String network;
	private int remainingRow; 
	private String message;
	private boolean isValidResponse;
	
	private long totalSubEventMeters;
	private int kva;
	
	private long connectedTotalRecords;
	private long totalFinalizeRecordInEvent;
	
	private boolean isEventLocked;
	
	public long getConnectedTotalRecords() {
		return connectedTotalRecords;
	}
	public void setConnectedTotalRecords(long connectedTotalRecords) {
		this.connectedTotalRecords = connectedTotalRecords;
	}
	public long getTotalFinalizeRecordInEvent() {
		return totalFinalizeRecordInEvent;
	}
	public void setTotalFinalizeRecordInEvent(long totalFinalizeRecordInEvent) {
		this.totalFinalizeRecordInEvent = totalFinalizeRecordInEvent;
	}
	public int getRemainingRow() {
		return remainingRow;
	}
	public void setRemainingRow(int remainingRow) {
		this.remainingRow = remainingRow;
	}
	public List<MeterEventLoad> getMeterEventLoads() {
		return meterEventLoads;
	}
	public void setMeterEventLoads(List<MeterEventLoad> meterEventLoads) {
		this.meterEventLoads = meterEventLoads;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public long getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(long totalRecord) {
		this.totalRecord = totalRecord;
	}
	public long getTotalMeterCount() {
		return totalMeterCount;
	}
	public void setTotalMeterCount(long totalMeterCount) {
		this.totalMeterCount = totalMeterCount;
	}
	public String getRecordOffsetRange() {
		return recordOffsetRange;
	}
	public void setRecordOffsetRange(String recordOffsetRange) {
		this.recordOffsetRange = recordOffsetRange;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValidResponse() {
		return isValidResponse;
	}
	public void setValidResponse(boolean isValidResponse) {
		this.isValidResponse = isValidResponse;
	}
	public long getTotalSubEventMeters() {
		return totalSubEventMeters;
	}
	public void setTotalSubEventMeters(long totalSubEventMeters) {
		this.totalSubEventMeters = totalSubEventMeters;
	}
	public int getKva() {
		return kva;
	}
	public void setKva(int kva) {
		this.kva = kva;
	}
	public boolean isEventLocked() {
		return isEventLocked;
	}
	public void setEventLocked(boolean isEventLocked) {
		this.isEventLocked = isEventLocked;
	}
		
	
}
