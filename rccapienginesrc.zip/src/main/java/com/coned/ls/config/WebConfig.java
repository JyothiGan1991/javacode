package com.coned.ls.config;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages={"com.coned.ls"})
@EnableTransactionManagement
/*@PropertySource("classpath:db-queries.properties")*/

public class WebConfig {
	
	private static final Logger LOGGER = LogManager.getLogger(WebConfig.class);
	
	@Value("${lsa.spring.datasource.jndi-name}")
    private String lsaJndiName;
	
	@Value("${vcap.spring.datasource.jndi-name}")
    private String vcapJndiName;
	
	@Value("${star.spring.datasource.jndi-name}")
    private String starJndiName;
	
	@Value("${lsarcc.spring.datasource.jndi-name}")
    private String lsarccJndiName;

	@Bean(name = "sqlserver", destroyMethod="")
	@Primary
    public DataSource getSQLDataSource() {
		LOGGER.info("Initiate SQL Server database connection");
		JndiDataSourceLookup lookup = new JndiDataSourceLookup();
		return lookup.getDataSource(vcapJndiName);
    }
	
	@Bean(name = "oracledb", destroyMethod="")
    public DataSource getOracleDataSource() {
		LOGGER.info("Initiate Oracle database connection");
		JndiDataSourceLookup lookup = new JndiDataSourceLookup();
		return lookup.getDataSource(lsaJndiName); 
    }
	
	@Bean(name = "lsarccds", destroyMethod="")
    public DataSource getCommonOracleDataSource() {
		LOGGER.info("Initiate Common Oracle database connection");
		JndiDataSourceLookup lookup = new JndiDataSourceLookup();
		return lookup.getDataSource(lsarccJndiName); 
    }
	
	@Bean(name = "stardb", destroyMethod="")
    public DataSource getSTARDataSource() {
		LOGGER.info("Initiate STAR database connection");
		JndiDataSourceLookup lookup = new JndiDataSourceLookup();
		return lookup.getDataSource(starJndiName);		   
    }
	
	@Bean("sqlServerJdbcTemplate")
	public JdbcTemplate createSQLServerJdbcTemplate(@Autowired @Qualifier("sqlserver") DataSource dataSourceSQLServer){
	    return new JdbcTemplate(dataSourceSQLServer);
	}
	
	@Bean("oracleJdbcTemplate")
	public JdbcTemplate createOracleJdbcTemplate(@Autowired @Qualifier("oracledb") DataSource dataSourceOracle){
	    return new JdbcTemplate(dataSourceOracle);
	}
	
	@Bean("starJdbcTemplate")
	public JdbcTemplate createStarJdbcTemplate(@Autowired @Qualifier("stardb") DataSource dataSourceStar){
	    return new JdbcTemplate(dataSourceStar);
	}
	
	@Bean("oracleCommonJdbcTemplate")
	public JdbcTemplate createCommonOracleJdbcTemplate(@Autowired @Qualifier("lsarccds") DataSource dataSourceOracleCommon){
	    return new JdbcTemplate(dataSourceOracleCommon);
	}
	
	@Bean
    @Qualifier("oracleTx")
    public DataSourceTransactionManager oracleTx() {
         return new DataSourceTransactionManager(getOracleDataSource());
    }
	
	@Bean
    @Qualifier("oracleCommonTx")
    public DataSourceTransactionManager oracleCommonTx() {
         return new DataSourceTransactionManager(getCommonOracleDataSource());
    }
}
