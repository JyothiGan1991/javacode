package com.oru.rest.okta;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.net.URL;
import java.util.Date;
import java.util.List;

/**
 * Validates Okta access tokens (JWT) using the authorization server JWKS.
 */
@Service
public class OktaJwtValidator {

    private static final Logger log = LoggerFactory.getLogger(OktaJwtValidator.class);

    private final OktaProperties properties;
    private ConfigurableJWTProcessor<SecurityContext> jwtProcessor;
    private volatile boolean initialized;

    public OktaJwtValidator(OktaProperties properties) {
        this.properties = properties;
    }

    @PostConstruct
    public void init() {
        if (properties.isEnabled()) {
            try {
                ensureInitialized();
            } catch (Exception e) {
                log.warn("Okta JWKS not initialized at startup (will retry on first validation): {}",
                        e.getMessage());
            }
        }
    }

    public synchronized void ensureInitialized() throws Exception {
        if (initialized) {
            return;
        }
        String jwksUri = properties.getJwksUri();
        log.info("Initializing Okta JWT validator with JWKS: {}", jwksUri);
        JWKSource<SecurityContext> keySource = new RemoteJWKSet<SecurityContext>(new URL(jwksUri));
        ConfigurableJWTProcessor<SecurityContext> processor = new DefaultJWTProcessor<SecurityContext>();
        JWSKeySelector<SecurityContext> keySelector =
                new JWSVerificationKeySelector<SecurityContext>(JWSAlgorithm.RS256, keySource);
        processor.setJWSKeySelector(keySelector);
        this.jwtProcessor = processor;
        this.initialized = true;
    }

    /**
     * @return true if the token is a valid Okta access token for this issuer
     */
    public boolean isValid(String token) {
        if (!StringUtils.hasText(token) || !looksLikeJwt(token)) {
            return false;
        }
        try {
            ensureInitialized();
            JWTClaimsSet claims = jwtProcessor.process(token, null);
            // Issuer
            String expectedIssuer = properties.getIssuer();
            if (StringUtils.hasText(expectedIssuer)
                    && (claims.getIssuer() == null
                    || !expectedIssuer.equals(claims.getIssuer()))) {
                log.warn("Okta token issuer mismatch. expected={}, actual={}",
                        expectedIssuer, claims.getIssuer());
                return false;
            }
            // Expiry
            Date exp = claims.getExpirationTime();
            if (exp != null && exp.before(new Date())) {
                log.warn("Okta token expired at {}", exp);
                return false;
            }
            // Optional audience
            if (StringUtils.hasText(properties.getAudience())) {
                List<String> audiences = claims.getAudience();
                if (audiences == null || !audiences.contains(properties.getAudience())) {
                    log.warn("Okta token audience mismatch. expected={}", properties.getAudience());
                    return false;
                }
            }
            log.debug("Okta token validated successfully (sub={})", claims.getSubject());
            return true;
        } catch (Exception e) {
            log.warn("Okta token validation failed: {}", e.getMessage());
            return false;
        }
    }

    public static boolean looksLikeJwt(String token) {
        // JWT has three base64 segments separated by dots
        if (token == null) {
            return false;
        }
        String[] parts = token.split("\\.");
        return parts.length == 3 && parts[0].length() > 10;
    }
}
