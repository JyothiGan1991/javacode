@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.6:DeviceTypes.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ssn.schema.service.v2_6.devicetypes;
