
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AlarmType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AlarmType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="EventLogID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="EventID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="Status" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AlarmStatusType"/&gt;
 *         &lt;element name="IsUserClearable" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlarmType", propOrder = {
    "id",
    "eventLogID",
    "eventID",
    "status",
    "isUserClearable"
})
public class AlarmType {

    @XmlElement(name = "ID")
    protected long id;
    @XmlElement(name = "EventLogID", required = true)
    protected String eventLogID;
    @XmlElement(name = "EventID")
    protected int eventID;
    @XmlElement(name = "Status", required = true)
    protected AlarmStatusType status;
    @XmlElement(name = "IsUserClearable")
    protected boolean isUserClearable;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setID(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the eventLogID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventLogID() {
        return eventLogID;
    }

    /**
     * Sets the value of the eventLogID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventLogID(String value) {
        this.eventLogID = value;
    }

    /**
     * Gets the value of the eventID property.
     * 
     */
    public int getEventID() {
        return eventID;
    }

    /**
     * Sets the value of the eventID property.
     * 
     */
    public void setEventID(int value) {
        this.eventID = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmStatusType }
     *     
     */
    public AlarmStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmStatusType }
     *     
     */
    public void setStatus(AlarmStatusType value) {
        this.status = value;
    }

    /**
     * Gets the value of the isUserClearable property.
     * 
     */
    public boolean isIsUserClearable() {
        return isUserClearable;
    }

    /**
     * Sets the value of the isUserClearable property.
     * 
     */
    public void setIsUserClearable(boolean value) {
        this.isUserClearable = value;
    }

}
