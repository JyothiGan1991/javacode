
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NonGroupedSortColumnName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="NonGroupedSortColumnName">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EventTime"/>
 *     &lt;enumeration value="SourceId"/>
 *     &lt;enumeration value="SourceName"/>
 *     &lt;enumeration value="EmitterId"/>
 *     &lt;enumeration value="EmitterName"/>
 *     &lt;enumeration value="Severity"/>
 *     &lt;enumeration value="NumOfDaysToKeep"/>
 *     &lt;enumeration value="JobId"/>
 *     &lt;enumeration value="AckId"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "NonGroupedSortColumnName")
@XmlEnum
public enum NonGroupedSortColumnName {

    @XmlEnumValue("EventTime")
    EVENT_TIME("EventTime"),
    @XmlEnumValue("SourceId")
    SOURCE_ID("SourceId"),
    @XmlEnumValue("SourceName")
    SOURCE_NAME("SourceName"),
    @XmlEnumValue("EmitterId")
    EMITTER_ID("EmitterId"),
    @XmlEnumValue("EmitterName")
    EMITTER_NAME("EmitterName"),
    @XmlEnumValue("Severity")
    SEVERITY("Severity"),
    @XmlEnumValue("NumOfDaysToKeep")
    NUM_OF_DAYS_TO_KEEP("NumOfDaysToKeep"),
    @XmlEnumValue("JobId")
    JOB_ID("JobId"),
    @XmlEnumValue("AckId")
    ACK_ID("AckId");
    private final String value;

    NonGroupedSortColumnName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NonGroupedSortColumnName fromValue(String v) {
        for (NonGroupedSortColumnName c: NonGroupedSortColumnName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
