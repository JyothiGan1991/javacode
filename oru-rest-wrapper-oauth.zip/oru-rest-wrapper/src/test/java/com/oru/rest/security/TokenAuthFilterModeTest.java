package com.oru.rest.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oru.rest.okta.OktaJwtValidator;
import com.oru.rest.okta.OktaProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TokenAuthFilterModeTest {

    @Mock
    private OktaJwtValidator oktaJwtValidator;

    private OktaProperties oktaProperties;
    private TokenAuthFilter filter;

    @BeforeEach
    void setUp() {
        oktaProperties = new OktaProperties();
        oktaProperties.setEnabled(true);
        filter = new TokenAuthFilter(oktaJwtValidator, oktaProperties, new ObjectMapper());
        ReflectionTestUtils.setField(filter, "authEnabled", true);
        ReflectionTestUtils.setField(filter, "configuredToken", "static-secret");
    }

    @Test
    void staticMode_acceptsStaticToken() throws Exception {
        ReflectionTestUtils.setField(filter, "authMode", "static");
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/v1/nrg/verify-pole");
        request.addHeader("Authorization", "Bearer static-secret");
        MockHttpServletResponse response = new MockHttpServletResponse();
        filter.doFilter(request, response, new MockFilterChain());
        assertEquals(200, response.getStatus() == 0 ? 200 : response.getStatus());
    }

    @Test
    void staticMode_rejectsWrongToken() throws Exception {
        ReflectionTestUtils.setField(filter, "authMode", "static");
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/v1/nrg/verify-pole");
        request.addHeader("Authorization", "Bearer wrong");
        MockHttpServletResponse response = new MockHttpServletResponse();
        filter.doFilter(request, response, new MockFilterChain());
        assertEquals(401, response.getStatus());
    }

    @Test
    void bothMode_acceptsOktaJwt() throws Exception {
        ReflectionTestUtils.setField(filter, "authMode", "both");
        when(oktaJwtValidator.isValid(anyString())).thenReturn(true);

        // Fake JWT shape
        String jwt = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ0ZXN0In0.signaturepart";
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/v1/nrg/verify-pole");
        request.addHeader("Authorization", "Bearer " + jwt);
        MockHttpServletResponse response = new MockHttpServletResponse();
        filter.doFilter(request, response, new MockFilterChain());
        assertEquals(200, response.getStatus() == 0 ? 200 : response.getStatus());
    }
}
