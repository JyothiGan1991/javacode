package com.coned.odsListener.subscriber;

import javax.jms.JMSException;

public interface OdsEventSubscriber {
	
	void processMessage(Object eventNotification) throws JMSException;

}
