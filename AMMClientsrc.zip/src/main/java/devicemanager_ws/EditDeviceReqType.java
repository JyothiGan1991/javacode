
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditDeviceReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditDeviceReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditBaseDeviceType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditNetworkBaseDeviceType"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditLocationType"/&gt;
 *           &lt;element name="RemoveLocation" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="LocationAddnlInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditLocationAddnlInfoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditDeviceReqType", propOrder = {
    "commonAttributes",
    "location",
    "removeLocation",
    "locationAddnlInfo"
})
public class EditDeviceReqType
    extends AddEditBaseDeviceType
{

    @XmlElement(name = "CommonAttributes", required = true)
    protected EditNetworkBaseDeviceType commonAttributes;
    @XmlElement(name = "Location")
    protected EditLocationType location;
    @XmlElement(name = "RemoveLocation")
    protected Boolean removeLocation;
    @XmlElement(name = "LocationAddnlInfo")
    protected EditLocationAddnlInfoType locationAddnlInfo;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link EditNetworkBaseDeviceType }
     *     
     */
    public EditNetworkBaseDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditNetworkBaseDeviceType }
     *     
     */
    public void setCommonAttributes(EditNetworkBaseDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link EditLocationType }
     *     
     */
    public EditLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditLocationType }
     *     
     */
    public void setLocation(EditLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the removeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRemoveLocation() {
        return removeLocation;
    }

    /**
     * Sets the value of the removeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRemoveLocation(Boolean value) {
        this.removeLocation = value;
    }

    /**
     * Gets the value of the locationAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link EditLocationAddnlInfoType }
     *     
     */
    public EditLocationAddnlInfoType getLocationAddnlInfo() {
        return locationAddnlInfo;
    }

    /**
     * Sets the value of the locationAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditLocationAddnlInfoType }
     *     
     */
    public void setLocationAddnlInfo(EditLocationAddnlInfoType value) {
        this.locationAddnlInfo = value;
    }

}
