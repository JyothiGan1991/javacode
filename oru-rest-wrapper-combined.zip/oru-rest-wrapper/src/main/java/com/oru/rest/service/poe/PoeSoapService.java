package com.oru.rest.service.poe;

import com.oru.rest.dto.IncidentCountRequest;
import com.oru.rest.dto.IsGasMainRequest;
import com.oru.rest.dto.VerifyPoleRequest;
import com.oru.rest.exception.SoapServiceException;
import com.oru.soap.poe.generated.POEServiceException_Exception;
import com.oru.soap.poe.generated.POEWebServicesSEI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PoeSoapService {

    private static final Logger log = LoggerFactory.getLogger(PoeSoapService.class);

    private final POEWebServicesSEI soapClient;

    public PoeSoapService(POEWebServicesSEI soapClient) {
        this.soapClient = soapClient;
    }

    public boolean isGasMain(IsGasMainRequest request) {
        log.debug("SOAP isGasMain premise={}, radius={}", request.getPremise(), request.getRadius());
        try {
            int radius = request.getRadius() != null ? request.getRadius().intValue() : 0;
            return soapClient.isGasMain(request.getPremise(), radius);
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on isGasMain: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call isGasMain: " + e.getMessage(), e);
        }
    }

    public boolean verifyPole(VerifyPoleRequest request) {
        log.debug("SOAP verifyPole x={}, y={}", request.getX(), request.getY());
        try {
            int x = request.getX() != null ? request.getX().intValue() : 0;
            int y = request.getY() != null ? request.getY().intValue() : 0;
            return soapClient.verifyPole(x, y);
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on verifyPole: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call verifyPole: " + e.getMessage(), e);
        }
    }

    public int incidentCount(IncidentCountRequest request) {
        log.debug("SOAP incidentCount startDate={}", request.getStartDate());
        try {
            return soapClient.incidentCount(
                    request.getStartDate(),
                    request.getStartTime(),
                    request.getEndDate(),
                    request.getEndTime());
        } catch (POEServiceException_Exception e) {
            throw new SoapServiceException("SOAP fault on incidentCount: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call incidentCount: " + e.getMessage(), e);
        }
    }
}
