package com.oru.rest.dto;

public class PremiseRequest {
    private String premise;
    public PremiseRequest() {}
    public PremiseRequest(String premise) { this.premise = premise; }
    public String getPremise() { return premise; }
    public void setPremise(String premise) { this.premise = premise; }
}
