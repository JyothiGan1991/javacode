package com.coned.ls.interceptor;



import org.aspectj.lang.JoinPoint;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.rest.RESTActionExecutor;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class APISecurityInterceptorTest {
	@Rule
	public MockitoRule rule = MockitoJUnit.rule().silent();

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private HttpServletRequest request;
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	@MockBean
	RESTActionExecutor restActionExecutor;

	@InjectMocks
	APISecurityInterceptor apiSecurityInterceptor;

	@Test//(expected = OperatorAuthorizationException.class)
	public void testBefore() throws OperatorAuthorizationException {

		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(request);
		request.addHeader("Authorization", "18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff-BUDIDHAK");

		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(Mockito.any(HttpServletRequest.class));
		String adid = "BUDIDHAK";
		String apiKey ="18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff"; 
				
		Mockito.when(restActionExecutor.isAPIEndpointAuthorized(adid, apiKey, 13, 10)).thenReturn(true);
		JoinPoint joinPoint = Mockito.mock(JoinPoint.class);

		boolean actual = apiSecurityInterceptor.before(joinPoint);

	}
	
	
	@Test(expected = OperatorAuthorizationException.class)
	public void testBefore1() throws OperatorAuthorizationException {

		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(request);
		request.addHeader("Authorization", "18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff-BUDIDHAK");

		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(Mockito.any(HttpServletRequest.class));
		String adid = "BUDIDHAK";
		String apiKey ="18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff"; 
				
		Mockito.when(restActionExecutor.isAPIEndpointAuthorized(adid, apiKey, 13, 10)).thenReturn(false);
		JoinPoint joinPoint = Mockito.mock(JoinPoint.class);

		boolean actual = apiSecurityInterceptor.before(joinPoint);

	}
	
	@Test(expected = OperatorAuthorizationException.class)
	public void testBefore2() throws OperatorAuthorizationException {

		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(request);
		//request.addHeader("Authorization", "18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff-BUDIDHAK");

		//Mockito.when(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()).thenReturn(Mockito.any(HttpServletRequest.class));
		String adid = "BUDIDHAK";
		String apiKey ="18f9fc142c8650458f64212b762965d10888413ea16dc78ccb411d35d3fa72ff"; 
				
		Mockito.when(restActionExecutor.isAPIEndpointAuthorized(adid, apiKey, 13, 10)).thenReturn(false);
		JoinPoint joinPoint = Mockito.mock(JoinPoint.class);

		boolean actual = apiSecurityInterceptor.before(joinPoint);

	}
	
	

}
