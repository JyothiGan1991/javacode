package com.coned.ls.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.coned.ls.controller.ReportController;
import com.coned.ls.controller.UserManagementController;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

@RunWith(MockitoJUnitRunner.class)
public class ReportServiceTest {
	
	@Mock
	ReportController reportController;

	@InjectMocks
	private ReportService reportService;


	@Test
	public void getEvents() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		Mockito.when(reportService.getEvents(null)).thenReturn(result);
		String report_name = "test";
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getEvents(report_name);
		Assert.assertEquals("", "");
	}
	@Test
	public void getCDR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCDR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCDR(request, payload);
		Assert.assertEquals("", "");
	}@Test
	public void getCWR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCWR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCWR(request, payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void getCRR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCRR(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCRR(request, payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void getCER() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-username");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCER(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = reportController.getCER(request, payload);
		Assert.assertEquals("", "");
	}
}
