
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterReadTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MeterReadTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_OP_LP_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_READ"/>
 *     &lt;enumeration value="JOB_OP_SECLOG_READ"/>
 *     &lt;enumeration value="JOB_OP_CONS_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_RST_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_READ"/>
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_RST_READ"/>
 *     &lt;enumeration value="JOB_OP_REG_PREV_SESN_READ"/>
 *     &lt;enumeration value="JOB_OP_NCC_DL"/>
 *     &lt;enumeration value="JOB_OP_NCC_REG"/>
 *     &lt;enumeration value="JOB_OP_NCC_EL"/>
 *     &lt;enumeration value="JOB_OP_IMU_PROXY_READ"/>
 *     &lt;enumeration value="JOB_OP_NEW_DATA_READ"/>
 *     &lt;enumeration value="JOB_OP_METER_EL_READ"/>
 *     &lt;enumeration value="JOB_OP_ERR_HIST_READ"/>
 *     &lt;enumeration value="JOB_OP_NIC_NEW_DATA_READ"/>
 *     &lt;enumeration value="JOB_OP_ZB_METER_READ"/>
 *     &lt;enumeration value="JOB_OP_ITRON_IMU_PROXY_READ"/>
 *     &lt;enumeration value="JOB_OP_GENERIC_METER_READ"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MeterReadTypeEnumeration")
@XmlEnum
public enum MeterReadTypeEnumeration {

    JOB_OP_LP_READ("JOB_OP_LP_READ"),
    JOB_OP_REGISTER_CURR_READ("JOB_OP_REGISTER_CURR_READ"),
    JOB_OP_SECLOG_READ("JOB_OP_SECLOG_READ"),
    JOB_OP_CONS_READ("JOB_OP_CONS_READ"),
    JOB_OP_REGISTER_CURR_RST_READ("JOB_OP_REGISTER_CURR_RST_READ"),
    JOB_OP_REGISTER_SELF_READ("JOB_OP_REGISTER_SELF_READ"),
    JOB_OP_REGISTER_SELF_RST_READ("JOB_OP_REGISTER_SELF_RST_READ"),
    JOB_OP_REG_PREV_SESN_READ("JOB_OP_REG_PREV_SESN_READ"),
    JOB_OP_NCC_DL("JOB_OP_NCC_DL"),
    JOB_OP_NCC_REG("JOB_OP_NCC_REG"),
    JOB_OP_NCC_EL("JOB_OP_NCC_EL"),
    JOB_OP_IMU_PROXY_READ("JOB_OP_IMU_PROXY_READ"),
    JOB_OP_NEW_DATA_READ("JOB_OP_NEW_DATA_READ"),
    JOB_OP_METER_EL_READ("JOB_OP_METER_EL_READ"),
    JOB_OP_ERR_HIST_READ("JOB_OP_ERR_HIST_READ"),
    JOB_OP_NIC_NEW_DATA_READ("JOB_OP_NIC_NEW_DATA_READ"),
    JOB_OP_ZB_METER_READ("JOB_OP_ZB_METER_READ"),
    JOB_OP_ITRON_IMU_PROXY_READ("JOB_OP_ITRON_IMU_PROXY_READ"),
    JOB_OP_GENERIC_METER_READ("JOB_OP_GENERIC_METER_READ"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MeterReadTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MeterReadTypeEnumeration fromValue(String v) {
        for (MeterReadTypeEnumeration c: MeterReadTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
