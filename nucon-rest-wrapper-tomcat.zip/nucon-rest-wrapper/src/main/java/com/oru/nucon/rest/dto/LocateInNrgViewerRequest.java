package com.oru.nucon.rest.dto;

public class LocateInNrgViewerRequest {
    private Integer arg0;
    private Integer arg1;
    private Integer arg2;
    private String arg3;

    public LocateInNrgViewerRequest() {}
    public LocateInNrgViewerRequest(Integer arg0, Integer arg1, Integer arg2, String arg3) {
        this.arg0 = arg0;
        this.arg1 = arg1;
        this.arg2 = arg2;
        this.arg3 = arg3;
    }

    public Integer getArg0() { return arg0; }
    public void setArg0(Integer arg0) { this.arg0 = arg0; }
    public Integer getArg1() { return arg1; }
    public void setArg1(Integer arg1) { this.arg1 = arg1; }
    public Integer getArg2() { return arg2; }
    public void setArg2(Integer arg2) { this.arg2 = arg2; }
    public String getArg3() { return arg3; }
    public void setArg3(String arg3) { this.arg3 = arg3; }
}
