/*
 * package com.coned.ls.client;
 * 
 * import javax.xml.bind.JAXBElement;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.ws.client.core.support.WebServiceGatewaySupport;
 * 
 * import com.ssn.schema.service.v2_2.commonenumerations.PriorityEnumeration;
 * import com.ssn.schema.service.v2_2.commonenumerations.PriorityType; import
 * com.ssn.schema.service.v2_2.commonenumerations.ProvisioningActionType; import
 * com.ssn.schema.service.v2_2.commonenumerations.
 * RemoteProvisioningTypeEnumeration; import
 * com.ssn.schema.service.v2_2.jobmanager.AddRemoteProvisioningJobType; import
 * com.ssn.schema.service.v2_2.jobmanager.EmptyType; import
 * com.ssn.schema.service.v2_2.jobmanager.JobInfoType; import
 * com.ssn.schema.service.v2_2.jobmanager.ObjectFactory; import
 * com.ssn.schema.service.v2_2.jobmanager.RemoteProvisioningJobType; import
 * com.ssn.schema.service.v2_2.jobmanager.ScheduleChoiceType;
 * 
 * public class JobManagerClient extends WebServiceGatewaySupport { private
 * static final Logger log = LoggerFactory.getLogger(JobManagerClient.class);
 * 
 * public Object disconnectJob(String utilDeviceID, String macID) {
 * 
 * AddRemoteProvisioningJobType addJob = new AddRemoteProvisioningJobType();
 * 
 * JobInfoType jit = new JobInfoType(); jit.setName("Disconnect Job");
 * addJob.setJobInfo(jit);
 * 
 * RemoteProvisioningJobType rpj = new RemoteProvisioningJobType();
 * rpj.getDeviceMacID().add(macID);
 * 
 * ProvisioningActionType pat = new ProvisioningActionType();
 * pat.setName(RemoteProvisioningTypeEnumeration.JOB_OP_PROVISION_DISCONNECT);
 * rpj.setProvisioningAction(pat);
 * 
 * rpj.setNumberRetries(0);
 * 
 * PriorityType pt = new PriorityType();
 * pt.setName(PriorityEnumeration.JOB_PRIORITY_LOW); rpj.setPriority(pt);
 * 
 * addJob.setRemoteProvisioningJob(rpj);
 * 
 * ScheduleChoiceType sct = new ScheduleChoiceType(); sct.setImmediate(new
 * EmptyType()); addJob.setSchedule(sct);
 * 
 * // log.info("" + addJob); log.info("Requesting Disconnect for meter[" +
 * utilDeviceID + "] with MAC ID[" + macID + "]");
 * 
 * 
 * return (JobIDResponseType) getWebServiceTemplate().marshalSendAndReceive(
 * "https://ammwsroute.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/JobManagerPort",
 * addJob);
 * 
 * 
 * 
 * return (JAXBElement<JobIDResponseType>) getWebServiceTemplate()
 * .marshalSendAndReceive(new
 * ObjectFactory().createAddRemoteProvisioningJob(addJob));
 * 
 * 
 * JAXBElement<AddRemoteProvisioningJobType> request = new
 * ObjectFactory().createAddRemoteProvisioningJob(addJob);
 * logger.info(String.format("request: {0}", "Disconnect request"));
 * 
 * return getWebServiceTemplate().marshalSendAndReceive(
 * "https://ammwsroute.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/JobManagerPort",
 * request, new SecurityHeader());
 * 
 * 
 * return getWebServiceTemplate().marshalSendAndReceive(
 * "https://ammwsroute.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/JobManagerPort",
 * addJob, new SecurityHeader());
 * 
 * 
 * } }
 */