package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

@RunWith(MockitoJUnitRunner.class)
public class RCCOpenEventServiceTest {

	@InjectMocks
	OpenEventService openEventService;
	
	@Mock
	RESTActionExecutor restActionExecutor;
	
	@Mock
	RESTActionExecutorConnect restActionExecutorConnect;
	
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void getOpenEventTest()
    {
    	List<String> events = new ArrayList<String>();

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutor.getOpenEvent("B")).thenReturn(ResponseEntity.ok().body(events));
    	
    	ResponseEntity<List<String>> resEntity = openEventService.getOpenEvent("B");
    	
    	Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
    	Assert.assertEquals(resEntity.getBody().size(), 3);
    	Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
     
    @Test
    public void getBoroughAndEventNameBoroTest()
    {
    	List<String> boros = new ArrayList<String>();

    	boros.add("B");
    	boros.add("M");
    	boros.add("Q");

		Mockito.when(restActionExecutor.getBoroughAndEventName("boro")).thenReturn(ResponseEntity.ok().body(boros));
    	
    	ResponseEntity<List<String>> resEntity = openEventService.getBoroughAndEventName("boro");
    	
    	Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
    	Assert.assertEquals(resEntity.getBody().size(), 3);
    	Assert.assertEquals(resEntity.getBody().get(0), "B");
    }
    
    @Test
    public void getBoroughAndEventNameTest()
    {
    	List<String> events = new ArrayList<String>();

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutor.getBoroughAndEventName("event_name")).thenReturn(ResponseEntity.ok().body(events));
   	
		ResponseEntity<List<String>> resEntity = openEventService.getBoroughAndEventName("event_name");
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().size(), 3);
		Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
    
    @Test
    public void getBoroughAndEventNameForConnectTest()
    {
    	List<String> events = new ArrayList<String>();
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(events, HttpStatus.OK);

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutorConnect.getBoroughAndEventNameForConnect("B")).thenReturn(response);
   	
		ResponseEntity<List<String>> resEntity = openEventService.getBoroughAndEventNameForConnect("B");
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().size(), 3);
		Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
    
    @Test
    public void getOpenEventForConnectTest()
    {
    	List<String> events = new ArrayList<String>();
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(events, HttpStatus.OK);

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutorConnect.getOpenEventForConnect("B")).thenReturn(response);
   	
		ResponseEntity<List<String>> resEntity = openEventService.getOpenEventForConnect("B");
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().size(), 3);
		Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
    
    @Test
    public void getSubFinalizeBoroughTest()
    {
    	List<String> boros = new ArrayList<String>();

    	boros.add("B");
    	boros.add("M");
    	boros.add("Q");

		Mockito.when(restActionExecutorConnect.getSubFinalizeBorough("boro")).thenReturn(ResponseEntity.ok().body(boros));
    	
    	ResponseEntity<List<String>> resEntity = openEventService.getSubFinalizeBorough("boro");
    	
    	Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
    	Assert.assertEquals(resEntity.getBody().size(), 3);
    	Assert.assertEquals(resEntity.getBody().get(0), "B");
    }
    
    @Test
    public void getSubFinalizeEventTest()
    {
    	List<String> events = new ArrayList<String>();
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(events, HttpStatus.OK);

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutorConnect.getSubFinalizeEvent("B")).thenReturn(response);
   	
		ResponseEntity<List<String>> resEntity = openEventService.getSubFinalizeEvent("B");
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().size(), 3);
		Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
    
    @Test
    public void getSubEventNameBySubBoroughTest()
    {
    	List<String> events = new ArrayList<String>();
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(events, HttpStatus.OK);

    	events.add("BoroughHall.01.12/10/20-01:22:01.AUTO");
    	events.add("Flatbush.16.10/22/20-16:37:17.AUTO");
    	events.add("BayRidge.20.10/23/20-12:11:09.ZHUT");

		Mockito.when(restActionExecutorConnect.getSubEventNameBySubBorough("B")).thenReturn(response);
   	
		ResponseEntity<List<String>> resEntity = openEventService.getSubEventNameBySubBorough("B");
   	
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
		Assert.assertEquals(resEntity.getBody().size(), 3);
		Assert.assertEquals(resEntity.getBody().get(0), "BoroughHall.01.12/10/20-01:22:01.AUTO");
    }
    
    @Test
    public void getSubFinalizeEventByEventAndBoroughTest()
    {
    	List<String> events = new ArrayList<String>();
    	ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(events, HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.getSubFinalizeEventByEventAndBorough("B","BoroughHall.01.12/10/20-01:22:01.AUTO")).thenReturn(response);
		ResponseEntity<List<String>> resEntity = openEventService.getSubFinalizeEventByEventAndBorough("B","BoroughHall.01.12/10/20-01:22:01.AUTO");
		Assert.assertEquals(resEntity.getStatusCode(), HttpStatus.OK);
    }
    

    
	
    
    
}
