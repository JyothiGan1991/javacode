package com.coned.ls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coned.ls.domain.FilterAttribute;
import com.coned.ls.repository.MeterFilterRepository;

/**
 * 
 * Service class to implement filter functionality.
 *
 */
@Service("meterFilterService")
public class MeterFilterServiceImpl implements MeterFilterService {

	@Autowired
	private MeterFilterRepository meterFilterRepository;

    /*
     * Method to Initiate filter attribute.
     * 
     * @Param borough         String
     * @Param eventName  	  String
     * @Param filterAttribute String
     * @Param startIndex  	  int
     * @Param fetchNext  	  int
     * 
     * @return 				  List<FilterAttribute> 
     *                         
     */
	@Override
	public List<FilterAttribute> initMeterFilter(final String borough,final String eventName, final String filterAttribute, final int startIndex, final int fetchNext) {
		return meterFilterRepository.initMeterFilter(borough, eventName, filterAttribute, startIndex, fetchNext);
	} 
}
