
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SourceTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SourceTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EVENT_SRC_TYPE_METER"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_NETWORK_DEVICE"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_GATEWAY"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_DATABASE"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_TRANSPORT_LAYER"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_DEVICE_MANAGER"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_DAL"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_ALARMS_MANAGER"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_JOB_LAYER"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_USER_INTERFACE"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_NIC"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_MT_IMPORT"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_STATE_MONITOR"/>
 *     &lt;enumeration value="EVENT_SRC_TYPE_RESULT_PROCESS"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SourceTypeEnum")
@XmlEnum
public enum SourceTypeEnum {

    EVENT_SRC_TYPE_METER("EVENT_SRC_TYPE_METER"),
    EVENT_SRC_TYPE_NETWORK_DEVICE("EVENT_SRC_TYPE_NETWORK_DEVICE"),
    EVENT_SRC_TYPE_GATEWAY("EVENT_SRC_TYPE_GATEWAY"),
    EVENT_SRC_TYPE_DATABASE("EVENT_SRC_TYPE_DATABASE"),
    EVENT_SRC_TYPE_TRANSPORT_LAYER("EVENT_SRC_TYPE_TRANSPORT_LAYER"),
    EVENT_SRC_TYPE_DEVICE_MANAGER("EVENT_SRC_TYPE_DEVICE_MANAGER"),
    EVENT_SRC_TYPE_DAL("EVENT_SRC_TYPE_DAL"),
    EVENT_SRC_TYPE_ALARMS_MANAGER("EVENT_SRC_TYPE_ALARMS_MANAGER"),
    EVENT_SRC_TYPE_JOB_LAYER("EVENT_SRC_TYPE_JOB_LAYER"),
    EVENT_SRC_TYPE_USER_INTERFACE("EVENT_SRC_TYPE_USER_INTERFACE"),
    EVENT_SRC_TYPE_NIC("EVENT_SRC_TYPE_NIC"),
    EVENT_SRC_TYPE_MT_IMPORT("EVENT_SRC_TYPE_MT_IMPORT"),
    EVENT_SRC_TYPE_STATE_MONITOR("EVENT_SRC_TYPE_STATE_MONITOR"),
    EVENT_SRC_TYPE_RESULT_PROCESS("EVENT_SRC_TYPE_RESULT_PROCESS"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    SourceTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SourceTypeEnum fromValue(String v) {
        for (SourceTypeEnum c: SourceTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
