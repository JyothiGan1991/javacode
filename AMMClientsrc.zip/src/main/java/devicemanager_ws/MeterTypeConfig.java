
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BaseMeterTypeConfig"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="AssociatedDevicesCount" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterTypeConfig", propOrder = {
    "typeConfigID",
    "associatedDevicesCount"
})
public class MeterTypeConfig
    extends BaseMeterTypeConfig
{

    @XmlElement(name = "TypeConfigID")
    protected long typeConfigID;
    @XmlElement(name = "AssociatedDevicesCount")
    protected Long associatedDevicesCount;

    /**
     * Gets the value of the typeConfigID property.
     * 
     */
    public long getTypeConfigID() {
        return typeConfigID;
    }

    /**
     * Sets the value of the typeConfigID property.
     * 
     */
    public void setTypeConfigID(long value) {
        this.typeConfigID = value;
    }

    /**
     * Gets the value of the associatedDevicesCount property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAssociatedDevicesCount() {
        return associatedDevicesCount;
    }

    /**
     * Sets the value of the associatedDevicesCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAssociatedDevicesCount(Long value) {
        this.associatedDevicesCount = value;
    }

}
