
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 *                         The operation/ErrorCode currently returned are :
 *                         AddDevice/dup_mac_address_add
 *                         AddDevice/dup_ip_address_add
 *                         AddDevice/invalid_date_format
 *                         AddDevice/type_config_add_edit_error
 *                         AddDevice/invalid_device_subtype
 *                         AddLocation/type_config_add_edit_error
 *                         AddLocation/invalid_contact_id
 *                         AddNote/invalid_macid
 *                         EditAccount/invalid_util_account_id
 *                         EditDevice/no_location
 *                         EditDevice/util_state_and_location_invalid
 *                         EditDevice/util_state_not_active
 *                         EditDevice/dup_mac_address_edit
 *                         EditDevice/dup_ip_address_edit
 *                         EditDevice/invalid_device_subtype
 *                         EditLocation/type_config_add_edit_error
 *                         EditLocation/invalid_util_location_id
 *                         EditLocation/invalid_contact_id
 *                         EditServicePoint/invalid_util_service_point_id
 *                         FindDevice/too_many_rows
 *                         FindDevice/invalid_device_subtype
 *                         FindNic/invalid_device_subtype
 *                         FindNiclessDevice/invalid_device_subtype
 *                         GetAccount/invalid_util_account_id
 *                         GetAccount/invalid_account_id
 *                         GetDevice/invalid_macid
 *                         GetDevice/invalid_device_subtype
 *                         GetLocation/invalid_util_location_id
 *                         GetLocation/invalid_location_id
 *                         GetServicePoint/invalid_util_service_point_id
 *                         GetServicePoint/invalid_service_point_id
 *                         GetServicePointTransformer/invalid_service_point_transformer_id
 *                         GetServicePointTransformer/invalid_util_service_point_transformer_id
 *                         GetTotalCountForFindDevice/invalid_device_subtype
 *                         GetTotalCountForFindNic/invalid_device_subtype
 *                         GetTotalCountForFindNiclessDevice/invalid_device_subtype
 *                         GetDistributionNetwork/invalid_distribution_network_id
 *                         ListNetworkDevices/invalid_device_subtype
 *                         ReplaceLocation/servicePoint_mismatch
 *                         ReplaceLocation/invalid_util_service_point_id
 *                         ReplaceLocation/invalid_util_location_id
 *                         ReplaceLocation/no_location
 *                         ReplaceLocation/util_state_and_location_invalid
 *                         ReplaceLocation/util_state_not_active
 *                         ReplaceLocation/type_config_add_edit_error
 *                         ReplaceLocation/device_not_specified
 *                         ReplaceLocation/invalid_macid
 *                         ReplaceLocation/invalid_device_subtype
 *                         ReplaceDeviceAtLocation/servicePoint_mismatch
 *                         ReplaceDeviceAtLocation/location_mismatch
 *                         ReplaceDeviceAtLocation/location_not_specified
 *                         ReplaceDeviceAtLocation/type_config_add_edit_error
 *                         ReplaceDeviceAtLocation/no_location
 *                         ReplaceDeviceAtLocation/util_state_and_location_invalid
 *                         ReplaceDeviceAtLocation/util_state_not_active
 *                         ReplaceDeviceAtLocation/device_not_specified
 *                         ReplaceDeviceAtLocation/invalid_macid
 *                         ReplaceDeviceAtLocation/invalid_device_subtype
 *                         SaveCriteriaForFindDevice/invalid_device_subtype
 *                         SetAdminState/device_not_specified
 *                         SetAdminState/invalid_macid
 *                         SetAdminState/servicePoint_mismatch
 *                         SetAdminState/no_location
 *                         SetAdminState/util_state_and_location_invalid
 *                         SetAdminState/util_state_not_active
 *                         SetAdminState/type_config_add_edit_error
 *                         SetAdminState/invalid_device_subtype
 *                         UpdateDevice/type_config_add_edit_error
 *                         UpdateDevice/no_location
 *                         UpdateDevice/util_state_and_location_invalid
 *                         UpdateDevice/util_state_not_active
 *                         UpdateDevice/device_not_specified
 *                         UpdateDevice/invalid_macid
 *                         UpdateDevice/type_config_add_edit_error
 *                         UpdateDevice/invalid_device_subtype
 *                         UpdateServicePoint/invalid_util_service_point_id
 *                     
 * 
 * <p>Java class for ErrorCodeFaultType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ErrorCodeFaultType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ErrorCodeFaultType", propOrder = {
    "errorCode",
    "errorMessage"
})
public class ErrorCodeFaultType {

    @XmlElement(name = "ErrorCode", required = true)
    protected String errorCode;
    @XmlElement(name = "ErrorMessage", required = true)
    protected String errorMessage;

    /**
     * Gets the value of the errorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

}
