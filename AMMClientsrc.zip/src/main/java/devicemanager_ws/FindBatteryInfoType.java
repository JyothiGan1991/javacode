
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindBatteryInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindBatteryInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BatteryID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BatteryManufacturer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatterySerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryManufacturerTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="BatteryExpirationTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="BatteryInstalledTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="BatteryLotNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryLastTestedTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindBatteryInfoType", propOrder = {
    "batteryID",
    "batteryManufacturer",
    "batteryModel",
    "batterySerialNumber",
    "batteryManufacturerTime",
    "batteryExpirationTime",
    "batteryInstalledTime",
    "batteryLotNumber",
    "batteryLastTestedTime"
})
public class FindBatteryInfoType {

    @XmlElement(name = "BatteryID")
    protected Long batteryID;
    @XmlElement(name = "BatteryManufacturer")
    protected String batteryManufacturer;
    @XmlElement(name = "BatteryModel")
    protected String batteryModel;
    @XmlElement(name = "BatterySerialNumber")
    protected String batterySerialNumber;
    @XmlElement(name = "BatteryManufacturerTime")
    protected TimeRangeType batteryManufacturerTime;
    @XmlElement(name = "BatteryExpirationTime")
    protected TimeRangeType batteryExpirationTime;
    @XmlElement(name = "BatteryInstalledTime")
    protected TimeRangeType batteryInstalledTime;
    @XmlElement(name = "BatteryLotNumber")
    protected String batteryLotNumber;
    @XmlElement(name = "BatteryLastTestedTime")
    protected TimeRangeType batteryLastTestedTime;

    /**
     * Gets the value of the batteryID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBatteryID() {
        return batteryID;
    }

    /**
     * Sets the value of the batteryID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBatteryID(Long value) {
        this.batteryID = value;
    }

    /**
     * Gets the value of the batteryManufacturer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryManufacturer() {
        return batteryManufacturer;
    }

    /**
     * Sets the value of the batteryManufacturer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryManufacturer(String value) {
        this.batteryManufacturer = value;
    }

    /**
     * Gets the value of the batteryModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryModel() {
        return batteryModel;
    }

    /**
     * Sets the value of the batteryModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryModel(String value) {
        this.batteryModel = value;
    }

    /**
     * Gets the value of the batterySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatterySerialNumber() {
        return batterySerialNumber;
    }

    /**
     * Sets the value of the batterySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatterySerialNumber(String value) {
        this.batterySerialNumber = value;
    }

    /**
     * Gets the value of the batteryManufacturerTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getBatteryManufacturerTime() {
        return batteryManufacturerTime;
    }

    /**
     * Sets the value of the batteryManufacturerTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setBatteryManufacturerTime(TimeRangeType value) {
        this.batteryManufacturerTime = value;
    }

    /**
     * Gets the value of the batteryExpirationTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getBatteryExpirationTime() {
        return batteryExpirationTime;
    }

    /**
     * Sets the value of the batteryExpirationTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setBatteryExpirationTime(TimeRangeType value) {
        this.batteryExpirationTime = value;
    }

    /**
     * Gets the value of the batteryInstalledTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getBatteryInstalledTime() {
        return batteryInstalledTime;
    }

    /**
     * Sets the value of the batteryInstalledTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setBatteryInstalledTime(TimeRangeType value) {
        this.batteryInstalledTime = value;
    }

    /**
     * Gets the value of the batteryLotNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryLotNumber() {
        return batteryLotNumber;
    }

    /**
     * Sets the value of the batteryLotNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryLotNumber(String value) {
        this.batteryLotNumber = value;
    }

    /**
     * Gets the value of the batteryLastTestedTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getBatteryLastTestedTime() {
        return batteryLastTestedTime;
    }

    /**
     * Sets the value of the batteryLastTestedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setBatteryLastTestedTime(TimeRangeType value) {
        this.batteryLastTestedTime = value;
    }

}
