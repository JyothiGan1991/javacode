package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventFinalizeService;
import com.coned.ls.service.MeterEventFinalizeServiceTmp;
import com.coned.ls.service.MeterEventValidateService;
//import com.coned.ls.service.MetersEventFinalizeServiceTmp;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.OpenEventServiceTmp;
import com.fasterxml.jackson.databind.ObjectMapper;



@RunWith(SpringRunner.class)
//@ContextConfiguration(classes= {RCCConnectControllerTmp.class,MeterEventFinalizeServiceTmp.class, OpenEventServiceTmp.class})
@SpringBootTest(classes = {RCCApplication.class, RCCConnectControllerTmp.class, MeterEventFinalizeServiceTmp.class, OpenEventServiceTmp.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class RCCConnectControllerTmpTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Mock
	private MeterEventValidateService meterEventValidateService = new MeterEventValidateService();
	
	@Mock
	private MeterEventFinalizeServiceTmp meterEventFinalizeServiceTmp = new MeterEventFinalizeServiceTmp();
	
	@Mock
	private OpenEventServiceTmp openEventServiceTmp;
	
	@InjectMocks
	RCCConnectControllerTmp rccConnectControllerTmp;
	
//	List<MeterEventLoad> meterEventLoads= new ArrayList<>();
//	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
	
	private static final String baseURL = "http://localhost:7001/rcc/v07/lsa-rcc-connect-tmp";
	@Test
	@Before
	public void setup() throws Exception{
		rccConnectControllerTmp = new RCCConnectControllerTmp();
		System.out.println("@Before annotation method is being called ....");
		
//		ReflectionTestUtils.setField(rccConnectControllerTmp, "openEventServiceTmp", openEventServiceTmp);
//		ReflectionTestUtils.setField(rccConnectControllerTmp, "meterEventValidateService", meterEventValidateService);
//		ReflectionTestUtils.setField(rccConnectControllerTmp, "meterEventFinalizeServiceTmp", meterEventFinalizeServiceTmp);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		String borough = "B";

	}
	
	@Test(expected = NullPointerException.class)
	public void finalizeValidateMeters() throws Exception{
		ResponseEntity<String> message = new ResponseEntity<String>("success", new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid= "XYZ";
		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		Mockito.when(meterEventFinalizeServiceTmp.finalizeValidateMeterTmp(meterEventFinalize, adid)).thenReturn(message);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<String> actual =  rccConnectControllerTmp.finalizeValidateMeters(request, borough, eventName);
		Assert.assertEquals("success", actual.getBody());
	}
	
	@Test(expected = NullPointerException.class)
	public void getEventNameByBorough() throws Exception{
        List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		Mockito.when(openEventServiceTmp.getOpenEvent(borough)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccConnectControllerTmp.getEventNameByBorough(borough);
		Assert.assertEquals(result.getBody().size(), actual.getBody().size());
	}

}
