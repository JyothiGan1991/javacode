
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetLocationReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetLocationReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="UtilPremiseID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *           &lt;element name="UtilLocationID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UtilLocationIDType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="Location" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="LocationAddnlInfo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DistributionNetwork" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Contacts" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ServicePoint" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetLocationReqType", propOrder = {
    "utilPremiseID",
    "locationID",
    "utilLocationID",
    "location",
    "locationAddnlInfo",
    "distributionNetwork",
    "contacts",
    "servicePoint"
})
public class GetLocationReqType {

    @XmlElement(name = "UtilPremiseID")
    protected String utilPremiseID;
    @XmlElement(name = "LocationID")
    protected Long locationID;
    @XmlElement(name = "UtilLocationID")
    protected UtilLocationIDType utilLocationID;
    @XmlElement(name = "Location")
    protected Boolean location;
    @XmlElement(name = "LocationAddnlInfo")
    protected Boolean locationAddnlInfo;
    @XmlElement(name = "DistributionNetwork")
    protected Boolean distributionNetwork;
    @XmlElement(name = "Contacts")
    protected Boolean contacts;
    @XmlElement(name = "ServicePoint")
    protected Boolean servicePoint;

    /**
     * Gets the value of the utilPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilPremiseID() {
        return utilPremiseID;
    }

    /**
     * Sets the value of the utilPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilPremiseID(String value) {
        this.utilPremiseID = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the utilLocationID property.
     * 
     * @return
     *     possible object is
     *     {@link UtilLocationIDType }
     *     
     */
    public UtilLocationIDType getUtilLocationID() {
        return utilLocationID;
    }

    /**
     * Sets the value of the utilLocationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilLocationIDType }
     *     
     */
    public void setUtilLocationID(UtilLocationIDType value) {
        this.utilLocationID = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocation(Boolean value) {
        this.location = value;
    }

    /**
     * Gets the value of the locationAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocationAddnlInfo() {
        return locationAddnlInfo;
    }

    /**
     * Sets the value of the locationAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocationAddnlInfo(Boolean value) {
        this.locationAddnlInfo = value;
    }

    /**
     * Gets the value of the distributionNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDistributionNetwork() {
        return distributionNetwork;
    }

    /**
     * Sets the value of the distributionNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDistributionNetwork(Boolean value) {
        this.distributionNetwork = value;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isContacts() {
        return contacts;
    }

    /**
     * Sets the value of the contacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setContacts(Boolean value) {
        this.contacts = value;
    }

    /**
     * Gets the value of the servicePoint property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isServicePoint() {
        return servicePoint;
    }

    /**
     * Sets the value of the servicePoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setServicePoint(Boolean value) {
        this.servicePoint = value;
    }

}
