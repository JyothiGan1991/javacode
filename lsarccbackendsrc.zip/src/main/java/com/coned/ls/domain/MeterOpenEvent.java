package com.coned.ls.domain;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * Class to store open event request details.
 *
 */
public class MeterOpenEvent implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String borough;
	private String eventName;
	private int startRowIndex;
	private int batchSize;
	@JsonProperty
	private boolean isFilterApplied;
	@JsonProperty
	private boolean isSortApplied;
	private Map<String,String> filterList;
	private Map<String,String> sortList;
	private String adid;
	private String fromDate;
	private String toDate;
	@JsonProperty
	private boolean isMeterStatusFilterApplied;
	@JsonProperty
	private boolean isMeterStatusSortApplied;
	
	public boolean isMeterStatusFilterApplied() {
		return isMeterStatusFilterApplied;
	}
	public void setMeterStatusFilterApplied(boolean isMeterStatusFilterApplied) {
		this.isMeterStatusFilterApplied = isMeterStatusFilterApplied;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public int getStartRowIndex() {
		return startRowIndex;
	}
	public void setStartRowIndex(int startRowIndex) {
		this.startRowIndex = startRowIndex;
	}
	public int getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}
	public boolean isFilterApplied() {
		return isFilterApplied;
	}
	public void setFilterApplied(boolean isFilterApplied) {
		this.isFilterApplied = isFilterApplied;
	}
	public boolean isSortApplied() {
		return isSortApplied;
	}
	public void setSortApplied(boolean isSortApplied) {
		this.isSortApplied = isSortApplied;
	}
	public Map<String, String> getFilterList() {
		return filterList;
	}
	public void setFilterList(Map<String, String> filterList) {
		this.filterList = filterList;
	}
	public Map<String, String> getSortList() {
		return sortList;
	}
	public void setSortList(Map<String, String> sortList) {
		this.sortList = sortList;
	}
	
	
	public String getAdid() {
		return adid;
	}
	public void setAdid(String adid) {
		this.adid = adid;
	}
	
	
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Override
	public String toString() {
		return "MeterOpenEvent [borough=" + borough + ", eventName=" + eventName + ", startRowIndex=" + startRowIndex
				+ ", batchSize=" + batchSize + ", isFilterApplied=" + isFilterApplied + ", isSortApplied="
				+ isSortApplied + ", filterList=" + filterList + ", sortList=" + sortList + ", adid=" + adid
				+ ", fromDate=" + fromDate + ", toDate=" + toDate + "]";
	}
	public boolean isMeterStatusSortApplied() {
		return isMeterStatusSortApplied;
	}
	public void setMeterStatusSortApplied(boolean isMeterStatusSortApplied) {
		this.isMeterStatusSortApplied = isMeterStatusSortApplied;
	}
}
