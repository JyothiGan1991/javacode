
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditBridgeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditBridgeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DNP3Address" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="EthernetMacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditBridgeType", propOrder = {
    "dnp3Address",
    "ethernetMacID"
})
@XmlSeeAlso({
    AddEditBridgeTypeReq.class
})
public class AddEditBridgeType {

    @XmlElement(name = "DNP3Address")
    protected Long dnp3Address;
    @XmlElement(name = "EthernetMacID")
    protected String ethernetMacID;

    /**
     * Gets the value of the dnp3Address property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDNP3Address() {
        return dnp3Address;
    }

    /**
     * Sets the value of the dnp3Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDNP3Address(Long value) {
        this.dnp3Address = value;
    }

    /**
     * Gets the value of the ethernetMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEthernetMacID() {
        return ethernetMacID;
    }

    /**
     * Sets the value of the ethernetMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEthernetMacID(String value) {
        this.ethernetMacID = value;
    }

}
