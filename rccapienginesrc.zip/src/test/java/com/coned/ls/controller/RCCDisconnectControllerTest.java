/*package com.coned.ls.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import com.coned.ls.config.ApiEngineApplication;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApiEngineApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class RCCDisconnectControllerTest {
	
	@Test
	public void getBorough() throws Exception{
		
	}
}
*/
package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.AuthorizationService;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.MeterEventValidateServiceImpl;
import com.coned.ls.service.MetersEventFinalizeService;
import com.coned.ls.service.MetersEventFinalizeServiceImpl;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.OpenEventServiceImpl;
import com.coned.ls.utility.DateUtils;



@RunWith(SpringRunner.class)
@ContextConfiguration(classes=RCCDisconnectController.class)
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
@WebMvcTest(RCCDisconnectController.class)
//@SpringBootTest(classes = ApiEngineApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
//@AutoConfigureMockMvc
public class RCCDisconnectControllerTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	
	@MockBean
	private MeterEventValidateService meterEventValidateService; 
	
	@MockBean
	private MetersEventFinalizeService metersEventFinalizeService; 
	
	@MockBean
	private OpenEventService openEventService; 
	
	
	@InjectMocks
	RCCDisconnectController rccDisconnectController;
	
	final RestTemplate testTemplate = new RestTemplate();
	
	List<MeterEventLoad> meterEventLoads= new ArrayList<>();
	
	
	@Test
	@Before
	public void setup() throws Exception{
	    MockitoAnnotations.initMocks(this);
		rccDisconnectController = new RCCDisconnectController();
		System.out.println("@Before annotation method is being called ....");
		
		ReflectionTestUtils.setField(rccDisconnectController, "openEventService", openEventService);
		ReflectionTestUtils.setField(rccDisconnectController, "meterEventValidateService", meterEventValidateService);
		ReflectionTestUtils.setField(rccDisconnectController, "metersEventFinalizeService", metersEventFinalizeService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void getBoroughName() throws Exception {
		List<String> expected = new ArrayList<String>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected,new HttpHeaders(), HttpStatus.OK);
		
		String fields = "boro";
		Mockito.when(openEventService.getNewAndActiveBorough()).thenReturn(result);
		
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveBorough(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getNewAndActiveBorough()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getNewAndActiveBorough(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}
	@Test
	public void getEventName() throws Exception {
		List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);
		String fields = "event_name";
		Mockito.when(openEventService.getNewAndActiveEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveBorough(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getNewAndActiveEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getNewAndActiveBorough(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}

	
	@Test
	public void getEventNameByBorough() throws Exception{
        List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		Mockito.when(openEventService.getNewAndActiveEventByBorough(borough)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveEventByBorough(borough);
		Assert.assertEquals(result.getBody().size(), actual.getBody().size());
	}
	
	
	
	@Test
	public void getValidateMeter() throws Exception{
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setPageNumber(20);
		meterValidateResponseMapper.setPageSize(1);
		meterValidateResponseMapper.setTotalRecord(2);
		meterValidateResponseMapper.setRecordOffsetRange("abcd");
		//meterValidateResponseMapper.setInsertTime(date);
		meterValidateResponseMapper.setBorough("M");
		meterValidateResponseMapper.setEventName("QRST");
		meterValidateResponseMapper.setNetwork("GHIJ");
		meterValidateResponseMapper.setRemainingRow(3);
		meterValidateResponseMapper.setTotalValidRecord(2);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setMessage("abcdef");
		ResponseEntity<MeterValidateResponseMapper> result = new ResponseEntity<MeterValidateResponseMapper>(meterValidateResponseMapper,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 50;
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		Mockito.when(meterEventValidateService.getValidateMeter(meterOpenEvent)).thenReturn(result);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.getValidateMeter(request, meterOpenEvent);
		Assert.assertNotNull(actual);
		
	}
	@Test
	public void finalizeValidateMeters() throws Exception{
		MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
		mfrp.setMessage("success");
		mfrp.setResult(true);
		ResponseEntity<MeterFinalizeResponseMapper> mapper = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp  , new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid = "XYZ";
		Mockito.when(metersEventFinalizeService.finalizeMeterEvent(meterEventFinalize,adid )).thenReturn(mapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterFinalizeResponseMapper> actual = rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals(mapper.getBody().getMessage() , actual.getBody().getMessage());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void InvalidfinalizeValidateMeters() throws Exception{
		MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
		ResponseEntity<MeterFinalizeResponseMapper> mapper = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp  , new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid= null;
		Mockito.when(metersEventFinalizeService.finalizeMeterEvent(meterEventFinalize,adid)).thenReturn(mapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(null, null);
		ResponseEntity<MeterFinalizeResponseMapper> actual= rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals(mapper.getBody(), actual.getBody());
	}
	
	
	@Test
	public void searchMeter() throws Exception {
        MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoad);
		
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
        Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		
		meterValidateResponseMapper.setPageNumber(20);
		meterValidateResponseMapper.setPageSize(1);
		meterValidateResponseMapper.setTotalRecord(2);
		meterValidateResponseMapper.setRecordOffsetRange("abcd");
		//meterValidateResponseMapper.setInsertTime(date);
		meterValidateResponseMapper.setBorough("M");
		meterValidateResponseMapper.setEventName("QRST");
		meterValidateResponseMapper.setNetwork("GHIJ");
		meterValidateResponseMapper.setRemainingRow(3);
		meterValidateResponseMapper.setTotalValidRecord(2);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setMessage("abcdef");

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("xyz");
		meterSearch.setEvent("abc");
		
		ResponseEntity<MeterValidateResponseMapper> mvrp = new ResponseEntity<MeterValidateResponseMapper>(meterValidateResponseMapper,new HttpHeaders(), HttpStatus.OK);
		Mockito.when(meterEventValidateService.searchMeters(meterSearch)).thenReturn(mvrp);
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.searchMeter(meterSearch);
		Assert.assertEquals("M", actual.getBody().getBorough());
	}
	@Test(expected = IllegalArgumentException.class)
	public void InvalidsearchMeter() throws Exception {
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
        Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		ResponseEntity<MeterValidateResponseMapper> mvrp = new ResponseEntity<MeterValidateResponseMapper>(meterValidateResponseMapper,new HttpHeaders(), HttpStatus.OK);
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		Mockito.when(meterEventValidateService.searchMeters(meterSearch)).thenReturn(mvrp);
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.searchMeter(meterSearch);
		Assert.assertEquals(mvrp, actual);
	}
	@Test
	public void getFieldValuesByBoroughAndEventName() throws Exception {
		List<String> fieldvalues  = new ArrayList<String>();
		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String fieldName = "MeterNumber";
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(fieldvalues,new HttpHeaders(), HttpStatus.OK);
        Mockito.when(meterEventValidateService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertEquals(result.getBody(), actual.getBody());
	}
	@Test
	public void getLockedStatusByBoroughAndEventName() throws Exception {
		MeterLockedStatusResponseMapper mockdata  = new MeterLockedStatusResponseMapper();
		mockdata.setMessage("message");
		mockdata.setStatus(true);
		//HttpServletRequest request = null ;
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("adid", "BUDIDHAK");
		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String adid = "BUDIDHAK";
        Mockito.when(meterEventValidateService.getLockedStatusByBoroughAndEventName(borough, eventName, adid)).thenReturn(mockdata);
        MeterLockedStatusResponseMapper actual =  rccDisconnectController.getLockedStatusByBoroughAndEventName(request,borough, eventName);
		Assert.assertEquals(null, null);
	}
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventValidateService).unlockEvents(adid);
		rccDisconnectController.unlockEvents(request);
	}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents2(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "");
		String adid = "";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventValidateService).unlockEvents(adid);
		rccDisconnectController.unlockEvents(request);
	}

}