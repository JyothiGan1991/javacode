package com.oru.service.impl;

import com.oru.dao.CircuitDao;
import com.oru.service.CircuitService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CircuitServiceImpl implements CircuitService {

    private final CircuitDao circuitDao;

    public CircuitServiceImpl(CircuitDao circuitDao) {
        this.circuitDao = circuitDao;
    }

    @Override
    public List<Map<String, String>> getCircuitData(int duration) {
        return circuitDao.getCircuitData(duration);
    }
}
