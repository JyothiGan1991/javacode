
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListNetworkDevicesReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListNetworkDevicesReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ListNetworkDevicesParametersType"/&gt;
 *         &lt;element name="SortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceSortMap" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListNetworkDevicesReqType", propOrder = {
    "searchParameters",
    "sortMap"
})
public class ListNetworkDevicesReqType {

    @XmlElement(name = "SearchParameters", required = true)
    protected ListNetworkDevicesParametersType searchParameters;
    @XmlElement(name = "SortMap")
    protected List<DeviceSortMap> sortMap;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link ListNetworkDevicesParametersType }
     *     
     */
    public ListNetworkDevicesParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListNetworkDevicesParametersType }
     *     
     */
    public void setSearchParameters(ListNetworkDevicesParametersType value) {
        this.searchParameters = value;
    }

    /**
     * Gets the value of the sortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DeviceSortMap }
     * 
     * 
     */
    public List<DeviceSortMap> getSortMap() {
        if (sortMap == null) {
            sortMap = new ArrayList<DeviceSortMap>();
        }
        return this.sortMap;
    }

}
