package com.coned.um.controller;

import java.util.HashMap;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;

import org.springframework.beans.factory.annotation.Value;

public class CustLoginConfig extends Configuration {
	//@Value("${aocc.app.name}")
	private String APP_NAME="AOCCApp";
	
	private static final String LOGIN_MODULE_CLASS = "weblogic.security.auth.login.UsernamePasswordLoginModule";
	@Override
	public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
		if(name.equals(APP_NAME)) {
			AppConfigurationEntry[] configArr = new AppConfigurationEntry[1];
			configArr[0] = new AppConfigurationEntry(LOGIN_MODULE_CLASS, 
					AppConfigurationEntry.LoginModuleControlFlag.SUFFICIENT, 
					new HashMap<String, Object>());
			return configArr;
		}
		throw new RuntimeException("Expected app: " +APP_NAME+", but got: "+name);
	}
}
