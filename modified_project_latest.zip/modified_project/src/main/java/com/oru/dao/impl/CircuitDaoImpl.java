package com.oru.dao.impl;

import com.oru.dao.CircuitDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class CircuitDaoImpl implements CircuitDao {

    private final JdbcTemplate jdbcTemplate;

    @Value("${circuit.query}")
    private String circuitQuery;

    public CircuitDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Map<String, String>> getCircuitData(int duration) {

        Object[] params = new Object[] {
            duration,  // first ?
            duration   // second ?
        };

        return jdbcTemplate.query(
            circuitQuery,
            params,
            (rs, rowNum) -> {
                Map<String, String> row = new HashMap<>();
                row.put("fid", String.valueOf(rs.getInt("fid")));
                row.put("circuit", rs.getString("circuit"));
                return row;
            }
        );
    }
}
