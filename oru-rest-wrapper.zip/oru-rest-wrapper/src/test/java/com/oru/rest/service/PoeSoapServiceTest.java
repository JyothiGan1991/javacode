package com.oru.rest.service;

import com.oru.rest.dto.IncidentCountRequest;
import com.oru.rest.dto.IsGasMainRequest;
import com.oru.rest.dto.VerifyPoleRequest;
import com.oru.rest.exception.SoapServiceException;
import com.oru.rest.service.poe.PoeSoapService;
import com.oru.soap.poe.generated.POEServiceException;
import com.oru.soap.poe.generated.POEServiceException_Exception;
import com.oru.soap.poe.generated.POEWebServicesSEI;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PoeSoapServiceTest {

    @Mock private POEWebServicesSEI soapClient;
    private PoeSoapService service;

    @BeforeEach
    void setUp() { service = new PoeSoapService(soapClient); }

    @Test
    void isGasMain_success() throws Exception {
        when(soapClient.isGasMain("p", 50)).thenReturn(true);
        assertTrue(service.isGasMain(new IsGasMainRequest("p", 50)));
    }

    @Test
    void isGasMain_fault() throws Exception {
        when(soapClient.isGasMain(any(), anyInt()))
                .thenThrow(new POEServiceException_Exception("f", new POEServiceException()));
        assertThrows(SoapServiceException.class, () -> service.isGasMain(new IsGasMainRequest("p", 1)));
    }

    @Test
    void verifyPole_success() throws Exception {
        when(soapClient.verifyPole(1, 2)).thenReturn(true);
        assertTrue(service.verifyPole(new VerifyPoleRequest(1, 2)));
    }

    @Test
    void incidentCount_success() throws Exception {
        when(soapClient.incidentCount(any(), any(), any(), any())).thenReturn(5);
        assertEquals(5, service.incidentCount(new IncidentCountRequest(null, null, null, null)));
    }
}
