package com.coned.model;

import java.sql.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_meter_event_load", schema = "AMI_LOAD_SHEDDING")
public class MeterEventLoad {

	@Id
	@JsonIgnore
	@Column(name = "METER_EVENT_LOAD_ID")
	private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "METER_EVENT_LOAD_ID")
    private FinalizedEventList finevent;
	
	@Column(name = "event_name")
	private String eventname;

	@Column(name = "boro_muni")
	private String borough;

	@Column(name = "meter_number")
	private String meterNumber;

	public String getMeterNumber() {
		return meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public MeterEventLoad() {

	}

	public MeterEventLoad(Long id, String eventname, String borough, String meterNumber) {
		this.id = id;
		this.eventname = eventname;
		this.borough = borough;
		this.meterNumber = meterNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	@Override
	public String toString() {
        return "User [id=" + id + ", eventname=" + eventname + ", borough=" + borough + ", meterNumber=" + meterNumber + "]";
	}
}
