
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UIQDeviceStateTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UIQDeviceStateTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_NEW"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INSTALLED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_DISCOVERED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INITIALIZING"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INIT_FAILED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INITIALIZED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_ACTIVE"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INACTIVE"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_UNREACHABLE"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_REMOVED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_MAINTENANCE"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_OPTIMIZE"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_RETIRED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_DISCONNECTED"/&gt;
 *     &lt;enumeration value="UIQ_DEVICE_STATE_SVC_DISCONECT"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "UIQDeviceStateTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum UIQDeviceStateTypeEnum {

    UIQ_DEVICE_STATE_NEW("UIQ_DEVICE_STATE_NEW"),
    UIQ_DEVICE_STATE_INSTALLED("UIQ_DEVICE_STATE_INSTALLED"),
    UIQ_DEVICE_STATE_DISCOVERED("UIQ_DEVICE_STATE_DISCOVERED"),
    UIQ_DEVICE_STATE_INITIALIZING("UIQ_DEVICE_STATE_INITIALIZING"),
    UIQ_DEVICE_STATE_INIT_FAILED("UIQ_DEVICE_STATE_INIT_FAILED"),
    UIQ_DEVICE_STATE_INITIALIZED("UIQ_DEVICE_STATE_INITIALIZED"),
    UIQ_DEVICE_STATE_ACTIVE("UIQ_DEVICE_STATE_ACTIVE"),
    UIQ_DEVICE_STATE_INACTIVE("UIQ_DEVICE_STATE_INACTIVE"),
    UIQ_DEVICE_STATE_UNREACHABLE("UIQ_DEVICE_STATE_UNREACHABLE"),
    UIQ_DEVICE_STATE_REMOVED("UIQ_DEVICE_STATE_REMOVED"),
    UIQ_DEVICE_STATE_MAINTENANCE("UIQ_DEVICE_STATE_MAINTENANCE"),
    UIQ_DEVICE_STATE_OPTIMIZE("UIQ_DEVICE_STATE_OPTIMIZE"),
    UIQ_DEVICE_STATE_RETIRED("UIQ_DEVICE_STATE_RETIRED"),
    UIQ_DEVICE_STATE_DISCONNECTED("UIQ_DEVICE_STATE_DISCONNECTED"),
    UIQ_DEVICE_STATE_SVC_DISCONECT("UIQ_DEVICE_STATE_SVC_DISCONECT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    UIQDeviceStateTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UIQDeviceStateTypeEnum fromValue(String v) {
        for (UIQDeviceStateTypeEnum c: UIQDeviceStateTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
