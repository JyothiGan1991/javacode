package com.coned.rsmc.repository;

import java.math.BigDecimal;
import java.util.List;

import com.coned.rsmc.domain.Meter;

public interface OutageRepository {
	List<Meter> getMetersWithNullMacAddr();

	void updateMeters(List<Meter> mList, List<BigDecimal> ids, String finalStatus) throws Exception;

	void saveJob(List<Meter> disconnectMetersList);

	List<Meter> getMeters();
}