package com.coned.ls.repository;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.domain.ExecuteExternalCall;
import com.coned.ls.exception.ExternalCallException;

import com.coned.ls.mapper.ExternalCallResponseMapper;

import com.coned.ls.mapper.NewEventListRowMapper;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class to save the meters in the execute tables
 *
 */
@Repository
public class JdbcExecuteExternalCallRepository implements ExecuteExternalCallRepository{

private static final Logger LOGGER = LogManager.getLogger(JdbcExecuteExternalCallRepository.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;
	
	/*
	 * Method to save the meters in the execute details table.
	 *
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, value="oracleTx")
	public ExternalCallResponseMapper executeMeterEventList(final ExecuteExternalCall executeExternalCall) throws ExternalCallException {
		ExternalCallResponseMapper externalCallResponseMapper = new ExternalCallResponseMapper();
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_FIN_MET_DET_FOR_EXECUTE").returningResultSet("SP_FIN_MET_DET_FOR_EXECUTE",new NewEventListRowMapper());
		
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		
		inParamMap.put("Borough", executeExternalCall.getBorough());
		inParamMap.put("Event", executeExternalCall.getEventName());	
		inParamMap.put("ExecuteTime", DateUtils.getDate());
		inParamMap.put("OpeartorADID", "AN20025372");		
		
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
		
		Object object = simpleJdbcCallResult.get("TOTALCOUNT");
		int result = Integer.parseInt(object.toString());
		try{
			if( result == 1 ){
				persistExecuteMeterList(executeExternalCall.getBorough(), executeExternalCall.getEventName());
				externalCallResponseMapper.setSuccess(true);
				return externalCallResponseMapper;
			}else if(result > 1){
				externalCallResponseMapper.setSuccess(false);
				externalCallResponseMapper.setMessage("DUPLICATE_RECORD_FOUND");
				throw new ExternalCallException("DUPLICATE_RECORD_FOUND");
			}else{
				externalCallResponseMapper.setSuccess(false);
				externalCallResponseMapper.setMessage("RECORD_NOT_FOUND");
				throw new ExternalCallException("RECORD_NOT_FOUND");
			}
		}catch(ExternalCallException ex){
			LOGGER.error(ex.getMessage(), ex);
			throw new ExternalCallException(ex.getMessage(),ex);
		}		
	}
	
	/*
	 * Method to save the meters in the execute list table.
	 *
	 */
	private void persistExecuteMeterList(final String borough,	final String eventName) throws ExternalCallException{
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_EXECUTE_MET_LIST").returningResultSet("SP_EXECUTE_MET_LIST",new NewEventListRowMapper());
		
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("borough", borough);
		inParamMap.put("event", eventName);		
		
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
		
		int totalCountFinalize = Integer.parseInt(simpleJdbcCallResult.get("TOTALCOUNTFINALIZE").toString());
		int totalCountReject = Integer.parseInt(simpleJdbcCallResult.get("TOTALCOUNTEXECUTE").toString());
		
		try{
			if(! (totalCountFinalize == totalCountReject) ){
				throw new ExternalCallException("MISMATCH_RECORD_FOUND");
			}
		}catch(ExternalCallException ex){
			throw new ExternalCallException(ex.getMessage(),ex);
		}	
	}
}
