package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.repository.OpenEventRepository;

/**
 * 
 * Service class for Open Event.
 *
 */
@Service("openEventService")
public class OpenEventServiceImpl implements OpenEventService {
	private static final Logger LOGGER = LogManager.getLogger(OpenEventServiceImpl.class);


	@Autowired
	private OpenEventRepository openEventRepository;

    /*
     * Method to read list of new and active borough.
	 *
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getNewAndActiveBorough() {
		List<String> newAndActiveBoroughs=new ArrayList<String>();
		try {
		 newAndActiveBoroughs = openEventRepository.getNewAndActiveBorough();
		}catch(Exception e) {
			LOGGER.error("error while fetching the boros:", e);
		}
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	} 

    /*
     * Method to read list of new and active events.
	 *
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getNewAndActiveEvent() {
		List<String> newAndActiveEvents=new ArrayList<String>();

		try {
		 newAndActiveEvents = openEventRepository.getNewAndActiveEvent();
	}catch(Exception e) {
		LOGGER.error("error while fetching the events:", e);
	}
		return ResponseEntity.ok().body(newAndActiveEvents);
	}

    /*
     * Method to read list of new and active events by borough.
	 *
     * @Param borough String
     * 
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(final String borough) {	
		List<String> newAndActiveBoroughs = openEventRepository.getNewAndActiveEventByBorough(borough);
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	}
	
    /*
     * Method to read list of borough finalized for connect from database.
	 *
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getSubFinalizeBorough() {
		List<String> subFinalizeBorough = openEventRepository.getSubFinalizeBorough();
		return ResponseEntity.ok().body(subFinalizeBorough);
	}

    /*
     * Method to read list of event finalized for connect from database.
	 *
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getSubFinalizeEvent() {
		List<String> subFinalizeEvent = openEventRepository.getSubFinalizeEvent();
		return ResponseEntity.ok().body(subFinalizeEvent);
	}

    /*
     * Method to read list of event finalized for connect by borough from database.
	 *
     * @Param borough String
     * 
     * @return 		  ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getSubFinalizeEventByBorough(final String borough) {
		List<String> subFinalizeEventByBorough = openEventRepository.getSubFinalizeEventByBorough(borough);
		return ResponseEntity.ok().body(subFinalizeEventByBorough);
	}

    /*
     * Method to read list of sub event finalized for connect from database.
	 *
     * @Param borough   String
     * @Param eventName String
     * 
     * @return 		    ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getSubFinalizeEventByEventAndBorough(final String borought, final String eventName) {
		List<String> subFinalizeEventByEventAndBorough = openEventRepository.getSubFinalizeEventByEventAndBorough(borought, eventName);
		return ResponseEntity.ok().body(subFinalizeEventByEventAndBorough);
	}

    /*
     * Method to read list of borough for disconnected meters from database.
     * 
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getExecuteBorough() {
		List<String> newAndActiveBoroughs = openEventRepository.getExecuteBorough();
		return ResponseEntity.ok().body(newAndActiveBoroughs);
		
	}

    /*
     * Method to read list of event for disconnected meters from database.
     * 
     * @return ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>> getExecuteEvent() {
		List<String> newAndActiveBoroughs = openEventRepository.getExecuteEvent();
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	}

    /*
     * Method to read list of event for disconnected meters by borough from database.
     * 
     * @Param borough String
     * 
     * @return        ResponseEntity<List<String>>
     *                         
     */	
	@Override
	public ResponseEntity<List<String>>  getExecuteEventByBorough(final String borough) {
		List<String> newAndActiveBoroughs = openEventRepository.getExecuteEventByBorough(borough);
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	}
}
