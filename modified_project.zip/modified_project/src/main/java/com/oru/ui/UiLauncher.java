package com.oru.ui;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.oru"})
public class UiLauncher {
    public static void main(String[] args){
        SpringApplication.run(UiLauncher.class,args);
    }
}
