
package com.ssn.schema.service.v2_6.devicetypes;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WANTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WANTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_POTS"/>
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_CDMA_WIRELESS"/>
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_CDMA_PACKET"/>
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_ETHERNET"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WANTypeEnum")
@XmlEnum
public enum WANTypeEnum {

    GATEWAY_WAN_TYPE_POTS("GATEWAY_WAN_TYPE_POTS"),
    GATEWAY_WAN_TYPE_CDMA_WIRELESS("GATEWAY_WAN_TYPE_CDMA_WIRELESS"),
    GATEWAY_WAN_TYPE_CDMA_PACKET("GATEWAY_WAN_TYPE_CDMA_PACKET"),
    GATEWAY_WAN_TYPE_ETHERNET("GATEWAY_WAN_TYPE_ETHERNET"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    WANTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WANTypeEnum fromValue(String v) {
        for (WANTypeEnum c: WANTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
