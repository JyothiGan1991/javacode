package com.coned.ls.rest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RestClientBuilderTest {

	@Test
	public void getBaseURL() {
		final String value = "http://172.16.81.109:7001/rcc-api";
		
	}
}
