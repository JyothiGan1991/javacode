
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateMeterTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateMeterTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Mode" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ln_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ll_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_sqr_hr_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_n_sqr_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Scale_va_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Scale_vah_sf" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="Timebase" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleScalar" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleDivisor" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleDivisor" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleScalar" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="CurrTransRatio" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="VoltTransRatio" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="UtilQyMeterRegRatio" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="MasterPwd" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ReaderPwd" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="CustomerPwd" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="WakeupInterval" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="MicroAP" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBoolean" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="MeterTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="MeterTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateMeterTypeReq", propOrder = {
    "mode",
    "scaleVSqrHrLnSf",
    "scaleVSqrHrLlSf",
    "scaleISqrHrSf",
    "scaleINSqrSf",
    "scaleVaSf",
    "scaleVahSf",
    "timebase",
    "currSampleScalar",
    "currSampleDivisor",
    "voltSampleDivisor",
    "voltSampleScalar",
    "currTransRatio",
    "voltTransRatio",
    "utilQyMeterRegRatio",
    "masterPwd",
    "readerPwd",
    "customerPwd",
    "wakeupInterval",
    "microAP",
    "meterTypeConfigID",
    "meterTypeConfigName"
})
public class UpdateMeterTypeReq {

    @XmlElement(name = "Mode")
    protected MeterModeType mode;
    @XmlElement(name = "Scale_v_sqr_hr_ln_sf")
    protected NullableLong scaleVSqrHrLnSf;
    @XmlElement(name = "Scale_v_sqr_hr_ll_sf")
    protected NullableLong scaleVSqrHrLlSf;
    @XmlElement(name = "Scale_i_sqr_hr_sf")
    protected NullableLong scaleISqrHrSf;
    @XmlElement(name = "Scale_i_n_sqr_sf")
    protected NullableLong scaleINSqrSf;
    @XmlElement(name = "Scale_va_sf")
    protected NullableLong scaleVaSf;
    @XmlElement(name = "Scale_vah_sf")
    protected NullableLong scaleVahSf;
    @XmlElement(name = "Timebase")
    protected NullableLong timebase;
    @XmlElement(name = "CurrSampleScalar")
    protected NullableLong currSampleScalar;
    @XmlElement(name = "CurrSampleDivisor")
    protected NullableLong currSampleDivisor;
    @XmlElement(name = "VoltSampleDivisor")
    protected NullableLong voltSampleDivisor;
    @XmlElement(name = "VoltSampleScalar")
    protected NullableLong voltSampleScalar;
    @XmlElement(name = "CurrTransRatio")
    protected NullableLong currTransRatio;
    @XmlElement(name = "VoltTransRatio")
    protected NullableLong voltTransRatio;
    @XmlElement(name = "UtilQyMeterRegRatio")
    protected NullableString utilQyMeterRegRatio;
    @XmlElement(name = "MasterPwd")
    protected NullableString masterPwd;
    @XmlElement(name = "ReaderPwd")
    protected NullableString readerPwd;
    @XmlElement(name = "CustomerPwd")
    protected NullableString customerPwd;
    @XmlElement(name = "WakeupInterval")
    protected NullableInt wakeupInterval;
    @XmlElement(name = "MicroAP")
    protected NullableBoolean microAP;
    @XmlElement(name = "MeterTypeConfigID")
    protected Long meterTypeConfigID;
    @XmlElement(name = "MeterTypeConfigName")
    protected String meterTypeConfigName;

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setMode(MeterModeType value) {
        this.mode = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLnSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleVSqrHrLnSf() {
        return scaleVSqrHrLnSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLnSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleVSqrHrLnSf(NullableLong value) {
        this.scaleVSqrHrLnSf = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLlSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleVSqrHrLlSf() {
        return scaleVSqrHrLlSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLlSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleVSqrHrLlSf(NullableLong value) {
        this.scaleVSqrHrLlSf = value;
    }

    /**
     * Gets the value of the scaleISqrHrSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleISqrHrSf() {
        return scaleISqrHrSf;
    }

    /**
     * Sets the value of the scaleISqrHrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleISqrHrSf(NullableLong value) {
        this.scaleISqrHrSf = value;
    }

    /**
     * Gets the value of the scaleINSqrSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleINSqrSf() {
        return scaleINSqrSf;
    }

    /**
     * Sets the value of the scaleINSqrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleINSqrSf(NullableLong value) {
        this.scaleINSqrSf = value;
    }

    /**
     * Gets the value of the scaleVaSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleVaSf() {
        return scaleVaSf;
    }

    /**
     * Sets the value of the scaleVaSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleVaSf(NullableLong value) {
        this.scaleVaSf = value;
    }

    /**
     * Gets the value of the scaleVahSf property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getScaleVahSf() {
        return scaleVahSf;
    }

    /**
     * Sets the value of the scaleVahSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setScaleVahSf(NullableLong value) {
        this.scaleVahSf = value;
    }

    /**
     * Gets the value of the timebase property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getTimebase() {
        return timebase;
    }

    /**
     * Sets the value of the timebase property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setTimebase(NullableLong value) {
        this.timebase = value;
    }

    /**
     * Gets the value of the currSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getCurrSampleScalar() {
        return currSampleScalar;
    }

    /**
     * Sets the value of the currSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setCurrSampleScalar(NullableLong value) {
        this.currSampleScalar = value;
    }

    /**
     * Gets the value of the currSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getCurrSampleDivisor() {
        return currSampleDivisor;
    }

    /**
     * Sets the value of the currSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setCurrSampleDivisor(NullableLong value) {
        this.currSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getVoltSampleDivisor() {
        return voltSampleDivisor;
    }

    /**
     * Sets the value of the voltSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setVoltSampleDivisor(NullableLong value) {
        this.voltSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getVoltSampleScalar() {
        return voltSampleScalar;
    }

    /**
     * Sets the value of the voltSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setVoltSampleScalar(NullableLong value) {
        this.voltSampleScalar = value;
    }

    /**
     * Gets the value of the currTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getCurrTransRatio() {
        return currTransRatio;
    }

    /**
     * Sets the value of the currTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setCurrTransRatio(NullableLong value) {
        this.currTransRatio = value;
    }

    /**
     * Gets the value of the voltTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getVoltTransRatio() {
        return voltTransRatio;
    }

    /**
     * Sets the value of the voltTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setVoltTransRatio(NullableLong value) {
        this.voltTransRatio = value;
    }

    /**
     * Gets the value of the utilQyMeterRegRatio property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getUtilQyMeterRegRatio() {
        return utilQyMeterRegRatio;
    }

    /**
     * Sets the value of the utilQyMeterRegRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setUtilQyMeterRegRatio(NullableString value) {
        this.utilQyMeterRegRatio = value;
    }

    /**
     * Gets the value of the masterPwd property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getMasterPwd() {
        return masterPwd;
    }

    /**
     * Sets the value of the masterPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setMasterPwd(NullableString value) {
        this.masterPwd = value;
    }

    /**
     * Gets the value of the readerPwd property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getReaderPwd() {
        return readerPwd;
    }

    /**
     * Sets the value of the readerPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setReaderPwd(NullableString value) {
        this.readerPwd = value;
    }

    /**
     * Gets the value of the customerPwd property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getCustomerPwd() {
        return customerPwd;
    }

    /**
     * Sets the value of the customerPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setCustomerPwd(NullableString value) {
        this.customerPwd = value;
    }

    /**
     * Gets the value of the wakeupInterval property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getWakeupInterval() {
        return wakeupInterval;
    }

    /**
     * Sets the value of the wakeupInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setWakeupInterval(NullableInt value) {
        this.wakeupInterval = value;
    }

    /**
     * Gets the value of the microAP property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBoolean }
     *     
     */
    public NullableBoolean getMicroAP() {
        return microAP;
    }

    /**
     * Sets the value of the microAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBoolean }
     *     
     */
    public void setMicroAP(NullableBoolean value) {
        this.microAP = value;
    }

    /**
     * Gets the value of the meterTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMeterTypeConfigID() {
        return meterTypeConfigID;
    }

    /**
     * Sets the value of the meterTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMeterTypeConfigID(Long value) {
        this.meterTypeConfigID = value;
    }

    /**
     * Gets the value of the meterTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterTypeConfigName() {
        return meterTypeConfigName;
    }

    /**
     * Sets the value of the meterTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterTypeConfigName(String value) {
        this.meterTypeConfigName = value;
    }

}
