package com.coned.ls;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;

public class CustomInterceptor implements ClientInterceptor {

	@Override
	public void afterCompletion(MessageContext arg0, Exception arg1) throws WebServiceClientException {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean handleFault(MessageContext arg0) throws WebServiceClientException {
		System.out.println("Fault Message: " + arg0.getPropertyNames());
		return false;
	}

	@Override
	public boolean handleRequest(MessageContext arg) throws WebServiceClientException {
		System.out.println("Client Request Message: " + arg.getRequest());

		return true;

	}

	@Override
	public boolean handleResponse(MessageContext arg0) throws WebServiceClientException {
		System.out.println("Client Response Message: " + arg0.getResponse());
		return false;
	}

}
