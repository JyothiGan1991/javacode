package com.coned.ls.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.mapper.NewEventListRowMapper;

/**
 * 
 * Repository class to implement Authorization functionalities.
 *
 */
@Repository
public class JdbcAuthorizationRepository  implements AuthorizationRepository{

	private static final Logger LOGGER = LogManager.getLogger(JdbcAuthorizationRepository.class);
	
	@Autowired
	protected JdbcTemplate oracleJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;
	
	/*
	 * Method to check user is authorized to access RCC API's.
	 * 
	 * @param  operatorADID String
	 * @param  role 		String
     * @return 				boolean 
	 */	
	public boolean isOperatorAuthorized(final String operatorADID, final String role) throws OperatorAuthorizationException{
		
		Integer countOfOperatorWithRole = oracleJdbcTemplate.queryForObject("SELECT COUNT(UPPER(U.USER_AD_ID)) FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?",  new Object[]{operatorADID,role}, Integer.class);

		try{
			if(null != countOfOperatorWithRole && Integer.valueOf(countOfOperatorWithRole) == 1){
				LOGGER.info(String.format("Operator successfully authorized"));
				
				return true;
			}else{
				throw new OperatorAuthorizationException("ACCESS_DENIED");
			}
		}
		catch (OperatorAuthorizationException ex) {
			LOGGER.error(ex.getMessage(), ex);
			
			throw new OperatorAuthorizationException(ex.getMessage(),ex);
		}
	}

	/*
	 * Method to save the apiKey in the database.
	 * 
	 * @param  adid   String
	 * @param  apiKey String
	 * @param  type   String
     * @return 		  OperatorLoginDetail 
	 */	
	@Override
	public OperatorLoginDetail persistApi(OperatorLoginDetail operatorLoginDetail)throws OperatorAuthorizationException {
		final String SELECT_SQL = "SELECT URM.USER_ROLE_ID FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?";
		final String SELECT_SQL_CLAIM = "SELECT U.ROLE_ID FROM LS_USER U INNER JOIN LS_USER_ROLE_MAPPING URM ON UPPER(URM.FK_USER_AD_ID) = UPPER(U.USER_AD_ID)  INNER JOIN LS_USER_ROLE UR ON UR.ROLE_ID = urm.FK_ROLE_ID WHERE UPPER(U.USER_AD_ID) = UPPER(?) AND ur.role = ?";
		final String INSERT_SQL = "INSERT INTO LS_USER_LOGIN(LOGIN_TIMESTAMP,API_KEY,API_KEY_STATUS,USER_LOGIN_STATUS,FK_USER_ROLE_ID) values(?,?,?,?,?)";

		try{
			if (operatorLoginDetail.getApiKeyStatus() == 12 && operatorLoginDetail.getLoginStatus() == 11) {
				unlockEvents(operatorLoginDetail.getAdid());
			}
			
			Integer userRoleId = oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{operatorLoginDetail.getAdid(), operatorLoginDetail.getRole()}, Integer.class);
			Integer userClaimId = oracleJdbcTemplate.queryForObject(SELECT_SQL_CLAIM,  new Object[]{operatorLoginDetail.getAdid(), operatorLoginDetail.getRole()}, Integer.class);

			if(userRoleId > 0){
				updateExistingLogin(userRoleId);
				
				List<OperatorLoginDetail> operatorLoginDetails = new  ArrayList<OperatorLoginDetail>();
				operatorLoginDetails.add(operatorLoginDetail);
				
				int[][] batchUpdate = oracleJdbcTemplate.batchUpdate(INSERT_SQL, operatorLoginDetails, 1,
		                new ParameterizedPreparedStatementSetter<OperatorLoginDetail>() {
		                    public void setValues(PreparedStatement ps, OperatorLoginDetail operatorLoginDetail)
								throws SQLException {
		                    	ps.setDate(1, new java.sql.Date(operatorLoginDetail.getLoginTimeStamp().getTime()));
						    	ps.setString(2, operatorLoginDetail.getApiKey());
						    	ps.setInt(3, operatorLoginDetail.getApiKeyStatus());
						    	ps.setInt(4, operatorLoginDetail.getLoginStatus());
						    	ps.setInt(5, userRoleId);
		                    }
		                });
				
				int update = 0;
				if(batchUpdate != null){
					update = batchUpdate[0].length;
				}
				LOGGER.debug("userClaimId? "+userClaimId+" update? "+update);
				if(update == 1){
					operatorLoginDetail.setUserRoleId(userRoleId);
					String userClaim = "Operator";
					if(userClaimId == 3) {
						userClaim = "Admin";
					}
					operatorLoginDetail.setUserClaim(userClaim);
					operatorLoginDetail.setResponseStatus(true);
					
					return operatorLoginDetail;
				}throw new OperatorAuthorizationException("API_KEY_NOT_PERSIST");
			} throw new OperatorAuthorizationException("MISSMATCH_FOUND_USER_AND_ROLE");
		}catch(OperatorAuthorizationException ex){
			LOGGER.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(),ex);
		}
	}
	
	/*
	 * Method to unlock the event.
	 * 
	 * @param  adid	String
     * @return 		void 
	 */
	private void unlockEvents(String adid) throws OperatorAuthorizationException {
		try{
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{adid});
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException("Exception ocured while unlocking the event.");
		}
	}
	
	/*
	 * Method to update login details in the database.
	 * 
	 * @param  userRoleId int
     * @return 		  	  int 
	 */	
	private int updateExistingLogin(final int userRoleId){
		final String UPDATE_SQL = "UPDATE  LS_USER_LOGIN SET API_KEY_STATUS = ?, USER_LOGIN_STATUS = ? WHERE FK_USER_ROLE_ID = ? AND USER_LOGIN_STATUS = 10";
		
		List<OperatorLoginDetail> operatorLoginDetails = new  ArrayList<OperatorLoginDetail>();
		OperatorLoginDetail operatorLoginDetail = new  OperatorLoginDetail();
		
		operatorLoginDetail.setApiKeyStatus(12);
		operatorLoginDetail.setLoginStatus(9);
		operatorLoginDetail.setUserRoleId(userRoleId);
		operatorLoginDetails.add(operatorLoginDetail);
		
		int[][] batchUpdate = oracleJdbcTemplate.batchUpdate(UPDATE_SQL, operatorLoginDetails, 1,
                new ParameterizedPreparedStatementSetter<OperatorLoginDetail>() {
                    public void setValues(PreparedStatement ps, OperatorLoginDetail operatorLoginDetail)
						throws SQLException {
				    	ps.setInt(1, operatorLoginDetail.getApiKeyStatus());
				    	ps.setInt(2, operatorLoginDetail.getLoginStatus());
				    	ps.setInt(3, operatorLoginDetail.getUserRoleId());
                    }
                });
		
		if(batchUpdate != null){
			return batchUpdate[0].length;
		} else {
			return 0;
		}
	}
	
	/*
	 * Method to read login details of the user.
	 * 
	 * @param  adid String
	 * @param  role String
     * @return 		OperatorLoginDetail 
	 */	
	@Override
	public OperatorLoginDetail getOperatorLoginDetail(final String adid, final String role) throws OperatorAuthorizationException {
		OperatorLoginDetail operatorLoginDetail= new OperatorLoginDetail();
		
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_OPERATOR_LOGIN_DETAIL").returningResultSet("SP_OPERATOR_LOGIN_DETAIL",new NewEventListRowMapper());

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("ADID", adid);
		inParamMap.put("ROLE_ID", 20001);		
		inParamMap.put("LOGIN_STATUS", 10);
		
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
		operatorLoginDetail.setAdid(simpleJdbcCallResult.get("ADID").toString());
		operatorLoginDetail.setApiKey(simpleJdbcCallResult.get("API_KEY").toString());
		operatorLoginDetail.setApiKeyStatus(Integer.valueOf(simpleJdbcCallResult.get("API_KEY_STATUS").toString()));
		operatorLoginDetail.setLoginStatus(Integer.valueOf(simpleJdbcCallResult.get("LOGIN_STATUS").toString()));
		operatorLoginDetail.setLoginTimeAsString(simpleJdbcCallResult.get("LOGIN_TIME").toString());
		operatorLoginDetail.setResponseStatus(true);
		operatorLoginDetail.setRole(simpleJdbcCallResult.get("ROLE_NAME").toString());
		operatorLoginDetail.setUserRoleId(Integer.valueOf(simpleJdbcCallResult.get("USER_ROLE_ID").toString()));
		operatorLoginDetail.setRoleId(Integer.valueOf(simpleJdbcCallResult.get("ROLE_ID").toString()));
		
		return operatorLoginDetail;
	}

	/*
	 * Method to call API Engine to check user is authorized to access API's.
	 * 
	 * @param  adid   		String
	 * @param  apiKey 		String
	 * @param  apiKeyStatus int
	 * @param  loginStatus  int
     * @return 				boolean 
	 */	
	@Override
	public boolean isAPIEndpointAuthorizeed(final String adid,final String apiKey,final int apiKeyStatus, final int loginStatus) throws OperatorAuthorizationException { //throws OperatorAuthorizationException {
		String SELECT_SQL = "SELECT count(ul.api_key) from LS_USER_LOGIN ul inner join LS_USER_ROLE_MAPPING urm on urm.user_role_id = ul.fk_user_role_id inner join ls_user lu on UPPER(lu.user_ad_id) = UPPER(urm.fk_user_ad_id) where ul.api_key = ? and ul.api_key_status = ? and ul.user_login_status = ? and UPPER(lu.user_ad_id) = UPPER(?)";
		Integer countOfOperatorWithRole = oracleJdbcTemplate.queryForObject(SELECT_SQL,  new Object[]{apiKey,apiKeyStatus,loginStatus,adid}, Integer.class);
		
		try{
			if(null != countOfOperatorWithRole && Integer.valueOf(countOfOperatorWithRole) == 1){
				LOGGER.info(String.format("Operator successfully authorized"));
				
				return true;
			}else{
				return false;
			}
		}
		catch (OperatorAuthorizationException ex) {
			LOGGER.error(ex.getMessage(), ex);
			
			throw new OperatorAuthorizationException("ACCESS_DENIED", HttpStatus.UNAUTHORIZED);
		}
	}
}