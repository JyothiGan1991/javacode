
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericMeterReadElementType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericMeterReadElementType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="StringValue" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="ByteValue" type="{http://www.w3.org/2001/XMLSchema}byte"/&gt;
 *           &lt;element name="ShortValue" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *           &lt;element name="IntegerValue" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *           &lt;element name="LongValue" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *           &lt;element name="FloatValue" type="{http://www.w3.org/2001/XMLSchema}float"/&gt;
 *           &lt;element name="DoubleValue" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *           &lt;element name="BooleanValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *           &lt;element name="TimeStampValue" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}TimestampType"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericMeterReadElementType", propOrder = {
    "name",
    "stringValue",
    "byteValue",
    "shortValue",
    "integerValue",
    "longValue",
    "floatValue",
    "doubleValue",
    "booleanValue",
    "timeStampValue"
})
public class GenericMeterReadElementType {

    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "StringValue")
    protected String stringValue;
    @XmlElement(name = "ByteValue")
    protected Byte byteValue;
    @XmlElement(name = "ShortValue")
    protected Short shortValue;
    @XmlElement(name = "IntegerValue")
    protected Integer integerValue;
    @XmlElement(name = "LongValue")
    protected Long longValue;
    @XmlElement(name = "FloatValue")
    protected Float floatValue;
    @XmlElement(name = "DoubleValue")
    protected Double doubleValue;
    @XmlElement(name = "BooleanValue")
    protected Boolean booleanValue;
    @XmlElement(name = "TimeStampValue")
    protected TimestampType timeStampValue;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the stringValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStringValue() {
        return stringValue;
    }

    /**
     * Sets the value of the stringValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStringValue(String value) {
        this.stringValue = value;
    }

    /**
     * Gets the value of the byteValue property.
     * 
     * @return
     *     possible object is
     *     {@link Byte }
     *     
     */
    public Byte getByteValue() {
        return byteValue;
    }

    /**
     * Sets the value of the byteValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Byte }
     *     
     */
    public void setByteValue(Byte value) {
        this.byteValue = value;
    }

    /**
     * Gets the value of the shortValue property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getShortValue() {
        return shortValue;
    }

    /**
     * Sets the value of the shortValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setShortValue(Short value) {
        this.shortValue = value;
    }

    /**
     * Gets the value of the integerValue property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIntegerValue() {
        return integerValue;
    }

    /**
     * Sets the value of the integerValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIntegerValue(Integer value) {
        this.integerValue = value;
    }

    /**
     * Gets the value of the longValue property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLongValue() {
        return longValue;
    }

    /**
     * Sets the value of the longValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLongValue(Long value) {
        this.longValue = value;
    }

    /**
     * Gets the value of the floatValue property.
     * 
     * @return
     *     possible object is
     *     {@link Float }
     *     
     */
    public Float getFloatValue() {
        return floatValue;
    }

    /**
     * Sets the value of the floatValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Float }
     *     
     */
    public void setFloatValue(Float value) {
        this.floatValue = value;
    }

    /**
     * Gets the value of the doubleValue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDoubleValue() {
        return doubleValue;
    }

    /**
     * Sets the value of the doubleValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDoubleValue(Double value) {
        this.doubleValue = value;
    }

    /**
     * Gets the value of the booleanValue property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBooleanValue() {
        return booleanValue;
    }

    /**
     * Sets the value of the booleanValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBooleanValue(Boolean value) {
        this.booleanValue = value;
    }

    /**
     * Gets the value of the timeStampValue property.
     * 
     * @return
     *     possible object is
     *     {@link TimestampType }
     *     
     */
    public TimestampType getTimeStampValue() {
        return timeStampValue;
    }

    /**
     * Sets the value of the timeStampValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimestampType }
     *     
     */
    public void setTimeStampValue(TimestampType value) {
        this.timeStampValue = value;
    }

}
