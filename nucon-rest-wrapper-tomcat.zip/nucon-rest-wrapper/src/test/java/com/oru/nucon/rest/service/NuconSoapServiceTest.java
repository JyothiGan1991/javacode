package com.oru.nucon.rest.service;

import com.oru.nucon.rest.dto.AccountRequest;
import com.oru.nucon.rest.dto.ElectricInfoDto;
import com.oru.nucon.rest.dto.LocateInNrgViewerRequest;
import com.oru.nucon.rest.dto.PremiseRequest;
import com.oru.nucon.rest.dto.SendToNrgRequest;
import com.oru.nucon.rest.dto.XYCoordinatesRequest;
import com.oru.nucon.rest.exception.SoapServiceException;
import com.oru.nucon.soap.generated.ElectricInfo;
import com.oru.nucon.soap.generated.NuconWS;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NuconSoapServiceTest {

    @Mock
    private NuconWS soapClient;

    private NuconSoapService service;

    @BeforeEach
    void setUp() {
        service = new NuconSoapService(soapClient);
    }

    private ElectricInfo sampleInfo() {
        ElectricInfo info = new ElectricInfo();
        info.setCircuit("C1");
        info.setCode("CODE");
        info.setInvolt(120.0);
        info.setKVA1("10");
        info.setTransformer("T1");
        return info;
    }

    @Test
    void getElectricInfoByAccount_success() {
        when(soapClient.getElectricInfoByAccount("ACC123")).thenReturn(sampleInfo());

        ElectricInfoDto dto = service.getElectricInfoByAccount(new AccountRequest("ACC123"));

        assertNotNull(dto);
        assertEquals("C1", dto.getCircuit());
        assertEquals(120.0, dto.getInvolt(), 0.001);
        assertEquals("10", dto.getKva1());
        verify(soapClient).getElectricInfoByAccount("ACC123");
    }

    @Test
    void getElectricInfoByAccount_nullResult() {
        when(soapClient.getElectricInfoByAccount(anyString())).thenReturn(null);
        assertNull(service.getElectricInfoByAccount(new AccountRequest("x")));
    }

    @Test
    void getElectricInfoByAccount_error() {
        when(soapClient.getElectricInfoByAccount(anyString())).thenThrow(new RuntimeException("down"));
        assertThrows(SoapServiceException.class,
                () -> service.getElectricInfoByAccount(new AccountRequest("x")));
    }

    @Test
    void getElectricInfoByPremise_success() {
        when(soapClient.getElectricInfoByPremise("PREM1")).thenReturn(sampleInfo());
        ElectricInfoDto dto = service.getElectricInfoByPremise(new PremiseRequest("PREM1"));
        assertEquals("C1", dto.getCircuit());
        verify(soapClient).getElectricInfoByPremise("PREM1");
    }

    @Test
    void getElectricInfoByXYCoordinates_success() {
        when(soapClient.getElectricInfoByXYCoordinates("100", "200")).thenReturn(sampleInfo());
        ElectricInfoDto dto = service.getElectricInfoByXYCoordinates(new XYCoordinatesRequest("100", "200"));
        assertEquals("T1", dto.getTransformer());
        verify(soapClient).getElectricInfoByXYCoordinates("100", "200");
    }

    @Test
    void sendToNRG_success() {
        doNothing().when(soapClient).sendToNRG(anyString(), any(), anyString());
        service.sendToNRG(new SendToNrgRequest("a", 1, "b"));
        verify(soapClient).sendToNRG("a", 1, "b");
    }

    @Test
    void sendToNRG_error() {
        doThrow(new RuntimeException("fail")).when(soapClient).sendToNRG(anyString(), any(), anyString());
        assertThrows(SoapServiceException.class,
                () -> service.sendToNRG(new SendToNrgRequest("a", 1, "b")));
    }

    @Test
    void locateInNRGViewer_success() {
        doNothing().when(soapClient).locateInNRGViewer(any(), any(), any(), anyString());
        service.locateInNRGViewer(new LocateInNrgViewerRequest(1, 2, 3, "label"));
        verify(soapClient).locateInNRGViewer(1, 2, 3, "label");
    }

    @Test
    void locateInNRGViewer_error() {
        doThrow(new RuntimeException("fail")).when(soapClient).locateInNRGViewer(any(), any(), any(), anyString());
        assertThrows(SoapServiceException.class,
                () -> service.locateInNRGViewer(new LocateInNrgViewerRequest(1, 2, 3, "x")));
    }
}
