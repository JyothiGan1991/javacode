
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddDeviceReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddDeviceReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditBaseDeviceType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddNetworkBaseDeviceType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddDeviceReqType", propOrder = {
    "commonAttributes"
})
@XmlSeeAlso({
    EditDeviceNewReqType.class
})
public class AddDeviceReqType
    extends AddEditBaseDeviceType
{

    @XmlElement(name = "CommonAttributes", required = true)
    protected AddNetworkBaseDeviceType commonAttributes;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link AddNetworkBaseDeviceType }
     *     
     */
    public AddNetworkBaseDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddNetworkBaseDeviceType }
     *     
     */
    public void setCommonAttributes(AddNetworkBaseDeviceType value) {
        this.commonAttributes = value;
    }

}
