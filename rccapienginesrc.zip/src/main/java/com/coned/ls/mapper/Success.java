package com.coned.ls.mapper;

public class Success {
	
}
