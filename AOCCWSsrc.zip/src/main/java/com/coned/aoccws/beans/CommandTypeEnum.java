package com.coned.aoccws.beans;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * Division Types to use
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum CommandTypeEnum {
	/** Disconnect */
	D("DISCONNECT"),
	/** Connect */
	C("CONNECT");

	private String value;

	public static final Map<String, String> cMap = new HashMap<String, String>();

	/**
	 * @param value
	 *            division to set
	 */
	private CommandTypeEnum(String value) {
		this.value = value;
	}

	/**
	 * @return current division
	 */
	public String getValue() {
		return this.value;
	}

	/** creates a Map of Enum and their values */
	static {
		for (CommandTypeEnum d : EnumSet.allOf(CommandTypeEnum.class)) {
			// if (!d.equals(Undefined))
			cMap.put(d.toString(), d.getValue());
		}
	}
	//@JsonCreator
	public static CommandTypeEnum getEnumFromValue(String s) {
		for (CommandTypeEnum denum : CommandTypeEnum.values()) {
			if (denum.getValue().equalsIgnoreCase(s))
				return denum;
		}
		return null;
		// return Undefined;
	}
}
