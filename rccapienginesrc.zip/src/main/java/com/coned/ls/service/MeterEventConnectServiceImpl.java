package com.coned.ls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.repository.MeterEventConnectRepository;

/**
 * 
 * Service class for RCC Connect.
 *
 */
@Service("meterEventConnectService")
public class MeterEventConnectServiceImpl implements MeterEventConnectService {

	@Autowired
	private MeterEventConnectRepository meterEventConnectRepository;
	
    /*
     * Method to return list of disconnected meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @Parm meterOpenEvent MeterOpenEvent 
     * 
     * @return 				ResponseEntity<MeterConnectResponseMapper> 
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent) throws Exception {
		return meterEventConnectRepository.getValidMetersForConnect(meterOpenEvent);
	}

    /*
     * Method to return list of values for a given field.
     * 
     * @Parm borough  	String 
     * @Parm eventName  String
     * @Parm fieldName  String
     * 
     * @return 			ResponseEntity<List<String>>  
     *                         
     */
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		List<String> fieldValues = meterEventConnectRepository.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		return ResponseEntity.ok().body(fieldValues);
	}
	
    /*
     * Method to return list of values for a given field for Connected Meters.
     * 
     * @Parm borough  	String 
     * @Parm eventName  String
     * @Parm fieldName  String
     * 
     * @return 			ResponseEntity<List<String>>  
     *                         
     */
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		List<String> fieldValues = meterEventConnectRepository.getConnectedMetersFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		return ResponseEntity.ok().body(fieldValues);
	}
	
    /*
     * Method to return list of connected meters created for the event.
     * 
     * @Parm borough  		String
     * @Parm eventName  	String 
     * @Parm startRowIndex  int
     * @Parm batchSize  	int
     * 
     * @return 				ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getConnectedMeters(final MeterOpenEvent meterOpenEvent) throws MeterEventConnectException {
		return meterEventConnectRepository.getConnectedMeters(meterOpenEvent);
	}

    /*
     * Method to finalize the list of meters selected in the Sub Event for connect.
     * 
     * @Parm subEvent SubEvent
     * 
     * @return		  ResponseEntity<MeterFinalizeResponseMapper> 
     *                         
     */
	@Override
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(final SubEvent subEvent)	throws Exception {
		return meterEventConnectRepository.finalizeSubEventMeter(subEvent);
	}
	
    /*
     * Method to search list of disconnected meters created for event.
     * 
     * @Parm meterSearch MeterSearch 
     * 
     * @return 			 ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper>  searchMeters(final MeterSearch meterSearch) {
		MeterConnectResponseMapper searchMeters = meterEventConnectRepository.searchMeters(meterSearch);
		return ResponseEntity.ok().body(searchMeters);
	}

    /*
     * Method to search list of connected meters created for event.
     * 
     * @Parm meterSearch MeterSearch 
     * 
     * @return 			 ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper>  searchMeterConnected(final MeterSearch meterSearch) {
		MeterConnectResponseMapper searchMeters = meterEventConnectRepository.searchMeterConnected(meterSearch);
		return ResponseEntity.ok().body(searchMeters);
	}
	
    /*
     * Method to return Suffix for Sub Event.
     * 
     * @Param borough  	String
     * @Param eventName String 
     * 
     * @return			ResponseEntity<Long>
     *                         
     */
	@Override
	public ResponseEntity<Long> getSubEventSuffix(final String borough, final String event) {
		return meterEventConnectRepository.getSubEventSuffix(borough, event);
	}
	
    /*
     * Method to return list of meters in the Sub Event.
     * 
     * @Param borough 		String 
     * @Param eventName 	String
     * @Param subEventName	String
     * @Param startRowIndex int
     * @Param batchSize  	int
     * 
     * @return 				ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex, final int batchSize) {
		return meterEventConnectRepository.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize);
	}
	
    /*
     * Method to return list of meters in the Sub Event.
     * 
     * @Param subEvent SubEvent 
     * 
     * @return 		   ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper>  getSubEventMeters(final SubEvent subEvent) {
		System.out.println("2");
		MeterConnectResponseMapper searchMeters = meterEventConnectRepository.getSubEventMeters(subEvent);
		return ResponseEntity.ok().body(searchMeters);
	}

    /*
     * Method to check event is locked.
     * 
     * @Param borough   String
     * @Param eventName String
     * @Param adid      String
     * 
     * @return			MeterLockedStatusResponseMapper
     *                         
     */
	@Override
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid) {
		return meterEventConnectRepository.isEventLocked(borough, eventName, adid);
	}
	
    /*
     * Method to unlocked the events.
     * 
     * @Param adid String
     * 
     * @return	   void
     *                         
     */
	@Override
	public void unlockEvents(final String adid) {
		meterEventConnectRepository.unlockEvents(adid);
	}
}
