
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RouteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RouteType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GatewayHop" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GatewayHopType"/&gt;
 *         &lt;element name="Hop" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}HopType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RouteType", propOrder = {
    "gatewayHop",
    "hop"
})
public class RouteType {

    @XmlElement(name = "GatewayHop", required = true)
    protected GatewayHopType gatewayHop;
    @XmlElement(name = "Hop", required = true)
    protected List<HopType> hop;

    /**
     * Gets the value of the gatewayHop property.
     * 
     * @return
     *     possible object is
     *     {@link GatewayHopType }
     *     
     */
    public GatewayHopType getGatewayHop() {
        return gatewayHop;
    }

    /**
     * Sets the value of the gatewayHop property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayHopType }
     *     
     */
    public void setGatewayHop(GatewayHopType value) {
        this.gatewayHop = value;
    }

    /**
     * Gets the value of the hop property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hop property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHop().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HopType }
     * 
     * 
     */
    public List<HopType> getHop() {
        if (hop == null) {
            hop = new ArrayList<HopType>();
        }
        return this.hop;
    }

}
