package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

/**
 * Interface for Open Event Service class.
 *
 */
public interface OpenEventService {
	
	// RCC Disconnect
	public ResponseEntity<List<String>> getNewAndActiveBorough();
	public ResponseEntity<List<String>> getNewAndActiveEvent();
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(final String borough);
	
	// RCC Connect - Open event
	public ResponseEntity<List<String>> getExecuteBorough();
	public ResponseEntity<List<String>> getExecuteEvent();
	public ResponseEntity<List<String>> getExecuteEventByBorough(final String borough);
	
	//RCC Connect 
	public ResponseEntity<List<String>> getSubFinalizeBorough();
	public ResponseEntity<List<String>> getSubFinalizeEvent();
	public ResponseEntity<List<String>> getSubFinalizeEventByBorough(final String borough);
	public ResponseEntity<List<String>> getSubFinalizeEventByEventAndBorough(final String borought, final String eventName);
}
