/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class TransformerAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(TransformerAttributesThread.class);    

    TransformerAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {

//transformer.street,
            
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,    \n" +
"                                     geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, transformer.circuit,transformer.seg,    \n" +
"                                     transformer.subseg,transformer.trangridx,transformer.trangridy,    \n" +
"                                     transformer.div,transformer.code,transformer.kva1,transformer.kva2,transformer.kva3,transformer.custowned,    \n" +
"                                     transformer.volt,transformer.tax,transformer.wms,transformer.code,transformer.fid1,transformer.fid2,    \n" +
"                                     transformer.bank1,transformer.bank2,transformer.bank3,transformer.tcn_1,transformer.tcn_2,transformer.tcn_3,                        \n" +
"                                     transformer.serial1,transformer.serial2,transformer.serial3,transformer.involt,transformer.neutral,transformer.xfmr2,transformer.xfmr3,transformer.outvolt,       \n" +
"                                     transformer.designdstat,transformer.status,transformer.mainline,devAddress.state,devAddress.town,devAddress.street                 \n" +
"                                     from     \n" +
"                                     ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_trans transformer,ed_assetlocation devAddress    \n" +
"                                     where geom.fid = transformer.fid    \n" +
"                                     and geom.featuretypeid = def.featuretypeid      \n" +
"                                     and geom.fid = devAddress.fid \n" +
"                                    and transformer.fid in (" + assetToQuery + ") "; 
                    
            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    
                    String attributes = rs.getString("attributes");
                    if (attributes != null) {
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            asset.setNmsAttributes(val[0], val[1]);
                        }
                    }

                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);

                    String subSegment = rs.getString("subseg");
                    asset.setNmsAttributes("subSegment", subSegment);

                    int gridx = rs.getInt("trangridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("trangridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));
                    
                    int div = rs.getInt("div");
                    asset.setNmsAttributes("div", Integer.toString(div));
                    
                    String code = rs.getString("code");
                    asset.setNmsAttributes("code", code);
                    
                    int kva1 = rs.getInt("kva1");
                    asset.setNmsAttributes("kva1", Integer.toString(kva1));

                    int kva2 = rs.getInt("kva2");
                    asset.setNmsAttributes("kva2", Integer.toString(kva2));

                    int kva3 = rs.getInt("kva3");
                    asset.setNmsAttributes("kva3", Integer.toString(kva3));
                    
                    boolean custowned = rs.getBoolean("custowned");
                    asset.setNmsAttributes("custowned", String.valueOf(custowned));

                    double volt = rs.getFloat("volt");
                    asset.setNmsAttributes("volt", String.format("%.2f", volt));  
                    
                    String tax = rs.getString("tax");
                    asset.setNmsAttributes("tax", tax);
                    
                    String wms = rs.getString("wms");
                    asset.setNmsAttributes("wms", wms);
                    
                    String town = rs.getString("town");
                    asset.setNmsAttributes("town", town);                    
                    
                    String state = rs.getString("state");
                    asset.setNmsAttributes("state", state);                                        
                    

// new attributes added on 10/26
                    
                    String xfmr2 = rs.getString("xfmr2");
                    asset.setNmsAttributes("xfmr2", xfmr2);
                    
                    String xfmr3 = rs.getString("xfmr3");
                    asset.setNmsAttributes("xfmr3", xfmr3);

                    int tcn_1 = rs.getInt("tcn_1");
                    asset.setNmsAttributes("tcn_1", Integer.toString(tcn_1));
                    
                    int tcn_2 = rs.getInt("tcn_2");
                    asset.setNmsAttributes("tcn_2", Integer.toString(tcn_2));

                    int tcn_3 = rs.getInt("tcn_3");
                    asset.setNmsAttributes("tcn_3", Integer.toString(tcn_3));
                    
                    String serial1 = rs.getString("serial1");
                    asset.setNmsAttributes("serial1", serial1);
                    
                    String serial2 = rs.getString("serial2");
                    asset.setNmsAttributes("serial2", serial2);

                    String serial3 = rs.getString("serial3");
                    asset.setNmsAttributes("serial3", serial3);
                    
                    String address = rs.getString("street");
                    asset.setNmsAttributes("location", address);                    

                    int bank1 = rs.getInt("bank1");
                    asset.setNmsAttributes("bank1", Integer.toString(bank1));
                    
                    int bank2 = rs.getInt("bank2");
                    asset.setNmsAttributes("bank2", Integer.toString(bank2));
                    
                    int bank3 = rs.getInt("bank3");
                    asset.setNmsAttributes("bank3", Integer.toString(bank3));
                    
                    int neutral = rs.getInt("neutral");
                    asset.setNmsAttributes("neutral", Integer.toString(neutral));

                    double outvolt = rs.getFloat("outvolt");
                    asset.setNmsAttributes("outvolt", String.valueOf(outvolt));
                    
                    double involt = rs.getFloat("involt");
                    asset.setNmsAttributes("involt", String.valueOf(involt));
                    
// end of attributes
                    
                    String street = rs.getString("street");
                    asset.setNmsAttributes("street", street);
                    

                    String status = rs.getString("status");
                    asset.setNmsAttributes("status", status);

                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);
                    

                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);                    

                    int fid1 = rs.getInt("fid1");
                    asset.setNmsAttributes("fid1", Integer.toString(fid1));

                    int fid2 = rs.getInt("fid2");
                    asset.setNmsAttributes("fid2", Integer.toString(fid2));
                    
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
