package com.oru.nucon.rest.config;

import com.oru.nucon.soap.generated.NuconWS;
import com.oru.nucon.soap.generated.NuconWSService;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.BindingProvider;

@Configuration
public class SoapClientConfig {

    private static final Logger log = LoggerFactory.getLogger(SoapClientConfig.class);

    @Value("${nucon.soap.endpoint-url}")
    private String endpointUrl;

    @Value("${nucon.soap.connect-timeout-ms:5000}")
    private long connectTimeoutMs;

    @Value("${nucon.soap.read-timeout-ms:10000}")
    private long readTimeoutMs;

    @Bean
    public NuconWS nuconWsClient() {
        log.info("Creating NuconWS SOAP client for endpoint: {}", endpointUrl);

        NuconWSService service = new NuconWSService();
        NuconWS port = service.getNuconWSPort();

        BindingProvider bp = (BindingProvider) port;
        bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

        try {
            org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPClientPolicy policy = new HTTPClientPolicy();
            policy.setConnectionTimeout(connectTimeoutMs);
            policy.setReceiveTimeout(readTimeoutMs);
            http.setClient(policy);
        } catch (Exception e) {
            log.warn("Could not configure CXF HTTP timeouts: {}", e.getMessage());
        }

        return port;
    }
}
