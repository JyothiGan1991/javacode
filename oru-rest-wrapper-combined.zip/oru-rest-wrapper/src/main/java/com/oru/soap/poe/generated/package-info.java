@javax.xml.bind.annotation.XmlSchema(namespace = "http://poe.oru.com/")
package com.oru.soap.poe.generated;
