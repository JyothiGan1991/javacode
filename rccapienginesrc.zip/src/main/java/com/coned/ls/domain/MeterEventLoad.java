package com.coned.ls.domain;

import java.util.Date;

public class MeterEventLoad {

	private long meterEventLoadId;		
	private String meterType;
	private String demand;
	private String borough;
	private String network;
	private String networkAbbr;
	private String feeder;
	private String feederNetworkAbbr;
	private String sdpid;
	private String meterNumber;
	private String accountNumber;
	private String customerName;
	private String phone1;
	private String customerZipCode;
	private String buildingNumber;
	private String phone2;
	private String serviceAddress;
	private String eventName;
	private Date insertTime;
	private String operatorAdID;
	private String meterStatus;
	private Date meterTimeStamp;
	private int eventStatus;
	private Date vcapInsertDateTime;
	private String vcapInsertTime;
	private String structureName;
	private String transformer;
	private String subEvent;
	private String executeCommandMeterStatus;
	private String prvCmdStatus;
	private String reqStatus;
	
	
	public MeterEventLoad() {
		super();
	}
	
	public long getMeterEventLoadId() {
		return meterEventLoadId;
	}

	public void setMeterEventLoadId(long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}



	public String getMeterType() {
		return meterType;
	}

	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}

	public String getDemand() {
		return demand;
	}

	public void setDemand(String demand) {
		this.demand = demand;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public String getNetworkAbbr() {
		return networkAbbr;
	}

	public void setNetworkAbbr(String networkAbbr) {
		this.networkAbbr = networkAbbr;
	}

	public String getFeeder() {
		return feeder;
	}

	public void setFeeder(String feeder) {
		this.feeder = feeder;
	}

	public String getFeederNetworkAbbr() {
		return feederNetworkAbbr;
	}

	public void setFeederNetworkAbbr(String feederNetworkAbbr) {
		this.feederNetworkAbbr = feederNetworkAbbr;
	}

	public String getSdpid() {
		return sdpid;
	}

	public void setSdpid(String sdpid) {
		this.sdpid = sdpid;
	}

	public String getMeterNumber() {
		return meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getCustomerZipCode() {
		return customerZipCode;
	}

	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getServiceAddress() {
		return serviceAddress;
	}

	public void setServiceAddress(String serviceAddress) {
		this.serviceAddress = serviceAddress;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public String getOperatorAdID() {
		return operatorAdID;
	}

	public void setOperatorAdID(String operatorAdID) {
		this.operatorAdID = operatorAdID;
	}

	public String getMeterStatus() {
		return meterStatus;
	}

	public void setMeterStatus(String meterStatus) {
		this.meterStatus = meterStatus;
	}

	public Date getMeterTimeStamp() {
		return meterTimeStamp;
	}

	public void setMeterTimeStamp(Date meterTimeStamp) {
		this.meterTimeStamp = meterTimeStamp;
	}

	
	public int getEventStatus() {
		return eventStatus;
	}

	public void setEventStatus(int eventStatus) {
		this.eventStatus = eventStatus;
	}

	public String getVcapInsertTime() {
		return vcapInsertTime;
	}

	public void setVcapInsertTime(String vcapInsertTime) {
		this.vcapInsertTime = vcapInsertTime;
	}

	public Date getVcapInsertDateTime() {
		return vcapInsertDateTime;
	}

	public void setVcapInsertDateTime(Date vcapInsertDateTime) {
		this.vcapInsertDateTime = vcapInsertDateTime;
	}

	public String getStructureName() {
		return structureName;
	}

	public void setStructureName(String structureName) {
		this.structureName = structureName;
	}

	public String getTransformer() {
		return transformer;
	}

	public void setTransformer(String transformer) {
		this.transformer = transformer;
	}
	
	public String getSubEvent() {
		return subEvent;
	}

	public void setSubEvent(String subEvent) {
		this.subEvent = subEvent;
	}

	
	public String getExecuteCommandMeterStatus() {
		return executeCommandMeterStatus;
	}

	public void setExecuteCommandMeterStatus(String executeCommandMeterStatus) {
		this.executeCommandMeterStatus = executeCommandMeterStatus;
	}

	@Override
	public String toString() {
		return "MeterEventLoad [meterEventLoadId=" + meterEventLoadId + ", meterType=" + meterType + ", demand="
				+ demand + ", borough=" + borough + ", network=" + network + ", networkAbbr=" + networkAbbr
				+ ", feeder=" + feeder + ", feederNetworkAbbr=" + feederNetworkAbbr + ", sdpid=" + sdpid
				+ ", meterNumber=" + meterNumber + ", accountNumber=" + accountNumber + ", customerName=" + customerName
				+ ", phone1=" + phone1 + ", customerZipCode=" + customerZipCode + ", buildingNumber=" + buildingNumber
				+ ", phone2=" + phone2 + ", serviceAddress=" + serviceAddress + ", eventName=" + eventName
				+ ", insertTime=" + insertTime + ", operatorAdID=" + operatorAdID + ", meterStatus=" + meterStatus
				+ ", meterTimeStamp=" + meterTimeStamp + ", eventStatus=" + eventStatus + ", vcapInsertTime="
				+ vcapInsertTime + ", structureName=" + structureName + ", transformer=" + transformer + ", subEvent="
				+ subEvent + ", executeCommandMeterStatus=" + executeCommandMeterStatus + ", prvCmdStatus="
				+ prvCmdStatus + ", reqStatus=" + reqStatus + "]";
	}

	public boolean isNull(String str){
		if(null == str){
			return true;
		}
		return false;
	}
	public boolean isObjectNull(Object obj){
		if(null == obj){
			return true;
		}
		return false;
	}
	

	public String getPrvCmdStatus() {
		return prvCmdStatus;
	}

	public void setPrvCmdStatus(String prvCmdStatus) {
		this.prvCmdStatus = prvCmdStatus;
	}

	public String getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	@Override
	public boolean equals(Object obj) {
		if(this == obj) 
            return true; 
        if(obj == null || obj.getClass()!= this.getClass()) 
            return false; 
       MeterEventLoad meterEventLoad = (MeterEventLoad) obj;
       return (meterEventLoad.borough == this.borough && meterEventLoad.eventName == this.eventName); 
	}

	@Override
	public int hashCode() {
		return (int) this.meterEventLoadId;
	}
	
	
}
