package com.coned.ls.domain;

import java.util.List;
/*
 * OpenEvent.class
 * Author : Anand Mahajan
 * Date : August 10, 2020
 * 
 */
public class OpenEvent {

	private String borough;
	private String event;
	private List<String> eventName;
	private String eventNameQuery;
	private String boroughQuery;
	private int totalRowCount;
	private int callAgain;
	
	
	
	
	
	
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public OpenEvent() {
		super();
	}
	
	public OpenEvent(String borough) {
		super();
		this.borough = borough;
	}


	public OpenEvent(String borough, List<String> eventName) {
		super();
		this.borough = borough;
		this.eventName = eventName;
	}
	
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public List<String> getEventName() {
		return eventName;
	}
	public void setEventName(List<String> eventName) {
		this.eventName = eventName;
	}	
	
	
	public OpenEvent(List<String> eventName) {
		super();
		this.eventName = eventName;
	}
	
	

	public String getEventNameQuery() {
		return eventNameQuery;
	}

	public void setEventNameQuery(String eventNameQuery) {
		this.eventNameQuery = eventNameQuery;
	}

	public String getBoroughQuery() {
		return boroughQuery;
	}

	public void setBoroughQuery(String boroughQuery) {
		this.boroughQuery = boroughQuery;
	}

	
	public OpenEvent(String eventNameQuery, String boroughQuery) {
		super();
		this.eventNameQuery = eventNameQuery;
		this.boroughQuery = boroughQuery;
	}

	@Override
	public String toString() {
		return "OpenEvent [borough=" + borough + ", eventName=" + eventName
				+ "]";
	}

	public int getTotalRowCount() {
		return totalRowCount;
	}

	public void setTotalRowCount(int totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	public int getCallAgain() {
		return callAgain;
	}

	public void setCallAgain(int callAgain) {
		this.callAgain = callAgain;
	}
	
	
	
}
