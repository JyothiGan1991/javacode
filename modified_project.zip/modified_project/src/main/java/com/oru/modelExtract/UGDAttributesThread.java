/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class UGDAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(UGDAttributesThread.class);        

    UGDAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select distinct geom.fid,geom.featuretypeid,def.featuretypename,GeometryType(geom.geom) geomType,\n" +
                                    "geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, ugd.circuit, ugd.sotagged, ugd.status, ugd.ugdtype, \n" +
                                    "ugd.gridx, ugd.gridy, ugd.phase, ugd.out_phase, ugd.phasei, ugd.phaseii, ugd.phaseiii, ugd.div, \n" +
                                    "ugd.seg, ugd.neutral, ugd.volt, ugd.comment, ugd.subseg, ugd.currentdstat, ugd.fuse, ugd.custowned, \n" +
                                    "ugd.dstat, ugd.designdstat,ugd.wafid1,ugd.wafid2,ugd.fid1,ugd.fid2,ugd.mainline \n" +
                                    "from \n" +
                                    "ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_ugd ugd  , ed.connection conn\n" +
                                    "where geom.fid = ugd.fid \n" +
                                    "and geom.fid = conn.fida\n" +
                                    "and ugd.fid = conn.fida\n" +
                                    "and geom.featuretypeid = def.featuretypeid\n" +
                                    "and ugd.fid in (" + assetToQuery + ") \n" +                    
                                    "order by geom.fid ";

            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                                        
                    String sotagged = rs.getString("sotagged");
                    asset.setNmsAttributes("sotagged", sotagged);
                    
                    String status = rs.getString("status");
                    asset.setNmsAttributes("status", status);
                    
                    String ugdtype = rs.getString("ugdtype");
                    asset.setNmsAttributes("ugdtype", ugdtype);
                    
                    
                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));
                    
                    int out_phase = rs.getInt("out_phase");
                    asset.setNmsAttributes("out_phase", Integer.toString(out_phase));
                    
                    String phasei = rs.getString("phasei");
                    asset.setNmsAttributes("phasei", phasei);
                    
                    String phaseii = rs.getString("phaseii");
                    asset.setNmsAttributes("phaseii", phaseii);

                    String phaseiii = rs.getString("phaseiii");
                    asset.setNmsAttributes("phaseiii", phaseiii);
                    
                    int div = rs.getInt("div");
                    asset.setNmsAttributes("div", Integer.toString(div));                    
                    
                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);

                    int neutral = rs.getInt("neutral");
                    asset.setNmsAttributes("neutral", Integer.toString(neutral));                    
                    
                    double volt = rs.getDouble("volt");
                    //asset.setNmsAttributes("volt", String.valueOf(volt));                      
                    asset.setNmsAttributes("volt", String.format("%.2f", volt));                      
                    // need to test this for formating the value to 2 decimal places 
                    //String.format("%.2f", volt)
                    
                    String comment = rs.getString("comment");
                    asset.setNmsAttributes("comment", comment);
                    
                    String subSegment = rs.getString("subseg");
                    asset.setNmsAttributes("subSegment", subSegment);
                    
                    String fuse = rs.getString("fuse");
                    asset.setNmsAttributes("fuse", fuse);
                    
                    boolean custowned = rs.getBoolean("custowned");
                    asset.setNmsAttributes("custowned", String.valueOf(custowned));
                    
                    String dstat = rs.getString("dstat");
                    asset.setNmsAttributes("dstat", dstat);
                    
                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);
                    
                    int wafid1 = rs.getInt("wafid1");
                    asset.setNmsAttributes("wafid1", Integer.toString(wafid1));
                    
                    int wafid2 = rs.getInt("wafid2");
                    asset.setNmsAttributes("wafid2", Integer.toString(wafid2));
                    
                    int fid1 = rs.getInt("fid1");
                    asset.setNmsAttributes("fid1", Integer.toString(fid1));
                    
                    int fid2 = rs.getInt("fid2");
                    asset.setNmsAttributes("fid2", Integer.toString(fid2));

                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);                   
                    

                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}

