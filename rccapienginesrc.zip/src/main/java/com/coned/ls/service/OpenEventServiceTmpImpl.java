package com.coned.ls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.repository.OpenEventRepository;
import com.coned.ls.repository.OpenEventRepositoryTmp;

/**
 * 
 * Service class for Open Event.
 *
 */
@Service("openEventServiceTmp")
public class OpenEventServiceTmpImpl implements OpenEventServiceTmp {

	@Autowired
	private OpenEventRepositoryTmp openEventRepositoryTmp;


	@Override
	public ResponseEntity<List<String>> getNewAndActiveBorough() {
		List<String> newAndActiveBoroughs = openEventRepositoryTmp.getNewAndActiveBorough();
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	}


	@Override
	public ResponseEntity<List<String>> getNewAndActiveEvent() {
		List<String> newAndActiveEvents = openEventRepositoryTmp.getNewAndActiveEvent();
		return ResponseEntity.ok().body(newAndActiveEvents);
	}


	@Override
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(final String borough) {	
		List<String> newAndActiveBoroughs = openEventRepositoryTmp.getNewAndActiveEventByBorough(borough);
		return ResponseEntity.ok().body(newAndActiveBoroughs);
	}
	
  
}
