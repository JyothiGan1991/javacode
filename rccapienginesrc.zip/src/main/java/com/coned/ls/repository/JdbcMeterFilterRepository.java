package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.coned.ls.domain.FilterAttribute;

/**
 * 
 * Repository class to implement filter functionality.
 *
 */
@Repository
public class JdbcMeterFilterRepository implements MeterFilterRepository {

private static final Logger logger = LogManager.getLogger(JdbcMeterFilterRepository.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
    /*
     * Method to Initiate filter attribute.
     * 
     * @Param borough         String
     * @Param eventName  	  String
     * @Param filterAttribute String
     * @Param startIndex  	  int
     * @Param fetchNext  	  int
     * 
     * @return 				  List<FilterAttribute> 
     *                         
     */
	@Override
	public List<FilterAttribute> initMeterFilter(final String borough, final String eventName, final String filterAttribute, final int startIndex, final int fetchNext) {
		
		String query = "select "+filterAttribute+" from (select t1.*,rownum rn from (select mel."+filterAttribute+" from LS_METER_EVENT_LOAD mel INNER JOIN ls_validate_event_list vel ON vel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND vel.boro_muni = mel.boro_muni AND vel.event_name = mel.event_name where mel.boro_muni = ? AND mel.event_name = ? group by mel."+filterAttribute+" ) t1 where rownum<=?) where rn>=?";

		logger.info(String.format("Query for initMeterFilter - %s", query));
		
		List<FilterAttribute> filterAttributeList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName,startIndex,fetchNext},new RowMapper<FilterAttribute>() {
			@Override
			public FilterAttribute mapRow(ResultSet rs, int rowNum)throws SQLException {
				FilterAttribute filterAttribute = new FilterAttribute();
				filterAttribute.setFilterAttribute(rs.getString(""+filterAttribute));
				return filterAttribute;
			}
        });
		
		logger.info(String.format("Query result - %s", filterAttributeList));
		
		return filterAttributeList;
	}
}
