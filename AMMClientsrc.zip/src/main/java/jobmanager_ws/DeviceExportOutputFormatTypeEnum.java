
package jobmanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceExportOutputFormatTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeviceExportOutputFormatTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TAB_FILE_FORMAT"/&gt;
 *     &lt;enumeration value="KML_FILE_FORMAT"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DeviceExportOutputFormatTypeEnum")
@XmlEnum
public enum DeviceExportOutputFormatTypeEnum {

    TAB_FILE_FORMAT("TAB_FILE_FORMAT"),
    KML_FILE_FORMAT("KML_FILE_FORMAT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DeviceExportOutputFormatTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeviceExportOutputFormatTypeEnum fromValue(String v) {
        for (DeviceExportOutputFormatTypeEnum c: DeviceExportOutputFormatTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
