
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RelayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RelayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PreferredGateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ParentGatewayType" minOccurs="0"/&gt;
 *         &lt;element name="PreferredIPAddressPrefix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AlternateGateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ParentGatewayType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AlternateIPAddressPrefix" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelayType", propOrder = {
    "preferredGateway",
    "preferredIPAddressPrefix",
    "alternateGateway",
    "alternateIPAddressPrefix"
})
@XmlSeeAlso({
    GetRelayType.class
})
public class RelayType {

    @XmlElement(name = "PreferredGateway")
    protected ParentGatewayType preferredGateway;
    @XmlElement(name = "PreferredIPAddressPrefix")
    protected String preferredIPAddressPrefix;
    @XmlElement(name = "AlternateGateway")
    protected List<ParentGatewayType> alternateGateway;
    @XmlElement(name = "AlternateIPAddressPrefix")
    protected List<String> alternateIPAddressPrefix;

    /**
     * Gets the value of the preferredGateway property.
     * 
     * @return
     *     possible object is
     *     {@link ParentGatewayType }
     *     
     */
    public ParentGatewayType getPreferredGateway() {
        return preferredGateway;
    }

    /**
     * Sets the value of the preferredGateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link ParentGatewayType }
     *     
     */
    public void setPreferredGateway(ParentGatewayType value) {
        this.preferredGateway = value;
    }

    /**
     * Gets the value of the preferredIPAddressPrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferredIPAddressPrefix() {
        return preferredIPAddressPrefix;
    }

    /**
     * Sets the value of the preferredIPAddressPrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferredIPAddressPrefix(String value) {
        this.preferredIPAddressPrefix = value;
    }

    /**
     * Gets the value of the alternateGateway property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternateGateway property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternateGateway().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ParentGatewayType }
     * 
     * 
     */
    public List<ParentGatewayType> getAlternateGateway() {
        if (alternateGateway == null) {
            alternateGateway = new ArrayList<ParentGatewayType>();
        }
        return this.alternateGateway;
    }

    /**
     * Gets the value of the alternateIPAddressPrefix property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternateIPAddressPrefix property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternateIPAddressPrefix().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAlternateIPAddressPrefix() {
        if (alternateIPAddressPrefix == null) {
            alternateIPAddressPrefix = new ArrayList<String>();
        }
        return this.alternateIPAddressPrefix;
    }

}
