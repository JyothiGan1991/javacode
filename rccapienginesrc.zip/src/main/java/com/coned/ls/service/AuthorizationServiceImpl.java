package com.coned.ls.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.repository.AuthorizationRepository;

/**
 * 
 * Service class for Authorization.
 *
 */
@Service("authorizationService")
public class AuthorizationServiceImpl implements AuthorizationService {

	@Autowired
	private AuthorizationRepository  authorizationRepository;
	
	/*
	 * Method to check user is authorized to access RCC API's.
	 * 
	 * @Param operatorADID String
	 * @Param role 		   String
	 * 
     * @return 			   boolean 
     * 
	 */	
	@Override
	public boolean isOperatorAuthorized(final String operatorADID, final String role)throws OperatorAuthorizationException {
		return authorizationRepository.isOperatorAuthorized(operatorADID, role);
	}

	/*
	 * Method to store login details in the database.
	 * 
	 * @Param operatorLoginDetail OperatorLoginDetail
	 * 
     * @return 					  OperatorLoginDetail 
	 */	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, value="oracleTx")
	public OperatorLoginDetail persistApi(final OperatorLoginDetail operatorLoginDetail)	throws OperatorAuthorizationException {
		return authorizationRepository.persistApi(operatorLoginDetail);
	}

	/*
	 * Method to read login details of the user.
	 * 
	 * @Param adid String
	 * @Param role String
	 * 
     * @return 	   OperatorLoginDetail 
	 */	
	@Override
	public OperatorLoginDetail getOperatorLoginDetail(final String adid,final String role)	throws OperatorAuthorizationException {
		return authorizationRepository.getOperatorLoginDetail(adid,role);
	}

	/*
	 * Method to check user is authorized to access RCC API's.
	 * 
	 * @Param adid         String
	 * @Param apiKey       String
	 * @Param apiKeyStatus int
	 * @Param loginStatus  int
	 * 
     * @return 			   boolean 
	 */	
	@Override
	public boolean isAPIEndpointAuthorizeed(final String adid,final String apiKey, final int apiKeyStatus, final int loginStatus) throws OperatorAuthorizationException {
		return authorizationRepository.isAPIEndpointAuthorizeed(adid,apiKey,apiKeyStatus, loginStatus);
	}
}
