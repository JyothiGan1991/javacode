
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ssn.schema.service.v2_6.commonenumerations package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ssn.schema.service.v2_6.commonenumerations
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PriorityType }
     * 
     */
    public PriorityType createPriorityType() {
        return new PriorityType();
    }

    /**
     * Create an instance of {@link ScheduleType }
     * 
     */
    public ScheduleType createScheduleType() {
        return new ScheduleType();
    }

    /**
     * Create an instance of {@link DeviceCapabilityType }
     * 
     */
    public DeviceCapabilityType createDeviceCapabilityType() {
        return new DeviceCapabilityType();
    }

    /**
     * Create an instance of {@link DeviceTypeType }
     * 
     */
    public DeviceTypeType createDeviceTypeType() {
        return new DeviceTypeType();
    }

    /**
     * Create an instance of {@link UIQDeviceStateType }
     * 
     */
    public UIQDeviceStateType createUIQDeviceStateType() {
        return new UIQDeviceStateType();
    }

    /**
     * Create an instance of {@link DayType }
     * 
     */
    public DayType createDayType() {
        return new DayType();
    }

    /**
     * Create an instance of {@link NotificationTypeType }
     * 
     */
    public NotificationTypeType createNotificationTypeType() {
        return new NotificationTypeType();
    }

    /**
     * Create an instance of {@link ProvisioningActionType }
     * 
     */
    public ProvisioningActionType createProvisioningActionType() {
        return new ProvisioningActionType();
    }

    /**
     * Create an instance of {@link TOUTierWeekdayType }
     * 
     */
    public TOUTierWeekdayType createTOUTierWeekdayType() {
        return new TOUTierWeekdayType();
    }

    /**
     * Create an instance of {@link TaskStatusType }
     * 
     */
    public TaskStatusType createTaskStatusType() {
        return new TaskStatusType();
    }

    /**
     * Create an instance of {@link ExecutionStatusType }
     * 
     */
    public ExecutionStatusType createExecutionStatusType() {
        return new ExecutionStatusType();
    }

    /**
     * Create an instance of {@link MonthType }
     * 
     */
    public MonthType createMonthType() {
        return new MonthType();
    }

    /**
     * Create an instance of {@link UtilDeviceStateType }
     * 
     */
    public UtilDeviceStateType createUtilDeviceStateType() {
        return new UtilDeviceStateType();
    }

    /**
     * Create an instance of {@link TimeZoneType }
     * 
     */
    public TimeZoneType createTimeZoneType() {
        return new TimeZoneType();
    }

    /**
     * Create an instance of {@link ApprovalStatusType }
     * 
     */
    public ApprovalStatusType createApprovalStatusType() {
        return new ApprovalStatusType();
    }

    /**
     * Create an instance of {@link JobTypeType }
     * 
     */
    public JobTypeType createJobTypeType() {
        return new JobTypeType();
    }

    /**
     * Create an instance of {@link CronJobTypeType }
     * 
     */
    public CronJobTypeType createCronJobTypeType() {
        return new CronJobTypeType();
    }

    /**
     * Create an instance of {@link ActivationStatusType }
     * 
     */
    public ActivationStatusType createActivationStatusType() {
        return new ActivationStatusType();
    }

    /**
     * Create an instance of {@link PositionType }
     * 
     */
    public PositionType createPositionType() {
        return new PositionType();
    }

    /**
     * Create an instance of {@link WeekdayType }
     * 
     */
    public WeekdayType createWeekdayType() {
        return new WeekdayType();
    }

    /**
     * Create an instance of {@link JobSubTypeType }
     * 
     */
    public JobSubTypeType createJobSubTypeType() {
        return new JobSubTypeType();
    }

    /**
     * Create an instance of {@link MeterReadTypeType }
     * 
     */
    public MeterReadTypeType createMeterReadTypeType() {
        return new MeterReadTypeType();
    }

}
