/*package com.coned.ls.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.controller.AOCCDisconnectController;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoadAction;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterValidateResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class MetersEventFinalizeRepositoryTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	@MockBean
	private MetersEventFinalizeRepository metersEventFinalizeRepository;
	 
	private MockMvc mockMvc;
	
	MeterEventFinalize meterEventFinalize;
	
	@Autowired
	private AOCCDisconnectController aOCCController; 
		
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300","Success",true);	
	}
	
	@Test
	public void findMeterEventFinalizeDetailsTest_True(){     
	    Assert.assertEquals(10, meterEventFinalize.getCountOfMeters());
	    Assert.assertEquals("AN20025372", meterEventFinalize.getOperatorAdId());
	    Assert.assertEquals("B", meterEventFinalize.getBorough());
	    Assert.assertEquals("SheepsheadBaySampleData7.27.20-1300",meterEventFinalize.getEventName());
	    Assert.assertEquals("Success", meterEventFinalize.getMessage());
	    Assert.assertEquals(true,meterEventFinalize.isValid());
	}
	
	@Test
	public void countOfMeterZero(){
		meterEventFinalize.setCountOfMeters(0);
		Assert.assertEquals(0, meterEventFinalize.getCountOfMeters());
	}
	
	@Test
	public void finalizeMeterEventList() throws Exception{
		MeterEventLoadAction mock = Mockito.mock(MeterEventLoadAction.class);		
		metersEventFinalizeRepository = Mockito.mock(MetersEventFinalizeRepository.class);
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMessage("Success");
		long[] finalizeMeters = {92764,92766,92768};
		List<Long> finalizeMetersList = Arrays.stream(finalizeMeters).boxed().collect(Collectors.toList());
		MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction(92764, "B", "Test_Event_Name", new Date(), "Test_AD_Id");
		//MeterValidateResponseMapper finalizeMeterEventList = metersEventFinalizeRepository.finalizeMeterEventList(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName(),finalizeMetersList);
		//Mockito.when(metersEventFinalizeRepository.finalizeMeterEventList(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName() ,finalizeMetersList)).thenReturn(meterValidateResponseMapper);
		//Assert.assertEquals(aOCCController.finalizeValidateMeters(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName()),meterValidateResponseMapper,0);
	}
	
	@Test
	public void finalizeMeterEventList_Exception() throws Exception{
		MeterEventLoadAction mock = Mockito.mock(MeterEventLoadAction.class);		
		metersEventFinalizeRepository = Mockito.mock(MetersEventFinalizeRepository.class);
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMessage("Success");
		long[] finalizeMeters = {0};
		List<Long> finalizeMetersList = Arrays.stream(finalizeMeters).boxed().collect(Collectors.toList());
		MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction(92764, "B", "Test_Event_Name", new Date(), "Test_AD_Id");
		//MeterValidateResponseMapper finalizeMeterEventList = metersEventFinalizeRepository.finalizeMeterEventList(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName(),finalizeMetersList);
		//Mockito.when(metersEventFinalizeRepository.finalizeMeterEventList(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName() ,finalizeMetersList)).thenReturn(meterValidateResponseMapper);
		//Assert.assertEquals(aOCCController.finalizeValidateMeters(meterEventLoadAction.getBorough(), meterEventLoadAction.getEventName()),meterValidateResponseMapper,0);
	}
}
*/