package com.oru.rest.config;

import com.oru.soap.nucon.generated.NuconWS;
import com.oru.soap.nucon.generated.NuconWSService;
import com.oru.soap.poe.generated.POEWebServicesSEI;
import com.oru.soap.poe.generated.POEWebServicesService;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.BindingProvider;

@Configuration
public class SoapClientConfig {

    private static final Logger log = LoggerFactory.getLogger(SoapClientConfig.class);

    @Value("${poe.soap.endpoint-url}")
    private String poeEndpointUrl;

    @Value("${poe.soap.connect-timeout-ms:5000}")
    private long poeConnectTimeout;

    @Value("${poe.soap.read-timeout-ms:10000}")
    private long poeReadTimeout;

    @Value("${nucon.soap.endpoint-url}")
    private String nuconEndpointUrl;

    @Value("${nucon.soap.connect-timeout-ms:5000}")
    private long nuconConnectTimeout;

    @Value("${nucon.soap.read-timeout-ms:10000}")
    private long nuconReadTimeout;

    @Bean
    public POEWebServicesSEI poeWebServicesClient() {
        log.info("Creating POE SOAP client: {}", poeEndpointUrl);
        POEWebServicesService service = new POEWebServicesService();
        POEWebServicesSEI port = service.getPOEWebServicesPort();
        configureEndpoint(port, poeEndpointUrl, poeConnectTimeout, poeReadTimeout);
        return port;
    }

    @Bean
    public NuconWS nuconWsClient() {
        log.info("Creating Nucon SOAP client: {}", nuconEndpointUrl);
        NuconWSService service = new NuconWSService();
        NuconWS port = service.getNuconWSPort();
        configureEndpoint(port, nuconEndpointUrl, nuconConnectTimeout, nuconReadTimeout);
        return port;
    }

    private void configureEndpoint(Object port, String endpointUrl, long connectTimeout, long readTimeout) {
        BindingProvider bp = (BindingProvider) port;
        bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
        try {
            org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPClientPolicy policy = new HTTPClientPolicy();
            policy.setConnectionTimeout(connectTimeout);
            policy.setReceiveTimeout(readTimeout);
            http.setClient(policy);
        } catch (Exception e) {
            log.warn("Could not configure CXF timeouts: {}", e.getMessage());
        }
    }
}
