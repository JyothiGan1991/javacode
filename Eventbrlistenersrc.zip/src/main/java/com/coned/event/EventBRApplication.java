package com.coned.event;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@ComponentScan(basePackages = "com.coned")
@EnableJms
public class EventBRApplication {
	/**
	 * launch the Spring application from a Java main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EventBRApplication.class, args);
	}
}
