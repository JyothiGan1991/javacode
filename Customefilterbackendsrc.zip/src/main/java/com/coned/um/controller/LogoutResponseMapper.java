package com.coned.um.controller;

public class LogoutResponseMapper {
	private String userName;
	private String logoutTime;
	private String message;
	
	public String getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(String logoutTime) {
		this.logoutTime = logoutTime;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String name) {
		userName = name;
	}
}
