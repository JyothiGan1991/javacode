package com.oru.nucon.rest.controller;

import com.oru.nucon.rest.dto.AccountRequest;
import com.oru.nucon.rest.dto.ElectricInfoDto;
import com.oru.nucon.rest.dto.LocateInNrgViewerRequest;
import com.oru.nucon.rest.dto.PremiseRequest;
import com.oru.nucon.rest.dto.SendToNrgRequest;
import com.oru.nucon.rest.dto.XYCoordinatesRequest;
import com.oru.nucon.rest.exception.GlobalExceptionHandler;
import com.oru.nucon.rest.exception.SoapServiceException;
import com.oru.nucon.rest.service.NuconSoapService;
import com.oru.nucon.soap.generated.NuconWS;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NuconController.class)
@Import({GlobalExceptionHandler.class, com.oru.nucon.rest.security.TokenAuthFilter.class})
@TestPropertySource(properties = {
        "api.auth.enabled=true",
        "api.auth.token=test-token-nucon"
})
class NuconControllerTest {

    private static final String AUTH = "Bearer test-token-nucon";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NuconSoapService nuconSoapService;

    @MockBean
    private NuconWS soapClient;

    private ElectricInfoDto sampleDto() {
        ElectricInfoDto dto = new ElectricInfoDto();
        dto.setCircuit("C1");
        dto.setInvolt(240.0);
        dto.setTransformer("TX1");
        return dto;
    }

    @Test
    void getElectricInfoByAccount_post() throws Exception {
        when(nuconSoapService.getElectricInfoByAccount(any(AccountRequest.class))).thenReturn(sampleDto());

        mockMvc.perform(post("/api/v1/nucon/electric-info/by-account")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"account\":\"ACC1\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.circuit").value("C1"))
                .andExpect(jsonPath("$.involt").value(240.0))
                .andExpect(jsonPath("$.transformer").value("TX1"));
    }

    @Test
    void getElectricInfoByAccount_get() throws Exception {
        when(nuconSoapService.getElectricInfoByAccount(any(AccountRequest.class))).thenReturn(sampleDto());

        mockMvc.perform(get("/api/v1/nucon/electric-info/by-account")
                        .header("Authorization", AUTH)
                        .param("account", "ACC1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.circuit").value("C1"));
    }

    @Test
    void getElectricInfoByPremise_post() throws Exception {
        when(nuconSoapService.getElectricInfoByPremise(any(PremiseRequest.class))).thenReturn(sampleDto());

        mockMvc.perform(post("/api/v1/nucon/electric-info/by-premise")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"premise\":\"P1\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.transformer").value("TX1"));
    }

    @Test
    void getElectricInfoByXY_post() throws Exception {
        when(nuconSoapService.getElectricInfoByXYCoordinates(any(XYCoordinatesRequest.class))).thenReturn(sampleDto());

        mockMvc.perform(post("/api/v1/nucon/electric-info/by-xy")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"x\":\"10\",\"y\":\"20\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.circuit").value("C1"));
    }

    @Test
    void sendToNRG_post() throws Exception {
        doNothing().when(nuconSoapService).sendToNRG(any(SendToNrgRequest.class));

        mockMvc.perform(post("/api/v1/nucon/send-to-nrg")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"arg0\":\"a\",\"arg1\":1,\"arg2\":\"b\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void locateInNRGViewer_post() throws Exception {
        doNothing().when(nuconSoapService).locateInNRGViewer(any(LocateInNrgViewerRequest.class));

        mockMvc.perform(post("/api/v1/nucon/locate-in-nrg-viewer")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"arg0\":1,\"arg1\":2,\"arg2\":3,\"arg3\":\"label\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void soapError_returns502() throws Exception {
        when(nuconSoapService.getElectricInfoByAccount(any(AccountRequest.class)))
                .thenThrow(new SoapServiceException("SOAP down"));

        mockMvc.perform(post("/api/v1/nucon/electric-info/by-account")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"account\":\"x\"}"))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.status").value(502))
                .andExpect(jsonPath("$.message").value("SOAP down"));
    }

    @Test
    void missingAuth_returns401() throws Exception {
        mockMvc.perform(post("/api/v1/nucon/electric-info/by-account")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"account\":\"x\"}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401))
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }

    @Test
    void wrongToken_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/nucon/electric-info/by-account")
                        .header("Authorization", "Bearer wrong-token")
                        .param("account", "x"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }
}
