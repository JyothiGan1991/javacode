package com.oru.poe.rest.controller;

import com.oru.poe.rest.dto.IncidentCountRequest;
import com.oru.poe.rest.dto.IsGasMainRequest;
import com.oru.poe.rest.dto.VerifyPoleRequest;
import com.oru.poe.rest.exception.GlobalExceptionHandler;
import com.oru.poe.rest.exception.SoapServiceException;
import com.oru.poe.rest.service.PoeSoapService;
import com.oru.poe.soap.generated.POEWebServicesSEI;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PoeController.class)
@Import({GlobalExceptionHandler.class, com.oru.poe.rest.security.TokenAuthFilter.class})
@TestPropertySource(properties = {
        "api.auth.enabled=true",
        "api.auth.token=test-token-poe"
})
class PoeControllerTest {

    private static final String AUTH = "Bearer test-token-poe";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PoeSoapService poeSoapService;

    @MockBean
    private POEWebServicesSEI soapClient;

    @Test
    void isGasMain_post_success() throws Exception {
        when(poeSoapService.isGasMain(any(IsGasMainRequest.class))).thenReturn(true);

        mockMvc.perform(post("/api/v1/poe/is-gas-main")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"premise\":\"123 Main\",\"radius\":50}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(true));
    }

    @Test
    void isGasMain_post_validationError_missingRadius() throws Exception {
        mockMvc.perform(post("/api/v1/poe/is-gas-main")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"premise\":\"123 Main\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.error").value("Bad Request"));
    }

    @Test
    void isGasMain_get_success() throws Exception {
        when(poeSoapService.isGasMain(any(IsGasMainRequest.class))).thenReturn(false);

        mockMvc.perform(get("/api/v1/poe/is-gas-main")
                        .header("Authorization", AUTH)
                        .param("premise", "abc")
                        .param("radius", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(false));
    }

    @Test
    void verifyPole_post_success() throws Exception {
        when(poeSoapService.verifyPole(any(VerifyPoleRequest.class))).thenReturn(true);

        mockMvc.perform(post("/api/v1/poe/verify-pole")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"x\":100,\"y\":200}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(true));
    }

    @Test
    void verifyPole_post_validationError() throws Exception {
        mockMvc.perform(post("/api/v1/poe/verify-pole")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"x\":100}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void verifyPole_get_success() throws Exception {
        when(poeSoapService.verifyPole(any(VerifyPoleRequest.class))).thenReturn(false);

        mockMvc.perform(get("/api/v1/poe/verify-pole")
                        .header("Authorization", AUTH)
                        .param("x", "10")
                        .param("y", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(false));
    }

    @Test
    void incidentCount_post_success() throws Exception {
        when(poeSoapService.incidentCount(any(IncidentCountRequest.class))).thenReturn(42);

        mockMvc.perform(post("/api/v1/poe/incident-count")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"startDate\":\"2024-01-01\",\"startTime\":\"00:00:00\",\"endDate\":\"2024-12-31\",\"endTime\":\"23:59:59\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(42));
    }

    @Test
    void incidentCount_get_success() throws Exception {
        when(poeSoapService.incidentCount(any(IncidentCountRequest.class))).thenReturn(7);

        mockMvc.perform(get("/api/v1/poe/incident-count")
                        .header("Authorization", AUTH)
                        .param("startDate", "2024-01-01")
                        .param("endDate", "2024-06-30"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(7));
    }

    @Test
    void soapServiceException_returns502() throws Exception {
        when(poeSoapService.isGasMain(any(IsGasMainRequest.class)))
                .thenThrow(new SoapServiceException("SOAP unavailable"));

        mockMvc.perform(post("/api/v1/poe/is-gas-main")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"radius\":1}"))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.status").value(502))
                .andExpect(jsonPath("$.message").value("SOAP unavailable"));
    }

    @Test
    void missingAuth_returns401() throws Exception {
        mockMvc.perform(post("/api/v1/poe/is-gas-main")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"radius\":1}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401))
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }

    @Test
    void wrongToken_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/poe/verify-pole")
                        .header("Authorization", "Bearer wrong-token")
                        .param("x", "1")
                        .param("y", "2"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }

    @Test
    void noBearerPrefix_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/poe/verify-pole")
                        .header("Authorization", "test-token-poe")
                        .param("x", "1")
                        .param("y", "2"))
                .andExpect(status().isUnauthorized());
    }
}
