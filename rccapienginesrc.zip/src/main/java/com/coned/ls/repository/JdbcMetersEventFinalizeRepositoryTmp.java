package com.coned.ls.repository;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for finalizing meters selected for disconnect.
 *
 */
@Repository
public class JdbcMetersEventFinalizeRepositoryTmp  implements MetersEventFinalizeRepositoryTmp{

	private static final Logger LOGGER = LogManager.getLogger(JdbcMetersEventFinalizeRepositoryTmp.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;

    /*
     * Method to finalize meters for disconnect.
     * 
     * @Param meterEventFinalize MeterEventFinalize
     * @Param adid  	  		 String
     * 
     * @return 				  	 MeterFinalizeResponseMapper 
     *                         
     */
	@Override
	@Transactional(rollbackFor = {Exception.class, MeterFinalizeException.class}, value="oracleTx")
	public MeterFinalizeResponseMapper finalizeMeterEvent(final MeterEventFinalize meterEventFinalize, final String adid) {
		LOGGER.debug("** into new JdbcMetersEventFinalizeRepositoryTmp ** ");
		MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper();
		
		long processStartTime = DateUtils.processStartTime();
		String borough = meterEventFinalize.getBorough();
		String event = meterEventFinalize.getEventName();
		
		try{
			if(varifyIfEventIsAlreadyFinalized(borough, event)){
				meterFinalizeResponseMapper.setResult(false);
				meterFinalizeResponseMapper.setStatusCode(705);
				meterFinalizeResponseMapper.setMessage("Event is already finalized"); // Event already finalized
				throw new MeterFinalizeException("Event is already finalized");
			}
			if(!meterEventFinalize.getIsSelectAll()){
				LOGGER.debug(" ** isSELECT ALL - NOT**");
				int batchSize = Integer.parseInt(String.valueOf(meterEventFinalize.getCountOfMeters()));
				List<String> listOfMeters = meterEventFinalize.getListOfMeters();
				String meters = listOfMeters.stream().map(Object::toString).collect(Collectors.joining(","));
				
				persistFinalizeMeterEventDetails(batchSize, borough, event, adid);
				
				 int finalizedEventId = getFinalizedEventId(borough, event, adid);
				 if(finalizedEventId!=0){
					 persistFinalizeMeterEventList(borough,event,meterEventFinalize.getFilterList(),meters, finalizedEventId);
					 unlockEvent(borough, event, adid);
					 meterFinalizeResponseMapper.setResult(true);
				 }else{
					 meterFinalizeResponseMapper.setResult(false);
					 meterFinalizeResponseMapper.setStatusCode(704);
					 throw new MeterFinalizeException("Exception occured while executing getFinalizedEventId");
				 }
			}else{	
				LOGGER.debug(" ** isSELECT ALL **");
				List<String> listOfMeters = meterEventFinalize.getListOfMeters();
				String meters = "";
				if (listOfMeters.size() > 0) {
					meters = listOfMeters.stream().map(Object::toString).collect(Collectors.joining(","));
				}
				
				int countOfValidMeters = getCountOfValidMeters(borough, event, meterEventFinalize.getFilterList(), meters);
				if(countOfValidMeters > 0){
					persistFinalizeMeterEventDetails(countOfValidMeters, borough, event, adid);
					int finalizedEventId = getFinalizedEventId(borough, event, adid);
					persistFinalizeMeterEventSelectAll(borough, event, meterEventFinalize.getFilterList(), meters, finalizedEventId);
					unlockEvent(borough, event, adid);
					meterFinalizeResponseMapper.setResult(true);
				}else{
					meterFinalizeResponseMapper.setResult(false);
				 	meterFinalizeResponseMapper.setStatusCode(705);				 	
					throw new MeterFinalizeException("Count of meter is zero");
				}
				LOGGER.debug(" ** 2--- isSELECT ALL **");
			}
			saveExeAction(borough, event, adid);
		}catch (MeterFinalizeException ex) {
			LOGGER.error(ex.getMessage(), ex);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("API Repo finalizeMeterEvent Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
		return meterFinalizeResponseMapper;
	}
	
	public boolean saveExeAction(String boro, String eventname, String adid) throws Exception {
		boolean success = false;
		try {
			LOGGER.debug("---------------------- START - FinalizeEventListDetailsController - saveExeAction ------------------------");
			/********************************************************************************************/
			String qstr = "";
			qstr = "SELECT finalized_event_id FROM ls_finalize_event_list_details feld WHERE feld.event_name = ?";
			Map<String, Object> umap = null;
			boolean userExist = true;
			boolean isActive = true;
			int eventId = oracleJdbcTemplate.queryForObject(qstr, new Object[] { eventname }, Integer.class);
			LOGGER.debug("eventId?  "+eventId);
			int res = 0;
//			int op_adid=3;
			qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list_details "
					+ "(fk_finalized_event_id, event_name, boro_muni, execute_time, EVENT_TYPE, OPERATOR_AD_ID)  "
					+ "SELECT finalized_event_id, event_name, boro_muni," + "current_timestamp, 'D','" + adid + "' "
					+ " FROM ami_load_shedding.ls_finalize_event_list_details " + "WHERE finalized_event_id IN (?)";
			oracleJdbcTemplate.update(qstr, eventId);
			LOGGER.debug("---INSERT INFO ls_execute_event_list_details -> Result: " + res);

			qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list "
					+ "(fk_meter_event_load_id, event_name, boro_muni, meter_number) "
					+ "SELECT l.fk_meter_event_load_id, l.event_name, l.boro_muni, m.meter_number "
					+ "FROM ami_load_shedding.ls_finalize_event_list l "
					+ "INNER JOIN ami_load_shedding.ls_finalize_event_list_details d "
					+ "ON d.event_name = l.event_name " + "AND d.boro_muni  = l.boro_muni "
					+ "INNER JOIN ami_load_shedding.ls_meter_event_load m "
					+ "ON m.meter_event_load_id = l.fk_meter_event_load_id " + "WHERE d.finalized_event_id IN (?)";
			LOGGER.debug("---INSERT INFO ls_execute_event_list -> Result: " + res);
			oracleJdbcTemplate.update(qstr, eventId);
			/*******************
			 * Start temporarily write into METER_STATUS_VW
			 ***********************
			qstr = "INSERT INTO ami_load_shedding.meter_status_vw "
					+ "(event_name, boro_muni, meter_number, prv_cmd_status, meter_status, req_status) "
					+ "SELECT l.event_name, l.boro_muni, m.meter_number, 'GMI_RSM_SUCCESS',	'RMT_PROV_RES_STAT_DISCONNECTED', 'I' "
					+ "FROM ami_load_shedding.ls_finalize_event_list l "
					+ "INNER JOIN ami_load_shedding.ls_finalize_event_list_details d "
					+ "ON d.event_name = l.event_name " + "AND d.boro_muni  = l.boro_muni "
					+ "INNER JOIN ami_load_shedding.ls_meter_event_load m "
					+ "ON m.meter_event_load_id = l.fk_meter_event_load_id " + "WHERE d.finalized_event_id IN (?)";
			LOGGER.debug("---INSERT INFO meter_status_vw -> Result: " + res);
			oracleJdbcTemplate.update(qstr, eventId);
			******************
			 * End temporarily write into METER_STATUS_VW
			 ************************/
			qstr = "DELETE FROM ami_load_shedding.ls_finalize_event_list " + "WHERE fk_finalized_event_id=?";				
			oracleJdbcTemplate.update(qstr, eventId);
			LOGGER.debug("---DELETE FROM ls_finalize_event_list -> Result: " + res);

			qstr = "DELETE FROM ami_load_shedding.ls_finalize_event_list_details " + "WHERE finalized_event_id =?";
			oracleJdbcTemplate.update(qstr, eventId);
			LOGGER.debug("---DELETE FROM ls_finalize_event_list_details -> Result: " + res);
			
			LOGGER.debug("---------------------- END - saveExeAction ------------------------");
			success = true;
		} catch (Exception e) {
			LOGGER.error("** Exception -> saveExeAction: "+e);
		}
		return success;
	}

    /*
     * Method to find count of valid meters.
     * 
     * @Param borough 	 String
     * @Param eventName  String
     * @Param filterList String
     * @Param meters	 String
     * 
     * @return 			 int 
     *                         
     */
	private int getCountOfValidMeters(final String borough, final String eventName, final String filterList, final String meters) {
		long processStartTime = DateUtils.processStartTime();
		
		String query = "SELECT FK_METER_EVENT_LOAD_ID FROM ls_validate_event_list WHERE BORO_MUNI = ? AND EVENT_NAME = ? " +  buildFilterQuery(filterList);
		List<String> eventLoadIdLst = oracleJdbcTemplate.queryForList(query,  new Object[]{borough, eventName}, String.class);	
		eventLoadIdLst.removeAll(Arrays.asList(meters.split(",")));
		
		System.out.println("API SellectAll getCountOfValidMeters Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
		
		return eventLoadIdLst.size();
    }
	
    /*
     * Method to find latest finalized event Id. 
     * 
     * @Param borough 	 String
     * @Param eventName  String
     * @Param adid		 String
     * 
     * @return 			 int 
     *                         
     */
	private int getFinalizedEventId(final String borough, final String eventName, String adid) {
		long processStartTime = DateUtils.processStartTime();
		
		String query = "select MAX(FINALIZED_EVENT_ID) from LS_FINALIZE_EVENT_LIST_DETAILS where boro_muni = ? and event_name = ? and OPERATOR_AD_ID = ?";
		
		Integer finalizedEventId = oracleJdbcTemplate.queryForObject(query,  new Object[]{borough, eventName, adid}, Integer.class);
		if(null!=finalizedEventId){
			return finalizedEventId;
		}
		
		System.out.println("API getFinalizedEventId : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
		
		return 0;
    }
	
    /*
     * Method to save the list of meters finalized for disconnect in the database. 
     * 
     * @Param borough 	 String
     * @Param eventName  String
     * @Param filterList String
     * @Param meters	 String
     * @Param eventId	 int
     * 
     * @return 			 boolean 
     *                         
     */
	private boolean persistFinalizeMeterEventList(String borough, String eventName, final String filterList, final String meters, final int eventId) throws MeterFinalizeException{
		long processStartTime = DateUtils.processStartTime();
		try{	
			String[] meterArry = meters.split(",");
			for (int begin=0; begin<=meterArry.length; begin+=990) {
				long processStartTimeBatchInsert = DateUtils.processStartTime();
				String filterStr = buildFilterQuery(meterArry, begin, (null != meters && !meters.equals("")? true : false), filterList);

				oracleJdbcTemplate.execute("insert into LS_FINALIZE_EVENT_LIST (FK_METER_EVENT_LOAD_ID,BORO_MUNI,event_name,FK_FINALIZED_EVENT_ID,METER_NUMBER) select vel.FK_METER_EVENT_LOAD_ID,vel.BORO_MUNI,vel.EVENT_NAME, ?, vel.METER_NUMBER from ls_validate_event_list vel where vel.boro_muni=? and vel.event_name=? " + 
											filterStr ,(PreparedStatementCallback<Boolean>) ps -> {
					ps.setInt(1, eventId);
					ps.setString(2, borough);
		            ps.setString(3, eventName);
		            ps.execute();
		            
		            return true;
				});
				
				System.out.println("API Batch Insert for each 1000 record  Response Time : "+DateUtils.processResponseTime(processStartTimeBatchInsert, DateUtils.processEndTime()));
			}
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			throw new MeterFinalizeException("Exception ocured while inserting record in finalize event list");
		}
		
		System.out.println("API persistFinalizeMeterEventList Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
		return false;        
	}

    /*
     * Method to save the finalized details for disconnect meters in the database. 
     * 
     * @Param countOfMeters int
     * @Param borough 	 	String
     * @Param eventName  	String
     * @Param adid		 	String
     * 
     * @return 			 	boolean 
     *                         
     */
	private boolean persistFinalizeMeterEventDetails(final int countOfMeters,String borough, String eventName, String adid) throws MeterFinalizeException{
		try{
			oracleJdbcTemplate.update("INSERT INTO LS_FINALIZE_EVENT_LIST_DETAILS (COUNT_OF_METERS, FINALIZE_TIME, BORO_MUNI, EVENT_NAME,OPERATOR_AD_ID,FK_EVENT_STATUS_ID) VALUES(?,?,?,?,?,?)", new Object[]{countOfMeters,new java.sql.Date(new Date().getTime()), borough, eventName,adid,4});

			return true;
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			
			throw new MeterFinalizeException("Exception ocured while inserting record in finalize event list detail");
		}
	}
	
    /*
     * Method to unlock the event. 
     * 
     * @Param borough 	 	String
     * @Param eventName  	String
     * @Param adid		 	String
     * 
     * @return 			 	void 
     *                         
     */
	private void unlockEvent(String borough, String eventName, String adid) throws MeterFinalizeException {
		long processStartTime = DateUtils.processStartTime();
		
		try{
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{borough, eventName,adid});
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			
			throw new MeterFinalizeException("Exception ocured while unlocking the event.");
		}
		
		System.out.println("API unlockEvent Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
	}

    /*
     * Method to save the list of meters finalized for disconnect in the database for selected all case. 
     * 
     * @Param borough 	 String
     * @Param eventName  String
     * @Param filterList String
     * @Param meters	 String
     * @Param eventId	 int
     * 
     * @return 			 int 
     *                         
     */
	private int persistFinalizeMeterEventSelectAll(final String borough, final String eventName, final String filterList, final String meters, final int eventId) throws MeterFinalizeException{
		long processStartTime = DateUtils.processStartTime();
		int countOfMeters = 0;
		try{
			
			if (null != meters && !meters.equals("")) {
				String query = "SELECT FK_METER_EVENT_LOAD_ID FROM ls_validate_event_list WHERE BORO_MUNI = ? AND EVENT_NAME = ? ";
				
				List<String> eventLoadIdLst = oracleJdbcTemplate.queryForList(query,  new Object[]{borough, eventName}, String.class);	
				eventLoadIdLst.removeAll(Arrays.asList(meters.split(",")));
				countOfMeters = eventLoadIdLst.size();
				
				System.out.println("API Exclude Meters count of meter Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
			
				String[] meterArry = new String[eventLoadIdLst.size()];
				meterArry = eventLoadIdLst.toArray(meterArry);
				for (int begin=0; begin<=meterArry.length; begin+=990) {				
					String filterStr = buildFilterQuery(meterArry, begin, (null != meters && !meters.equals("")? true : false), filterList);

					oracleJdbcTemplate.execute("insert into LS_FINALIZE_EVENT_LIST (FK_METER_EVENT_LOAD_ID,BORO_MUNI,event_name,FK_FINALIZED_EVENT_ID,METER_NUMBER) select vel.FK_METER_EVENT_LOAD_ID,vel.BORO_MUNI,vel.EVENT_NAME, ?, vel.METER_NUMBER from ls_validate_event_list vel where vel.boro_muni=? and vel.event_name=? " + 
				                               filterStr,(PreparedStatementCallback<Boolean>) ps -> {
				        ps.setInt(1, eventId);
				        ps.setString(2, borough);
				        ps.setString(3, eventName);
				        ps.execute();
				        
				        return true;
				    });	
				}
				
				System.out.println("API Exclude Meters Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
			} else {
				oracleJdbcTemplate.execute("insert into LS_FINALIZE_EVENT_LIST (FK_METER_EVENT_LOAD_ID,BORO_MUNI,event_name,FK_FINALIZED_EVENT_ID,METER_NUMBER) select vel.FK_METER_EVENT_LOAD_ID,vel.BORO_MUNI,vel.EVENT_NAME, ?, vel.METER_NUMBER from ls_validate_event_list vel where vel.boro_muni=? and vel.event_name=? ", 
                        (PreparedStatementCallback<Boolean>) ps -> {
					 ps.setInt(1, eventId);
					 ps.setString(2, borough);
					 ps.setString(3, eventName);
					 ps.execute();
					 
					 return true;			
    			});
				
				System.out.println("API Sellect All Meter insert Response Time : "+DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()));
			}
		}catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			
			throw new MeterFinalizeException("Exception ocured while inserting record in finalize event list for select all");
		}	

		return countOfMeters; 
	}

    /*
     * Method to build filter query. 
     * 
     * @Param filterList String
     * 
     * @return 			 String 
     *                         
     */
	private String buildFilterQuery(final String filterList) {
		StringBuffer filterAndOrderQuery = new StringBuffer("");
		
		if (null != filterList && !filterList.equals("null") && !filterList.equals("")) {
			String[] filterFields = filterList.split(",");

			for (String filterField : filterFields) {
				String[] filterFieldInfo = filterField.split(":");
				
				filterAndOrderQuery.append(" AND ");
				filterAndOrderQuery.append(getDatabaseFieldName(filterFieldInfo[0]));
				filterAndOrderQuery.append(" IN (");
				
				String[] filterFieldValues = filterFieldInfo[1].split("-");
				boolean isFirstFilterField = true;
				for (String filterFieldValue : filterFieldValues) {
					if (isFirstFilterField)
						isFirstFilterField = false;
					else
						filterAndOrderQuery.append(", ");
					
					filterAndOrderQuery.append("'");
					
					if (filterFieldInfo[0].equals("serviceAddress")) {
						filterAndOrderQuery.append(filterFieldValue.replaceAll("%20", " "));
					} else {
						filterAndOrderQuery.append(filterFieldValue);
					}
					
					filterAndOrderQuery.append("'");
				}
				filterAndOrderQuery.append(") ");
			}
		}

		return filterAndOrderQuery.toString();
	}

    /*
     * Method to build filter query. 
     * 
     * @Param metersArry String[]
     * @Param begin		 int
     * @Param isMeters 	 boolean
     * @Param filterList String
	 *
     * @return 			 String 
     *                         
     */
	private String buildFilterQuery(String[] metersArry, final int begin, final boolean isMeters, final String filterList) {
		String metersStr = "";
		if (isMeters) {
			StringBuffer metersBffr = new StringBuffer();
			boolean isFirst = true;
			for (int j=begin; j<(begin+990 < metersArry.length ? begin+990 : metersArry.length); j++) {
				if (isFirst) {
					metersBffr.append(metersArry[j]);
					isFirst = false;
				} else {
					metersBffr.append("," + metersArry[j]);
				}
			}
			
			metersStr = metersBffr.toString();
		}

		String filterStr = "";
		if (!metersStr.equals("") && null != filterList && !filterList.equals("")) {
			filterStr = buildFilterQuery(filterList) + " and vel.FK_METER_EVENT_LOAD_ID IN (" + metersStr + ") ";
		} else if (null != filterList && !filterList.equals("")) {
			filterStr = buildFilterQuery(filterList);
		}  else if (!metersStr.equals("")) {
			filterStr = " and vel.FK_METER_EVENT_LOAD_ID IN (" + metersStr + ") ";
		}
		
		return filterStr;
	}
	
    /*
     * Method to find database field name of the field. 
     * 
     * @Param filterList String
	 *
     * @return 			 String 
     *                         
     */
	private String getDatabaseFieldName(String fieldName) {
		String dbFieldName = "";
		switch(fieldName) {
			case "meterEventLoadId" :
				dbFieldName = "METER_EVENT_LOAD_ID";
				break;
			case "borough" :
				dbFieldName = "boro_muni";
				break;
			case "eventName" :
				dbFieldName = "event_name";
				break;
			case "demand" :
				dbFieldName = "demand";
				break;
			case "feeder" :
				dbFieldName = "feeder";
				break;
			case "buildingNumber" :
				dbFieldName = "building_num";
				break;
			case "serviceAddress" :
				dbFieldName = "service_address";
				break;
			case "customerZipCode" :
				dbFieldName = "cust_zip_code";
				break;
			case "meterNumber" :
				dbFieldName = "meter_number";
				break;
			case "accountNumber" :
				dbFieldName = "account_number";
				break;	
			case "network" :
				dbFieldName = "network";
				break;
			case "eventStatus" :
				dbFieldName = "FK_EVENT_STATUS";
				break;
			case "vcapInsertTime" :
				dbFieldName = "VCAP_INSERT_TIME";
				break;
			case "transformer" :
				dbFieldName = "TRANSFORMER";	
				break;
			case "structureName" :
				dbFieldName = "STRUCTURE";
		}
		
		return dbFieldName;
	}

    /*
     * Method to check event is already finalized. 
     * 
     * @Param borough 	 String
     * @Param eventName  String
	 *
     * @return 			 boolean 
     *                         
     */
	private boolean varifyIfEventIsAlreadyFinalized(final String borough, final String eventName) {
		String query = "select COUNT(finalized_event_id) from ls_finalize_event_list_details where boro_muni= ? AND event_name= ?";
		Integer count = oracleJdbcTemplate.queryForObject(query,  new Object[]{borough, eventName}, Integer.class);

		if(null!=count && count > 0){
			return true;
		}
		
		return false;
	}
}