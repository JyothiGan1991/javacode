package com.coned.ls.repository;

import java.util.List;

/**
 * 
 * Interface for Open Evevnt repository class.
 *
 */
public interface OpenEventRepository {
	
	// RCC Disconnect
	public List<String> getNewAndActiveBorough();
	public List<String> getNewAndActiveEvent();
	public List<String> getNewAndActiveEventByBorough(final String borough);

	// RCC Connect - Only Execute open event
	public List<String> getExecuteBorough();
	public List<String> getExecuteEvent();
	public List<String> getExecuteEventByBorough(final String borough);
	
	public List<String> getSubFinalizeBorough();
	public List<String> getSubFinalizeEvent();
	public List<String> getSubFinalizeEventByBorough(final String borough);
	public List<String> getSubFinalizeEventByEventAndBorough(final String borought, final String eventName);
}