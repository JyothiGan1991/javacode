
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JobTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="JobTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_CRON_JOB"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_METER_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_EXPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_IMPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_REPORT"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_PING"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_NCC_ALARM_CLEAR"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEV_PROG_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_REMOTE_PROVISION"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_ARB_METER_COMMAND"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEMAND_RESET"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_BRIDGE_CONFIGURE"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"/&gt;
 *     &lt;enumeration value="JOB_OP_TYPE_DEVICE_DATA_IMPORT"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "JobTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum JobTypeEnumeration {

    JOB_OP_TYPE_CRON_JOB("JOB_OP_TYPE_CRON_JOB"),
    JOB_OP_TYPE_METER_READ("JOB_OP_TYPE_METER_READ"),
    JOB_OP_TYPE_EXPORT("JOB_OP_TYPE_EXPORT"),
    JOB_OP_TYPE_IMPORT("JOB_OP_TYPE_IMPORT"),
    JOB_OP_TYPE_REPORT("JOB_OP_TYPE_REPORT"),
    JOB_OP_TYPE_PING("JOB_OP_TYPE_PING"),
    JOB_OP_TYPE_NCC_ALARM_CLEAR("JOB_OP_TYPE_NCC_ALARM_CLEAR"),
    JOB_OP_TYPE_DEV_PROG_READ("JOB_OP_TYPE_DEV_PROG_READ"),
    JOB_OP_TYPE_REMOTE_PROVISION("JOB_OP_TYPE_REMOTE_PROVISION"),
    JOB_OP_TYPE_ARB_METER_COMMAND("JOB_OP_TYPE_ARB_METER_COMMAND"),
    JOB_OP_TYPE_DEMAND_RESET("JOB_OP_TYPE_DEMAND_RESET"),
    JOB_OP_TYPE_BRIDGE_CONFIGURE("JOB_OP_TYPE_BRIDGE_CONFIGURE"),
    JOB_OP_TYPE_TRGGR_BRDG_NTFCTN("JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"),
    JOB_OP_TYPE_DEVICE_DATA_IMPORT("JOB_OP_TYPE_DEVICE_DATA_IMPORT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    JobTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JobTypeEnumeration fromValue(String v) {
        for (JobTypeEnumeration c: JobTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
