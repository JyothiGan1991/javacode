package com.coned.ls.repository;

import java.util.HashMap;
import java.util.Map;



import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.ExecuteExternalCall;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SimpleJdbcCallFactory;
import com.coned.ls.exception.ExternalCallException;
import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.ExternalCallResponseMapper;
import com.coned.ls.utility.DateUtils;

import jakarta.activation.DataSource;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { ExecuteExternalCallRepository.class })
@AutoConfigureMockMvc
public class ExecuteExternalCallRepositoryTest {

	@Autowired
	private WebApplicationContext wac;
	@Mock
	JndiDataSourceLookup test;

	@MockBean
	@Qualifier("lsarccds")
	private DataSource dataSource;

	@Mock
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	private SimpleJdbcCall simpleJdbcCall;

	@InjectMocks
	JdbcExecuteExternalCallRepository metersEventRejectRepository;

	@Mock
	private SimpleJdbcCallFactory simpleJdbcCallFactory;
	private MockMvc mockMvc;

	private OpenEvent openEvent;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(metersEventRejectRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		ReflectionTestUtils.setField(this.metersEventRejectRepository, "simpleJdbcCall", simpleJdbcCall);
		metersEventRejectRepository.oracleJdbcTemplate = Mockito.mock(JdbcTemplate.class);
	}

	@Test(expected = IllegalStateException.class)
	public void executeMeterEventList() throws MeterRejectException, ExternalCallException {

		ExternalCallResponseMapper externalCallResponseMapper = new ExternalCallResponseMapper();

		ExecuteExternalCall obje = new ExecuteExternalCall();
		obje.setBorough("Test");
		obje.setEventName("Test");
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("Borough", obje.getBorough());
		inParamMap.put("Event", obje.getEventName());
		inParamMap.put("ExecuteTime", DateUtils.getDate());
		inParamMap.put("OpeartorADID", "AN20025372");
		Map<String, Object> map = new HashMap<>();
		map.put("TOTALCOUNT", "1");
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);

		Mockito.when(simpleJdbcCall.execute(inParamSql)).thenReturn(map);
		Mockito.when(simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Mockito.when(metersEventRejectRepository.executeMeterEventList(obje)).thenReturn(externalCallResponseMapper);
		ExternalCallResponseMapper response = metersEventRejectRepository.executeMeterEventList(obje);
		Assert.assertEquals(externalCallResponseMapper, response);
	}

	@Test(expected = IllegalStateException.class)
	public void persistRejectedMeterListTest() throws MeterRejectException {

		Map<String, Object> map = new HashMap<>();

		map.putIfAbsent("TOTALCOUNTFINALIZE", "1");
		map.putIfAbsent("TOTALCOUNTFINALIZE", "1");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("borough", "borough");
		inParamMap.put("event", " eventName");

		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Mockito.when(simpleJdbcCall.execute(inParamSql)).thenReturn(map);
		ReflectionTestUtils.invokeMethod(metersEventRejectRepository, "persistExecuteMeterList", "borough",
				"eventName");

	}

}
