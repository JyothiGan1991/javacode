package com.coned.ls.controller;

import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.MetersEventFinalizeService;
import com.coned.ls.service.MetersEventFinalizeServiceTmp;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.OpenEventServiceTmp;
import com.coned.ls.utility.DateUtils;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("rcc/connect-tmp")
public class RCCConnectControllerTmp extends BaseController{
	private static final Logger LOGGER = LogManager.getLogger(RCCConnectControllerTmp.class);

	@Autowired
	private MetersEventFinalizeServiceTmp metersEventFinalizeServiceTmp;
	
	@Autowired
	private OpenEventServiceTmp openEventServiceTmp; 
	
	@Autowired
	private MeterEventValidateService meterEventValidateService;  
		
	@GetMapping("/events/open/meters")
	public ResponseEntity<List<String>> getNewAndActiveBorough(@RequestParam(name = "fields") String fields) {
		LOGGER.info(String.format("Request for list of borough or event names"));
		
		if (fields.equalsIgnoreCase("boro")) {
			return openEventServiceTmp.getNewAndActiveBorough();
		} else if(fields.equalsIgnoreCase("event_name")) {
			return openEventServiceTmp.getNewAndActiveEvent();
		}
		
		throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
	}

	@GetMapping("/events/open/meters/{borough}")
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(@PathVariable(name = "borough") String borough) {
		LOGGER.info(String.format("Request for open event by borough : %s", borough));
		
		return openEventServiceTmp.getNewAndActiveEventByBorough(borough);
	}

	@PostMapping("/events/finalize/meters")
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeValidateMeters(HttpServletRequest request,@RequestBody MeterEventFinalize meterEventFinalize) throws Exception {
		LOGGER.info(String.format("Request for finalizing the list of meters created for borough : %s", meterEventFinalize.getBorough(), " eventName : %s", meterEventFinalize.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return metersEventFinalizeServiceTmp.finalizeMeterEvent(meterEventFinalize, adid);
	}
}