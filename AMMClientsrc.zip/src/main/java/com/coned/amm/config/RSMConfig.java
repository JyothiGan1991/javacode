package com.coned.amm.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "client")
@PropertySource("file:${external.config}/amm_config.properties")
public class RSMConfig {
	private String username, password, deviceManagerUri, jobManagerUri, deviceResultsUri;

	/**
	 * @return the deviceResultsUri
	 */
	public String getDeviceResultsUri() {
		return deviceResultsUri;
	}

	/**
	 * @param deviceResultsUri
	 *            the deviceResultsUri to set
	 */
	public void setDeviceResultsUri(String deviceResultsUri) {
		this.deviceResultsUri = deviceResultsUri;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the deviceManagerUri
	 */
	public String getDeviceManagerUri() {
		return deviceManagerUri;
	}

	/**
	 * @param deviceManagerUri
	 *            the deviceManagerUri to set
	 */
	public void setDeviceManagerUri(String deviceManagerUri) {
		this.deviceManagerUri = deviceManagerUri;
	}

	/**
	 * @return the jobManagerUri
	 */
	public String getJobManagerUri() {
		return jobManagerUri;
	}

	/**
	 * @param jobManagerUri
	 *            the jobManagerUri to set
	 */
	public void setJobManagerUri(String jobManagerUri) {
		this.jobManagerUri = jobManagerUri;
	}

}
