/**
 * 
 */
package com.coned.odsListener.handler;

import javax.xml.bind.JAXBElement;

import com.tibco.ods.EndDeviceEventsEventMessageType;

/**
 * @author DATHATHRIA
 *
 */
public interface MessageHandler {
	void handleODSEvent(JAXBElement<EndDeviceEventsEventMessageType> events);
}
