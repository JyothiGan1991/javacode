
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RemoteProvisioningTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ARM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GET_STATUS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_RESET_TS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_PP_BALNCE"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_DLP_PROPS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DEACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_ESCC_PROP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GROUP_CONFIG"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_BROADCAST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROV_SET_IGNORE_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CLEAR_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DS"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RemoteProvisioningTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum RemoteProvisioningTypeEnumeration {

    JOB_OP_PROVISION_ARM("JOB_OP_PROVISION_ARM"),
    JOB_OP_PROVISION_CONNECT("JOB_OP_PROVISION_CONNECT"),
    JOB_OP_PROVISION_DISCONNECT("JOB_OP_PROVISION_DISCONNECT"),
    JOB_OP_PROVISION_GET_STATUS("JOB_OP_PROVISION_GET_STATUS"),
    JOB_OP_PROVISION_RESET_TS("JOB_OP_PROVISION_RESET_TS"),
    JOB_OP_PROVISION_ENABLE_PPM("JOB_OP_PROVISION_ENABLE_PPM"),
    JOB_OP_PROVISION_DISABLE_PPM("JOB_OP_PROVISION_DISABLE_PPM"),
    JOB_OP_PROVISION_SET_PP_BALNCE("JOB_OP_PROVISION_SET_PP_BALNCE"),
    JOB_OP_PROVISION_ENABLE_DLP("JOB_OP_PROVISION_ENABLE_DLP"),
    JOB_OP_PROVISION_DISABLE_DLP("JOB_OP_PROVISION_DISABLE_DLP"),
    JOB_OP_PROVISION_SET_DLP_PROPS("JOB_OP_PROVISION_SET_DLP_PROPS"),
    JOB_OP_PROVISION_ENABLE_LOCK("JOB_OP_PROVISION_ENABLE_LOCK"),
    JOB_OP_PROVISION_DISABLE_LOCK("JOB_OP_PROVISION_DISABLE_LOCK"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L1")
    JOB_OP_PROVISION_CONNECT_L_1("JOB_OP_PROVISION_CONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L1")
    JOB_OP_PROVISION_DISCONNECT_L_1("JOB_OP_PROVISION_DISCONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L2")
    JOB_OP_PROVISION_CONNECT_L_2("JOB_OP_PROVISION_CONNECT_L2"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L2")
    JOB_OP_PROVISION_DISCONNECT_L_2("JOB_OP_PROVISION_DISCONNECT_L2"),
    JOB_OP_PROVISION_ACT_ESCC("JOB_OP_PROVISION_ACT_ESCC"),
    JOB_OP_PROVISION_DEACT_ESCC("JOB_OP_PROVISION_DEACT_ESCC"),
    JOB_OP_PROVISION_ENABLE_ESCC("JOB_OP_PROVISION_ENABLE_ESCC"),
    JOB_OP_PROVISION_DISABLE_ESCC("JOB_OP_PROVISION_DISABLE_ESCC"),
    JOB_OP_PROVISION_SET_ESCC_PROP("JOB_OP_PROVISION_SET_ESCC_PROP"),
    JOB_OP_PROVISION_ENABLE_BOOST("JOB_OP_PROVISION_ENABLE_BOOST"),
    JOB_OP_PROVISION_DISABLE_BOOST("JOB_OP_PROVISION_DISABLE_BOOST"),
    JOB_OP_PROVISION_GROUP_CONFIG("JOB_OP_PROVISION_GROUP_CONFIG"),
    JOB_OP_PROVISION_BROADCAST("JOB_OP_PROVISION_BROADCAST"),
    JOB_OP_PROV_SET_IGNORE_TAMPER("JOB_OP_PROV_SET_IGNORE_TAMPER"),
    JOB_OP_PROVISION_CLEAR_TAMPER("JOB_OP_PROVISION_CLEAR_TAMPER"),
    JOB_OP_PROVISION_ENABLE_DS("JOB_OP_PROVISION_ENABLE_DS"),
    JOB_OP_PROVISION_DISABLE_DS("JOB_OP_PROVISION_DISABLE_DS"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    RemoteProvisioningTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RemoteProvisioningTypeEnumeration fromValue(String v) {
        for (RemoteProvisioningTypeEnumeration c: RemoteProvisioningTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
