package com.coned.ls.mapper;

import java.util.List;

/**
 * 
 * Class to return login response.
 *
 */
public class LoginResponseMapper {

	private boolean isAuthenticated;
	private String token;
	private List<String> userClaim;
	private String name;
	private String message;
	
	public boolean isAuthenticated() {
		return isAuthenticated;
	}
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<String> getUserClaim() {
		return userClaim;
	}
	public void setUserClaim(List<String> userClaim) {
		this.userClaim = userClaim;
	}
}
