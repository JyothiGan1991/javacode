package com.coned.event.repository;

import com.ssn.schema.service.v2_6.eventmanager.FindEventResultType;

public interface EventRepository {
	/**
	 * This persists the event status
	 * 
	 * @param result the event details
	 * @return the number of inserted rows
	 */
	int saveEventStatus(FindEventResultType result);

}
