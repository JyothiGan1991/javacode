package com.coned.ls.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.FilterAttribute;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFilterResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.service.MeterEventConnectService;
import com.coned.ls.service.MeterFilterService;
import com.coned.ls.service.OpenEventService;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller to implement Rest Api's for RCC Connect.
 * 
 */
@RestController
@RequestMapping("rcc/connect")
public class RCCConnectController extends BaseController{

	private static final Logger logger = LogManager.getLogger(RCCConnectController.class);

	@Autowired
	private OpenEventService openEventService; 
	
	@Autowired
	private MeterEventConnectService meterEventConnectService;
	
	@Autowired
	private MeterFilterService meterFilterService;  
	
    /*
     * This API return list of borough if the value of parameter is boro or list of event names if the value 
     * is event_name for disconnected meters. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields Valid input for this parameter are boro and event_name. 
     * 
     * @return 				ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/meters")
	public ResponseEntity<List<String>> getBoroughAndEventName(@RequestParam(name = "fields") String fields) {
		logger.info(String.format("Connect : Request for open event borough list"));

		if (fields.equalsIgnoreCase("boro")) {
			return openEventService.getExecuteBorough();
		} else if (fields.equalsIgnoreCase("event_name")) {
			return openEventService.getExecuteEvent();
		} else {
			throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
		}
	}

    /*
     * API to return list of event names for disconnected meters by borough.
     * 
     * @PathVariable borough 	Name of the borough. 
     * 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/meters/{borough}")
	public ResponseEntity<List<String>> getEventNameByBorough(@PathVariable(name = "borough") String borough) {
		logger.info(String.format("Connect : Request for open event list by borough %s", borough));
		
		return openEventService.getExecuteEventByBorough(borough);
	}
	
    /*
     * API to return list of disconnected meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @RequestBody meterOpenEvent  MeterOpenEvent 
     * 
     * @return 						ResponseEntity<MeterConnectResponseMapper> 
     *                         
     */
	@PostMapping("/events/meters")
	public ResponseEntity<MeterConnectResponseMapper> getValidMetersForConnect(HttpServletRequest request,@RequestBody MeterOpenEvent meterOpenEvent) throws Exception {
		logger.info(String.format("Connect : Request for list of meters by borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == adid || adid.equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		
		return meterEventConnectService.getValidMetersForConnect(meterOpenEvent);
	}

    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/meters/fields/{borough}")
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		logger.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));
		String decodedEventName=decodeEventname(eventName);
		ResponseEntity<List<String>> fieldValues = meterEventConnectService.getFieldValuesByBoroughAndEventName(borough, decodedEventName, fieldName);
		return fieldValues;
	}
	
    /*
     * API to return list of Connected Meters values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/connected/meters/fields/{borough}")
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		logger.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));
		String decodedEventName=decodeEventname(eventName);
		ResponseEntity<List<String>> fieldValues = meterEventConnectService.getConnectedMetersFieldValuesByBoroughAndEventName(borough, decodedEventName, fieldName);
		return fieldValues;
	}
	
    /*
     * API to return list of connected meters created for the event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * @RequestParam startRowIndex  int
     * @RequestParam batchSize  	int
     * 
     * @return 						ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@PostMapping("/events/connected/meters")
	public ResponseEntity<MeterConnectResponseMapper> getConnectedMeters(@RequestBody MeterOpenEvent meterOpenEvent) throws MeterEventConnectException {
		logger.info(String.format("Connect : Request for connected meter list by borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));
		
		if( null!= meterOpenEvent.getBorough() && null != meterOpenEvent.getEventName() && meterOpenEvent.getBatchSize() !=0 && meterOpenEvent.getStartRowIndex() !=0){
			return meterEventConnectService.getConnectedMeters(meterOpenEvent);
			
		} else{
			 logger.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(meterConnectResponseMapper);
		}
	}

    /*
     * API to finalize the list of meters selected in the Sub Event for connect.
     * 
     * @RequestBody subEvent SubEvent
     * 
     * @return				 ResponseEntity<MeterFinalizeResponseMapper> 
     *                         
     */
	@PostMapping("/events/finalize-sub/meters/")
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(HttpServletRequest request,@RequestBody SubEvent subEvent) throws Exception {
		logger.info(String.format("Connect : Request to finalize Sub Event based on borough : %s and event %s", subEvent.getBorough(), subEvent.getEvent()));

		String borough = subEvent.getBorough();
		String event  = subEvent.getEvent();
		String subEventName = subEvent.getSubEventName();
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		
		if(null != borough && null != event && null != subEventName){
			logger.info(String.format("Request for finalize sub meter event list based on borough : %s and event %s and sub event name %s", borough, event, subEventName));
			
			subEvent.setAdid(adid);
			return meterEventConnectService.finalizeSubEventMeter(subEvent);
		} else{
			logger.error(String.format("Connect : Invalid paramter passed."));
			
			MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper(false);
			meterFinalizeResponseMapper.setMessage("Invalid paramter passed");
			return ResponseEntity.status(701).body(meterFinalizeResponseMapper);
		}
	}

    /*
     * API to return Suffix for Sub Event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * @RequestParam items			String
     * 
     * @return				 		ResponseEntity<Long>
     *                         
     */
	@GetMapping("/events/finalize/sub-event/suffix")
	public ResponseEntity<Long> getSubEventSuffix(@RequestParam(name = "borough") final String borough, @RequestParam(name = "eventName") final String eventName,@RequestParam(name = "items") final String items) throws MeterEventConnectException {
		logger.info(String.format("Request for sub event suffix based on borough : %s and event %s and items is %s", borough, eventName, items));
		if( null!= borough && null != eventName && null!=items){
			String decodedEventName=decodeEventname(eventName);
			return meterEventConnectService.getSubEventSuffix(borough, decodedEventName);
		}else{
			 logger.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper(false);
			 meterFinalizeResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new Long(0));
		}	 
	}
	
    /*
     * API to Initiate filter attribute.
     * 
     * @Param borough         String
     * @Param eventName  	  String
     * @Param filterAttribute String
     * @Param startIndex  	  int
     * @Param fetchNext  	  int
     * 
     * @return 				  MeterFilterResponseMapper 
     *                         
     */
	@GetMapping("/events/filter/meters")
	public MeterFilterResponseMapper initMeterFilter(@RequestParam(name = "borough") String borough,@RequestParam(name = "eventName") String eventName,@RequestParam(name = "filterAttribute") String filterAttribute,@RequestParam(name = "startIndex") int startIndex, @RequestParam(name = "fetchNext") int fetchNext) throws Exception {
		logger.info(String.format("Initiate filter attribute for borough %s and event %s and filterAttribute %s start index at %s to %s",borough, eventName, filterAttribute, startIndex, fetchNext));
		String decodedEventName=decodeEventname(eventName);
		MeterFilterResponseMapper meterFilterResponseMapper = new MeterFilterResponseMapper();
		List<FilterAttribute> initMeterFilter = meterFilterService.initMeterFilter(borough, decodedEventName, filterAttribute, startIndex, fetchNext);
		if(!initMeterFilter.isEmpty()){
			meterFilterResponseMapper.setFilterAttributes(initMeterFilter);
			meterFilterResponseMapper.setValidResponse(true);
		}else{
			meterFilterResponseMapper.setValidResponse(false);
		}
		return meterFilterResponseMapper;
	}
	
    /*
     * This API return list of borough for Sub Event if the value of parameter is sub_boro or list of event names 
     * if the value is sub_event_name. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields  	Valid input for this parameter are sub_boro and sub_event_name. 
     * 
     * @return 				 	ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/sub-event/meters")
	public ResponseEntity<List<String>> getSubBoroughAndEventName(@RequestParam(name = "fields") String fields) {
		logger.info(String.format("Connect : Request for sub open event borough list"));
		
		if((fields.equalsIgnoreCase("sub_boro") || fields.equalsIgnoreCase("sub_event_name"))){
			if(fields.equalsIgnoreCase("sub_boro")){
				return openEventService.getSubFinalizeBorough();
			}else{
				return openEventService.getSubFinalizeEvent();
			}
		}else{
			 logger.info(String.format("Connect : Exception occured throw IllegalArgumentException"));
			 throw new IllegalArgumentException("Invalid input parameter, Valid parameters are sub_boro or sub_event_name.");
		}
	}

    /*
     * API to return list of event names for Sub Event.
     * 
     * @PathVariable borough 	Name of the borough. 
     * 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/sub-event/meters/{borough}")
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(@PathVariable(name = "borough") String borough) {
		logger.info(String.format("Connect : Request for open event list by borough %s", borough));
		
		return openEventService.getSubFinalizeEventByBorough(borough);
	}
	
    /*
     * API to return list of Sub Event names for the event.
     * 
     * @RequestParam borough 	String 
     * @RequestParam eventName 	String
     * 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/finalize/sub-event/meters")
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(@RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") String eventName) {
		logger.info(String.format("Connect : API Request parameter borough %s and event %s", borough, eventName));
		if(borough != null && eventName != null){
			String decodedEventName=decodeEventname(eventName);
			return openEventService.getSubFinalizeEventByEventAndBorough(borough, decodedEventName);
		}else{
			 logger.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new ArrayList<String>());
		}
	} 
	
    /*
     * API to search list of disconnected meters created for event.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * 
     * @return 					 ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@PostMapping("/events/search/meters")
	public ResponseEntity<MeterConnectResponseMapper> searchMeter(@RequestBody MeterSearch meterSearch) throws Exception {
		if(null != meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			return meterEventConnectService.searchMeters(meterSearch);
		}else{
			 logger.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new MeterConnectResponseMapper());
		}
	}
	
    /*
     * API to return list of meters in the Sub Event.
     * 
     * @RequestParam borough 		String 
     * @RequestParam eventName 		String
     * @RequestParam subEventName	String
     * @RequestParam startRowIndex  int
     * @RequestParam batchSize  	int
     * 
     * @return 				   		ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@GetMapping("/events/sub-event/meters")
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(@RequestParam(name = "borough") final String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "subEventName") final String subEventName,@RequestParam(name = "startRowIndex")final int startRowIndex,@RequestParam(name = "batchSize") final int batchSize) {
		logger.info(String.format("Request for validate meter event list based on borough : %s and event %s and pagesize is %s", borough, eventName, batchSize));
		
		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
		try{
			if( null!= borough && null != eventName && batchSize!=0 && startRowIndex!=0){
				String  decodedEventName=decodeEventname(eventName);
				return meterEventConnectService.getSubEventMeters(borough, decodedEventName, subEventName, startRowIndex, batchSize);
			}
		}catch(IllegalArgumentException ex){
			logger.error(ex.getMessage(), ex);
		}
		 return ResponseEntity.status(HttpStatus.NO_CONTENT).body(meterConnectResponseMapper);
	}
	
    /*
     * API to search list of connected meters created for event.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * 
     * @return 					 ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@PostMapping("/events/connected/search/meters")
	public ResponseEntity<MeterConnectResponseMapper> searchMeterConnected(@RequestBody MeterSearch meterSearch) throws Exception {
		logger.info(String.format("Connect : Request for list of connected meters based on borough : %s and event %s", meterSearch.getBorough(), meterSearch.getEvent()));

		if(null != meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			return meterEventConnectService.searchMeterConnected(meterSearch);
		}else{
			 logger.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 
			 return ResponseEntity.status(701).body(new MeterConnectResponseMapper());
		}
	}
	
    /*
     * API to create Sub Event.
     * 
     * @RequestBody subEvent SubEvent
     * 
     * @return				 ResponseEntity<MeterConnectResponseMapper>
     *                         
     */
	@PostMapping("/events/sub-event/meters")
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(@RequestBody SubEvent subEvent) throws Exception {
		logger.info(String.format("Connect : Request for creating Sub Event by borough : %s", subEvent.getBorough(), " eventName : %s", subEvent.getEvent()));

		return meterEventConnectService.getSubEventMeters(subEvent);
	}

    /*
     * API to check event is locked.
     * 
     * @RequestParam borough   String
     * @RequestParam eventName String
     * 
     * @return				   MeterLockedStatusResponseMapper
     *                         
     */
	@GetMapping("/events/status/meters")
	public MeterLockedStatusResponseMapper isEventLocked(HttpServletRequest request,@RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName){
		logger.info(String.format("Connect : Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		String decodedEventName=decodeEventname(eventName);
		return meterEventConnectService.isEventLocked(borough, decodedEventName, adid);
	}

    /*
     * API to unlocked the events.
     * 
     * @RequestBody request HttpServletRequest
     * 
     * @return				void
     *                         
     */
	@PutMapping("/events/status/meters")
	public void unlockEvents(HttpServletRequest request) {
		logger.info(String.format("Request to unlock the events"));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		meterEventConnectService.unlockEvents(adid);
	}
	private String decodeEventname(String eventName){
		String decodedEventName=eventName;
		if(eventName!=null){
			 try {
				decodedEventName=URLDecoder.decode(eventName,StandardCharsets.UTF_8.name());
			} catch (UnsupportedEncodingException e) {
				logger.error("Unsupported encoding:", e);
			}

		}
		return decodedEventName;
	}
}
