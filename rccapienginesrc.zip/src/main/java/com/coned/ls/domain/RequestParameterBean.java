package com.coned.ls.domain;

public class RequestParameterBean {

	private String requestParameterOne;
	private String requestParameterTwo;
	private String requestParameterThree;
	private String requestParameterFour;
	private String requestParameterFive;
	
	
	
	public String getRequestParameterOne() {
		return requestParameterOne;
	}
	public void setRequestParameterOne(String requestParameterOne) {
		this.requestParameterOne = requestParameterOne;
	}
	public String getRequestParameterTwo() {
		return requestParameterTwo;
	}
	public void setRequestParameterTwo(String requestParameterTwo) {
		this.requestParameterTwo = requestParameterTwo;
	}
	public String getRequestParameterThree() {
		return requestParameterThree;
	}
	public void setRequestParameterThree(String requestParameterThree) {
		this.requestParameterThree = requestParameterThree;
	}
	public String getRequestParameterFour() {
		return requestParameterFour;
	}
	public void setRequestParameterFour(String requestParameterFour) {
		this.requestParameterFour = requestParameterFour;
	}
	public String getRequestParameterFive() {
		return requestParameterFive;
	}
	public void setRequestParameterFive(String requestParameterFive) {
		this.requestParameterFive = requestParameterFive;
	}
	
	
	
}
