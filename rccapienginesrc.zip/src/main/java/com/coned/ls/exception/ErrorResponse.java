package com.coned.ls.exception;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * Class used to store error details.
 *
 */
public class ErrorResponse {

	@JsonProperty("detail")
	private String detail;
	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("title")
	private String title;
	
	@JsonProperty("timestamp")
	private Date timestamp;
	
	@JsonProperty("method")
	private String method;
	
	@JsonProperty("debugMessage")
	private Object debugMessage;
	
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}

	public Object getDebugMessage() {
		return debugMessage;
	}
	public ErrorResponse() {
		super();
	}
	public void setDebugMessage(Object printStackTrace) {
		this.debugMessage = printStackTrace;
	}
	
	
}
