package com.coned.ls.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.MeterEventValidateRepository;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={MeterEventValidateService.class})
@AutoConfigureMockMvc
public class MeterEventValidateServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private MeterEventValidateService meterEventValidateService = new MeterEventValidateServiceImpl();
	
	@Mock
	private MeterEventValidateRepository meterEventValidateRepository;
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	private MeterEventLoad  meterEventLoad;
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		meterEventLoad = meterEventLoadC;
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setIsEventLocked(false);
		
	}
	@Test
	public void getValidateMeterTest() throws MeterValidateException, VcapRecordNotFoundException{
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		String adid = "XYZ";
		Mockito.when(meterEventValidateRepository.isEventLocked("C","SheepsheadBaySampleData7.27.20-1350", adid)).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.isEventFinalized("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.verifyNewEventEntryInLS("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(false);
		Mockito.when(meterEventValidateRepository.pushMeterEventFromVcapToLS("C", "SheepsheadBaySampleData7.27.20-1350", "Test", "Test", adid)).thenReturn(true);
		Mockito.when(meterEventValidateRepository.validateMeterEventWithStar("C", "SheepsheadBaySampleData7.27.20-1350")).thenReturn(false);
		Mockito.when(meterEventValidateRepository.getValidateMeterList(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),Mockito.anyString(), Mockito.anyString())).thenReturn(meterValidateResponseMapper);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("C");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		meterOpenEvent.setFromDate(fromDateAsString);
		meterOpenEvent.setToDate(toDateAsString);
		meterOpenEvent.setAdid(adid);
		
		Map<String,String> map = new HashMap<>();
		map.put("Test", "Test");
		meterOpenEvent.setFilterList(map);
		meterOpenEvent.setFilterApplied(true);
		meterOpenEvent.setSortList(map);
		meterOpenEvent.setSortApplied(true);
		
		
		
		ResponseEntity<MeterValidateResponseMapper> validateMeter = meterEventValidateService.getValidateMeter(meterOpenEvent);
		
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
	}
	
	@Test
	public void getValidateMeterTest2() throws MeterValidateException, VcapRecordNotFoundException{
		MeterValidateResponseMapper meterValidateResponseMapper=new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setIsEventLocked(true);
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("C");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		meterOpenEvent.setFromDate(fromDateAsString);
		meterOpenEvent.setToDate(toDateAsString);
		meterOpenEvent.setAdid(adid);
		
		Mockito.when(meterEventValidateRepository.isEventLocked("C","SheepsheadBaySampleData7.27.20-1350", adid)).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.isEventFinalized("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.verifyNewEventEntryInLS("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(false);
		Mockito.when(meterEventValidateRepository.pushMeterEventFromVcapToLS("C", "SheepsheadBaySampleData7.27.20-1350", "Test", "Test", adid)).thenReturn(true);
		Mockito.when(meterEventValidateRepository.validateMeterEventWithStar("C", "SheepsheadBaySampleData7.27.20-1350")).thenReturn(false);
		Mockito.when(meterEventValidateRepository.getValidateMeterList(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),Mockito.anyString(), Mockito.anyString())).thenReturn(meterValidateResponseMapper);
		ResponseEntity<MeterValidateResponseMapper> validateMeter = meterEventValidateService.getValidateMeter(meterOpenEvent);
		
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
		}
	
	@Test
	public void getValidateMeterTest3() throws MeterValidateException, VcapRecordNotFoundException{	
		
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("C");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		meterOpenEvent.setFromDate(fromDateAsString);
		meterOpenEvent.setToDate(toDateAsString);
		meterOpenEvent.setAdid(adid);
		
		Mockito.when(meterEventValidateRepository.isEventLocked("C","SheepsheadBaySampleData7.27.20-1350", adid)).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.isEventFinalized("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.verifyNewEventEntryInLS("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(false);
		Mockito.when(meterEventValidateRepository.pushMeterEventFromVcapToLS("C", "SheepsheadBaySampleData7.27.20-1350", fromDateAsString, toDateAsString, adid)).thenReturn(true);
		Mockito.when(meterEventValidateRepository.validateMeterEventWithStar("C", "SheepsheadBaySampleData7.27.20-1350")).thenReturn(true);
		Mockito.when(meterEventValidateRepository.getValidateMeterList(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),Mockito.anyString(), Mockito.anyString())).thenReturn(meterValidateResponseMapper);
		ResponseEntity<MeterValidateResponseMapper> validateMeter = meterEventValidateService.getValidateMeter(meterOpenEvent);
		
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
		
	}
	
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeterTest_Exception() throws MeterValidateException, VcapRecordNotFoundException{
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		meterValidateResponseMapper.getMeterEventLoads().clear();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid="XYZ";
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("C");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		meterOpenEvent.setFromDate(fromDateAsString);
		meterOpenEvent.setToDate(toDateAsString);
		meterOpenEvent.setAdid(adid);
		
		Mockito.when(meterEventValidateRepository.isEventLocked("C","SheepsheadBaySampleData7.27.20-1350", "XYZ")).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.isEventFinalized("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterValidateResponseMapper);
		Mockito.when(meterEventValidateRepository.verifyNewEventEntryInLS("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(true);
		Mockito.when(meterEventValidateRepository.getValidateMeterList(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),Mockito.anyString(), Mockito.anyString())).thenReturn(meterValidateResponseMapper);
		
		ResponseEntity<MeterValidateResponseMapper> validateMeter = meterEventValidateService.getValidateMeter(meterOpenEvent);
		
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getBody().getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
		}
	
	@Test
	public void searchMetersTest(){
		DateUtils.setDate(new Date());
		MeterSearch meterSearch = new MeterSearch();
		Mockito.when(meterEventValidateRepository.searchMeters(meterSearch)).thenReturn(meterValidateResponseMapper);
		ResponseEntity<MeterValidateResponseMapper> searchMeter = meterEventValidateService.searchMeters(meterSearch);
		
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(searchMeter.getBody().getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
	}
	
	@Test
	public void verifyNewEventEntryInLSTest(){
		Mockito.when(meterEventValidateRepository.verifyNewEventEntryInLS(Mockito.anyString() , Mockito.anyString())).thenReturn(true);
		Boolean verifyNewEventEntryInLSTest = meterEventValidateService.verifyNewEventEntryInLS(Mockito.anyString() , Mockito.anyString());
		Assert.assertEquals(verifyNewEventEntryInLSTest,true);
	}

	
	@Test
	public void pushMeterEventFromVcapToLSTest() throws MeterValidateException, VcapRecordNotFoundException{
		Mockito.when(meterEventValidateRepository.pushMeterEventFromVcapToLS(Mockito.anyString() , Mockito.anyString(), Mockito.anyString() , Mockito.anyString(), Mockito.anyString() )).thenReturn(true);
		Boolean pushMeterEventFromVcapToLSTest = meterEventValidateService.pushMeterEventFromVcapToLS(Mockito.anyString() , Mockito.anyString(), Mockito.anyString() , Mockito.anyString(), Mockito.anyString());
		Assert.assertEquals(pushMeterEventFromVcapToLSTest,true);
	}
	
	//validateMeterEventWithStar
	@Test
	public void validateMeterEventWithStarTest() throws MeterValidateException, VcapRecordNotFoundException{
		Mockito.when(meterEventValidateRepository.validateMeterEventWithStar(Mockito.anyString() , Mockito.anyString())).thenReturn(true);
		Boolean validateMeterEventWithStarTest = meterEventValidateService.validateMeterEventWithStar(Mockito.anyString() , Mockito.anyString());
		Assert.assertEquals(validateMeterEventWithStarTest,true);
	}
	@Test
    public void  getFieldValuesByBoroughAndEventNameTest(){
    	List<String> fields = new ArrayList<String>();
        //ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(fields, HttpStatus.OK);
		Mockito.when(meterEventValidateRepository.getFieldValuesByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","sub_event")).thenReturn((fields));
		ResponseEntity<List<String>> actual = meterEventValidateService.getFieldValuesByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","sub_event");
		Assert.assertEquals(fields,actual.getBody());
    }
	
	@Test
	public void getInValidateMeterListTest() {
		MeterValidateResponseMapper mapper = new MeterValidateResponseMapper();
		Mockito.when(meterEventValidateRepository.getInValidateMeterList(Mockito.anyString() , Mockito.anyString(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(mapper);
		MeterValidateResponseMapper actual = meterEventValidateService.getInValidateMeterList(Mockito.anyString() , Mockito.anyString(), Mockito.anyInt(),Mockito.anyInt());
		Assert.assertEquals(mapper.getBorough(),actual.getBorough());
	}
	@Test
    public void getLockedStatusByBoroughAndEventNameTest(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
		Mockito.when(meterEventValidateRepository.getLockedStatusByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = meterEventValidateService.getLockedStatusByBoroughAndEventName("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK");
		Assert.assertEquals(mlsp.getMessage(),response.getMessage());
    }
	@Test
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doNothing().when(meterEventValidateRepository).unlockEvents(adid);
		meterEventValidateService.unlockEvents(adid);
	}
    
}
