
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditRelayTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditRelayTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EmptyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RelayTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditRelayTypeReq", propOrder = {
    "relayTypeConfigID"
})
public class AddEditRelayTypeReq
    extends EmptyType
{

    @XmlElement(name = "RelayTypeConfigID")
    protected long relayTypeConfigID;

    /**
     * Gets the value of the relayTypeConfigID property.
     * 
     */
    public long getRelayTypeConfigID() {
        return relayTypeConfigID;
    }

    /**
     * Sets the value of the relayTypeConfigID property.
     * 
     */
    public void setRelayTypeConfigID(long value) {
        this.relayTypeConfigID = value;
    }

}
