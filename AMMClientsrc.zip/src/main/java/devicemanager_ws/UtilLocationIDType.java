
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UtilLocationIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UtilLocationIDType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UtilLocationID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="LocationType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DefinedLocationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UtilLocationIDType", propOrder = {
    "utilLocationID",
    "locationType"
})
public class UtilLocationIDType {

    @XmlElement(name = "UtilLocationID", required = true)
    protected String utilLocationID;
    @XmlElement(name = "LocationType")
    protected DefinedLocationType locationType;

    /**
     * Gets the value of the utilLocationID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilLocationID() {
        return utilLocationID;
    }

    /**
     * Sets the value of the utilLocationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilLocationID(String value) {
        this.utilLocationID = value;
    }

    /**
     * Gets the value of the locationType property.
     * 
     * @return
     *     possible object is
     *     {@link DefinedLocationType }
     *     
     */
    public DefinedLocationType getLocationType() {
        return locationType;
    }

    /**
     * Sets the value of the locationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DefinedLocationType }
     *     
     */
    public void setLocationType(DefinedLocationType value) {
        this.locationType = value;
    }

}
