
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CountsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CountsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ResolvedCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="UnresolvedCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="AssignedCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="AlarmingEventCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="EventOnlyCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="UserAlarmCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="SelfAlarmCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="DistinctUserCount" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CountsType", propOrder = {
    "resolvedCount",
    "unresolvedCount",
    "assignedCount",
    "alarmingEventCount",
    "eventOnlyCount",
    "userAlarmCount",
    "selfAlarmCount",
    "distinctUserCount"
})
public class CountsType {

    @XmlElement(name = "ResolvedCount")
    protected long resolvedCount;
    @XmlElement(name = "UnresolvedCount")
    protected long unresolvedCount;
    @XmlElement(name = "AssignedCount")
    protected long assignedCount;
    @XmlElement(name = "AlarmingEventCount")
    protected long alarmingEventCount;
    @XmlElement(name = "EventOnlyCount")
    protected long eventOnlyCount;
    @XmlElement(name = "UserAlarmCount")
    protected long userAlarmCount;
    @XmlElement(name = "SelfAlarmCount")
    protected long selfAlarmCount;
    @XmlElement(name = "DistinctUserCount")
    protected long distinctUserCount;

    /**
     * Gets the value of the resolvedCount property.
     * 
     */
    public long getResolvedCount() {
        return resolvedCount;
    }

    /**
     * Sets the value of the resolvedCount property.
     * 
     */
    public void setResolvedCount(long value) {
        this.resolvedCount = value;
    }

    /**
     * Gets the value of the unresolvedCount property.
     * 
     */
    public long getUnresolvedCount() {
        return unresolvedCount;
    }

    /**
     * Sets the value of the unresolvedCount property.
     * 
     */
    public void setUnresolvedCount(long value) {
        this.unresolvedCount = value;
    }

    /**
     * Gets the value of the assignedCount property.
     * 
     */
    public long getAssignedCount() {
        return assignedCount;
    }

    /**
     * Sets the value of the assignedCount property.
     * 
     */
    public void setAssignedCount(long value) {
        this.assignedCount = value;
    }

    /**
     * Gets the value of the alarmingEventCount property.
     * 
     */
    public long getAlarmingEventCount() {
        return alarmingEventCount;
    }

    /**
     * Sets the value of the alarmingEventCount property.
     * 
     */
    public void setAlarmingEventCount(long value) {
        this.alarmingEventCount = value;
    }

    /**
     * Gets the value of the eventOnlyCount property.
     * 
     */
    public long getEventOnlyCount() {
        return eventOnlyCount;
    }

    /**
     * Sets the value of the eventOnlyCount property.
     * 
     */
    public void setEventOnlyCount(long value) {
        this.eventOnlyCount = value;
    }

    /**
     * Gets the value of the userAlarmCount property.
     * 
     */
    public long getUserAlarmCount() {
        return userAlarmCount;
    }

    /**
     * Sets the value of the userAlarmCount property.
     * 
     */
    public void setUserAlarmCount(long value) {
        this.userAlarmCount = value;
    }

    /**
     * Gets the value of the selfAlarmCount property.
     * 
     */
    public long getSelfAlarmCount() {
        return selfAlarmCount;
    }

    /**
     * Sets the value of the selfAlarmCount property.
     * 
     */
    public void setSelfAlarmCount(long value) {
        this.selfAlarmCount = value;
    }

    /**
     * Gets the value of the distinctUserCount property.
     * 
     */
    public long getDistinctUserCount() {
        return distinctUserCount;
    }

    /**
     * Sets the value of the distinctUserCount property.
     * 
     */
    public void setDistinctUserCount(long value) {
        this.distinctUserCount = value;
    }

}
