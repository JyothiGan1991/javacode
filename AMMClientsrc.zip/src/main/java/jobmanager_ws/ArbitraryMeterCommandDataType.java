
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArbitraryMeterCommandDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArbitraryMeterCommandDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}FilterableExportDataType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileSegmenting" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}MeterReadFileSegmentingType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArbitraryMeterCommandDataType", propOrder = {
    "fileSegmenting"
})
public class ArbitraryMeterCommandDataType
    extends FilterableExportDataType
{

    @XmlElement(name = "FileSegmenting")
    protected MeterReadFileSegmentingType fileSegmenting;

    /**
     * Gets the value of the fileSegmenting property.
     * 
     * @return
     *     possible object is
     *     {@link MeterReadFileSegmentingType }
     *     
     */
    public MeterReadFileSegmentingType getFileSegmenting() {
        return fileSegmenting;
    }

    /**
     * Sets the value of the fileSegmenting property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterReadFileSegmentingType }
     *     
     */
    public void setFileSegmenting(MeterReadFileSegmentingType value) {
        this.fileSegmenting = value;
    }

}
