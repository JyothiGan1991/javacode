
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindServicePtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindServicePtType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServicePtID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilServicePtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterPhase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterLocCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePhaseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ServiceVoltLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpLongitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpLatitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpHeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpExtUrl" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *         &lt;element name="SpImage1Note" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpImage2Note" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DevicePtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DeviceCtRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LastBillDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NextBillDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Account" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindAccountType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtTransformer" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindServicePtTransformerType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TenantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindServicePtType", propOrder = {
    "servicePtID",
    "utilServicePtID",
    "serviceType",
    "meterPhase",
    "meterLocCode",
    "servicePhaseCode",
    "serviceVoltLevelCode",
    "spLongitude",
    "spLatitude",
    "spHeight",
    "spExtUrl",
    "spImage1Note",
    "spImage2Note",
    "devicePtRatio",
    "deviceCtRatio",
    "billingCycle",
    "lastBillDate",
    "nextBillDate",
    "account",
    "servicePtTransformer",
    "servicePtAttribute1",
    "servicePtAttribute2",
    "servicePtAttribute3",
    "servicePtAttribute4",
    "servicePtAttribute5",
    "tenantId"
})
public class FindServicePtType {

    @XmlElement(name = "ServicePtID")
    protected Long servicePtID;
    @XmlElement(name = "UtilServicePtID")
    protected String utilServicePtID;
    @XmlElement(name = "ServiceType")
    protected String serviceType;
    @XmlElement(name = "MeterPhase")
    protected String meterPhase;
    @XmlElement(name = "MeterLocCode")
    protected String meterLocCode;
    @XmlElement(name = "ServicePhaseCode")
    protected Integer servicePhaseCode;
    @XmlElement(name = "ServiceVoltLevelCode")
    protected String serviceVoltLevelCode;
    @XmlElement(name = "SpLongitude")
    protected Double spLongitude;
    @XmlElement(name = "SpLatitude")
    protected Double spLatitude;
    @XmlElement(name = "SpHeight")
    protected Double spHeight;
    @XmlElement(name = "SpExtUrl")
    @XmlSchemaType(name = "anyURI")
    protected String spExtUrl;
    @XmlElement(name = "SpImage1Note")
    protected String spImage1Note;
    @XmlElement(name = "SpImage2Note")
    protected String spImage2Note;
    @XmlElement(name = "DevicePtRatio")
    protected Double devicePtRatio;
    @XmlElement(name = "DeviceCtRatio")
    protected Double deviceCtRatio;
    @XmlElement(name = "BillingCycle")
    protected String billingCycle;
    @XmlElement(name = "LastBillDate")
    protected String lastBillDate;
    @XmlElement(name = "NextBillDate")
    protected String nextBillDate;
    @XmlElement(name = "Account")
    protected FindAccountType account;
    @XmlElement(name = "ServicePtTransformer")
    protected FindServicePtTransformerType servicePtTransformer;
    @XmlElement(name = "ServicePtAttribute1")
    protected String servicePtAttribute1;
    @XmlElement(name = "ServicePtAttribute2")
    protected String servicePtAttribute2;
    @XmlElement(name = "ServicePtAttribute3")
    protected String servicePtAttribute3;
    @XmlElement(name = "ServicePtAttribute4")
    protected String servicePtAttribute4;
    @XmlElement(name = "ServicePtAttribute5")
    protected String servicePtAttribute5;
    @XmlElement(name = "TenantId")
    protected String tenantId;

    /**
     * Gets the value of the servicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServicePtID() {
        return servicePtID;
    }

    /**
     * Sets the value of the servicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServicePtID(Long value) {
        this.servicePtID = value;
    }

    /**
     * Gets the value of the utilServicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePtID() {
        return utilServicePtID;
    }

    /**
     * Sets the value of the utilServicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePtID(String value) {
        this.utilServicePtID = value;
    }

    /**
     * Gets the value of the serviceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * Sets the value of the serviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceType(String value) {
        this.serviceType = value;
    }

    /**
     * Gets the value of the meterPhase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterPhase() {
        return meterPhase;
    }

    /**
     * Sets the value of the meterPhase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterPhase(String value) {
        this.meterPhase = value;
    }

    /**
     * Gets the value of the meterLocCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterLocCode() {
        return meterLocCode;
    }

    /**
     * Sets the value of the meterLocCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterLocCode(String value) {
        this.meterLocCode = value;
    }

    /**
     * Gets the value of the servicePhaseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getServicePhaseCode() {
        return servicePhaseCode;
    }

    /**
     * Sets the value of the servicePhaseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setServicePhaseCode(Integer value) {
        this.servicePhaseCode = value;
    }

    /**
     * Gets the value of the serviceVoltLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceVoltLevelCode() {
        return serviceVoltLevelCode;
    }

    /**
     * Sets the value of the serviceVoltLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceVoltLevelCode(String value) {
        this.serviceVoltLevelCode = value;
    }

    /**
     * Gets the value of the spLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpLongitude() {
        return spLongitude;
    }

    /**
     * Sets the value of the spLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpLongitude(Double value) {
        this.spLongitude = value;
    }

    /**
     * Gets the value of the spLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpLatitude() {
        return spLatitude;
    }

    /**
     * Sets the value of the spLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpLatitude(Double value) {
        this.spLatitude = value;
    }

    /**
     * Gets the value of the spHeight property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpHeight() {
        return spHeight;
    }

    /**
     * Sets the value of the spHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpHeight(Double value) {
        this.spHeight = value;
    }

    /**
     * Gets the value of the spExtUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpExtUrl() {
        return spExtUrl;
    }

    /**
     * Sets the value of the spExtUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpExtUrl(String value) {
        this.spExtUrl = value;
    }

    /**
     * Gets the value of the spImage1Note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpImage1Note() {
        return spImage1Note;
    }

    /**
     * Sets the value of the spImage1Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpImage1Note(String value) {
        this.spImage1Note = value;
    }

    /**
     * Gets the value of the spImage2Note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpImage2Note() {
        return spImage2Note;
    }

    /**
     * Sets the value of the spImage2Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpImage2Note(String value) {
        this.spImage2Note = value;
    }

    /**
     * Gets the value of the devicePtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDevicePtRatio() {
        return devicePtRatio;
    }

    /**
     * Sets the value of the devicePtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDevicePtRatio(Double value) {
        this.devicePtRatio = value;
    }

    /**
     * Gets the value of the deviceCtRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDeviceCtRatio() {
        return deviceCtRatio;
    }

    /**
     * Sets the value of the deviceCtRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDeviceCtRatio(Double value) {
        this.deviceCtRatio = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycle(String value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the lastBillDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastBillDate() {
        return lastBillDate;
    }

    /**
     * Sets the value of the lastBillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastBillDate(String value) {
        this.lastBillDate = value;
    }

    /**
     * Gets the value of the nextBillDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextBillDate() {
        return nextBillDate;
    }

    /**
     * Sets the value of the nextBillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextBillDate(String value) {
        this.nextBillDate = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link FindAccountType }
     *     
     */
    public FindAccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindAccountType }
     *     
     */
    public void setAccount(FindAccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the servicePtTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link FindServicePtTransformerType }
     *     
     */
    public FindServicePtTransformerType getServicePtTransformer() {
        return servicePtTransformer;
    }

    /**
     * Sets the value of the servicePtTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindServicePtTransformerType }
     *     
     */
    public void setServicePtTransformer(FindServicePtTransformerType value) {
        this.servicePtTransformer = value;
    }

    /**
     * Gets the value of the servicePtAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute1() {
        return servicePtAttribute1;
    }

    /**
     * Sets the value of the servicePtAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute1(String value) {
        this.servicePtAttribute1 = value;
    }

    /**
     * Gets the value of the servicePtAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute2() {
        return servicePtAttribute2;
    }

    /**
     * Sets the value of the servicePtAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute2(String value) {
        this.servicePtAttribute2 = value;
    }

    /**
     * Gets the value of the servicePtAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute3() {
        return servicePtAttribute3;
    }

    /**
     * Sets the value of the servicePtAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute3(String value) {
        this.servicePtAttribute3 = value;
    }

    /**
     * Gets the value of the servicePtAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute4() {
        return servicePtAttribute4;
    }

    /**
     * Sets the value of the servicePtAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute4(String value) {
        this.servicePtAttribute4 = value;
    }

    /**
     * Gets the value of the servicePtAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute5() {
        return servicePtAttribute5;
    }

    /**
     * Sets the value of the servicePtAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute5(String value) {
        this.servicePtAttribute5 = value;
    }

    /**
     * Gets the value of the tenantId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * Sets the value of the tenantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenantId(String value) {
        this.tenantId = value;
    }

}
