
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateNetworkBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateNetworkBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType" minOccurs="0"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="UtilNmState" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableUtilNetworkStateType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetworkID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicArchitecture" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableNicArchitectureType" minOccurs="0"/&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BackboneDevice" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBoolean" minOccurs="0"/&gt;
 *         &lt;element name="Suspect" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBoolean" minOccurs="0"/&gt;
 *         &lt;element name="SuspectReason" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="MfgDate" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="HardwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="InstallTS" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="RemoveTS" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="GUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetDeviceID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CatalogNumber" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ProgramSealAtManufacture" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute4" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute5" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute4" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute5" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="NicTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="NicTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;choice&gt;
 *           &lt;element name="NicSoftwareTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="NicSoftwareTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;choice&gt;
 *           &lt;element name="BatteryTypeConfigID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *           &lt;element name="BatteryTypeConfigIdentifier" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBatteryIdentifier" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateNetworkBaseDeviceType", propOrder = {
    "didType",
    "didSubtype",
    "utilDeviceID",
    "utilDeviceState",
    "utilNmState",
    "name",
    "networkID",
    "nicSerialNumber",
    "nicArchitecture",
    "macID",
    "nicHardwareConfig",
    "nicSoftwareConfig",
    "serialNumber",
    "backboneDevice",
    "suspect",
    "suspectReason",
    "description",
    "timeZoneID",
    "mfgDate",
    "softwareConfig",
    "hardwareConfig",
    "installTS",
    "removeTS",
    "guid",
    "netDeviceID",
    "catalogNumber",
    "programSealAtManufacture",
    "deviceAttribute1",
    "deviceAttribute2",
    "deviceAttribute3",
    "deviceAttribute4",
    "deviceAttribute5",
    "nicAttribute1",
    "nicAttribute2",
    "nicAttribute3",
    "nicAttribute4",
    "nicAttribute5",
    "nicTypeConfigID",
    "nicTypeConfigName",
    "nicSoftwareTypeConfigID",
    "nicSoftwareTypeConfigName",
    "batteryTypeConfigID",
    "batteryTypeConfigIdentifier"
})
public class UpdateNetworkBaseDeviceType {

    @XmlElement(name = "DidType")
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype")
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "UtilDeviceID")
    protected String utilDeviceID;
    @XmlElement(name = "UtilDeviceState")
    protected UtilDeviceStateType utilDeviceState;
    @XmlElement(name = "UtilNmState")
    protected NullableUtilNetworkStateType utilNmState;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "NetworkID")
    protected String networkID;
    @XmlElement(name = "NicSerialNumber")
    protected String nicSerialNumber;
    @XmlElement(name = "NicArchitecture")
    protected NullableNicArchitectureType nicArchitecture;
    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "NicHardwareConfig")
    protected NullableString nicHardwareConfig;
    @XmlElement(name = "NicSoftwareConfig")
    protected NullableString nicSoftwareConfig;
    @XmlElement(name = "SerialNumber")
    protected String serialNumber;
    @XmlElement(name = "BackboneDevice", defaultValue = "false")
    protected NullableBoolean backboneDevice;
    @XmlElement(name = "Suspect", defaultValue = "false")
    protected NullableBoolean suspect;
    @XmlElement(name = "SuspectReason")
    protected NullableString suspectReason;
    @XmlElement(name = "Description")
    protected NullableString description;
    @XmlElement(name = "TimeZoneID")
    protected TimeZoneType timeZoneID;
    @XmlElement(name = "MfgDate")
    protected NullableString mfgDate;
    @XmlElement(name = "SoftwareConfig")
    protected NullableString softwareConfig;
    @XmlElement(name = "HardwareConfig")
    protected NullableString hardwareConfig;
    @XmlElement(name = "InstallTS")
    protected NullableString installTS;
    @XmlElement(name = "RemoveTS")
    protected NullableString removeTS;
    @XmlElement(name = "GUID")
    protected String guid;
    @XmlElement(name = "NetDeviceID")
    protected Long netDeviceID;
    @XmlElement(name = "CatalogNumber")
    protected NullableString catalogNumber;
    @XmlElement(name = "ProgramSealAtManufacture")
    protected NullableString programSealAtManufacture;
    @XmlElement(name = "DeviceAttribute1")
    protected NullableString deviceAttribute1;
    @XmlElement(name = "DeviceAttribute2")
    protected NullableString deviceAttribute2;
    @XmlElement(name = "DeviceAttribute3")
    protected NullableString deviceAttribute3;
    @XmlElement(name = "DeviceAttribute4")
    protected NullableString deviceAttribute4;
    @XmlElement(name = "DeviceAttribute5")
    protected NullableString deviceAttribute5;
    @XmlElement(name = "NicAttribute1")
    protected NullableString nicAttribute1;
    @XmlElement(name = "NicAttribute2")
    protected NullableString nicAttribute2;
    @XmlElement(name = "NicAttribute3")
    protected NullableString nicAttribute3;
    @XmlElement(name = "NicAttribute4")
    protected NullableString nicAttribute4;
    @XmlElement(name = "NicAttribute5")
    protected NullableString nicAttribute5;
    @XmlElement(name = "NicTypeConfigID")
    protected Long nicTypeConfigID;
    @XmlElement(name = "NicTypeConfigName")
    protected String nicTypeConfigName;
    @XmlElement(name = "NicSoftwareTypeConfigID")
    protected Long nicSoftwareTypeConfigID;
    @XmlElement(name = "NicSoftwareTypeConfigName")
    protected String nicSoftwareTypeConfigName;
    @XmlElement(name = "BatteryTypeConfigID")
    protected NullableLong batteryTypeConfigID;
    @XmlElement(name = "BatteryTypeConfigIdentifier")
    protected NullableBatteryIdentifier batteryTypeConfigIdentifier;

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the utilDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceState() {
        return utilDeviceState;
    }

    /**
     * Sets the value of the utilDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceState(UtilDeviceStateType value) {
        this.utilDeviceState = value;
    }

    /**
     * Gets the value of the utilNmState property.
     * 
     * @return
     *     possible object is
     *     {@link NullableUtilNetworkStateType }
     *     
     */
    public NullableUtilNetworkStateType getUtilNmState() {
        return utilNmState;
    }

    /**
     * Sets the value of the utilNmState property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableUtilNetworkStateType }
     *     
     */
    public void setUtilNmState(NullableUtilNetworkStateType value) {
        this.utilNmState = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the networkID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkID() {
        return networkID;
    }

    /**
     * Sets the value of the networkID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkID(String value) {
        this.networkID = value;
    }

    /**
     * Gets the value of the nicSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSerialNumber() {
        return nicSerialNumber;
    }

    /**
     * Sets the value of the nicSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSerialNumber(String value) {
        this.nicSerialNumber = value;
    }

    /**
     * Gets the value of the nicArchitecture property.
     * 
     * @return
     *     possible object is
     *     {@link NullableNicArchitectureType }
     *     
     */
    public NullableNicArchitectureType getNicArchitecture() {
        return nicArchitecture;
    }

    /**
     * Sets the value of the nicArchitecture property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableNicArchitectureType }
     *     
     */
    public void setNicArchitecture(NullableNicArchitectureType value) {
        this.nicArchitecture = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the nicHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicHardwareConfig() {
        return nicHardwareConfig;
    }

    /**
     * Sets the value of the nicHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicHardwareConfig(NullableString value) {
        this.nicHardwareConfig = value;
    }

    /**
     * Gets the value of the nicSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicSoftwareConfig() {
        return nicSoftwareConfig;
    }

    /**
     * Sets the value of the nicSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicSoftwareConfig(NullableString value) {
        this.nicSoftwareConfig = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the backboneDevice property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBoolean }
     *     
     */
    public NullableBoolean getBackboneDevice() {
        return backboneDevice;
    }

    /**
     * Sets the value of the backboneDevice property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBoolean }
     *     
     */
    public void setBackboneDevice(NullableBoolean value) {
        this.backboneDevice = value;
    }

    /**
     * Gets the value of the suspect property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBoolean }
     *     
     */
    public NullableBoolean getSuspect() {
        return suspect;
    }

    /**
     * Sets the value of the suspect property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBoolean }
     *     
     */
    public void setSuspect(NullableBoolean value) {
        this.suspect = value;
    }

    /**
     * Gets the value of the suspectReason property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSuspectReason() {
        return suspectReason;
    }

    /**
     * Sets the value of the suspectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSuspectReason(NullableString value) {
        this.suspectReason = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDescription(NullableString value) {
        this.description = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setTimeZoneID(TimeZoneType value) {
        this.timeZoneID = value;
    }

    /**
     * Gets the value of the mfgDate property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getMfgDate() {
        return mfgDate;
    }

    /**
     * Sets the value of the mfgDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setMfgDate(NullableString value) {
        this.mfgDate = value;
    }

    /**
     * Gets the value of the softwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSoftwareConfig() {
        return softwareConfig;
    }

    /**
     * Sets the value of the softwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSoftwareConfig(NullableString value) {
        this.softwareConfig = value;
    }

    /**
     * Gets the value of the hardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getHardwareConfig() {
        return hardwareConfig;
    }

    /**
     * Sets the value of the hardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setHardwareConfig(NullableString value) {
        this.hardwareConfig = value;
    }

    /**
     * Gets the value of the installTS property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getInstallTS() {
        return installTS;
    }

    /**
     * Sets the value of the installTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setInstallTS(NullableString value) {
        this.installTS = value;
    }

    /**
     * Gets the value of the removeTS property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRemoveTS() {
        return removeTS;
    }

    /**
     * Sets the value of the removeTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRemoveTS(NullableString value) {
        this.removeTS = value;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGUID() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGUID(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the netDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNetDeviceID() {
        return netDeviceID;
    }

    /**
     * Sets the value of the netDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNetDeviceID(Long value) {
        this.netDeviceID = value;
    }

    /**
     * Gets the value of the catalogNumber property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getCatalogNumber() {
        return catalogNumber;
    }

    /**
     * Sets the value of the catalogNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setCatalogNumber(NullableString value) {
        this.catalogNumber = value;
    }

    /**
     * Gets the value of the programSealAtManufacture property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getProgramSealAtManufacture() {
        return programSealAtManufacture;
    }

    /**
     * Sets the value of the programSealAtManufacture property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setProgramSealAtManufacture(NullableString value) {
        this.programSealAtManufacture = value;
    }

    /**
     * Gets the value of the deviceAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDeviceAttribute1() {
        return deviceAttribute1;
    }

    /**
     * Sets the value of the deviceAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDeviceAttribute1(NullableString value) {
        this.deviceAttribute1 = value;
    }

    /**
     * Gets the value of the deviceAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDeviceAttribute2() {
        return deviceAttribute2;
    }

    /**
     * Sets the value of the deviceAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDeviceAttribute2(NullableString value) {
        this.deviceAttribute2 = value;
    }

    /**
     * Gets the value of the deviceAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDeviceAttribute3() {
        return deviceAttribute3;
    }

    /**
     * Sets the value of the deviceAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDeviceAttribute3(NullableString value) {
        this.deviceAttribute3 = value;
    }

    /**
     * Gets the value of the deviceAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDeviceAttribute4() {
        return deviceAttribute4;
    }

    /**
     * Sets the value of the deviceAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDeviceAttribute4(NullableString value) {
        this.deviceAttribute4 = value;
    }

    /**
     * Gets the value of the deviceAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getDeviceAttribute5() {
        return deviceAttribute5;
    }

    /**
     * Sets the value of the deviceAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setDeviceAttribute5(NullableString value) {
        this.deviceAttribute5 = value;
    }

    /**
     * Gets the value of the nicAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicAttribute1() {
        return nicAttribute1;
    }

    /**
     * Sets the value of the nicAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicAttribute1(NullableString value) {
        this.nicAttribute1 = value;
    }

    /**
     * Gets the value of the nicAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicAttribute2() {
        return nicAttribute2;
    }

    /**
     * Sets the value of the nicAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicAttribute2(NullableString value) {
        this.nicAttribute2 = value;
    }

    /**
     * Gets the value of the nicAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicAttribute3() {
        return nicAttribute3;
    }

    /**
     * Sets the value of the nicAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicAttribute3(NullableString value) {
        this.nicAttribute3 = value;
    }

    /**
     * Gets the value of the nicAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicAttribute4() {
        return nicAttribute4;
    }

    /**
     * Sets the value of the nicAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicAttribute4(NullableString value) {
        this.nicAttribute4 = value;
    }

    /**
     * Gets the value of the nicAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getNicAttribute5() {
        return nicAttribute5;
    }

    /**
     * Sets the value of the nicAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setNicAttribute5(NullableString value) {
        this.nicAttribute5 = value;
    }

    /**
     * Gets the value of the nicTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNicTypeConfigID() {
        return nicTypeConfigID;
    }

    /**
     * Sets the value of the nicTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNicTypeConfigID(Long value) {
        this.nicTypeConfigID = value;
    }

    /**
     * Gets the value of the nicTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicTypeConfigName() {
        return nicTypeConfigName;
    }

    /**
     * Sets the value of the nicTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicTypeConfigName(String value) {
        this.nicTypeConfigName = value;
    }

    /**
     * Gets the value of the nicSoftwareTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNicSoftwareTypeConfigID() {
        return nicSoftwareTypeConfigID;
    }

    /**
     * Sets the value of the nicSoftwareTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNicSoftwareTypeConfigID(Long value) {
        this.nicSoftwareTypeConfigID = value;
    }

    /**
     * Gets the value of the nicSoftwareTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareTypeConfigName() {
        return nicSoftwareTypeConfigName;
    }

    /**
     * Sets the value of the nicSoftwareTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareTypeConfigName(String value) {
        this.nicSoftwareTypeConfigName = value;
    }

    /**
     * Gets the value of the batteryTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getBatteryTypeConfigID() {
        return batteryTypeConfigID;
    }

    /**
     * Sets the value of the batteryTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setBatteryTypeConfigID(NullableLong value) {
        this.batteryTypeConfigID = value;
    }

    /**
     * Gets the value of the batteryTypeConfigIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBatteryIdentifier }
     *     
     */
    public NullableBatteryIdentifier getBatteryTypeConfigIdentifier() {
        return batteryTypeConfigIdentifier;
    }

    /**
     * Sets the value of the batteryTypeConfigIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBatteryIdentifier }
     *     
     */
    public void setBatteryTypeConfigIdentifier(NullableBatteryIdentifier value) {
        this.batteryTypeConfigIdentifier = value;
    }

}
