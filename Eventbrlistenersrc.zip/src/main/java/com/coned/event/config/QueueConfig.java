/**
 * 
 */
package com.coned.event.config;

import java.util.Hashtable;
import java.util.Vector;

import jakarta.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;

import com.coned.odsListener.exception.JMSErrorHandler;
import com.tibco.tibjms.TibjmsQueueConnectionFactory;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

@Configuration
public class QueueConfig {

	private static final String TIBCO_HOST_NAME = "tibco.host.name";
	private static final String TIBCO_VENDOR = "tibco.vendor";
	private static final String TIBCO_SSL_ENABLED = "tibco.ssl.enabled";
	private static final String SSL_ENABLE_VERIFY_HOST = "com.tibco.tibjms.naming.ssl_enable_verify_host";
	private static final String TIBCO_SSL_CERTIFICATE = "tibco.ssl.certificate";
	private static final String TIBCO_PASSWORD = "tibco.password";
	private static final String TIBCO_USER_NAME = "tibco.user.name";
	private static final String TIBCO_URL = "tibco.url";

	@Autowired
	private Environment env;

	/**
	 * This configures the JMS listener container factory.
	 * 
	 * @param subscriberConnectionFactory the connection Factory
	 * @param configurer                  the listener configure
	 * @return the message listener factory
	 */
	@Bean
	public JmsListenerContainerFactory<?> listenerConnFactory(
			@Qualifier("subscriber") ConnectionFactory subscriberConnectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		try {
			factory.setErrorHandler(new JMSErrorHandler());
			configurer.configure(factory, subscriberConnectionFactory);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return factory;
	}

	/**
	 * Creates the queue connection with the specified user identity
	 * 
	 * @return the TIBCO connection factory
	 */
	@Bean(name = "subscriber")
	public ConnectionFactory subscriberConnFactory() {
		TibjmsQueueConnectionFactory factory = new TibjmsQueueConnectionFactory(env.getProperty(TIBCO_URL), null,
				getTibcoProperties());
		factory.setUserName(env.getProperty(TIBCO_USER_NAME));
		factory.setUserPassword(env.getProperty(TIBCO_PASSWORD));

		return (ConnectionFactory) factory;
	}

	/**
	 * This builds the TIBCO properties object
	 * 
	 * @return TIBCO properties object
	 */
	private Hashtable<Object, Object> getTibcoProperties() {
		Vector<String> ssl_trusted = new Vector<String>();
		ssl_trusted.addElement(env.getProperty(TIBCO_SSL_CERTIFICATE));

		Hashtable<Object, Object> tibcoProperites = new Hashtable<>();
		tibcoProperites.put(SSL_ENABLE_VERIFY_HOST, Boolean.parseBoolean(env.getProperty(TIBCO_SSL_ENABLED)));
		tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.TRUSTED_CERTIFICATES, ssl_trusted);
		tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.VENDOR, env.getProperty(TIBCO_VENDOR));
		tibcoProperites.put(com.tibco.tibjms.TibjmsSSL.EXPECTED_HOST_NAME, env.getProperty(TIBCO_HOST_NAME));
		return tibcoProperites;
	}

	/**
	 * Obtains the new instance of a JAXBContext on the top level class and creates
	 * this Unmarshaller object that can be used to convert XMLdata into a java
	 * content tree.
	 * 
	 * @return the Unmarshaller
	 * @throws JAXBException
	 */
	@Bean
	public Unmarshaller unmarshaller() throws JAXBException {
		JAXBContext jaxbContext = JAXBContext
				.newInstance(com.ssn.schema.service.v2_6.eventmanager.FindEventResponseType.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return jaxbUnmarshaller;
	}
}
