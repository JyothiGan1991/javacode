package com.coned.rc.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.coned.rc.beans.Event;
import com.coned.rc.beans.Meter;

public interface RetryDao {

	List<Event> getEvents();

	List<Meter> getFailedMeters(List<BigDecimal> ids);

	Map<BigDecimal, Integer> getMeterCount(List<BigDecimal> ids);

	int getRetryCount(String eventName, String subEventName, String boro);

	int saveRetry(Event req);

	// public int[] saveRetry(List<Event> retryEventList) ;

	void updateRetry(Event req, String status);

}
