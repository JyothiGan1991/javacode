package com.oru.poe.rest.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class IsGasMainRequest {

    private String premise;

    @NotNull(message = "Radius is required")
    @Min(value = 0, message = "Radius must be >= 0")
    private Integer radius;

    public IsGasMainRequest() {
    }

    public IsGasMainRequest(String premise, Integer radius) {
        this.premise = premise;
        this.radius = radius;
    }

    public String getPremise() {
        return premise;
    }

    public void setPremise(String premise) {
        this.premise = premise;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }
}
