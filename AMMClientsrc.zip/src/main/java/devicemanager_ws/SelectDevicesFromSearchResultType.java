
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SelectDevicesFromSearchResultType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SelectDevicesFromSearchResultType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchKey" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="AllDevices" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AllDevicesType" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="DeviceList" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceList" minOccurs="0"/&gt;
 *           &lt;element name="DeviceListByNetDeviceID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceListByID" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SelectDevicesFromSearchResultType", propOrder = {
    "searchKey",
    "allDevices",
    "deviceList",
    "deviceListByNetDeviceID"
})
public class SelectDevicesFromSearchResultType {

    @XmlElement(name = "SearchKey")
    protected long searchKey;
    @XmlElement(name = "AllDevices")
    protected AllDevicesType allDevices;
    @XmlElement(name = "DeviceList")
    protected DeviceList deviceList;
    @XmlElement(name = "DeviceListByNetDeviceID")
    protected DeviceListByID deviceListByNetDeviceID;

    /**
     * Gets the value of the searchKey property.
     * 
     */
    public long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     */
    public void setSearchKey(long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the allDevices property.
     * 
     * @return
     *     possible object is
     *     {@link AllDevicesType }
     *     
     */
    public AllDevicesType getAllDevices() {
        return allDevices;
    }

    /**
     * Sets the value of the allDevices property.
     * 
     * @param value
     *     allowed object is
     *     {@link AllDevicesType }
     *     
     */
    public void setAllDevices(AllDevicesType value) {
        this.allDevices = value;
    }

    /**
     * Gets the value of the deviceList property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceList }
     *     
     */
    public DeviceList getDeviceList() {
        return deviceList;
    }

    /**
     * Sets the value of the deviceList property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceList }
     *     
     */
    public void setDeviceList(DeviceList value) {
        this.deviceList = value;
    }

    /**
     * Gets the value of the deviceListByNetDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceListByID }
     *     
     */
    public DeviceListByID getDeviceListByNetDeviceID() {
        return deviceListByNetDeviceID;
    }

    /**
     * Sets the value of the deviceListByNetDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceListByID }
     *     
     */
    public void setDeviceListByNetDeviceID(DeviceListByID value) {
        this.deviceListByNetDeviceID = value;
    }

}
