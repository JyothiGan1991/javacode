
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExecutionStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExecutionStatusEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_EXEC_STATUS_NOT_STARTED"/>
 *     &lt;enumeration value="JOB_EXEC_STATUS_RUNNING"/>
 *     &lt;enumeration value="JOB_EXEC_STATUS_COMPLETE"/>
 *     &lt;enumeration value="JOB_EXEC_STATUS_FAILURE"/>
 *     &lt;enumeration value="JOB_EXEC_STATUS_UNKNOWN"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ExecutionStatusEnumeration")
@XmlEnum
public enum ExecutionStatusEnumeration {

    JOB_EXEC_STATUS_NOT_STARTED("JOB_EXEC_STATUS_NOT_STARTED"),
    JOB_EXEC_STATUS_RUNNING("JOB_EXEC_STATUS_RUNNING"),
    JOB_EXEC_STATUS_COMPLETE("JOB_EXEC_STATUS_COMPLETE"),
    JOB_EXEC_STATUS_FAILURE("JOB_EXEC_STATUS_FAILURE"),
    JOB_EXEC_STATUS_UNKNOWN("JOB_EXEC_STATUS_UNKNOWN"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ExecutionStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ExecutionStatusEnumeration fromValue(String v) {
        for (ExecutionStatusEnumeration c: ExecutionStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
