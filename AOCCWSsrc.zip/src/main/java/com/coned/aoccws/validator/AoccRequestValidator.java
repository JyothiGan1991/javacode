/**
 * 
 */
package com.coned.aoccws.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.coned.aoccws.beans.AoccRequest;

public class AoccRequestValidator implements Validator{
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	 /**
     * This Validator validates *just* AoccRequest instances
     */
	@Override
	public boolean supports(Class<?> clazz) {
		return AoccRequest.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object obj, Errors err) {
		logger.info("########## In validator" + obj);
		AoccRequest req = (AoccRequest) obj;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "eventName", "value.required", "Event name field can't be empty.");
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "boro", "value.required", "Boro field can't be empty.");
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "eventType", "value.required", "Event Type field can't be empty.");
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "eventTime", "value.required", "Event Time field can't be empty.");
		
		if (! (req.getEventType().equalsIgnoreCase("C") || req.getEventType().equalsIgnoreCase("D")) ){
			err.rejectValue("eventType", "value.required", "Event Type is not valid.");
		}
		if(req.getEventType().equalsIgnoreCase("C")){
			ValidationUtils.rejectIfEmptyOrWhitespace(err, "subEventName", "value.required", "Sub Event name field can't be empty.");
		}
		
		if( err.getAllErrors().size() > 0){
			logger.error("########## " + err.getAllErrors().size());
		}
	}
}
