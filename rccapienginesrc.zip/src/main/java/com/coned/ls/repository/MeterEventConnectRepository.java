package com.coned.ls.repository;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

/**
 * 
 * Interface for RCC Connect repository class.
 *
 */
public interface MeterEventConnectRepository {
	
	public ResponseEntity<MeterConnectResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent) throws Exception ;	
	public ResponseEntity<MeterConnectResponseMapper> getConnectedMeters(final MeterOpenEvent meterOpenEvent) throws MeterEventConnectException;
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(final SubEvent subEvent) throws Exception;
	public MeterConnectResponseMapper searchMeters(final MeterSearch meterSearch);
	public MeterConnectResponseMapper searchMeterConnected(final MeterSearch meterSearch);
	public ResponseEntity<Long> getSubEventSuffix(final String borough, final String event);
	
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex, final int batchSize);
	public MeterConnectResponseMapper getSubEventMeters(final SubEvent subEvent);
	public List<String> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) throws IllegalArgumentException;
	public List<String> getConnectedMetersFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) throws IllegalArgumentException;
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid);
	public void unlockEvents(final String adid);
}
