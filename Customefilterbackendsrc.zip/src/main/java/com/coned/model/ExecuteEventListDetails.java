package com.coned.model;

import java.sql.Date;
import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_execute_event_list_details", schema="AMI_LOAD_SHEDDING")
public class ExecuteEventListDetails {

    @Id
    @JsonIgnore
    @Column(name = "fk_finalized_event_id")
    private Long id;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "event_type")
    private String eventType;
    
    @Column(name = "boro_muni")
    private String borough;
    
    @Column(name = "execute_time")
    private LocalDateTime executeDateTime;
 
    @Column(name = "operator_ad_id")
    private String operatorAdId;
    
    public String getOperatorAdId() {
		return operatorAdId;
	}

	public void setOperatorAdId(String operatorAdId) {
		this.operatorAdId = operatorAdId;
	}

	public ExecuteEventListDetails() {

    }

    public ExecuteEventListDetails(String eventname, String borough, LocalDateTime logintime) {
        this.eventName = eventname;
        this.borough = borough;
        this.executeDateTime = logintime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
   
    public String getEventname() {
        return eventName;
    }

    public void setEventname(String eventname) {
        this.eventName = eventname;
    }
    
    public String getEventtype() {
        return eventType;
    }

    public void setEventtype(String eventtype) {
        this.eventType = eventtype;
    }

    public String getBorough() {
        return borough;
    }

    public void setBoromuni(String boromuni) {
        this.borough = boromuni;
    }
    
    public LocalDateTime getExecuteDateTime() {
        return executeDateTime;
    }

    public void setExecuteDateTime(LocalDateTime executetime) {
        this.executeDateTime = executetime;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", executeDateTime=" + executeDateTime + "]";
    }
}
