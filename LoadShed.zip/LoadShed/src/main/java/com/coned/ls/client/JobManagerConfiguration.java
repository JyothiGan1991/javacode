/*
 * package com.coned.ls.client;
 * 
 * import org.apache.http.auth.UsernamePasswordCredentials; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.context.annotation.PropertySource; import
 * org.springframework.oxm.jaxb.Jaxb2Marshaller; import
 * org.springframework.ws.transport.http.HttpComponentsMessageSender;
 * 
 * @Configuration
 * 
 * @PropertySource({ "classpath:application.properties" }) public class
 * JobManagerConfiguration {
 * 
 * @Value("${client.devicemanager-uri}") private String dmUri;
 * 
 * @Value("${client.jobmanager-uri}") private String jbUri;
 * 
 * @Value("${client.systeminfo-uri}") private String systemUri;
 * 
 * @Value("${client.user.name}") private String userName;
 * 
 * @Value("${client.user.password}") private String userPassword;
 * 
 * @Bean public Jaxb2Marshaller marshaller() { Jaxb2Marshaller marshaller = new
 * Jaxb2Marshaller(); // this package must match the package in the
 * <generatePackage> // specified in // pom.xml
 * marshaller.setPackagesToScan("jm_ws"); return marshaller; }
 * 
 * @Bean public JobManagerClient jobManagerClient(Jaxb2Marshaller marshaller) {
 * JobManagerClient client = new JobManagerClient();
 * client.setDefaultUri(jbUri); client.setMarshaller(marshaller);
 * client.setUnmarshaller(marshaller);
 * client.setMessageSender(httpComponentsMessageSender()); return client; }
 * 
 * @Bean public Jaxb2Marshaller dmmarshaller() { Jaxb2Marshaller dmmarshaller =
 * new Jaxb2Marshaller(); // this package must match the package in the
 * <generatePackage> // specified in // pom.xml
 * dmmarshaller.setPackagesToScan("dm_ws"); return dmmarshaller; }
 * 
 * @Bean public DeviceManagerClient devManagerClient(Jaxb2Marshaller
 * dmmarshaller) { DeviceManagerClient client = new DeviceManagerClient();
 * client.setDefaultUri(dmUri); client.setMarshaller(dmmarshaller);
 * client.setUnmarshaller(dmmarshaller);
 * client.setMessageSender(httpComponentsMessageSender()); return client; }
 * 
 * @Bean public Jaxb2Marshaller simarshaller() { Jaxb2Marshaller simarshaller =
 * new Jaxb2Marshaller(); // this package must match the package in the
 * <generatePackage> // specified in // pom.xml
 * simarshaller.setPackagesToScan("systemInfo_ws"); return simarshaller; }
 * 
 * @Bean public SystemInfoClient syinfoManagerClient(Jaxb2Marshaller
 * simarshaller) { SystemInfoClient client = new SystemInfoClient();
 * client.setDefaultUri(systemUri); client.setMarshaller(simarshaller);
 * client.setUnmarshaller(simarshaller); //
 * client.setMessageSender(httpComponentsMessageSender()); return client; }
 * 
 * 
 * @Bean public WebServiceTemplate webServiceTemplate() { WebServiceTemplate
 * webServiceTemplate = new WebServiceTemplate();
 * webServiceTemplate.setMarshaller(simarshaller());
 * webServiceTemplate.setUnmarshaller(simarshaller());
 * webServiceTemplate.setDefaultUri(systemUri); // set a
 * HttpComponentsMessageSender which provides support for basic //
 * authentication
 * webServiceTemplate.setMessageSender(httpComponentsMessageSender());
 * 
 * return webServiceTemplate; }
 * 
 * 
 * @Bean public HttpComponentsMessageSender httpComponentsMessageSender() {
 * HttpComponentsMessageSender httpComponentsMessageSender = new
 * HttpComponentsMessageSender(); // set the basic authorization credentials
 * httpComponentsMessageSender.setCredentials(usernamePasswordCredentials());
 * return httpComponentsMessageSender; }
 * 
 * @Bean public UsernamePasswordCredentials usernamePasswordCredentials() { //
 * pass the user name and password to be used return new
 * UsernamePasswordCredentials(userName, userPassword); }
 * 
 * }
 */