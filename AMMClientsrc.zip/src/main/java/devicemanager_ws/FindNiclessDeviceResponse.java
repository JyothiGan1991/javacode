
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindNiclessDeviceResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindNiclessDeviceResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqDeviceStateID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType"/&gt;
 *         &lt;element name="UtilDeviceStateID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType"/&gt;
 *         &lt;element name="LastOpStateChangeTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType"/&gt;
 *         &lt;element name="MfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountryID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="Latitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="Longitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilPremiseID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ChildrenCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IsSelected" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="IsReadOnly" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="UtilServicePointID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Suspect" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SuspectReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CustomerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilAccountID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ConfigTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindNiclessDeviceResponse", propOrder = {
    "name",
    "uiqDeviceStateID",
    "utilDeviceStateID",
    "lastOpStateChangeTime",
    "didType",
    "didSubtype",
    "mfgModel",
    "mfgName",
    "utilDeviceID",
    "serialNumber",
    "address1",
    "address2",
    "city",
    "state",
    "postalCode",
    "countryID",
    "latitude",
    "longitude",
    "billingCycle",
    "utilPremiseID",
    "childrenCount",
    "isSelected",
    "isReadOnly",
    "utilServicePointID",
    "suspect",
    "suspectReason",
    "customerName",
    "utilAccountID",
    "configTypeName"
})
public class FindNiclessDeviceResponse {

    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "UiqDeviceStateID", required = true)
    protected UIQDeviceStateType uiqDeviceStateID;
    @XmlElement(name = "UtilDeviceStateID", required = true)
    protected UtilDeviceStateType utilDeviceStateID;
    @XmlElement(name = "LastOpStateChangeTime")
    protected String lastOpStateChangeTime;
    @XmlElement(name = "DidType", required = true)
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype", required = true)
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "MfgModel")
    protected String mfgModel;
    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "UtilDeviceID", required = true)
    protected String utilDeviceID;
    @XmlElement(name = "SerialNumber", required = true)
    protected String serialNumber;
    @XmlElement(name = "Address1")
    protected String address1;
    @XmlElement(name = "Address2")
    protected String address2;
    @XmlElement(name = "City")
    protected String city;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "PostalCode")
    protected String postalCode;
    @XmlElement(name = "CountryID")
    protected Integer countryID;
    @XmlElement(name = "Latitude")
    protected Double latitude;
    @XmlElement(name = "Longitude")
    protected Double longitude;
    @XmlElement(name = "BillingCycle")
    protected String billingCycle;
    @XmlElement(name = "UtilPremiseID")
    protected String utilPremiseID;
    @XmlElement(name = "ChildrenCount")
    protected Integer childrenCount;
    @XmlElement(name = "IsSelected")
    protected boolean isSelected;
    @XmlElement(name = "IsReadOnly")
    protected boolean isReadOnly;
    @XmlElement(name = "UtilServicePointID")
    protected String utilServicePointID;
    @XmlElement(name = "Suspect")
    protected Boolean suspect;
    @XmlElement(name = "SuspectReason")
    protected String suspectReason;
    @XmlElement(name = "CustomerName")
    protected String customerName;
    @XmlElement(name = "UtilAccountID")
    protected String utilAccountID;
    @XmlElement(name = "ConfigTypeName")
    protected String configTypeName;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the uiqDeviceStateID property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUiqDeviceStateID() {
        return uiqDeviceStateID;
    }

    /**
     * Sets the value of the uiqDeviceStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUiqDeviceStateID(UIQDeviceStateType value) {
        this.uiqDeviceStateID = value;
    }

    /**
     * Gets the value of the utilDeviceStateID property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceStateID() {
        return utilDeviceStateID;
    }

    /**
     * Sets the value of the utilDeviceStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceStateID(UtilDeviceStateType value) {
        this.utilDeviceStateID = value;
    }

    /**
     * Gets the value of the lastOpStateChangeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastOpStateChangeTime() {
        return lastOpStateChangeTime;
    }

    /**
     * Sets the value of the lastOpStateChangeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastOpStateChangeTime(String value) {
        this.lastOpStateChangeTime = value;
    }

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the mfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgModel() {
        return mfgModel;
    }

    /**
     * Sets the value of the mfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgModel(String value) {
        this.mfgModel = value;
    }

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the countryID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCountryID() {
        return countryID;
    }

    /**
     * Sets the value of the countryID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCountryID(Integer value) {
        this.countryID = value;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLatitude() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLatitude(Double value) {
        this.latitude = value;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLongitude() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLongitude(Double value) {
        this.longitude = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycle(String value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the utilPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilPremiseID() {
        return utilPremiseID;
    }

    /**
     * Sets the value of the utilPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilPremiseID(String value) {
        this.utilPremiseID = value;
    }

    /**
     * Gets the value of the childrenCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getChildrenCount() {
        return childrenCount;
    }

    /**
     * Sets the value of the childrenCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setChildrenCount(Integer value) {
        this.childrenCount = value;
    }

    /**
     * Gets the value of the isSelected property.
     * 
     */
    public boolean isIsSelected() {
        return isSelected;
    }

    /**
     * Sets the value of the isSelected property.
     * 
     */
    public void setIsSelected(boolean value) {
        this.isSelected = value;
    }

    /**
     * Gets the value of the isReadOnly property.
     * 
     */
    public boolean isIsReadOnly() {
        return isReadOnly;
    }

    /**
     * Sets the value of the isReadOnly property.
     * 
     */
    public void setIsReadOnly(boolean value) {
        this.isReadOnly = value;
    }

    /**
     * Gets the value of the utilServicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePointID() {
        return utilServicePointID;
    }

    /**
     * Sets the value of the utilServicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePointID(String value) {
        this.utilServicePointID = value;
    }

    /**
     * Gets the value of the suspect property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSuspect() {
        return suspect;
    }

    /**
     * Sets the value of the suspect property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSuspect(Boolean value) {
        this.suspect = value;
    }

    /**
     * Gets the value of the suspectReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuspectReason() {
        return suspectReason;
    }

    /**
     * Sets the value of the suspectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuspectReason(String value) {
        this.suspectReason = value;
    }

    /**
     * Gets the value of the customerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Sets the value of the customerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerName(String value) {
        this.customerName = value;
    }

    /**
     * Gets the value of the utilAccountID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilAccountID() {
        return utilAccountID;
    }

    /**
     * Sets the value of the utilAccountID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilAccountID(String value) {
        this.utilAccountID = value;
    }

    /**
     * Gets the value of the configTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigTypeName() {
        return configTypeName;
    }

    /**
     * Sets the value of the configTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigTypeName(String value) {
        this.configTypeName = value;
    }

}
