package com.coned.ls.controller;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



//import org.aspectj.lang.JoinPoint;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.rest.RestClientBuilder;
import com.coned.ls.service.MeterEventService;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.UserManagementService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserManagementControllerTest {


	@InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	UserManagementController usermgmtController;

	@Mock
	private UserManagementService userManagementService;

	@Before
	public void setup() throws Exception {
		usermgmtController = new UserManagementController();
		System.out.println("@Before annotation method is being called ....");
		ReflectionTestUtils.setField(usermgmtController, "userManagementService", userManagementService);
	}

	@Test
	public void getUsers() {
		List<Object> expected = new ArrayList<Object>();
		ResponseEntity<List<Object>> result = new ResponseEntity<List<Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		Mockito.when(userManagementService.getUsers()).thenReturn(result);
		ResponseEntity<List<Object>> actual = usermgmtController.getUsers();
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void listLDAPUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		HttpServletRequest request = null;
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		
		Mockito.when(userManagementService.listLDAPUser(username)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.listLDAPUser(username);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
		
	@Test
	public void createUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-varangalr");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(userManagementService.createUser(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.createUser(request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	@Test
	public void updateUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		payload.put("adid", username);
		
		Mockito.when(userManagementService.updateUser(username, payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.updateUser(username, request, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		
	}
	@Test
	public void deleteUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		String username = "ADID";
		String adid = "ADID";
		
		Mockito.when(userManagementService.deleteUser(username, adid)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.deleteUser(username, request);
//		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		Assert.assertEquals("Null", "Null");
		
	}
}