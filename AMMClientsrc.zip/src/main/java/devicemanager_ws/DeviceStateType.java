
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceStateType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceStateType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Creator" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="UiqDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType"/&gt;
 *         &lt;element name="Timestamp" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimestampType"/&gt;
 *         &lt;element name="Note" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceStateType", propOrder = {
    "creator",
    "uiqDeviceState",
    "timestamp",
    "note"
})
public class DeviceStateType {

    @XmlElement(name = "Creator", required = true)
    protected String creator;
    @XmlElement(name = "UiqDeviceState", required = true)
    protected UIQDeviceStateType uiqDeviceState;
    @XmlElement(name = "Timestamp", required = true)
    protected TimestampType timestamp;
    @XmlElement(name = "Note", required = true)
    protected String note;

    /**
     * Gets the value of the creator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the creator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreator(String value) {
        this.creator = value;
    }

    /**
     * Gets the value of the uiqDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUiqDeviceState() {
        return uiqDeviceState;
    }

    /**
     * Sets the value of the uiqDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUiqDeviceState(UIQDeviceStateType value) {
        this.uiqDeviceState = value;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link TimestampType }
     *     
     */
    public TimestampType getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimestampType }
     *     
     */
    public void setTimestamp(TimestampType value) {
        this.timestamp = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

}
