
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterReadByDeviceSearchParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterReadByDeviceSearchParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/&gt;
 *         &lt;element name="FromTime" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ToTime" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MeterDataType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}MeterDataTypeEnumeration"/&gt;
 *         &lt;element name="DeviceCapability" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LPSetId" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterReadByDeviceSearchParametersType", propOrder = {
    "deviceMacID",
    "fromTime",
    "toTime",
    "meterDataType",
    "deviceCapability",
    "lpSetId"
})
public class MeterReadByDeviceSearchParametersType {

    @XmlElement(name = "DeviceMacID", required = true)
    protected List<String> deviceMacID;
    @XmlElement(name = "FromTime", required = true)
    protected String fromTime;
    @XmlElement(name = "ToTime", required = true)
    protected String toTime;
    @XmlElement(name = "MeterDataType", required = true)
    @XmlSchemaType(name = "string")
    protected MeterDataTypeEnumeration meterDataType;
    @XmlElement(name = "DeviceCapability")
    protected String deviceCapability;
    @XmlElement(name = "LPSetId", type = Long.class)
    protected List<Long> lpSetId;

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the fromTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromTime() {
        return fromTime;
    }

    /**
     * Sets the value of the fromTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromTime(String value) {
        this.fromTime = value;
    }

    /**
     * Gets the value of the toTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToTime() {
        return toTime;
    }

    /**
     * Sets the value of the toTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToTime(String value) {
        this.toTime = value;
    }

    /**
     * Gets the value of the meterDataType property.
     * 
     * @return
     *     possible object is
     *     {@link MeterDataTypeEnumeration }
     *     
     */
    public MeterDataTypeEnumeration getMeterDataType() {
        return meterDataType;
    }

    /**
     * Sets the value of the meterDataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterDataTypeEnumeration }
     *     
     */
    public void setMeterDataType(MeterDataTypeEnumeration value) {
        this.meterDataType = value;
    }

    /**
     * Gets the value of the deviceCapability property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceCapability() {
        return deviceCapability;
    }

    /**
     * Sets the value of the deviceCapability property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceCapability(String value) {
        this.deviceCapability = value;
    }

    /**
     * Gets the value of the lpSetId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lpSetId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLPSetId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getLPSetId() {
        if (lpSetId == null) {
            lpSetId = new ArrayList<Long>();
        }
        return this.lpSetId;
    }

}
