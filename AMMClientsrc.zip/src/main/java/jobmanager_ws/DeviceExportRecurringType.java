
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceExportRecurringType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceExportRecurringType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="All" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EmptyType"/&gt;
 *           &lt;element name="DeviceType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeEnum"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="ExportOnlyChangedDevices" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceExportRecurringType", propOrder = {
    "all",
    "deviceType",
    "exportOnlyChangedDevices"
})
public class DeviceExportRecurringType {

    @XmlElement(name = "All")
    protected EmptyType all;
    @XmlElement(name = "DeviceType")
    @XmlSchemaType(name = "string")
    protected DeviceTypeEnum deviceType;
    @XmlElement(name = "ExportOnlyChangedDevices")
    protected boolean exportOnlyChangedDevices;

    /**
     * Gets the value of the all property.
     * 
     * @return
     *     possible object is
     *     {@link EmptyType }
     *     
     */
    public EmptyType getAll() {
        return all;
    }

    /**
     * Sets the value of the all property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmptyType }
     *     
     */
    public void setAll(EmptyType value) {
        this.all = value;
    }

    /**
     * Gets the value of the deviceType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeEnum }
     *     
     */
    public DeviceTypeEnum getDeviceType() {
        return deviceType;
    }

    /**
     * Sets the value of the deviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeEnum }
     *     
     */
    public void setDeviceType(DeviceTypeEnum value) {
        this.deviceType = value;
    }

    /**
     * Gets the value of the exportOnlyChangedDevices property.
     * 
     */
    public boolean isExportOnlyChangedDevices() {
        return exportOnlyChangedDevices;
    }

    /**
     * Sets the value of the exportOnlyChangedDevices property.
     * 
     */
    public void setExportOnlyChangedDevices(boolean value) {
        this.exportOnlyChangedDevices = value;
    }

}
