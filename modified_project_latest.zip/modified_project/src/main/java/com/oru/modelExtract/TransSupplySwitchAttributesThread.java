/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class TransSupplySwitchAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(TransSupplySwitchAttributesThread.class);    

    TransSupplySwitchAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
/*String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,\n" +
*"                    GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue,\n" +
*"                    ST_Y(geom) yValue, ts.circuit, ts.fid1, ts.fid2, ts.sotagged, ts.gridx, ts.gridy, ts.dstat, ts.phase, ts.seg,ts.mainline\n" +
*"                    from ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_trans_supply_switch ts\n" +
*"                    where geom.featuretypeid = def.featuretypeid\n" +
*"                    and ts.fid = geom.fid  \n" +
*"                    and ts.fid in (" + assetToQuery + ")  \n" +                    
*"                    order by fid    ";*/

        	
//Gandhamj updated the query on 08/21/2023 but it is still in testing process
        	
String newPointQuery = "select geom.fid, geom.featuretypeid, def.featuretypename, GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue,"
					+ " ST_Y(geom) yValue, "
				    + " CASE WHEN ts.fid IN (8205485) THEN '44-5-13' " 
					+ " else ts.circuit "  
					+ " END circuit, "
					+ " ts.fid1, ts.fid2, ts.sotagged, ts.gridx, ts.gridy, ts.dstat, ts.currentdstat, ts.designdstat, ts.phase, ts.seg,ts.mainline, "
					+ " asset.street as location, asset.town, asset.state" + " from ed.geom geom "
					+ " join nrgcore.nrgfeaturetypedef def on geom.featuretypeid = def.featuretypeid "
					+ " join asset_ed.ed_trans_supply_switch ts on ts.fid = geom.fid "
					+ " left join gis.ed_assetlocation asset on asset.fid = geom.fid " + " where ts.fid in ("
					+ assetToQuery + ") order by fid  ";
        	
            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));
                    
                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                    
                    int fid1 = rs.getInt("fid1");
                    asset.setNmsAttributes("fid1", Integer.toString(fid1));

                    int fid2 = rs.getInt("fid2");
                    asset.setNmsAttributes("fid2", Integer.toString(fid2));
                    
                    boolean sotagged = rs.getBoolean("sotagged");
                    asset.setNmsAttributes("sotagged", String.valueOf(sotagged));
                    
                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    String dstat = rs.getString("dstat");
                    asset.setNmsAttributes("dstat", dstat);
                    
                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);
                    
                    String currentdstat = rs.getString("currentdstat");
                    asset.setNmsAttributes("currentdstat", currentdstat);

                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));
                    
                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);                    

                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
