
package com.ssn.schema.service.v2_6.devicetypes;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocationTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LocationTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="LOCATION_TYPE_PREMISE"/>
 *     &lt;enumeration value="LOCATION_TYPE_NETWORK"/>
 *     &lt;enumeration value="LOCATION_TYPE_POLE"/>
 *     &lt;enumeration value="LOCATION_TYPE_TRANSFORM"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LocationTypeEnum")
@XmlEnum
public enum LocationTypeEnum {

    LOCATION_TYPE_PREMISE("LOCATION_TYPE_PREMISE"),
    LOCATION_TYPE_NETWORK("LOCATION_TYPE_NETWORK"),
    LOCATION_TYPE_POLE("LOCATION_TYPE_POLE"),
    LOCATION_TYPE_TRANSFORM("LOCATION_TYPE_TRANSFORM"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    LocationTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LocationTypeEnum fromValue(String v) {
        for (LocationTypeEnum c: LocationTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
