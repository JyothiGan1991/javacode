
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditMeterTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditMeterTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditMeterType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MeterTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditMeterTypeReq", propOrder = {
    "meterTypeConfigID"
})
public class AddEditMeterTypeReq
    extends AddEditMeterType
{

    @XmlElement(name = "MeterTypeConfigID")
    protected long meterTypeConfigID;

    /**
     * Gets the value of the meterTypeConfigID property.
     * 
     */
    public long getMeterTypeConfigID() {
        return meterTypeConfigID;
    }

    /**
     * Sets the value of the meterTypeConfigID property.
     * 
     */
    public void setMeterTypeConfigID(long value) {
        this.meterTypeConfigID = value;
    }

}
