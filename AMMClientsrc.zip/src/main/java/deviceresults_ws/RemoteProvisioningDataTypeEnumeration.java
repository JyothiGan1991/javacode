
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningDataTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RemoteProvisioningDataTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_BASIC"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_PPM"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_STATUS"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_DLP"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_LOCKOUT"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_ESCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_AUX"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_BOOST"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_BCAST"/&gt;
 *     &lt;enumeration value="RMT_PROV_DATA_TYPE_GROUP_CFG"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RemoteProvisioningDataTypeEnumeration")
@XmlEnum
public enum RemoteProvisioningDataTypeEnumeration {

    RMT_PROV_DATA_TYPE_BASIC("RMT_PROV_DATA_TYPE_BASIC"),
    RMT_PROV_DATA_TYPE_PPM("RMT_PROV_DATA_TYPE_PPM"),
    RMT_PROV_DATA_TYPE_STATUS("RMT_PROV_DATA_TYPE_STATUS"),
    RMT_PROV_DATA_TYPE_DLP("RMT_PROV_DATA_TYPE_DLP"),
    RMT_PROV_DATA_TYPE_LOCKOUT("RMT_PROV_DATA_TYPE_LOCKOUT"),
    RMT_PROV_DATA_TYPE_ESCC("RMT_PROV_DATA_TYPE_ESCC"),
    RMT_PROV_DATA_TYPE_AUX("RMT_PROV_DATA_TYPE_AUX"),
    RMT_PROV_DATA_TYPE_BOOST("RMT_PROV_DATA_TYPE_BOOST"),
    RMT_PROV_DATA_TYPE_BCAST("RMT_PROV_DATA_TYPE_BCAST"),
    RMT_PROV_DATA_TYPE_GROUP_CFG("RMT_PROV_DATA_TYPE_GROUP_CFG"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    RemoteProvisioningDataTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RemoteProvisioningDataTypeEnumeration fromValue(String v) {
        for (RemoteProvisioningDataTypeEnumeration c: RemoteProvisioningDataTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
