package com.coned.ls.domain;

import java.util.Date;

/**
 * 
 * Class to store finalized event details.
 *
 */
public class MeterEventFinalizeDetails{
	
	private long countOfMeters;
	private Date finalizeTime;
	private String operatorAdId;
	private String borough;
	private String eventName;
	private String message;
	private boolean isValid;
	
	
	
	public MeterEventFinalizeDetails() {
		super();
	}
	public MeterEventFinalizeDetails(long countOfMeters, Date finalizeTime,
			String operatorAdId, String borough, String eventName) {
		super();
		this.countOfMeters = countOfMeters;
		this.finalizeTime = finalizeTime;
		this.operatorAdId = operatorAdId;
		this.borough = borough;
		this.eventName = eventName;
	}
	public long getCountOfMeters() {
		return countOfMeters;
	}
	public void setCountOfMeters(long countOfMeters) {
		this.countOfMeters = countOfMeters;
	}
	public Date getFinalizeTime() {
		return finalizeTime;
	}
	public void setFinalizeTime(Date finalizeTime) {
		this.finalizeTime = finalizeTime;
	}
	public String getOperatorAdId() {
		return operatorAdId;
	}
	public void setOperatorAdId(String operatorAdId) {
		this.operatorAdId = operatorAdId;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValid() {
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	@Override
	public String toString() {
		return "MeterEventFinalize [countOfMeters=" + countOfMeters
				+ ", finalizeTime=" + finalizeTime + ", operatorAdId="
				+ operatorAdId + ", borough=" + borough + ", eventName="
				+ eventName + "]";
	}
	
	
}
