package com.coned.ls.rest;

import java.net.URI;
import java.util.Map;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 
 * Class to build rest end point url.
 *
 */
@Component
public class RestClientBuilder {
	
	private static final Logger logger = LogManager.getLogger(RestClientBuilder.class);

	public static String baseURL; 

	public static URI buildURI(String url, final Map<String, String> params){		
		System.out.println("BASE URI : "+getBaseURL());
		StringBuilder stringBuilder = new StringBuilder(getBaseURL());
		url = stringBuilder.append(url).toString();
		URI uri = UriComponentsBuilder.fromUriString(url).buildAndExpand(params).toUri();
		uri = UriComponentsBuilder.fromUri(uri).build().toUri();
		logger.info("REST endpoint --- "+uri);
		return uri;
	}
	
	public static URI customBuildURI(String url){	
		System.out.println("BASE URI : "+getBaseURL());
		StringBuilder stringBuilder = new StringBuilder(getBaseURL());
		url = stringBuilder.append(url).toString();
		logger.info("REST endpoint custom --- "+url);
		URI uri = UriComponentsBuilder.fromUriString(url).buildAndExpand().toUri();
		uri = UriComponentsBuilder.fromUri(uri).build().toUri();
		logger.info("REST endpoint --- "+uri);
		return uri;
	}
	
	public static URI customBuildURI(String url,final String urlParameter){	
		System.out.println("BASE URI : "+getBaseURL());
		StringBuilder stringBuilder = new StringBuilder(getBaseURL());
		url = stringBuilder.append(url).append(urlParameter).toString();
		logger.info("REST endpoint custom --- "+url);
		URI uri = UriComponentsBuilder.fromUriString(url).buildAndExpand().toUri();
		uri = UriComponentsBuilder.fromUri(uri).build().toUri();
		logger.info("REST endpoint --- "+uri);
		return uri;
	}

	public static String getBaseURL() {
		if(baseURL!=null){
			return baseURL;
		}else{
			try {
	            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	            HttpRequest httpRequest = new ServletServerHttpRequest(request);
	            UriComponents uriComponents = UriComponentsBuilder.fromHttpRequest(httpRequest).build();

	            String scheme = uriComponents.getScheme();       // Schema: http / https
	            String serverName = request.getServerName();     // hostname
	            int serverPort = request.getServerPort();        // 80

	            StringBuilder url = new StringBuilder();

	            url.append(scheme).append("://");
	            url.append(serverName);

	            if (serverPort != 80 && serverPort != 443) {
	                url.append(":").append(serverPort);
	            }
	            RestClientBuilder.baseURL = url.append("/rcc-api").toString();
	     } catch (Exception ex) {
	            logger.error("Exception " + ex);
	     }
		}
		return baseURL;
	}
	
	
}
