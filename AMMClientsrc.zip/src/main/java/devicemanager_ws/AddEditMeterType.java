
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditMeterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditMeterType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Mode" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ln_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ll_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_sqr_hr_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_n_sqr_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_va_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_vah_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Timebase" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleScalar" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleDivisor" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleDivisor" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleScalar" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrTransRatio" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltTransRatio" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilQyMeterRegRatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MasterPwd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReaderPwd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CustomerPwd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WakeupInterval" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IsMicroAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditMeterType", propOrder = {
    "mode",
    "scaleVSqrHrLnSf",
    "scaleVSqrHrLlSf",
    "scaleISqrHrSf",
    "scaleINSqrSf",
    "scaleVaSf",
    "scaleVahSf",
    "timebase",
    "currSampleScalar",
    "currSampleDivisor",
    "voltSampleDivisor",
    "voltSampleScalar",
    "currTransRatio",
    "voltTransRatio",
    "utilQyMeterRegRatio",
    "masterPwd",
    "readerPwd",
    "customerPwd",
    "wakeupInterval",
    "isMicroAP"
})
@XmlSeeAlso({
    AddEditMeterTypeReq.class
})
public class AddEditMeterType {

    @XmlElement(name = "Mode")
    protected MeterModeType mode;
    @XmlElement(name = "Scale_v_sqr_hr_ln_sf")
    protected Long scaleVSqrHrLnSf;
    @XmlElement(name = "Scale_v_sqr_hr_ll_sf")
    protected Long scaleVSqrHrLlSf;
    @XmlElement(name = "Scale_i_sqr_hr_sf")
    protected Long scaleISqrHrSf;
    @XmlElement(name = "Scale_i_n_sqr_sf")
    protected Long scaleINSqrSf;
    @XmlElement(name = "Scale_va_sf")
    protected Long scaleVaSf;
    @XmlElement(name = "Scale_vah_sf")
    protected Long scaleVahSf;
    @XmlElement(name = "Timebase")
    protected Long timebase;
    @XmlElement(name = "CurrSampleScalar")
    protected Long currSampleScalar;
    @XmlElement(name = "CurrSampleDivisor")
    protected Long currSampleDivisor;
    @XmlElement(name = "VoltSampleDivisor")
    protected Long voltSampleDivisor;
    @XmlElement(name = "VoltSampleScalar")
    protected Long voltSampleScalar;
    @XmlElement(name = "CurrTransRatio")
    protected Long currTransRatio;
    @XmlElement(name = "VoltTransRatio")
    protected Long voltTransRatio;
    @XmlElement(name = "UtilQyMeterRegRatio")
    protected String utilQyMeterRegRatio;
    @XmlElement(name = "MasterPwd")
    protected String masterPwd;
    @XmlElement(name = "ReaderPwd")
    protected String readerPwd;
    @XmlElement(name = "CustomerPwd")
    protected String customerPwd;
    @XmlElement(name = "WakeupInterval")
    protected Integer wakeupInterval;
    @XmlElement(name = "IsMicroAP")
    protected Boolean isMicroAP;

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setMode(MeterModeType value) {
        this.mode = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLnSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVSqrHrLnSf() {
        return scaleVSqrHrLnSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLnSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVSqrHrLnSf(Long value) {
        this.scaleVSqrHrLnSf = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLlSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVSqrHrLlSf() {
        return scaleVSqrHrLlSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLlSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVSqrHrLlSf(Long value) {
        this.scaleVSqrHrLlSf = value;
    }

    /**
     * Gets the value of the scaleISqrHrSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleISqrHrSf() {
        return scaleISqrHrSf;
    }

    /**
     * Sets the value of the scaleISqrHrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleISqrHrSf(Long value) {
        this.scaleISqrHrSf = value;
    }

    /**
     * Gets the value of the scaleINSqrSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleINSqrSf() {
        return scaleINSqrSf;
    }

    /**
     * Sets the value of the scaleINSqrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleINSqrSf(Long value) {
        this.scaleINSqrSf = value;
    }

    /**
     * Gets the value of the scaleVaSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVaSf() {
        return scaleVaSf;
    }

    /**
     * Sets the value of the scaleVaSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVaSf(Long value) {
        this.scaleVaSf = value;
    }

    /**
     * Gets the value of the scaleVahSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVahSf() {
        return scaleVahSf;
    }

    /**
     * Sets the value of the scaleVahSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVahSf(Long value) {
        this.scaleVahSf = value;
    }

    /**
     * Gets the value of the timebase property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTimebase() {
        return timebase;
    }

    /**
     * Sets the value of the timebase property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTimebase(Long value) {
        this.timebase = value;
    }

    /**
     * Gets the value of the currSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrSampleScalar() {
        return currSampleScalar;
    }

    /**
     * Sets the value of the currSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrSampleScalar(Long value) {
        this.currSampleScalar = value;
    }

    /**
     * Gets the value of the currSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrSampleDivisor() {
        return currSampleDivisor;
    }

    /**
     * Sets the value of the currSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrSampleDivisor(Long value) {
        this.currSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltSampleDivisor() {
        return voltSampleDivisor;
    }

    /**
     * Sets the value of the voltSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltSampleDivisor(Long value) {
        this.voltSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltSampleScalar() {
        return voltSampleScalar;
    }

    /**
     * Sets the value of the voltSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltSampleScalar(Long value) {
        this.voltSampleScalar = value;
    }

    /**
     * Gets the value of the currTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrTransRatio() {
        return currTransRatio;
    }

    /**
     * Sets the value of the currTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrTransRatio(Long value) {
        this.currTransRatio = value;
    }

    /**
     * Gets the value of the voltTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltTransRatio() {
        return voltTransRatio;
    }

    /**
     * Sets the value of the voltTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltTransRatio(Long value) {
        this.voltTransRatio = value;
    }

    /**
     * Gets the value of the utilQyMeterRegRatio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilQyMeterRegRatio() {
        return utilQyMeterRegRatio;
    }

    /**
     * Sets the value of the utilQyMeterRegRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilQyMeterRegRatio(String value) {
        this.utilQyMeterRegRatio = value;
    }

    /**
     * Gets the value of the masterPwd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterPwd() {
        return masterPwd;
    }

    /**
     * Sets the value of the masterPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterPwd(String value) {
        this.masterPwd = value;
    }

    /**
     * Gets the value of the readerPwd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReaderPwd() {
        return readerPwd;
    }

    /**
     * Sets the value of the readerPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReaderPwd(String value) {
        this.readerPwd = value;
    }

    /**
     * Gets the value of the customerPwd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerPwd() {
        return customerPwd;
    }

    /**
     * Sets the value of the customerPwd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerPwd(String value) {
        this.customerPwd = value;
    }

    /**
     * Gets the value of the wakeupInterval property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWakeupInterval() {
        return wakeupInterval;
    }

    /**
     * Sets the value of the wakeupInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWakeupInterval(Integer value) {
        this.wakeupInterval = value;
    }

    /**
     * Gets the value of the isMicroAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsMicroAP() {
        return isMicroAP;
    }

    /**
     * Sets the value of the isMicroAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsMicroAP(Boolean value) {
        this.isMicroAP = value;
    }

}
