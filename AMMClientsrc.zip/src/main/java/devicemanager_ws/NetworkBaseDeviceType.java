
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CabinetID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CabinetSlotNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType"/&gt;
 *         &lt;element name="UtilNmState" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UtilNetworkStateType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NetworkID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NicSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicArchitecture" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicArchitectureType" minOccurs="0"/&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BackboneDevice" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SocketAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Suspect" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SuspectReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="DeviceConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BaseDeviceConfigType" minOccurs="0"/&gt;
 *         &lt;element name="InstallTS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RemoveTS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CatalogNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProgramSealAtManufacture" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkBaseDeviceType", propOrder = {
    "didType",
    "didSubtype",
    "utilDeviceID",
    "cabinetID",
    "cabinetSlotNum",
    "utilDeviceState",
    "utilNmState",
    "name",
    "networkID",
    "nicSerialNumber",
    "nicArchitecture",
    "macID",
    "nicHardwareConfig",
    "nicSoftwareConfig",
    "serialNumber",
    "backboneDevice",
    "socketAP",
    "suspect",
    "suspectReason",
    "description",
    "timeZoneID",
    "deviceConfig",
    "installTS",
    "removeTS",
    "catalogNumber",
    "programSealAtManufacture",
    "deviceAttribute1",
    "deviceAttribute2",
    "deviceAttribute3",
    "deviceAttribute4",
    "deviceAttribute5",
    "nicAttribute1",
    "nicAttribute2",
    "nicAttribute3",
    "nicAttribute4",
    "nicAttribute5"
})
@XmlSeeAlso({
    AddNetworkBaseDeviceType.class,
    EditNetworkBaseDeviceType.class,
    GetDeviceType.class
})
public class NetworkBaseDeviceType {

    @XmlElement(name = "DidType", required = true)
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype", required = true)
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "UtilDeviceID", required = true)
    protected String utilDeviceID;
    @XmlElement(name = "CabinetID")
    protected String cabinetID;
    @XmlElement(name = "CabinetSlotNum")
    protected String cabinetSlotNum;
    @XmlElement(name = "UtilDeviceState", required = true)
    protected UtilDeviceStateType utilDeviceState;
    @XmlElement(name = "UtilNmState")
    protected UtilNetworkStateType utilNmState;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "NetworkID", required = true)
    protected String networkID;
    @XmlElement(name = "NicSerialNumber")
    protected String nicSerialNumber;
    @XmlElement(name = "NicArchitecture")
    protected NicArchitectureType nicArchitecture;
    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "NicHardwareConfig")
    protected String nicHardwareConfig;
    @XmlElement(name = "NicSoftwareConfig")
    protected String nicSoftwareConfig;
    @XmlElement(name = "SerialNumber", required = true)
    protected String serialNumber;
    @XmlElement(name = "BackboneDevice", defaultValue = "false")
    protected Boolean backboneDevice;
    @XmlElement(name = "SocketAP", defaultValue = "false")
    protected Boolean socketAP;
    @XmlElement(name = "Suspect", defaultValue = "false")
    protected Boolean suspect;
    @XmlElement(name = "SuspectReason")
    protected String suspectReason;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "TimeZoneID")
    protected TimeZoneType timeZoneID;
    @XmlElement(name = "DeviceConfig")
    protected BaseDeviceConfigType deviceConfig;
    @XmlElement(name = "InstallTS")
    protected String installTS;
    @XmlElement(name = "RemoveTS")
    protected String removeTS;
    @XmlElement(name = "CatalogNumber")
    protected String catalogNumber;
    @XmlElement(name = "ProgramSealAtManufacture")
    protected String programSealAtManufacture;
    @XmlElement(name = "DeviceAttribute1")
    protected String deviceAttribute1;
    @XmlElement(name = "DeviceAttribute2")
    protected String deviceAttribute2;
    @XmlElement(name = "DeviceAttribute3")
    protected String deviceAttribute3;
    @XmlElement(name = "DeviceAttribute4")
    protected String deviceAttribute4;
    @XmlElement(name = "DeviceAttribute5")
    protected String deviceAttribute5;
    @XmlElement(name = "NicAttribute1")
    protected String nicAttribute1;
    @XmlElement(name = "NicAttribute2")
    protected String nicAttribute2;
    @XmlElement(name = "NicAttribute3")
    protected String nicAttribute3;
    @XmlElement(name = "NicAttribute4")
    protected String nicAttribute4;
    @XmlElement(name = "NicAttribute5")
    protected String nicAttribute5;

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the cabinetID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCabinetID() {
        return cabinetID;
    }

    /**
     * Sets the value of the cabinetID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCabinetID(String value) {
        this.cabinetID = value;
    }

    /**
     * Gets the value of the cabinetSlotNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCabinetSlotNum() {
        return cabinetSlotNum;
    }

    /**
     * Sets the value of the cabinetSlotNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCabinetSlotNum(String value) {
        this.cabinetSlotNum = value;
    }

    /**
     * Gets the value of the utilDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceState() {
        return utilDeviceState;
    }

    /**
     * Sets the value of the utilDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceState(UtilDeviceStateType value) {
        this.utilDeviceState = value;
    }

    /**
     * Gets the value of the utilNmState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public UtilNetworkStateType getUtilNmState() {
        return utilNmState;
    }

    /**
     * Sets the value of the utilNmState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public void setUtilNmState(UtilNetworkStateType value) {
        this.utilNmState = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the networkID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkID() {
        return networkID;
    }

    /**
     * Sets the value of the networkID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkID(String value) {
        this.networkID = value;
    }

    /**
     * Gets the value of the nicSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSerialNumber() {
        return nicSerialNumber;
    }

    /**
     * Sets the value of the nicSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSerialNumber(String value) {
        this.nicSerialNumber = value;
    }

    /**
     * Gets the value of the nicArchitecture property.
     * 
     * @return
     *     possible object is
     *     {@link NicArchitectureType }
     *     
     */
    public NicArchitectureType getNicArchitecture() {
        return nicArchitecture;
    }

    /**
     * Sets the value of the nicArchitecture property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicArchitectureType }
     *     
     */
    public void setNicArchitecture(NicArchitectureType value) {
        this.nicArchitecture = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the nicHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareConfig() {
        return nicHardwareConfig;
    }

    /**
     * Sets the value of the nicHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareConfig(String value) {
        this.nicHardwareConfig = value;
    }

    /**
     * Gets the value of the nicSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareConfig() {
        return nicSoftwareConfig;
    }

    /**
     * Sets the value of the nicSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareConfig(String value) {
        this.nicSoftwareConfig = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the backboneDevice property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBackboneDevice() {
        return backboneDevice;
    }

    /**
     * Sets the value of the backboneDevice property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBackboneDevice(Boolean value) {
        this.backboneDevice = value;
    }

    /**
     * Gets the value of the socketAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSocketAP() {
        return socketAP;
    }

    /**
     * Sets the value of the socketAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSocketAP(Boolean value) {
        this.socketAP = value;
    }

    /**
     * Gets the value of the suspect property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSuspect() {
        return suspect;
    }

    /**
     * Sets the value of the suspect property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSuspect(Boolean value) {
        this.suspect = value;
    }

    /**
     * Gets the value of the suspectReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuspectReason() {
        return suspectReason;
    }

    /**
     * Sets the value of the suspectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuspectReason(String value) {
        this.suspectReason = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setTimeZoneID(TimeZoneType value) {
        this.timeZoneID = value;
    }

    /**
     * Gets the value of the deviceConfig property.
     * 
     * @return
     *     possible object is
     *     {@link BaseDeviceConfigType }
     *     
     */
    public BaseDeviceConfigType getDeviceConfig() {
        return deviceConfig;
    }

    /**
     * Sets the value of the deviceConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link BaseDeviceConfigType }
     *     
     */
    public void setDeviceConfig(BaseDeviceConfigType value) {
        this.deviceConfig = value;
    }

    /**
     * Gets the value of the installTS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstallTS() {
        return installTS;
    }

    /**
     * Sets the value of the installTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstallTS(String value) {
        this.installTS = value;
    }

    /**
     * Gets the value of the removeTS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoveTS() {
        return removeTS;
    }

    /**
     * Sets the value of the removeTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoveTS(String value) {
        this.removeTS = value;
    }

    /**
     * Gets the value of the catalogNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCatalogNumber() {
        return catalogNumber;
    }

    /**
     * Sets the value of the catalogNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCatalogNumber(String value) {
        this.catalogNumber = value;
    }

    /**
     * Gets the value of the programSealAtManufacture property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramSealAtManufacture() {
        return programSealAtManufacture;
    }

    /**
     * Sets the value of the programSealAtManufacture property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramSealAtManufacture(String value) {
        this.programSealAtManufacture = value;
    }

    /**
     * Gets the value of the deviceAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute1() {
        return deviceAttribute1;
    }

    /**
     * Sets the value of the deviceAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute1(String value) {
        this.deviceAttribute1 = value;
    }

    /**
     * Gets the value of the deviceAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute2() {
        return deviceAttribute2;
    }

    /**
     * Sets the value of the deviceAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute2(String value) {
        this.deviceAttribute2 = value;
    }

    /**
     * Gets the value of the deviceAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute3() {
        return deviceAttribute3;
    }

    /**
     * Sets the value of the deviceAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute3(String value) {
        this.deviceAttribute3 = value;
    }

    /**
     * Gets the value of the deviceAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute4() {
        return deviceAttribute4;
    }

    /**
     * Sets the value of the deviceAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute4(String value) {
        this.deviceAttribute4 = value;
    }

    /**
     * Gets the value of the deviceAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute5() {
        return deviceAttribute5;
    }

    /**
     * Sets the value of the deviceAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute5(String value) {
        this.deviceAttribute5 = value;
    }

    /**
     * Gets the value of the nicAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute1() {
        return nicAttribute1;
    }

    /**
     * Sets the value of the nicAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute1(String value) {
        this.nicAttribute1 = value;
    }

    /**
     * Gets the value of the nicAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute2() {
        return nicAttribute2;
    }

    /**
     * Sets the value of the nicAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute2(String value) {
        this.nicAttribute2 = value;
    }

    /**
     * Gets the value of the nicAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute3() {
        return nicAttribute3;
    }

    /**
     * Sets the value of the nicAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute3(String value) {
        this.nicAttribute3 = value;
    }

    /**
     * Gets the value of the nicAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute4() {
        return nicAttribute4;
    }

    /**
     * Sets the value of the nicAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute4(String value) {
        this.nicAttribute4 = value;
    }

    /**
     * Gets the value of the nicAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute5() {
        return nicAttribute5;
    }

    /**
     * Sets the value of the nicAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute5(String value) {
        this.nicAttribute5 = value;
    }

}
