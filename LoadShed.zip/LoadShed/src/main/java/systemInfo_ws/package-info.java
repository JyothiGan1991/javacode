@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.2:SystemInfo.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package systemInfo_ws;
