
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdvancedMeterReadDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdvancedMeterReadDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}BaseExportDataType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OutputFormat" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}MeterReadOutputFormatType"/&gt;
 *         &lt;element name="FileSegmenting" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}MeterReadFileSegmentingType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="ExportType" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}ExportTypeEnumeration" default="Informational" /&gt;
 *       &lt;attribute name="LogExportExceptions" type="{http://www.w3.org/2001/XMLSchema}boolean" default="true" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdvancedMeterReadDataType", propOrder = {
    "outputFormat",
    "fileSegmenting"
})
public class AdvancedMeterReadDataType
    extends BaseExportDataType
{

    @XmlElement(name = "OutputFormat", required = true)
    protected MeterReadOutputFormatType outputFormat;
    @XmlElement(name = "FileSegmenting")
    protected MeterReadFileSegmentingType fileSegmenting;
    @XmlAttribute(name = "ExportType")
    protected ExportTypeEnumeration exportType;
    @XmlAttribute(name = "LogExportExceptions")
    protected Boolean logExportExceptions;

    /**
     * Gets the value of the outputFormat property.
     * 
     * @return
     *     possible object is
     *     {@link MeterReadOutputFormatType }
     *     
     */
    public MeterReadOutputFormatType getOutputFormat() {
        return outputFormat;
    }

    /**
     * Sets the value of the outputFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterReadOutputFormatType }
     *     
     */
    public void setOutputFormat(MeterReadOutputFormatType value) {
        this.outputFormat = value;
    }

    /**
     * Gets the value of the fileSegmenting property.
     * 
     * @return
     *     possible object is
     *     {@link MeterReadFileSegmentingType }
     *     
     */
    public MeterReadFileSegmentingType getFileSegmenting() {
        return fileSegmenting;
    }

    /**
     * Sets the value of the fileSegmenting property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterReadFileSegmentingType }
     *     
     */
    public void setFileSegmenting(MeterReadFileSegmentingType value) {
        this.fileSegmenting = value;
    }

    /**
     * Gets the value of the exportType property.
     * 
     * @return
     *     possible object is
     *     {@link ExportTypeEnumeration }
     *     
     */
    public ExportTypeEnumeration getExportType() {
        if (exportType == null) {
            return ExportTypeEnumeration.INFORMATIONAL;
        } else {
            return exportType;
        }
    }

    /**
     * Sets the value of the exportType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExportTypeEnumeration }
     *     
     */
    public void setExportType(ExportTypeEnumeration value) {
        this.exportType = value;
    }

    /**
     * Gets the value of the logExportExceptions property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isLogExportExceptions() {
        if (logExportExceptions == null) {
            return true;
        } else {
            return logExportExceptions;
        }
    }

    /**
     * Sets the value of the logExportExceptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLogExportExceptions(Boolean value) {
        this.logExportExceptions = value;
    }

}
