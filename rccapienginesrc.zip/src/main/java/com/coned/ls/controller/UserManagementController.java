package com.coned.ls.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXPrincipal;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
/*import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;*/
import javax.security.auth.Subject;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;


/*import org.apache.commons.codec.digest.DigestUtils;
*/import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.UserManagementService;

@RequestMapping("rcc/um")
@RestController
//@PropertySource("file:/home/logs/config.properties")
public class UserManagementController {
	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";

	private String APP_NAME = "AOCCApp";
	private static final Logger logger = LoggerFactory.getLogger(UserManagementController.class);

	/*
	 * private String hostname = System.getProperty("aocc.server.hostname"); private
	 * String portString = System.getProperty("aocc.server.portnumber");
	 * 
	 * private String ldapUsername = System.getProperty("aocc.ldap.username");
	 * private String ldapPassword = System.getProperty("aocc.ldap.password");
	 */
	@Autowired
	private Environment env;

	/*
	 * @Value("${weblogic.jmx.host}") private static String hostname;
	 * 
	 * @Value("${weblogic.jmx.port}") private static String portString;
	 * 
	 * @Value("${ldap.search.user}") private static String ldapUsername;
	 * 
	 * @Value("${ldap.search.user.pwd}") private static String ldapPassword;
	 */

	private static MBeanServerConnection connection;
	private static JMXConnector connector;
	private static final ObjectName service = null;
	ObjectName[] atnProviders = null;
	ObjectName mBeanTypeService = null;

	@Autowired
	private UserManagementService userManagementService;

	@GetMapping("/users")
	public ResponseEntity<List<Map<String, Object>>> getUsers() {
		logger.info(String.format("Request for persist API key into database"));
		try {
			ResponseEntity<List<Map<String, Object>>> users = userManagementService.getUsers();
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}

	@PostMapping("/users")
	public ResponseEntity<Map<String, Object>> createUser(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for CREATE USER into database"));

		try {
			ResponseEntity<Map<String, Object>> response = userManagementService.createUser(payload);
			return response;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}

	@PutMapping("/users/{username}")
	public ResponseEntity<Map<String, Object>> updateUser(@PathVariable("username") String username,
			@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for UPDATE USER into database"));

		try {
			ResponseEntity<Map<String, Object>> response = userManagementService.updateUser(username, payload);
			return response;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}

	@DeleteMapping("/users/{username}")
	public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable("username") String username,
			@RequestParam(name = "updatedBy") String updatedBy) {
		logger.info(String.format("Request for DELETE USER into database"));
		try {
			ResponseEntity<Map<String, Object>> response = userManagementService.deleteUser(username, updatedBy);
			return response;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}

	@GetMapping("/adusers/{username}")
	public ResponseEntity<Map<String, Object>> listLDAPUsers(@PathVariable("username") String username) {
		UserManagementController c = new UserManagementController();
		Map<String, Object> users = new HashMap<String, Object>();
		try {
			initConnection();
			c.getAuthprovider();

			ObjectName userReader = c.getUserreader();
			ObjectName userAttrReader = c.getUserAttrReader();
			String uCurName = (String) connection.invoke(userReader, "listUsers", new Object[] { username, 100 },
					new String[] { "java.lang.String", "java.lang.Integer" });
			logger.debug(uCurName);

			boolean hasCurrent = (Boolean) connection.invoke(userReader, "haveCurrent", new Object[] { uCurName },
					new String[] { "java.lang.String" });
			logger.debug("---- before loop hasCurrent? " + hasCurrent);
			boolean userExists = false;

			while (hasCurrent) {
				userExists = (boolean) connection.invoke(userReader, "userExists", new Object[] { username },
						new String[] { "java.lang.String" });
				username = (String) connection.invoke(userReader, "getCurrentName", new Object[] { uCurName },
						new String[] { "java.lang.String" });

				logger.debug("  -- user? " + username + " userExists? " + userExists);

				break;
			}
			users.put("userName", username);
			users.put("userExists", userExists);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception listLDAPUsers: " + e);
		}
		logger.debug(" ---- END listLDAPUsers ----- ");
		return ResponseEntity.ok().body(users);
	}

	public void initConnection() throws Exception {
		logger.debug(" ---- START initConnection() ---- ");
		FileInputStream fis = null;
		try {
			getUserName();
			String protocol = "t3";
			Properties prop = null;
			String path = env.getProperty("config.file.path");
			fis = new FileInputStream(path);
			prop = new Properties();
			prop.load(fis);
			String hostname = prop.getProperty("weblogic.jmx.host");
			String portString = prop.getProperty("weblogic.jmx.port");
			logger.debug("hostname: " + hostname + " portString: " + portString);

			String userName = prop.getProperty("ldap.search.user");
			String password = prop.getProperty("ldap.search.user.pwd");

			logger.debug("userName: "+userName+" password: "+password);

			Integer portInteger = Integer.valueOf(portString);
			int port = portInteger.intValue();
			String jndiroot = "/jndi/";
			String mserver = "weblogic.management.mbeanservers.domainruntime";
			JMXServiceURL serviceURL = new JMXServiceURL(protocol, hostname, port, jndiroot + mserver);

			Hashtable h = new Hashtable();
			logger.debug(" ---- Username? " + userName);
			h.put(Context.SECURITY_PRINCIPAL, userName);
			h.put(Context.SECURITY_CREDENTIALS, password);
			h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
			h.put("jmx.remote.x.request.waiting.timeout", new Long(10000));
			connector = JMXConnectorFactory.connect(serviceURL, h);
			connection = connector.getMBeanServerConnection();
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			throw new Exception(fnfe.getMessage());
		} catch (IOException ioe) {
			ioe.printStackTrace();
			throw new Exception(ioe.getMessage());
		} catch (Exception e) {
			logger.error("**Exception initConnection(): " + e);
			throw e;
		} finally {
			fis.close();
		}
		logger.debug(" ---- END initConnection() ----- ");
	}

	private String getUserName() {
		logger.debug("---------------------- START - getUserName() ------------------------");
		AccessControlContext acc = AccessController.getContext();
		Subject subject = Subject.getSubject(acc);
		logger.debug("subject? " + subject);
		if (subject != null) {
			Set<JMXPrincipal> principals = subject.getPrincipals(JMXPrincipal.class);
			JMXPrincipal principal = principals.iterator().next();
			logger.debug("principal " + principal);
			logger.debug("principal " + principal.getName());
			return principal.getName();
		}
		logger.debug("---------------------- END - getUserName() ------------------------");
		return "";
	}

	ObjectName[] getAuthprovider() throws Exception{
		logger.debug("---- START getAuthprovider() ----");
		try {
			mBeanTypeService = new ObjectName(
					"com.bea:Name=MBeanTypeService,Type=weblogic.management.mbeanservers.MBeanTypeService");
			ObjectName service = new ObjectName(
					"com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
			ObjectName domainMBean = (ObjectName) connection.getAttribute(service, "DomainConfiguration");
			ObjectName securityConfiguration = (ObjectName) connection.getAttribute(domainMBean,
					"SecurityConfiguration");
			// DefaultRealm
			ObjectName defaultRealm = (ObjectName) connection.getAttribute(securityConfiguration, "DefaultRealm");
			logger.debug("defaultRealm? " + defaultRealm);
			atnProviders = (ObjectName[]) connection.getAttribute(defaultRealm, "AuthenticationProviders");
//			atnProviders.remove(int index);
			logger.debug("atnProviders? " + atnProviders.length);
			logger.debug("atnProviders[0]? " + atnProviders[0] + " atnProviders[1]: " + atnProviders[1]
					+ " atnProviders[2]? " + atnProviders[2]);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getAuthprovider(): " + e);
			throw e;
		}
		logger.debug("---- END getAuthprovider() ----");
		return atnProviders;
	}

	ObjectName getUserreader() {
		logger.debug("---- START getUserreader() ----");
		ObjectName userReader = null;
		try {
			for (ObjectName provider : atnProviders) {
				if (userReader == null) {
					ModelMBeanInfo info = (ModelMBeanInfo) connection.getMBeanInfo(provider);
					String className = (String) info.getMBeanDescriptor().getFieldValue("interfaceClassName");
					logger.debug("className? " + className);
					if (className != null) {
						String[] beans = (String[]) connection.invoke(mBeanTypeService, "getSubtypes",
								new Object[] { "weblogic.management.security.authentication.UserReaderMBean" },
								new String[] { "java.lang.String" });
//						logger.debug("beans? "+beans.toString());
						for (String bean : beans) {
							logger.debug("bean? " + bean);
							if (bean.equals(className)) {
								userReader = provider;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getUserreader(): " + e);
		}
		logger.debug("---- END getUserreader() ----");
		return userReader;
	}

	ObjectName getUserAttrReader() {
		logger.debug("---- START getUserAttrReader() ----");
		ObjectName userAttrReader = null;
		try {
			for (ObjectName provider : atnProviders) {
				if (userAttrReader == null) {
					ModelMBeanInfo info = (ModelMBeanInfo) connection.getMBeanInfo(provider);
					String className = (String) info.getMBeanDescriptor().getFieldValue("interfaceClassName");
					logger.debug("className? " + className);
					if (className != null) {
						String[] beans = (String[]) connection.invoke(mBeanTypeService, "getSubtypes",
								new Object[] { "weblogic.management.security.authentication.UserAttributeReaderMBean" },
								new String[] { "java.lang.String" });
//						logger.debug("beans? "+beans.toString());
						for (String bean : beans) {
							logger.debug("bean? " + bean);
							if (bean.equals(className)) {
								userAttrReader = provider;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getUserAttrReader(): " + e);
		}
		logger.debug("---- END getUserAttrReader() ----");
		return userAttrReader;
	}
}