package com.coned.amm.service;

import java.util.Optional;

import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coned.amm.config.AppConfig;
import com.coned.amm.config.GlobalProperties;
import com.coned.amm.config.RSMConfig;

import jobmanager_ws.AddRemoteProvisioningJobType;
import jobmanager_ws.EmptyType;
import jobmanager_ws.ErrorCodeFault;
import jobmanager_ws.GetJobStatusType;
import jobmanager_ws.JobIDResponseType;
import jobmanager_ws.JobInfoType;
import jobmanager_ws.JobManagerPortType;
import jobmanager_ws.JobManagerService;
import jobmanager_ws.JobStatusType;
import jobmanager_ws.PriorityEnumeration;
import jobmanager_ws.PriorityType;
import jobmanager_ws.ProvisioningActionType;
import jobmanager_ws.RemoteProvisioningJobType;
import jobmanager_ws.RemoteProvisioningTypeEnumeration;
import jobmanager_ws.ScheduleChoiceType;

@Service
public class JMService {
	private static final Logger logger = LoggerFactory.getLogger(JMService.class);

	@Autowired
	protected DmgrService dMgrService;

	@Autowired
	DvcResultsService dvcrService;

	@Autowired
	private GlobalProperties prop;

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private JobManagerPortType jobManagerService;

	public Optional<Object> remoteConnectDisconnect(String meterId, String macId, boolean isDisconnect) {
		try {
			JobIDResponseType response;
			AddRemoteProvisioningJobType addJob = new AddRemoteProvisioningJobType();
			addJob.setAutoActivate(true);
			addJob.setRemoteProvisioningJob(populateRPJobType(macId, isDisconnect, addJob));
			addJob.setSchedule(populateSchedule());

			if (this.jobManagerService != null) {
				response = this.jobManagerService.addRemoteProvisioningJob(addJob);
			} else {
				response = this.appConfig.jobManagerService().addRemoteProvisioningJob(addJob);
			}

			logger.info("Response Job ID for connect/disconnect operation: " + response.getJobID());
			return Optional.of(response.getJobID());
		} catch (ErrorCodeFault errorCodeFault) {
			logger.error("Error response from AMM for connect/disconnect operation; " + errorCodeFault);
			return Optional.of(errorCodeFault);
		}
		// return jobID;
	}

	private RemoteProvisioningJobType populateRPJobType(String macId, boolean isDisconnect,
			AddRemoteProvisioningJobType addJob) {
		RemoteProvisioningJobType rpj = new RemoteProvisioningJobType();
		ProvisioningActionType pat = new ProvisioningActionType();
		JobInfoType jit = new JobInfoType();
		if (isDisconnect) {
			jit.setName("Disconnect Job");
			pat.setName(RemoteProvisioningTypeEnumeration.JOB_OP_PROVISION_DISCONNECT);
		} else {
			jit.setName("connect Job");
			pat.setName(RemoteProvisioningTypeEnumeration.JOB_OP_PROVISION_CONNECT);
		}
		addJob.setJobInfo(jit);
		rpj.getDeviceMacID().add(macId);
		rpj.setProvisioningAction(pat);
		// As per the AMM documentation set number of retries to 0.
		rpj.setNumberRetries(Integer.valueOf(prop.getRetryCount()).intValue());
		rpj.setPriority(populatePriority(prop.getCdpriority()));
		return rpj;
	}

	private PriorityType populatePriority(String priority) {
		PriorityType pt = new PriorityType();
		pt.setName(PriorityEnumeration.fromValue(priority));
		return pt;
	}

	private ScheduleChoiceType populateSchedule() {
		ScheduleChoiceType sct = new ScheduleChoiceType();
		EmptyType et = new EmptyType();
		sct.setImmediate(et);
		return sct;
	}

	public Optional<Object> getJobStatus(long jobID) {
		try {
			JobStatusType response;
			logger.info("Requesting disconnect status for job id [" + jobID + "]");
			GetJobStatusType jst = new GetJobStatusType();
			jst.setJobID(jobID);
			if (this.jobManagerService != null) {
				response = this.jobManagerService.getJobStatus(jst);
			} else {
				response = this.appConfig.jobManagerService().getJobStatus(jst);
			}
			logger.info("EXECUTION Progress[" + response.getExecutionProgress() + "]");
			logger.info("EXECUTION STATUS MESSAGE[" + response.getExecutionStatus().getName() + "]");
			logger.info("EXECUTION RESULT MESSAGE[" + response.getExecutionResultMessage() + "]");

			return Optional.of(response.getExecutionStatus().getName());
		} catch (ErrorCodeFault errorCodeFault) {
			logger.error("Error response from AMM for Job Status operation; ", errorCodeFault);
			return Optional.of(errorCodeFault);
		}
		// return Optional.empty();
	}

	public Optional<Object> getSwitchStatus(String macID) {
		try {
			JobIDResponseType response;
			RemoteProvisioningJobType rpj = new RemoteProvisioningJobType();
			rpj.getDeviceMacID().add(macID);
			rpj.setNumberRetries(Integer.valueOf(this.prop.getRetryCount()).intValue());

			ProvisioningActionType pat = new ProvisioningActionType();
			pat.setName(RemoteProvisioningTypeEnumeration.JOB_OP_PROVISION_GET_STATUS);

			rpj.setProvisioningAction(pat);
			rpj.setPriority(populatePriority(this.prop.getSspriority()));

			AddRemoteProvisioningJobType addJob = new AddRemoteProvisioningJobType();
			addJob.setAutoActivate(Boolean.valueOf(true));
			addJob.setJobInfo(populateJIT());
			addJob.setRemoteProvisioningJob(rpj);
			addJob.setSchedule(populateSchedule());
			
			if (this.jobManagerService != null) {
				response = this.jobManagerService.addRemoteProvisioningJob(addJob);
			} else {
				response = this.appConfig.jobManagerService().addRemoteProvisioningJob(addJob);
			}
			logger.info("Response Job ID for disconnect: " + response.getJobID());
			return Optional.of(response.getJobID());

		} catch (ErrorCodeFault errorCodeFault) {
			logger.error("Error response from AMM for Switch Status operation; " + errorCodeFault);
			return Optional.of(errorCodeFault);
		}
		// return jobID;
	}

	private JobInfoType populateJIT() {
		JobInfoType jit = new JobInfoType();
		jit.setName("Check Switch Status Job");
		return jit;
	}

	/*
	 * private JobManagerPortType jobManagerService() { JobManagerService dms = new
	 * JobManagerService(); JobManagerPortType jip = dms.getJobManagerPort();
	 * 
	 * ((BindingProvider)
	 * jip).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
	 * config.getJobManagerUri()); ((BindingProvider)
	 * jip).getRequestContext().put(BindingProvider.USERNAME_PROPERTY,
	 * config.getUsername()); ((BindingProvider)
	 * jip).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY,
	 * config.getPassword()); return jip; }
	 */
}
