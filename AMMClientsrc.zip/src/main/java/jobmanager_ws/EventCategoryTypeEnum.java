
package jobmanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EventCategoryTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="EventCategoryTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="EVENT_CAT_METER_READ"/&gt;
 *     &lt;enumeration value="EVENT_CAT_METER_COMM"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DEVICE_PING"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DEVICE_CONFIG"/&gt;
 *     &lt;enumeration value="EVENT_CAT_NIC_EVENT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_METER_EVENT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_UIQ_PROCESS"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DEVICE_REG"/&gt;
 *     &lt;enumeration value="EVENT_CAT_IMU_EVENT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_UIQ_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_GATEWAY_STATUS"/&gt;
 *     &lt;enumeration value="EVENT_CAT_JOB"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DBMS"/&gt;
 *     &lt;enumeration value="EVENT_CAT_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_BILLING_CYCLE_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DEVICE_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_LOCATION_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_ROUTE_IMPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_DEVICE_ROUTE"/&gt;
 *     &lt;enumeration value="EVENT_CAT_EXPORT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_REMOTE_SIGNALING"/&gt;
 *     &lt;enumeration value="EVENT_CAT_ZIGBEE_METER_EVENT"/&gt;
 *     &lt;enumeration value="EVENT_CAT_ITRON_IMU_EVENT"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "EventCategoryTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum EventCategoryTypeEnum {

    EVENT_CAT_METER_READ("EVENT_CAT_METER_READ"),
    EVENT_CAT_METER_COMM("EVENT_CAT_METER_COMM"),
    EVENT_CAT_DEVICE_PING("EVENT_CAT_DEVICE_PING"),
    EVENT_CAT_DEVICE_CONFIG("EVENT_CAT_DEVICE_CONFIG"),
    EVENT_CAT_NIC_EVENT("EVENT_CAT_NIC_EVENT"),
    EVENT_CAT_METER_EVENT("EVENT_CAT_METER_EVENT"),
    EVENT_CAT_UIQ_PROCESS("EVENT_CAT_UIQ_PROCESS"),
    EVENT_CAT_DEVICE_REG("EVENT_CAT_DEVICE_REG"),
    EVENT_CAT_IMU_EVENT("EVENT_CAT_IMU_EVENT"),
    EVENT_CAT_UIQ_IMPORT("EVENT_CAT_UIQ_IMPORT"),
    EVENT_CAT_GATEWAY_STATUS("EVENT_CAT_GATEWAY_STATUS"),
    EVENT_CAT_JOB("EVENT_CAT_JOB"),
    EVENT_CAT_DBMS("EVENT_CAT_DBMS"),
    EVENT_CAT_IMPORT("EVENT_CAT_IMPORT"),
    EVENT_CAT_BILLING_CYCLE_IMPORT("EVENT_CAT_BILLING_CYCLE_IMPORT"),
    EVENT_CAT_DEVICE_IMPORT("EVENT_CAT_DEVICE_IMPORT"),
    EVENT_CAT_LOCATION_IMPORT("EVENT_CAT_LOCATION_IMPORT"),
    EVENT_CAT_ROUTE_IMPORT("EVENT_CAT_ROUTE_IMPORT"),
    EVENT_CAT_DEVICE_ROUTE("EVENT_CAT_DEVICE_ROUTE"),
    EVENT_CAT_EXPORT("EVENT_CAT_EXPORT"),
    EVENT_CAT_REMOTE_SIGNALING("EVENT_CAT_REMOTE_SIGNALING"),
    EVENT_CAT_ZIGBEE_METER_EVENT("EVENT_CAT_ZIGBEE_METER_EVENT"),
    EVENT_CAT_ITRON_IMU_EVENT("EVENT_CAT_ITRON_IMU_EVENT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    EventCategoryTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EventCategoryTypeEnum fromValue(String v) {
        for (EventCategoryTypeEnum c: EventCategoryTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
