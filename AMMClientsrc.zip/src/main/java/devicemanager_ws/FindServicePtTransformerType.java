
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindServicePtTransformerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindServicePtTransformerType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServicePtTransformerID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilTransformerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CTRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="PTRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindServicePtTransformerType", propOrder = {
    "servicePtTransformerID",
    "utilTransformerID",
    "utilTransformerType",
    "utilTransformerName",
    "ctRatio",
    "ptRatio"
})
public class FindServicePtTransformerType {

    @XmlElement(name = "ServicePtTransformerID")
    protected Long servicePtTransformerID;
    @XmlElement(name = "UtilTransformerID")
    protected String utilTransformerID;
    @XmlElement(name = "UtilTransformerType")
    protected String utilTransformerType;
    @XmlElement(name = "UtilTransformerName")
    protected String utilTransformerName;
    @XmlElement(name = "CTRatio")
    protected Double ctRatio;
    @XmlElement(name = "PTRatio")
    protected Double ptRatio;

    /**
     * Gets the value of the servicePtTransformerID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServicePtTransformerID() {
        return servicePtTransformerID;
    }

    /**
     * Sets the value of the servicePtTransformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServicePtTransformerID(Long value) {
        this.servicePtTransformerID = value;
    }

    /**
     * Gets the value of the utilTransformerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerID() {
        return utilTransformerID;
    }

    /**
     * Sets the value of the utilTransformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerID(String value) {
        this.utilTransformerID = value;
    }

    /**
     * Gets the value of the utilTransformerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerType() {
        return utilTransformerType;
    }

    /**
     * Sets the value of the utilTransformerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerType(String value) {
        this.utilTransformerType = value;
    }

    /**
     * Gets the value of the utilTransformerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilTransformerName() {
        return utilTransformerName;
    }

    /**
     * Sets the value of the utilTransformerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilTransformerName(String value) {
        this.utilTransformerName = value;
    }

    /**
     * Gets the value of the ctRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCTRatio() {
        return ctRatio;
    }

    /**
     * Sets the value of the ctRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCTRatio(Double value) {
        this.ctRatio = value;
    }

    /**
     * Gets the value of the ptRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPTRatio() {
        return ptRatio;
    }

    /**
     * Sets the value of the ptRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPTRatio(Double value) {
        this.ptRatio = value;
    }

}
