# Nucon REST Wrapper API (Java 8 / WAR for Tomcat)

Spring Boot 2.7 REST API that wraps the NuconWS SOAP Web Services defined in `nuconws.wsdl` (+ `nuconws_schema1.xsd`).

**Target:** Java 8, packaged as **WAR** for deployment on external Apache Tomcat.

## Features

- REST endpoints that internally invoke the corresponding SOAP operations
- Configurable SOAP endpoint URL
- Global exception handling
- Unit tests with mocked SOAP client
- Maven project importable in Eclipse
- Produces a deployable WAR (`nucon-rest-wrapper.war`)


## API Authentication

All `/api/**` endpoints require a Bearer token.

Configure in `application.yml`:

```yaml
api:
  auth:
    enabled: true
    token: change-me-nucon-secret-token
```

Example request:

```bash
curl -X POST http://localhost:9091/api/v1/nucon/electric-info/by-account \
  -H "Authorization: Bearer change-me-nucon-secret-token" \
  -H "Content-Type: application/json" \
  -d '{"account":"ACC123"}'
```

Missing or invalid token returns **HTTP 401**:

```json
{
  "timestamp": "...",
  "status": 401,
  "error": "Unauthorized",
  "message": "Authentication failed",
  "path": "/api/v1/nucon/..."
}
```

Set `api.auth.enabled: false` to disable authentication (not recommended for production).

## SOAP Operations Wrapped

| SOAP Operation                    | REST Endpoint                              | Request                                      | Response                          |
|-----------------------------------|--------------------------------------------|----------------------------------------------|-----------------------------------|
| `getElectricInfoByAccount`        | `POST/GET /api/v1/nucon/electric-info/by-account` | `account` (string)                        | `ElectricInfoDto` JSON            |
| `getElectricInfoByPremise`        | `POST/GET /api/v1/nucon/electric-info/by-premise` | `premise` (string)                        | `ElectricInfoDto` JSON            |
| `getElectricInfoByXYCoordinates`  | `POST/GET /api/v1/nucon/electric-info/by-xy`      | `x`, `y` (string)                         | `ElectricInfoDto` JSON            |
| `sendToNRG`                       | `POST /api/v1/nucon/send-to-nrg`                 | `arg0` (string), `arg1` (int), `arg2` (string) | `{ "success": true, ... }`     |
| `locateInNRGViewer`               | `POST /api/v1/nucon/locate-in-nrg-viewer`        | `arg0/1/2` (int), `arg3` (string)         | `{ "success": true, ... }`        |

## Requirements

- JDK 8+
- Maven 3.6+
- Apache Tomcat 8.5 / 9.x

## Build

```bash
mvn clean package
```

Produces: `target/nucon-rest-wrapper.war`

## Deploy to Tomcat

Copy `target/nucon-rest-wrapper.war` to Tomcat `webapps/`.

Default context: `/nucon-rest-wrapper`  
Example: `http://localhost:8080/nucon-rest-wrapper/api/v1/nucon/electric-info/by-account?account=ACC123`

Override SOAP endpoint:

```text
-Dnucon.soap.endpoint-url=http://your-host:8080/nuconWS/services/NuconWSPort
```

## Run locally (embedded Tomcat)

```bash
mvn spring-boot:run
```

Default port: **9091**

## Configuration

`src/main/resources/application.yml`:

```yaml
server:
  port: 9091

nucon:
  soap:
    endpoint-url: http://localhost:8080/nuconWS/services/NuconWSPort
    connect-timeout-ms: 5000
    read-timeout-ms: 10000
```

## Example Requests

```bash
# By account
curl -X POST http://localhost:9091/api/v1/nucon/electric-info/by-account \
  -H "Content-Type: application/json" \
  -d '{"account":"ACC123"}'

# By premise
curl "http://localhost:9091/api/v1/nucon/electric-info/by-premise?premise=PREM001"

# By XY
curl -X POST http://localhost:9091/api/v1/nucon/electric-info/by-xy \
  -H "Content-Type: application/json" \
  -d '{"x":"100","y":"200"}'

# sendToNRG
curl -X POST http://localhost:9091/api/v1/nucon/send-to-nrg \
  -H "Content-Type: application/json" \
  -d '{"arg0":"id","arg1":1,"arg2":"meta"}'

# locateInNRGViewer
curl -X POST http://localhost:9091/api/v1/nucon/locate-in-nrg-viewer \
  -H "Content-Type: application/json" \
  -d '{"arg0":10,"arg1":20,"arg2":5,"arg3":"label"}'
```

## Import into Eclipse

1. File → Import → Existing Maven Projects
2. Select `nucon-rest-wrapper` folder
3. Use Java 8+ JRE
4. Maven → Update Project if needed

## Notes

- SOAP client is generated from WSDL+XSD at build time into `target/generated-sources/cxf`.
- `spring-boot-starter-tomcat` is `provided` so the WAR uses the server Tomcat.
- SOAP failures return HTTP 502.
