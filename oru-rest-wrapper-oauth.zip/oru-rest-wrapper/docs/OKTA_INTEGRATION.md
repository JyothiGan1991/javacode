# Okta OAuth 2.0 Client Credentials Integration

This application supports **service-to-service** authentication using Okta's
`client_credentials` grant, as described in the Okta OAuth 2.0 document.

## Modes (PROD-safe)

| `api.auth.mode` | Behavior |
|-----------------|----------|
| **`static`** (default) | Only `api.auth.token` is accepted — **same as previous PROD behavior** |
| **`okta`** | Only valid Okta access tokens (JWT) are accepted |
| **`both`** | Accept either static token **or** valid Okta JWT |

Okta is **off by default** (`okta.enabled: false`). Existing deployments keep working
without configuration changes.

## Okta setup (Admin)

1. Create an **API Services** application in Okta.
2. Use a custom authorization server (commonly `default`):
   - Issuer: `https://{yourOktaDomain}/oauth2/default`
   - Token URL: `https://{yourOktaDomain}/oauth2/default/v1/token`
   - JWKS: `https://{yourOktaDomain}/oauth2/default/v1/keys`
3. Define a scope (e.g. `api.read`) and an access policy allowing this client.
4. Copy **Client ID** and **Client Secret**.

## Application configuration

```yaml
api:
  auth:
    enabled: true
    mode: both
    token: change-me-oru-secret-token

okta:
  enabled: true
  domain: your-org.okta.com
  authorization-server-id: default
  client-id: ${OKTA_CLIENT_ID}
  client-secret: ${OKTA_CLIENT_SECRET}
  scope: api.read
```

```bash
export OKTA_CLIENT_ID="your-client-id"
export OKTA_CLIENT_SECRET="your-client-secret"
```

## Obtain a token (client credentials)

```bash
OKTA_DOMAIN="your-org.okta.com"
CLIENT_ID="..."
CLIENT_SECRET="..."

TOKEN=$(curl -s -X POST "https://${OKTA_DOMAIN}/oauth2/default/v1/token" \
  -u "${CLIENT_ID}:${CLIENT_SECRET}" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Accept: application/json" \
  -d "grant_type=client_credentials&scope=api.read" \
  | python -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
```

## Call NRG APIs

```bash
curl -H "Authorization: Bearer ${TOKEN}" \
  "http://localhost:9090/api/v1/nrg/verify-pole?x=100&y=200"
```

## Java helper

`OktaTokenClient` requests tokens the same way (Basic auth + form body):

```java
@Autowired
private OktaTokenClient oktaTokenClient;

String accessToken = oktaTokenClient.requestAccessToken().getAccessToken();
```

## Suggested cutover

1. Deploy with `mode: static` (no change).
2. Enable Okta in a lower environment; set `mode: both`.
3. Point consumers at Okta tokens.
4. Switch PROD to `mode: okta` when ready.
