package com.coned.ls.controller;

import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.ReportService;

@RequestMapping("rcc/report")
@RestController
public class ReportController {
	private static final Logger logger = LoggerFactory.getLogger(ReportController.class);

	@Autowired
	private ReportService reportService;

	@GetMapping("/{report_name}/events")
	public ResponseEntity<List<Map<String, Object>>> getEvents(@PathVariable(name = "report_name") String report_name) {
		logger.info(String.format("Request for get ConnectFailed Events"));
		try {
			ResponseEntity<List<Map<String, Object>>> users = reportService.getEvents(report_name);
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
	/*
	 * Method to check getExtFailEvents.
	 * 
	 * @RequestBody 
	 * 
     * @return 		
	 */	
	@PostMapping("/cwr")
	public ResponseEntity<List<Map<String, Object>>> getCWR(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for get ExtFail Events"));
		try {
		
			ResponseEntity<List<Map<String, Object>>> users = reportService.getCWRData(payload);
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
	@PostMapping("/cdr")
	public ResponseEntity<List<Map<String, Object>>> getCDR(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for get ExtFail Events"));
		try {
		
			ResponseEntity<List<Map<String, Object>>> users = reportService.getCDRData(payload);
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
	@PostMapping("/cer")
	public ResponseEntity<Map<String, Object>> getCER(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for get ExtFail Events"));
		try {
		
			ResponseEntity<Map<String, Object>> users = reportService.getCERData(payload);
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
	
	@PostMapping("/crr")
	public ResponseEntity<List<Map<String, Object>>> getCRR(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for get ExtFail Events"));
		try {
		
			ResponseEntity<List<Map<String, Object>>> users = reportService.getCRRData(payload);
			return users;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
	
	@PostMapping("/cmr")
	public ResponseEntity<Map<String, Object>> getCMR(@RequestBody Map<String, Object> payload) {
		logger.info(String.format("Request for get Connected Meter Report"));
		try {
		
			ResponseEntity<Map<String, Object>> meters = reportService.getCMRData(payload);
			return meters;
		} catch (OperatorAuthorizationException ex) {
			logger.error(ex.getMessage(), ex);
			throw new OperatorAuthorizationException(ex.getMessage(), ex);
		}
	}
}