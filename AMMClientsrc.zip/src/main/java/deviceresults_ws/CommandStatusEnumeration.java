
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CommandStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CommandStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SUCCESS"/&gt;
 *     &lt;enumeration value="C1218_ERROR"/&gt;
 *     &lt;enumeration value="C1218_SERVICE_NOT_SUPPORTED"/&gt;
 *     &lt;enumeration value="C1218_INSUFFICIENT_SECURITY_CLEARANCE"/&gt;
 *     &lt;enumeration value="C1218_OPERATION_NOT_POSSIBLE"/&gt;
 *     &lt;enumeration value="C1218_INAPPROPRIATE_ACTION_REQUESTED"/&gt;
 *     &lt;enumeration value="C1218_DEVICE_BUSY"/&gt;
 *     &lt;enumeration value="C1218_DATA_NOT_READY"/&gt;
 *     &lt;enumeration value="C1218_DATA_LOCKED"/&gt;
 *     &lt;enumeration value="C1218_RENEGOTIATE_REQUEST"/&gt;
 *     &lt;enumeration value="C1218_INVALID_SERVICE_SEQUENCE_STATE"/&gt;
 *     &lt;enumeration value="C1219_PROG_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_READ_PROG_SEAL_ERROR"/&gt;
 *     &lt;enumeration value="C1219_PARTIAL_RESULTS"/&gt;
 *     &lt;enumeration value="C1219_RT_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_RTO_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_WT_WRITE_ERROR"/&gt;
 *     &lt;enumeration value="C1219_WTO_WRITE_ERROR"/&gt;
 *     &lt;enumeration value="C1219_EP_PROCRUN_ERROR"/&gt;
 *     &lt;enumeration value="C1219_SR_READ_HDR_ERROR"/&gt;
 *     &lt;enumeration value="C1219_SR_INDEX_OUT_OF_BOUNDS"/&gt;
 *     &lt;enumeration value="C1219_SR_RTO_ERROR"/&gt;
 *     &lt;enumeration value="C1219_QEL_STATE_ERROR"/&gt;
 *     &lt;enumeration value="C1219_QEL_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_TBL63_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_RI_RTO_ERROR"/&gt;
 *     &lt;enumeration value="C1219_RI_BLK_OUT_OF_BOUND_ERROR"/&gt;
 *     &lt;enumeration value="C1219_RI_ITVL_OUT_OF_BOUND_ERROR"/&gt;
 *     &lt;enumeration value="C1219_EL_OUT_OF_BOUND_ERROR"/&gt;
 *     &lt;enumeration value="C1219_TBL61_READ_ERROR"/&gt;
 *     &lt;enumeration value="C1219_UNSUPPORTED_METER_PROGRAM"/&gt;
 *     &lt;enumeration value="C1219_QEL_RTO_ERROR"/&gt;
 *     &lt;enumeration value="C1219_RSP_TOO_LARGE"/&gt;
 *     &lt;enumeration value="UNKNOWN_ERROR"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "CommandStatusEnumeration")
@XmlEnum
public enum CommandStatusEnumeration {

    SUCCESS("SUCCESS"),
    @XmlEnumValue("C1218_ERROR")
    C_1218_ERROR("C1218_ERROR"),
    @XmlEnumValue("C1218_SERVICE_NOT_SUPPORTED")
    C_1218_SERVICE_NOT_SUPPORTED("C1218_SERVICE_NOT_SUPPORTED"),
    @XmlEnumValue("C1218_INSUFFICIENT_SECURITY_CLEARANCE")
    C_1218_INSUFFICIENT_SECURITY_CLEARANCE("C1218_INSUFFICIENT_SECURITY_CLEARANCE"),
    @XmlEnumValue("C1218_OPERATION_NOT_POSSIBLE")
    C_1218_OPERATION_NOT_POSSIBLE("C1218_OPERATION_NOT_POSSIBLE"),
    @XmlEnumValue("C1218_INAPPROPRIATE_ACTION_REQUESTED")
    C_1218_INAPPROPRIATE_ACTION_REQUESTED("C1218_INAPPROPRIATE_ACTION_REQUESTED"),
    @XmlEnumValue("C1218_DEVICE_BUSY")
    C_1218_DEVICE_BUSY("C1218_DEVICE_BUSY"),
    @XmlEnumValue("C1218_DATA_NOT_READY")
    C_1218_DATA_NOT_READY("C1218_DATA_NOT_READY"),
    @XmlEnumValue("C1218_DATA_LOCKED")
    C_1218_DATA_LOCKED("C1218_DATA_LOCKED"),
    @XmlEnumValue("C1218_RENEGOTIATE_REQUEST")
    C_1218_RENEGOTIATE_REQUEST("C1218_RENEGOTIATE_REQUEST"),
    @XmlEnumValue("C1218_INVALID_SERVICE_SEQUENCE_STATE")
    C_1218_INVALID_SERVICE_SEQUENCE_STATE("C1218_INVALID_SERVICE_SEQUENCE_STATE"),
    @XmlEnumValue("C1219_PROG_READ_ERROR")
    C_1219_PROG_READ_ERROR("C1219_PROG_READ_ERROR"),
    @XmlEnumValue("C1219_READ_PROG_SEAL_ERROR")
    C_1219_READ_PROG_SEAL_ERROR("C1219_READ_PROG_SEAL_ERROR"),
    @XmlEnumValue("C1219_PARTIAL_RESULTS")
    C_1219_PARTIAL_RESULTS("C1219_PARTIAL_RESULTS"),
    @XmlEnumValue("C1219_RT_READ_ERROR")
    C_1219_RT_READ_ERROR("C1219_RT_READ_ERROR"),
    @XmlEnumValue("C1219_RTO_READ_ERROR")
    C_1219_RTO_READ_ERROR("C1219_RTO_READ_ERROR"),
    @XmlEnumValue("C1219_WT_WRITE_ERROR")
    C_1219_WT_WRITE_ERROR("C1219_WT_WRITE_ERROR"),
    @XmlEnumValue("C1219_WTO_WRITE_ERROR")
    C_1219_WTO_WRITE_ERROR("C1219_WTO_WRITE_ERROR"),
    @XmlEnumValue("C1219_EP_PROCRUN_ERROR")
    C_1219_EP_PROCRUN_ERROR("C1219_EP_PROCRUN_ERROR"),
    @XmlEnumValue("C1219_SR_READ_HDR_ERROR")
    C_1219_SR_READ_HDR_ERROR("C1219_SR_READ_HDR_ERROR"),
    @XmlEnumValue("C1219_SR_INDEX_OUT_OF_BOUNDS")
    C_1219_SR_INDEX_OUT_OF_BOUNDS("C1219_SR_INDEX_OUT_OF_BOUNDS"),
    @XmlEnumValue("C1219_SR_RTO_ERROR")
    C_1219_SR_RTO_ERROR("C1219_SR_RTO_ERROR"),
    @XmlEnumValue("C1219_QEL_STATE_ERROR")
    C_1219_QEL_STATE_ERROR("C1219_QEL_STATE_ERROR"),
    @XmlEnumValue("C1219_QEL_READ_ERROR")
    C_1219_QEL_READ_ERROR("C1219_QEL_READ_ERROR"),
    @XmlEnumValue("C1219_TBL63_READ_ERROR")
    C_1219_TBL_63_READ_ERROR("C1219_TBL63_READ_ERROR"),
    @XmlEnumValue("C1219_RI_RTO_ERROR")
    C_1219_RI_RTO_ERROR("C1219_RI_RTO_ERROR"),
    @XmlEnumValue("C1219_RI_BLK_OUT_OF_BOUND_ERROR")
    C_1219_RI_BLK_OUT_OF_BOUND_ERROR("C1219_RI_BLK_OUT_OF_BOUND_ERROR"),
    @XmlEnumValue("C1219_RI_ITVL_OUT_OF_BOUND_ERROR")
    C_1219_RI_ITVL_OUT_OF_BOUND_ERROR("C1219_RI_ITVL_OUT_OF_BOUND_ERROR"),
    @XmlEnumValue("C1219_EL_OUT_OF_BOUND_ERROR")
    C_1219_EL_OUT_OF_BOUND_ERROR("C1219_EL_OUT_OF_BOUND_ERROR"),
    @XmlEnumValue("C1219_TBL61_READ_ERROR")
    C_1219_TBL_61_READ_ERROR("C1219_TBL61_READ_ERROR"),
    @XmlEnumValue("C1219_UNSUPPORTED_METER_PROGRAM")
    C_1219_UNSUPPORTED_METER_PROGRAM("C1219_UNSUPPORTED_METER_PROGRAM"),
    @XmlEnumValue("C1219_QEL_RTO_ERROR")
    C_1219_QEL_RTO_ERROR("C1219_QEL_RTO_ERROR"),
    @XmlEnumValue("C1219_RSP_TOO_LARGE")
    C_1219_RSP_TOO_LARGE("C1219_RSP_TOO_LARGE"),
    UNKNOWN_ERROR("UNKNOWN_ERROR"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    CommandStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CommandStatusEnumeration fromValue(String v) {
        for (CommandStatusEnumeration c: CommandStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
