package com.coned.ls.domain;

import java.util.Date;

public class ValidateStarDBData {

	private long meterEventLoadId;	
	private String borough;
	private String eventName;
	private String meterNumber;
	private String accountNumber;
	private String customerZipCode;
	private String criticalFilter;
	private String lsaFilter;
	
	
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getMeterNumber() {
		return meterNumber;
	}
	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerZipCode() {
		return customerZipCode;
	}
	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}
	public String getCriticalFilter() {
		return criticalFilter;
	}
	public void setCriticalFilter(String criticalFilter) {
		this.criticalFilter = criticalFilter;
	}
	public String getLsaFilter() {
		return lsaFilter;
	}
	public void setLsaFilter(String lsaFilter) {
		this.lsaFilter = lsaFilter;
	}
	
	public long getMeterEventLoadId() {
		return meterEventLoadId;
	}
	public void setMeterEventLoadId(long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	@Override
	public String toString() {
		return "ValidateStarDBData [meterEventLoadId=" + meterEventLoadId
				+ ", borough=" + borough + ", eventName=" + eventName
				+ ", meterNumber=" + meterNumber + ", accountNumber="
				+ accountNumber + ", customerZipCode=" + customerZipCode
				+ ", criticalFilter=" + criticalFilter + ", lsaFilter="
				+ lsaFilter + "]";
	}
}
