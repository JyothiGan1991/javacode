
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindDeviceConfigType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindDeviceConfigType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgDate" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="MfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicMfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicMfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicMfgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="NicSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicArchitecture" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicArchitectureType" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareReleasedTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindDeviceConfigType", propOrder = {
    "mfgName",
    "mfgDate",
    "mfgModel",
    "mfgCode",
    "softwareVersion",
    "softwareRev",
    "softwarePatch",
    "softwareConfig",
    "hardwareVersion",
    "hardwareRev",
    "hardwarePatch",
    "hardwareConfig",
    "nicMfgName",
    "nicMfgModel",
    "nicMfgCode",
    "nicTypeName",
    "nicTypeDesc",
    "macID",
    "nicSerialNumber",
    "nicArchitecture",
    "nicSoftwareVersion",
    "nicSoftwareRev",
    "nicSoftwarePatch",
    "nicSoftwareConfig",
    "nicSoftwareDesc",
    "nicHardwareVersion",
    "nicHardwareRev",
    "nicHardwarePatch",
    "nicHardwareConfig",
    "nicSoftwareTypeName",
    "nicSoftwareReleasedTime",
    "nicAttribute1",
    "nicAttribute2",
    "nicAttribute3",
    "nicAttribute4",
    "nicAttribute5"
})
public class FindDeviceConfigType {

    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "MfgDate")
    protected TimeRangeType mfgDate;
    @XmlElement(name = "MfgModel")
    protected String mfgModel;
    @XmlElement(name = "MfgCode")
    protected String mfgCode;
    @XmlElement(name = "SoftwareVersion")
    protected String softwareVersion;
    @XmlElement(name = "SoftwareRev")
    protected String softwareRev;
    @XmlElement(name = "SoftwarePatch")
    protected String softwarePatch;
    @XmlElement(name = "SoftwareConfig")
    protected String softwareConfig;
    @XmlElement(name = "HardwareVersion")
    protected String hardwareVersion;
    @XmlElement(name = "HardwareRev")
    protected String hardwareRev;
    @XmlElement(name = "HardwarePatch")
    protected String hardwarePatch;
    @XmlElement(name = "HardwareConfig")
    protected String hardwareConfig;
    @XmlElement(name = "NicMfgName")
    protected String nicMfgName;
    @XmlElement(name = "NicMfgModel")
    protected String nicMfgModel;
    @XmlElement(name = "NicMfgCode")
    protected String nicMfgCode;
    @XmlElement(name = "NicTypeName")
    protected String nicTypeName;
    @XmlElement(name = "NicTypeDesc")
    protected String nicTypeDesc;
    @XmlElement(name = "MacID")
    protected List<String> macID;
    @XmlElement(name = "NicSerialNumber")
    protected String nicSerialNumber;
    @XmlElement(name = "NicArchitecture")
    protected NicArchitectureType nicArchitecture;
    @XmlElement(name = "NicSoftwareVersion")
    protected String nicSoftwareVersion;
    @XmlElement(name = "NicSoftwareRev")
    protected String nicSoftwareRev;
    @XmlElement(name = "NicSoftwarePatch")
    protected String nicSoftwarePatch;
    @XmlElement(name = "NicSoftwareConfig")
    protected String nicSoftwareConfig;
    @XmlElement(name = "NicSoftwareDesc")
    protected String nicSoftwareDesc;
    @XmlElement(name = "NicHardwareVersion")
    protected String nicHardwareVersion;
    @XmlElement(name = "NicHardwareRev")
    protected String nicHardwareRev;
    @XmlElement(name = "NicHardwarePatch")
    protected String nicHardwarePatch;
    @XmlElement(name = "NicHardwareConfig")
    protected String nicHardwareConfig;
    @XmlElement(name = "NicSoftwareTypeName")
    protected String nicSoftwareTypeName;
    @XmlElement(name = "NicSoftwareReleasedTime")
    protected TimeRangeType nicSoftwareReleasedTime;
    @XmlElement(name = "NicAttribute1")
    protected String nicAttribute1;
    @XmlElement(name = "NicAttribute2")
    protected String nicAttribute2;
    @XmlElement(name = "NicAttribute3")
    protected String nicAttribute3;
    @XmlElement(name = "NicAttribute4")
    protected String nicAttribute4;
    @XmlElement(name = "NicAttribute5")
    protected String nicAttribute5;

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the mfgDate property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getMfgDate() {
        return mfgDate;
    }

    /**
     * Sets the value of the mfgDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setMfgDate(TimeRangeType value) {
        this.mfgDate = value;
    }

    /**
     * Gets the value of the mfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgModel() {
        return mfgModel;
    }

    /**
     * Sets the value of the mfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgModel(String value) {
        this.mfgModel = value;
    }

    /**
     * Gets the value of the mfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgCode() {
        return mfgCode;
    }

    /**
     * Sets the value of the mfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgCode(String value) {
        this.mfgCode = value;
    }

    /**
     * Gets the value of the softwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareVersion() {
        return softwareVersion;
    }

    /**
     * Sets the value of the softwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareVersion(String value) {
        this.softwareVersion = value;
    }

    /**
     * Gets the value of the softwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareRev() {
        return softwareRev;
    }

    /**
     * Sets the value of the softwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareRev(String value) {
        this.softwareRev = value;
    }

    /**
     * Gets the value of the softwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwarePatch() {
        return softwarePatch;
    }

    /**
     * Sets the value of the softwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwarePatch(String value) {
        this.softwarePatch = value;
    }

    /**
     * Gets the value of the softwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareConfig() {
        return softwareConfig;
    }

    /**
     * Sets the value of the softwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareConfig(String value) {
        this.softwareConfig = value;
    }

    /**
     * Gets the value of the hardwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareVersion() {
        return hardwareVersion;
    }

    /**
     * Sets the value of the hardwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareVersion(String value) {
        this.hardwareVersion = value;
    }

    /**
     * Gets the value of the hardwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareRev() {
        return hardwareRev;
    }

    /**
     * Sets the value of the hardwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareRev(String value) {
        this.hardwareRev = value;
    }

    /**
     * Gets the value of the hardwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwarePatch() {
        return hardwarePatch;
    }

    /**
     * Sets the value of the hardwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwarePatch(String value) {
        this.hardwarePatch = value;
    }

    /**
     * Gets the value of the hardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareConfig() {
        return hardwareConfig;
    }

    /**
     * Sets the value of the hardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareConfig(String value) {
        this.hardwareConfig = value;
    }

    /**
     * Gets the value of the nicMfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgName() {
        return nicMfgName;
    }

    /**
     * Sets the value of the nicMfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgName(String value) {
        this.nicMfgName = value;
    }

    /**
     * Gets the value of the nicMfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgModel() {
        return nicMfgModel;
    }

    /**
     * Sets the value of the nicMfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgModel(String value) {
        this.nicMfgModel = value;
    }

    /**
     * Gets the value of the nicMfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgCode() {
        return nicMfgCode;
    }

    /**
     * Sets the value of the nicMfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgCode(String value) {
        this.nicMfgCode = value;
    }

    /**
     * Gets the value of the nicTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicTypeName() {
        return nicTypeName;
    }

    /**
     * Sets the value of the nicTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicTypeName(String value) {
        this.nicTypeName = value;
    }

    /**
     * Gets the value of the nicTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicTypeDesc() {
        return nicTypeDesc;
    }

    /**
     * Sets the value of the nicTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicTypeDesc(String value) {
        this.nicTypeDesc = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the macID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMacID() {
        if (macID == null) {
            macID = new ArrayList<String>();
        }
        return this.macID;
    }

    /**
     * Gets the value of the nicSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSerialNumber() {
        return nicSerialNumber;
    }

    /**
     * Sets the value of the nicSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSerialNumber(String value) {
        this.nicSerialNumber = value;
    }

    /**
     * Gets the value of the nicArchitecture property.
     * 
     * @return
     *     possible object is
     *     {@link NicArchitectureType }
     *     
     */
    public NicArchitectureType getNicArchitecture() {
        return nicArchitecture;
    }

    /**
     * Sets the value of the nicArchitecture property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicArchitectureType }
     *     
     */
    public void setNicArchitecture(NicArchitectureType value) {
        this.nicArchitecture = value;
    }

    /**
     * Gets the value of the nicSoftwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareVersion() {
        return nicSoftwareVersion;
    }

    /**
     * Sets the value of the nicSoftwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareVersion(String value) {
        this.nicSoftwareVersion = value;
    }

    /**
     * Gets the value of the nicSoftwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareRev() {
        return nicSoftwareRev;
    }

    /**
     * Sets the value of the nicSoftwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareRev(String value) {
        this.nicSoftwareRev = value;
    }

    /**
     * Gets the value of the nicSoftwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwarePatch() {
        return nicSoftwarePatch;
    }

    /**
     * Sets the value of the nicSoftwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwarePatch(String value) {
        this.nicSoftwarePatch = value;
    }

    /**
     * Gets the value of the nicSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareConfig() {
        return nicSoftwareConfig;
    }

    /**
     * Sets the value of the nicSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareConfig(String value) {
        this.nicSoftwareConfig = value;
    }

    /**
     * Gets the value of the nicSoftwareDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareDesc() {
        return nicSoftwareDesc;
    }

    /**
     * Sets the value of the nicSoftwareDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareDesc(String value) {
        this.nicSoftwareDesc = value;
    }

    /**
     * Gets the value of the nicHardwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareVersion() {
        return nicHardwareVersion;
    }

    /**
     * Sets the value of the nicHardwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareVersion(String value) {
        this.nicHardwareVersion = value;
    }

    /**
     * Gets the value of the nicHardwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareRev() {
        return nicHardwareRev;
    }

    /**
     * Sets the value of the nicHardwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareRev(String value) {
        this.nicHardwareRev = value;
    }

    /**
     * Gets the value of the nicHardwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwarePatch() {
        return nicHardwarePatch;
    }

    /**
     * Sets the value of the nicHardwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwarePatch(String value) {
        this.nicHardwarePatch = value;
    }

    /**
     * Gets the value of the nicHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareConfig() {
        return nicHardwareConfig;
    }

    /**
     * Sets the value of the nicHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareConfig(String value) {
        this.nicHardwareConfig = value;
    }

    /**
     * Gets the value of the nicSoftwareTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareTypeName() {
        return nicSoftwareTypeName;
    }

    /**
     * Sets the value of the nicSoftwareTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareTypeName(String value) {
        this.nicSoftwareTypeName = value;
    }

    /**
     * Gets the value of the nicSoftwareReleasedTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getNicSoftwareReleasedTime() {
        return nicSoftwareReleasedTime;
    }

    /**
     * Sets the value of the nicSoftwareReleasedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setNicSoftwareReleasedTime(TimeRangeType value) {
        this.nicSoftwareReleasedTime = value;
    }

    /**
     * Gets the value of the nicAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute1() {
        return nicAttribute1;
    }

    /**
     * Sets the value of the nicAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute1(String value) {
        this.nicAttribute1 = value;
    }

    /**
     * Gets the value of the nicAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute2() {
        return nicAttribute2;
    }

    /**
     * Sets the value of the nicAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute2(String value) {
        this.nicAttribute2 = value;
    }

    /**
     * Gets the value of the nicAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute3() {
        return nicAttribute3;
    }

    /**
     * Sets the value of the nicAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute3(String value) {
        this.nicAttribute3 = value;
    }

    /**
     * Gets the value of the nicAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute4() {
        return nicAttribute4;
    }

    /**
     * Sets the value of the nicAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute4(String value) {
        this.nicAttribute4 = value;
    }

    /**
     * Gets the value of the nicAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicAttribute5() {
        return nicAttribute5;
    }

    /**
     * Sets the value of the nicAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicAttribute5(String value) {
        this.nicAttribute5 = value;
    }

}
