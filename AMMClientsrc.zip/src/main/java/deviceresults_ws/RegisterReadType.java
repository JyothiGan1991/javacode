
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegisterReadType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegisterReadType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DataTimeZone" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="Tier" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}TierType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="RegisterReadSource" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RegisterReadSourceType" minOccurs="0"/&gt;
 *         &lt;element name="RegisterReadStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}IntervalStatusType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="StatusFlag" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}StatusFlagTypeWithDesc" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="GatewaySerialNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="GatewayName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceMacID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ProxyDeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ProxyDeviceName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ReadTime" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="Season" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="GatewayCollectedTimestamp" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobId" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="JobName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CustomerID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegisterReadType", propOrder = {
    "dataTimeZone",
    "tier",
    "registerReadSource",
    "registerReadStatus",
    "statusFlag"
})
public class RegisterReadType {

    @XmlElement(name = "DataTimeZone")
    protected TimeZoneType dataTimeZone;
    @XmlElement(name = "Tier", required = true)
    protected List<TierType> tier;
    @XmlElement(name = "RegisterReadSource")
    protected RegisterReadSourceType registerReadSource;
    @XmlElement(name = "RegisterReadStatus")
    @XmlSchemaType(name = "string")
    protected List<IntervalStatusType> registerReadStatus;
    @XmlElement(name = "StatusFlag")
    protected List<StatusFlagTypeWithDesc> statusFlag;
    @XmlAttribute(name = "GatewaySerialNumber", required = true)
    protected String gatewaySerialNumber;
    @XmlAttribute(name = "GatewayName", required = true)
    protected String gatewayName;
    @XmlAttribute(name = "DeviceMacID", required = true)
    protected String deviceMacID;
    @XmlAttribute(name = "DeviceName", required = true)
    protected String deviceName;
    @XmlAttribute(name = "ProxyDeviceMacID")
    protected String proxyDeviceMacID;
    @XmlAttribute(name = "ProxyDeviceName")
    protected String proxyDeviceName;
    @XmlAttribute(name = "ReadTime", required = true)
    protected String readTime;
    @XmlAttribute(name = "Season", required = true)
    protected int season;
    @XmlAttribute(name = "GatewayCollectedTimestamp", required = true)
    protected String gatewayCollectedTimestamp;
    @XmlAttribute(name = "JobId", required = true)
    protected long jobId;
    @XmlAttribute(name = "JobName", required = true)
    protected String jobName;
    @XmlAttribute(name = "CustomerID")
    protected String customerID;

    /**
     * Gets the value of the dataTimeZone property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getDataTimeZone() {
        return dataTimeZone;
    }

    /**
     * Sets the value of the dataTimeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setDataTimeZone(TimeZoneType value) {
        this.dataTimeZone = value;
    }

    /**
     * Gets the value of the tier property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tier property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTier().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TierType }
     * 
     * 
     */
    public List<TierType> getTier() {
        if (tier == null) {
            tier = new ArrayList<TierType>();
        }
        return this.tier;
    }

    /**
     * Gets the value of the registerReadSource property.
     * 
     * @return
     *     possible object is
     *     {@link RegisterReadSourceType }
     *     
     */
    public RegisterReadSourceType getRegisterReadSource() {
        return registerReadSource;
    }

    /**
     * Sets the value of the registerReadSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegisterReadSourceType }
     *     
     */
    public void setRegisterReadSource(RegisterReadSourceType value) {
        this.registerReadSource = value;
    }

    /**
     * Gets the value of the registerReadStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registerReadStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegisterReadStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IntervalStatusType }
     * 
     * 
     */
    public List<IntervalStatusType> getRegisterReadStatus() {
        if (registerReadStatus == null) {
            registerReadStatus = new ArrayList<IntervalStatusType>();
        }
        return this.registerReadStatus;
    }

    /**
     * Gets the value of the statusFlag property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statusFlag property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatusFlag().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatusFlagTypeWithDesc }
     * 
     * 
     */
    public List<StatusFlagTypeWithDesc> getStatusFlag() {
        if (statusFlag == null) {
            statusFlag = new ArrayList<StatusFlagTypeWithDesc>();
        }
        return this.statusFlag;
    }

    /**
     * Gets the value of the gatewaySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewaySerialNumber() {
        return gatewaySerialNumber;
    }

    /**
     * Sets the value of the gatewaySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewaySerialNumber(String value) {
        this.gatewaySerialNumber = value;
    }

    /**
     * Gets the value of the gatewayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayName() {
        return gatewayName;
    }

    /**
     * Sets the value of the gatewayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayName(String value) {
        this.gatewayName = value;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMacID() {
        return deviceMacID;
    }

    /**
     * Sets the value of the deviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMacID(String value) {
        this.deviceMacID = value;
    }

    /**
     * Gets the value of the deviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Sets the value of the deviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Gets the value of the proxyDeviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProxyDeviceMacID() {
        return proxyDeviceMacID;
    }

    /**
     * Sets the value of the proxyDeviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxyDeviceMacID(String value) {
        this.proxyDeviceMacID = value;
    }

    /**
     * Gets the value of the proxyDeviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProxyDeviceName() {
        return proxyDeviceName;
    }

    /**
     * Sets the value of the proxyDeviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxyDeviceName(String value) {
        this.proxyDeviceName = value;
    }

    /**
     * Gets the value of the readTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReadTime() {
        return readTime;
    }

    /**
     * Sets the value of the readTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReadTime(String value) {
        this.readTime = value;
    }

    /**
     * Gets the value of the season property.
     * 
     */
    public int getSeason() {
        return season;
    }

    /**
     * Sets the value of the season property.
     * 
     */
    public void setSeason(int value) {
        this.season = value;
    }

    /**
     * Gets the value of the gatewayCollectedTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayCollectedTimestamp() {
        return gatewayCollectedTimestamp;
    }

    /**
     * Sets the value of the gatewayCollectedTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayCollectedTimestamp(String value) {
        this.gatewayCollectedTimestamp = value;
    }

    /**
     * Gets the value of the jobId property.
     * 
     */
    public long getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     */
    public void setJobId(long value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the jobName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the value of the jobName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerID(String value) {
        this.customerID = value;
    }

}
