package com.coned.model;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "ls_finalize_event_list_details", schema="AMI_LOAD_SHEDDING")
public class FinalizeEventListDetails {

    @Id
//    @JsonIgnore
    @Column(name = "finalized_event_id")
    private Long id;

    @Column(name = "event_name")
    private String eventName;

    @JsonIgnore
    @Column(name = "boro_muni")
    private String borough;
    
    @Column(name = "finalize_time")
    private LocalDateTime finalizationDateTime;
 
    @Column(name = "count_of_meters")
    private Long numberOfFinalizedMeters;
    
	/*
	 * @JsonManagedReference
	 * 
	 * @OneToMany(mappedBy = "event_name", cascade = { CascadeType.ALL }) private
	 * List < FinalizedEventList > finalizeEventList;
	 */
    
    public Long getNumberOfFinalizedMeters() {
		return numberOfFinalizedMeters;
	}

	public void setNumberOfFinalizedMeters(Long numberOfFinalizedMeters) {
		this.numberOfFinalizedMeters = numberOfFinalizedMeters;
	}

	public FinalizeEventListDetails() {

    }

    public FinalizeEventListDetails(String username, String token, LocalDateTime logintime) {
        this.eventName = username;
        this.borough = token;
        this.finalizationDateTime = logintime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
   
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventname) {
        this.eventName = eventname;
    }

    public String getBorough() {
        return borough;
    }

    public void setBorough(String borough) {
        this.borough = borough;
    }
    
    public LocalDateTime getFinalizationDateTime() {
        return finalizationDateTime;
    }

    public void setFinalizationDateTime(LocalDateTime finalizetime) {
        this.finalizationDateTime = finalizetime;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", finalizationDateTime=" + finalizationDateTime + "]";
    }
}
