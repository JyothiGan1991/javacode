
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SortColumnName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SortColumnName"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MacID"/&gt;
 *     &lt;enumeration value="UtilDeviceID"/&gt;
 *     &lt;enumeration value="IPAddress"/&gt;
 *     &lt;enumeration value="UiqDeviceStateID"/&gt;
 *     &lt;enumeration value="UtlDeviceStateID"/&gt;
 *     &lt;enumeration value="Name"/&gt;
 *     &lt;enumeration value="SerialNumber"/&gt;
 *     &lt;enumeration value="DidType"/&gt;
 *     &lt;enumeration value="DidSubtype"/&gt;
 *     &lt;enumeration value="BillingCycleID"/&gt;
 *     &lt;enumeration value="UtilAccountID"/&gt;
 *     &lt;enumeration value="UtilPremiseID"/&gt;
 *     &lt;enumeration value="UtilServicePointID"/&gt;
 *     &lt;enumeration value="Address1"/&gt;
 *     &lt;enumeration value="Address2"/&gt;
 *     &lt;enumeration value="City"/&gt;
 *     &lt;enumeration value="State"/&gt;
 *     &lt;enumeration value="PostalCode"/&gt;
 *     &lt;enumeration value="CountryID"/&gt;
 *     &lt;enumeration value="GatewayPhNum"/&gt;
 *     &lt;enumeration value="WANIPAddress"/&gt;
 *     &lt;enumeration value="WANPhoneNum"/&gt;
 *     &lt;enumeration value="GatewayIPPool"/&gt;
 *     &lt;enumeration value="RFChannel"/&gt;
 *     &lt;enumeration value="DeviceCount"/&gt;
 *     &lt;enumeration value="RelayTypeName"/&gt;
 *     &lt;enumeration value="IMUTypeName"/&gt;
 *     &lt;enumeration value="BridgeTypeName"/&gt;
 *     &lt;enumeration value="MeterMfgModel"/&gt;
 *     &lt;enumeration value="GatewayMfgModel"/&gt;
 *     &lt;enumeration value="RelayMfgModel"/&gt;
 *     &lt;enumeration value="DownstreamDeviceCount"/&gt;
 *     &lt;enumeration value="WANTypeID"/&gt;
 *     &lt;enumeration value="LastOpStateChangeTime"/&gt;
 *     &lt;enumeration value="LastCommTimeSearch"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SortColumnName")
@XmlEnum
public enum SortColumnName {

    @XmlEnumValue("MacID")
    MAC_ID("MacID"),
    @XmlEnumValue("UtilDeviceID")
    UTIL_DEVICE_ID("UtilDeviceID"),
    @XmlEnumValue("IPAddress")
    IP_ADDRESS("IPAddress"),
    @XmlEnumValue("UiqDeviceStateID")
    UIQ_DEVICE_STATE_ID("UiqDeviceStateID"),
    @XmlEnumValue("UtlDeviceStateID")
    UTL_DEVICE_STATE_ID("UtlDeviceStateID"),
    @XmlEnumValue("Name")
    NAME("Name"),
    @XmlEnumValue("SerialNumber")
    SERIAL_NUMBER("SerialNumber"),
    @XmlEnumValue("DidType")
    DID_TYPE("DidType"),
    @XmlEnumValue("DidSubtype")
    DID_SUBTYPE("DidSubtype"),
    @XmlEnumValue("BillingCycleID")
    BILLING_CYCLE_ID("BillingCycleID"),
    @XmlEnumValue("UtilAccountID")
    UTIL_ACCOUNT_ID("UtilAccountID"),
    @XmlEnumValue("UtilPremiseID")
    UTIL_PREMISE_ID("UtilPremiseID"),
    @XmlEnumValue("UtilServicePointID")
    UTIL_SERVICE_POINT_ID("UtilServicePointID"),
    @XmlEnumValue("Address1")
    ADDRESS_1("Address1"),
    @XmlEnumValue("Address2")
    ADDRESS_2("Address2"),
    @XmlEnumValue("City")
    CITY("City"),
    @XmlEnumValue("State")
    STATE("State"),
    @XmlEnumValue("PostalCode")
    POSTAL_CODE("PostalCode"),
    @XmlEnumValue("CountryID")
    COUNTRY_ID("CountryID"),
    @XmlEnumValue("GatewayPhNum")
    GATEWAY_PH_NUM("GatewayPhNum"),
    @XmlEnumValue("WANIPAddress")
    WANIP_ADDRESS("WANIPAddress"),
    @XmlEnumValue("WANPhoneNum")
    WAN_PHONE_NUM("WANPhoneNum"),
    @XmlEnumValue("GatewayIPPool")
    GATEWAY_IP_POOL("GatewayIPPool"),
    @XmlEnumValue("RFChannel")
    RF_CHANNEL("RFChannel"),
    @XmlEnumValue("DeviceCount")
    DEVICE_COUNT("DeviceCount"),
    @XmlEnumValue("RelayTypeName")
    RELAY_TYPE_NAME("RelayTypeName"),
    @XmlEnumValue("IMUTypeName")
    IMU_TYPE_NAME("IMUTypeName"),
    @XmlEnumValue("BridgeTypeName")
    BRIDGE_TYPE_NAME("BridgeTypeName"),
    @XmlEnumValue("MeterMfgModel")
    METER_MFG_MODEL("MeterMfgModel"),
    @XmlEnumValue("GatewayMfgModel")
    GATEWAY_MFG_MODEL("GatewayMfgModel"),
    @XmlEnumValue("RelayMfgModel")
    RELAY_MFG_MODEL("RelayMfgModel"),
    @XmlEnumValue("DownstreamDeviceCount")
    DOWNSTREAM_DEVICE_COUNT("DownstreamDeviceCount"),
    @XmlEnumValue("WANTypeID")
    WAN_TYPE_ID("WANTypeID"),
    @XmlEnumValue("LastOpStateChangeTime")
    LAST_OP_STATE_CHANGE_TIME("LastOpStateChangeTime"),
    @XmlEnumValue("LastCommTimeSearch")
    LAST_COMM_TIME_SEARCH("LastCommTimeSearch");
    private final String value;

    SortColumnName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SortColumnName fromValue(String v) {
        for (SortColumnName c: SortColumnName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
