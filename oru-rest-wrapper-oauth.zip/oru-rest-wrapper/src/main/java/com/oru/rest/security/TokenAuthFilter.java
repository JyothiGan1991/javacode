package com.oru.rest.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oru.rest.dto.ErrorResponse;
import com.oru.rest.okta.OktaJwtValidator;
import com.oru.rest.okta.OktaProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Protects /api/** with Bearer authentication.
 * <ul>
 *   <li>mode=static — only api.auth.token (legacy / PROD default)</li>
 *   <li>mode=okta — only valid Okta JWT access tokens</li>
 *   <li>mode=both — either static token or valid Okta JWT</li>
 * </ul>
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TokenAuthFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(TokenAuthFilter.class);
    private static final String BEARER_PREFIX = "Bearer ";

    @Value("${api.auth.enabled:true}")
    private boolean authEnabled;

    /**
     * static | okta | both
     */
    @Value("${api.auth.mode:static}")
    private String authMode;

    @Value("${api.auth.token:}")
    private String configuredToken;

    private final OktaJwtValidator oktaJwtValidator;
    private final OktaProperties oktaProperties;
    private final ObjectMapper objectMapper;

    public TokenAuthFilter(OktaJwtValidator oktaJwtValidator,
                           OktaProperties oktaProperties,
                           ObjectMapper objectMapper) {
        this.oktaJwtValidator = oktaJwtValidator;
        this.oktaProperties = oktaProperties;
        this.objectMapper = objectMapper;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        if (path == null) {
            return true;
        }
        if (path.contains("/swagger-ui")
                || path.contains("/v3/api-docs")
                || path.contains("/swagger-resources")
                || path.endsWith("/swagger-ui.html")
                || path.contains("/webjars/")) {
            return true;
        }
        return !path.contains("/api/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        if (!authEnabled) {
            filterChain.doFilter(request, response);
            return;
        }

        String authHeader = request.getHeader("Authorization");
        if (!StringUtils.hasText(authHeader) || !authHeader.startsWith(BEARER_PREFIX)) {
            log.warn("Missing or invalid Authorization header for {}", request.getRequestURI());
            writeUnauthorized(response, request.getRequestURI(), "Authentication failed");
            return;
        }

        String token = authHeader.substring(BEARER_PREFIX.length()).trim();
        String mode = authMode == null ? "static" : authMode.trim().toLowerCase();

        boolean accepted = false;
        if ("static".equals(mode) || "both".equals(mode)) {
            if (StringUtils.hasText(configuredToken) && configuredToken.equals(token)) {
                accepted = true;
            }
        }
        if (!accepted && ("okta".equals(mode) || "both".equals(mode))) {
            if (oktaProperties.isEnabled() && OktaJwtValidator.looksLikeJwt(token)
                    && oktaJwtValidator.isValid(token)) {
                accepted = true;
            }
        }

        if (!accepted) {
            // Keep legacy error when static-only and token config missing
            if ("static".equals(mode) && !StringUtils.hasText(configuredToken)) {
                writeUnauthorized(response, request.getRequestURI(), "Authentication configuration error");
                return;
            }
            log.warn("Authentication failed for {} (mode={})", request.getRequestURI(), mode);
            writeUnauthorized(response, request.getRequestURI(), "Authentication failed");
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void writeUnauthorized(HttpServletResponse response, String path, String message)
            throws IOException {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getOutputStream(),
                new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Unauthorized", message, path));
    }
}
