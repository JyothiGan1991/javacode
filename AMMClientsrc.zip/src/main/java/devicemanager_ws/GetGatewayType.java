
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetGatewayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetGatewayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GatewayType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="WAN" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}WANTypeConfig" minOccurs="0"/&gt;
 *         &lt;element name="GWTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GatewayTypeConfig" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetGatewayType", propOrder = {
    "wan",
    "gwTypeConfig"
})
public class GetGatewayType
    extends GatewayType
{

    @XmlElement(name = "WAN")
    protected WANTypeConfig wan;
    @XmlElement(name = "GWTypeConfig")
    protected GatewayTypeConfig gwTypeConfig;

    /**
     * Gets the value of the wan property.
     * 
     * @return
     *     possible object is
     *     {@link WANTypeConfig }
     *     
     */
    public WANTypeConfig getWAN() {
        return wan;
    }

    /**
     * Sets the value of the wan property.
     * 
     * @param value
     *     allowed object is
     *     {@link WANTypeConfig }
     *     
     */
    public void setWAN(WANTypeConfig value) {
        this.wan = value;
    }

    /**
     * Gets the value of the gwTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link GatewayTypeConfig }
     *     
     */
    public GatewayTypeConfig getGWTypeConfig() {
        return gwTypeConfig;
    }

    /**
     * Sets the value of the gwTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayTypeConfig }
     *     
     */
    public void setGWTypeConfig(GatewayTypeConfig value) {
        this.gwTypeConfig = value;
    }

}
