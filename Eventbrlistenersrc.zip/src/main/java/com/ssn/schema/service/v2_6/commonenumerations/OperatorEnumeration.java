
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OperatorEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OperatorEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SQL_EQUAL_TO"/>
 *     &lt;enumeration value="SQL_NOT_EQUAL_TO"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "OperatorEnumeration")
@XmlEnum
public enum OperatorEnumeration {

    SQL_EQUAL_TO("SQL_EQUAL_TO"),
    SQL_NOT_EQUAL_TO("SQL_NOT_EQUAL_TO"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    OperatorEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static OperatorEnumeration fromValue(String v) {
        for (OperatorEnumeration c: OperatorEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
