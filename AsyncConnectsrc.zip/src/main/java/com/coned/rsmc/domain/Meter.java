package com.coned.rsmc.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Meter {
	private BigDecimal id;
	private BigDecimal requestId;
	private String meterNumber;
	private String macAddress;

	private String boro;
	private String eventName;
	private String subEventName;
	private Long jobId;
	private Timestamp requestTime;
	private Timestamp connectTime;

	public Meter(BigDecimal id, BigDecimal requestId, String eventName, String subEventName, String meterNumber,
			String boro, String macAddress) {
		this.id = id;
		this.requestId = requestId;
		this.eventName = eventName;
		this.subEventName = subEventName;
		this.meterNumber = meterNumber;
		this.boro = boro;
		this.macAddress = macAddress;
	}

	public Meter(BigDecimal id, BigDecimal requestId, String eventName, String subEventName, String meterNumber,
			String boro) {
		this.id = id;
		this.requestId = requestId;
		this.eventName = eventName;
		this.subEventName = subEventName;
		this.meterNumber = meterNumber;
		this.boro = boro;
	}
	
	public BigDecimal getRequestId() {
		return this.requestId;
	}

	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}

	public String getMeterNumber() {
		return this.meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public String getMacAddress() {
		return this.macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getBoro() {
		return this.boro;
	}

	public void setBoro(String boro) {
		this.boro = boro;
	}

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Long getJobId() {
		return this.jobId;
	}

	public void setJobId(long id) {
		this.jobId = id;
	}

	public Timestamp getRequestTime() {
		return this.requestTime;
	}

	public void setRequestTime(Timestamp requestTime) {
		this.requestTime = requestTime;
	}

	public String getSubEventName() {
		return this.subEventName;
	}

	public void setSubEventName(String subEventName) {
		this.subEventName = subEventName;
	}

	public Timestamp getConnectTime() {
		return connectTime;
	}

	public void setConnectTime(Timestamp connectTime) {
		this.connectTime = connectTime;
	}

	@Override
	public String toString() {
		return "Meter [id=" + id + ", requestId=" + requestId + ", meterNumber=" + meterNumber + ", macAddress="
				+ macAddress + ", boro=" + boro + ", eventName=" + eventName + ", subEventName=" + subEventName
				+ ", jobId=" + jobId + ", requestTime=" + requestTime + ", connectTime=" + connectTime + "]";
	}

}
