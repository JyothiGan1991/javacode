package com.coned.ls.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.coned.ls.repository.UserManagementRepository;

@Service("userManagementService")
public class UserManagementServiceImpl implements UserManagementService {
	@Autowired
	private UserManagementRepository userManagementRepository;

	@Override
	public ResponseEntity<Map<String, Object>> createUser(Map<String, Object> payload){
		return userManagementRepository.createUser(payload);
	} 
	@Override
	public ResponseEntity<Map<String, Object>> updateUser(String username, Map<String, Object> payload){
		return userManagementRepository.updateUser(username, payload);
	} 
	@Override
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy){
		return userManagementRepository.deleteUser(username, updatedBy);
	}
	@Override
	public ResponseEntity<List<Map<String, Object>>> getUsers(){
		return ResponseEntity.ok().body(userManagementRepository.getUsers());
	} 
}
