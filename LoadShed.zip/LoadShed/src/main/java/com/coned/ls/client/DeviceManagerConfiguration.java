/*
 * package com.coned.ls.client;
 * 
 * import org.apache.http.auth.UsernamePasswordCredentials; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.context.annotation.PropertySource; import
 * org.springframework.oxm.jaxb.Jaxb2Marshaller; import
 * org.springframework.ws.transport.http.HttpComponentsMessageSender;
 * 
 * @Configuration
 * 
 * @PropertySource({ "classpath:application.properties" }) public class
 * DeviceManagerConfiguration {
 * 
 * 
 * @Value("${client.devicemanager-uri}") private String dmUri;
 * 
 * 
 * @Value("${client.jobmanager-uri}") private String jbUri;
 * 
 * @Value("${client.user.name}") private String userName;
 * 
 * @Value("${client.user.password}") private String userPassword;
 * 
 * @Bean public Jaxb2Marshaller marshaller() { Jaxb2Marshaller marshaller = new
 * Jaxb2Marshaller(); // this package must match the package in the
 * <generatePackage> specified in // pom.xml //
 * marshaller.setContextPath("com.coned.LoadShedding.dm_ws"); //
 * marshaller.setContextPath("com.coned.LoadShedding.jm_ws");
 * marshaller.setPackagesToScan("jm_ws"); // marshaller.setMtomEnabled(true);
 * return marshaller; }
 * 
 * @Bean public JobManagerClient devManagerClient(Jaxb2Marshaller marshaller) {
 * JobManagerClient client = new JobManagerClient(); // TODO- HIMA - externalize
 * the URL client.setDefaultUri(jbUri); client.setMarshaller(marshaller);
 * client.setUnmarshaller(marshaller);
 * client.setMessageSender(httpComponentsMessageSender()); return client; }
 * 
 * 
 * @Bean public DeviceManagerClient devManagerClient(Jaxb2Marshaller marshaller)
 * { DeviceManagerClient client = new DeviceManagerClient(); // TODO- HIMA -
 * externalize the URL client.setDefaultUri(
 * "https://ammwsroute.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/DeviceManagerPort"
 * ); client.setMarshaller(marshaller); client.setUnmarshaller(marshaller);
 * client.setMessageSender(httpComponentsMessageSender()); return client; }
 * 
 * 
 * @Bean public HttpComponentsMessageSender httpComponentsMessageSender() {
 * HttpComponentsMessageSender httpComponentsMessageSender = new
 * HttpComponentsMessageSender(); // set the basic // // authorization // //
 * credentials
 * httpComponentsMessageSender.setCredentials(usernamePasswordCredentials());
 * return httpComponentsMessageSender; }
 * 
 * @Bean public UsernamePasswordCredentials usernamePasswordCredentials() { //
 * pass the user name and password to be used return new
 * UsernamePasswordCredentials(userName, userPassword); }
 * 
 * }
 */