# ORU REST Wrapper (POE + Nucon combined)

Single Spring Boot 2.7 / Java 8 **WAR** application that wraps both:

- **POE** SOAP Web Services (`POEWebServices.wsdl`)
- **Nucon** SOAP Web Services (`nuconws.wsdl` + XSD)

Two REST controllers, shared Bearer-token authentication, deployable to external Tomcat.

## Build

```bash
mvn clean package
```

Produces: `target/oru-rest-wrapper.war`

## Run locally

```bash
mvn spring-boot:run
# port 9090
```

## Authentication

All `/api/**` endpoints require:

```
Authorization: Bearer <token>
```

Configure in `application.yml`:

```yaml
api:
  auth:
    enabled: true
    token: change-me-oru-secret-token
```

Invalid/missing token → **HTTP 401** `"Authentication failed"`.

## API endpoints

### POE (`/api/v1/poe`)

| Method | Path | Body / Params |
|--------|------|---------------|
| POST/GET | `/is-gas-main` | `premise`, `radius` |
| POST/GET | `/verify-pole` | `x`, `y` |
| POST/GET | `/incident-count` | `startDate`, `startTime`, `endDate`, `endTime` |

### Nucon (`/api/v1/nucon`)

| Method | Path | Body / Params |
|--------|------|---------------|
| POST/GET | `/electric-info/by-account` | `account` |
| POST/GET | `/electric-info/by-premise` | `premise` |
| POST/GET | `/electric-info/by-xy` | `x`, `y` |
| POST | `/send-to-nrg` | `arg0`, `arg1`, `arg2` |
| POST | `/locate-in-nrg-viewer` | `arg0`, `arg1`, `arg2`, `arg3` |

## Example

```bash
TOKEN=change-me-oru-secret-token

curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:9090/api/v1/poe/is-gas-main?premise=123&radius=50"

curl -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"account":"ACC123"}' \
  http://localhost:9090/api/v1/nucon/electric-info/by-account
```

## SOAP endpoints (configurable)

```yaml
poe:
  soap:
    endpoint-url: http://localhost:8080/poeWebServices/services/POEWebServicesPort
nucon:
  soap:
    endpoint-url: http://localhost:8080/nuconWS/services/NuconWSPort
```

## Deploy to Tomcat

Copy `target/oru-rest-wrapper.war` to `$TOMCAT_HOME/webapps/`.

Context path: `/oru-rest-wrapper`
