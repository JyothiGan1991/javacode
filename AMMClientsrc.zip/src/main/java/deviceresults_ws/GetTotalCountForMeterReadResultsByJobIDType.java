
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetTotalCountForMeterReadResultsByJobIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetTotalCountForMeterReadResultsByJobIDType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterReadByJobSearchParametersType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetTotalCountForMeterReadResultsByJobIDType", propOrder = {
    "searchParameters"
})
public class GetTotalCountForMeterReadResultsByJobIDType {

    @XmlElement(name = "SearchParameters", required = true)
    protected MeterReadByJobSearchParametersType searchParameters;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link MeterReadByJobSearchParametersType }
     *     
     */
    public MeterReadByJobSearchParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterReadByJobSearchParametersType }
     *     
     */
    public void setSearchParameters(MeterReadByJobSearchParametersType value) {
        this.searchParameters = value;
    }

}
