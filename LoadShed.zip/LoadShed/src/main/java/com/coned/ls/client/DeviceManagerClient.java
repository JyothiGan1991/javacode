/*
 * package com.coned.ls.client;
 * 
 * import javax.xml.soap.SOAPException;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.ws.client.core.support.WebServiceGatewaySupport;
 * 
 * import com.ssn.schema.service.v2_2.devicemanager.DeviceSearchParametersType;
 * import com.ssn.schema.service.v2_2.devicemanager.FindBaseDeviceType; import
 * com.ssn.schema.service.v2_2.devicemanager.FindDeviceReqType;
 * 
 * public class DeviceManagerClient extends WebServiceGatewaySupport { private
 * static final Logger log = LoggerFactory.getLogger(DeviceManagerClient.class);
 * 
 * public Object retrieveMACID(String utilDeviceID) throws SOAPException {
 * FindDeviceReqType request = new FindDeviceReqType();
 * DeviceSearchParametersType dspt = new DeviceSearchParametersType();
 * FindBaseDeviceType fbdt = new FindBaseDeviceType();
 * fbdt.setUtilDeviceID(utilDeviceID); dspt.setCommonAttributes(fbdt);
 * request.setSearchParameters(dspt); log.info("Requesting MAC id for meter[" +
 * utilDeviceID + "]");
 * 
 * return getWebServiceTemplate().marshalSendAndReceive(
 * "https://mt.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/DeviceManagerPort",
 * request);
 * 
 * 
 * WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
 * MessageFactory msgFactory =
 * MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
 * SaajSoapMessageFactory newSoapMessageFactory = new
 * SaajSoapMessageFactory(msgFactory);
 * webServiceTemplate.setMessageFactory(newSoapMessageFactory);
 * 
 * return webServiceTemplate.marshalSendAndReceive(
 * "https://ammwsroute.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/DeviceManagerPort",
 * new dm_ws.ObjectFactory().createFindDevice(request), new SecurityHeader());
 * 
 * 
 * } }
 */