package com.coned.jpa.controller;

import java.math.BigDecimal;
import java.net.InetAddress;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.security.auth.Subject;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import com.coned.service.BaseService;
import com.coned.um.controller.CustCallbackHandler;
import com.coned.um.controller.CustLoginConfig;
import com.coned.um.controller.LoginRequest;
import com.coned.um.controller.LoginResponseMapper;
import com.coned.um.controller.LogoutResponseMapper;
import com.coned.util.AOCCWebUtil;


@RestController
//@EnableEncryptableProperties
//@RequestMapping("/auth")
@CrossOrigin
public class HomeController {

	//@Value("${aocc.app.name}")
	private String APP_NAME="AOCCApp";
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	BaseService baseSrv;
	
	@Autowired
	AOCCWebUtil webutil;
	
	@PostMapping(value = "/signout")
	@CrossOrigin
	public ResponseEntity<LogoutResponseMapper> logout(HttpServletRequest request) {
		logger.debug("-- START HomeController - signout() -- ");
		ResponseEntity<LogoutResponseMapper> response = null;
		LogoutResponseMapper detail = new LogoutResponseMapper();
		try {
			String header = request.getHeader("Authorization");
			String[] keys = header.split("-", 2);
			String apiKey = keys[0];
			String userName = keys[1];
			logger.debug(" apiKey? "+apiKey+" Username? "+userName);
			logger.debug("------> 1-SessionID From Request: " + request.getSession().getId());

			Principal p = new com.sun.security.auth.UserPrincipal(userName);
			Subject sub = new Subject();
			sub.getPrincipals().add(p);
			LoginContext lc = new LoginContext(APP_NAME, sub, null, new CustLoginConfig());
			lc.logout();
			request.getSession().invalidate();
			logger.debug("------> 2-SessionID From Request: " + request.getSession().getId());

			detail.setUserName(userName);
			String logoutTime = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
			logger.debug("logoutTime "+logoutTime);
			detail.setLogoutTime(logoutTime);
			logger.debug(" before save ");
			boolean isLoggedout = baseSrv.saveUserLogin(userName, apiKey, "logout", logoutTime);
			logger.debug(" after save ");
			if(isLoggedout)
				detail.setMessage("success");
			response = new ResponseEntity<LogoutResponseMapper>(detail, new HttpHeaders(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("** Exception: "+e);
			detail.setMessage("failed");
			response = new ResponseEntity<LogoutResponseMapper>(detail, new HttpHeaders(),
					HttpStatus.INTERNAL_SERVER_ERROR);// Status code: 500
		}
		logger.debug("-- END HomeController - logout() -- ");
		return response;
	}
	
	@PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@CrossOrigin
	public ResponseEntity<LoginResponseMapper> login(@RequestBody LoginRequest loginRequest, HttpServletRequest request) {
		logger.debug("----- ** Into login ** --------- ");
		String userName = loginRequest.getUserName();
		String password = loginRequest.getPassword();
		LoginContext lc;
 
		ResponseEntity<LoginResponseMapper> response = null;
		LoginResponseMapper lrs = new LoginResponseMapper();
		lrs.setBearerToken(null);
		lrs.setUserName(userName);

		try {
			HttpSession session = request.getSession(false);
			logger.debug("first" + session);
			System.setProperty("java.security.auth.login.config", "jass.config");

			Configuration config = new CustLoginConfig();

//			accessServerEnv();
			logger.debug("HostAddress? "+InetAddress.getLocalHost().getHostAddress()+" HostName: "+InetAddress.getLocalHost().getHostName());
			logger.debug("HostAddress? "+InetAddress.getLoopbackAddress().getHostAddress()+" HostName: "+InetAddress.getLoopbackAddress().getHostName());
			lc = new LoginContext(APP_NAME, null, new CustCallbackHandler(userName, password, "t3://localhost:7001?"),
					new CustLoginConfig());
			lc.login();
			Subject subject = lc.getSubject();
			
			logger.debug("Subject: " + subject);
			session = request.getSession();

			logger.debug("------> SessionID From Request: " + request.getSession().getId());
			logger.debug("------> jSessionI D From Spring security: "
					+ RequestContextHolder.currentRequestAttributes().getSessionId());
			String jSessionID = RequestContextHolder.currentRequestAttributes().getSessionId();
			String currentTimeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			String uniqueKey = jSessionID + currentTimeStamp;
			String apiKey = DigestUtils.sha256Hex(uniqueKey);
			logger.debug("------> APIKey " + apiKey);
			
			Set<Principal> principals = subject.getPrincipals(Principal.class);

			Iterator itr = principals.iterator();
			while (itr.hasNext()) {
				Principal p = (Principal) itr.next();
				logger.debug("name? " + p.getName());
			}
			
			logger.debug("isUserAuthorized? "+ baseSrv.getUserDetails(userName));
			List<Object[]> list = baseSrv.getUserDetails(userName);
			logger.debug("userdetails: "+list);
			boolean userActive = false;
			String userRole = "";
			for (Object[] obj : list) {
				int status = ((BigDecimal) obj[0]).intValue();
				if ( status == 1 )
					userActive = true;
			     userRole = (String) obj[1];
			}
			logger.debug("userActive: "+userActive+" userRole? "+userRole);
			if(userActive) {
				String loginTime = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
				baseSrv.saveUserLogin(userName, apiKey, "login", loginTime);
				lrs.setUserName(userName);
				
				lrs.setLoginTime(loginTime);
				lrs.setBearerToken(apiKey+"-"+userName);
				lrs.setMessage("success");
				lrs.setUserClaim(new String[] {userRole});
				response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.OK);
			} else {
				lrs.setMessage("unauthorized");
			    response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.OK);// Status code : 401(HttpStatus.UNAUTHORIZED)
			}

		} catch (LoginException e) {
			logger.debug(" ** LoginException: " + e);
			lrs.setMessage("failed");
			response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.OK);//HttpStatus.BAD_REQUEST
		} catch (Exception e) {
			logger.debug(" ** Exception: " + e);
			lrs.setMessage("servererror");
			response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(),
					HttpStatus.OK);// Status code: 500(HttpStatus.INTERNAL_SERVER_ERROR)
		}
		return response;
	}
}
/*
 * 	@GetMapping(value = "/home", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<String> getHelloWorld() {
		return new ResponseEntity<String>("Hello World", HttpStatus.OK);
	}
 */
/*public void updateUserlogin() {
	try {
		Map<String, Object> requestParam = new HashMap<String, Object>();
		requestParam.put("id", 11);
		requestParam.put("ldapUsername", "testuser1");
		requestParam.put("token", "CCCASDFL;KLJASDOFUIOUALJDSFLAJKSDFLK");
		requestParam.put("logintime", "2021-01-06T17:51:17Z");

		requestParam.put("status", "login");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject jsonObj = new JSONObject(requestParam);
		HttpEntity<String> entity = new HttpEntity<String>(jsonObj.toString(), headers);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Map> responseE = restTemplate.exchange("http://localhost:7001" + "/um/userlogin",
				HttpMethod.POST, entity, Map.class, Collections.EMPTY_MAP);
		logger.debug("responseE? " + responseE);

	} catch (Exception e) {
		logger.debug("Exception: " + e);
	}
}*/

/*public void accessServerEnv() {
try {
	logger.debug("----- Start accessServerEnv ------ ");
    InitialContext ctx = new InitialContext();
    String serverName = System.getProperty("weblogic.Name");
    MBeanServer server = (MBeanServer)ctx.lookup("java:comp/env/jmx/runtime");
    logger.debug("server? "+server.toString()+" domain? "+server.getDefaultDomain());
    ObjectName objName = new ObjectName("com.bea:Name=" + serverName + ",Type=Server");
    Integer port = (Integer)server.getAttribute(objName, "ListenPort");
    
    logger.debug("SERVER NAME: " + serverName + ", PORT: " + port);
    logger.debug("----- End accessServerEnv ------ ");
} catch (NamingException e) {
    e.printStackTrace();
} catch (MalformedObjectNameException e) {
    e.printStackTrace();
} catch (MBeanException e) {
    e.printStackTrace();
} catch (AttributeNotFoundException e) {
    e.printStackTrace();
} catch (InstanceNotFoundException e) {
    e.printStackTrace();
} catch (ReflectionException e) {
    e.printStackTrace();
}
}*/