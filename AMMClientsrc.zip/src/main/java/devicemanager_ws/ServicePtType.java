
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServicePtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServicePtType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilServicePtID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ServiceType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="AccountID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MeterPhase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterLocCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePhaseCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ServiceVoltLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LineFreq" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="CurrTransRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="VoltTransRatio" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpLongitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpLatitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpHeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="SpExtUrl" type="{http://www.w3.org/2001/XMLSchema}anyURI" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SpImage1" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="SpImage1Note" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpImage2" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="SpImage2Note" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpInsertTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpInsertBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpUpdateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SpUpdateBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TransformerID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TenantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServicePtType", propOrder = {
    "locationID",
    "servicePtID",
    "utilServicePtID",
    "serviceType",
    "accountID",
    "meterPhase",
    "meterLocCode",
    "servicePhaseCode",
    "serviceVoltLevelCode",
    "lineFreq",
    "currTransRatio",
    "voltTransRatio",
    "spLongitude",
    "spLatitude",
    "spHeight",
    "spExtUrl",
    "spImage1",
    "spImage1Note",
    "spImage2",
    "spImage2Note",
    "spInsertTime",
    "spInsertBy",
    "spUpdateTime",
    "spUpdateBy",
    "billingCycle",
    "transformerID",
    "servicePtAttribute1",
    "servicePtAttribute2",
    "servicePtAttribute3",
    "servicePtAttribute4",
    "servicePtAttribute5",
    "tenantId"
})
@XmlSeeAlso({
    GetServicePtType.class,
    EditServicePtType.class
})
public class ServicePtType {

    @XmlElement(name = "LocationID")
    protected Long locationID;
    @XmlElement(name = "ServicePtID")
    protected Long servicePtID;
    @XmlElement(name = "UtilServicePtID", required = true)
    protected String utilServicePtID;
    @XmlElement(name = "ServiceType", required = true)
    protected String serviceType;
    @XmlElement(name = "AccountID")
    protected Long accountID;
    @XmlElement(name = "MeterPhase")
    protected String meterPhase;
    @XmlElement(name = "MeterLocCode")
    protected String meterLocCode;
    @XmlElement(name = "ServicePhaseCode")
    protected Integer servicePhaseCode;
    @XmlElement(name = "ServiceVoltLevelCode")
    protected String serviceVoltLevelCode;
    @XmlElement(name = "LineFreq")
    protected Integer lineFreq;
    @XmlElement(name = "CurrTransRatio")
    protected Double currTransRatio;
    @XmlElement(name = "VoltTransRatio")
    protected Double voltTransRatio;
    @XmlElement(name = "SpLongitude")
    protected Double spLongitude;
    @XmlElement(name = "SpLatitude")
    protected Double spLatitude;
    @XmlElement(name = "SpHeight")
    protected Double spHeight;
    @XmlElement(name = "SpExtUrl")
    @XmlSchemaType(name = "anyURI")
    protected List<String> spExtUrl;
    @XmlElement(name = "SpImage1")
    protected byte[] spImage1;
    @XmlElement(name = "SpImage1Note")
    protected String spImage1Note;
    @XmlElement(name = "SpImage2")
    protected byte[] spImage2;
    @XmlElement(name = "SpImage2Note")
    protected String spImage2Note;
    @XmlElement(name = "SpInsertTime")
    protected String spInsertTime;
    @XmlElement(name = "SpInsertBy")
    protected String spInsertBy;
    @XmlElement(name = "SpUpdateTime")
    protected String spUpdateTime;
    @XmlElement(name = "SpUpdateBy")
    protected String spUpdateBy;
    @XmlElement(name = "BillingCycle")
    protected String billingCycle;
    @XmlElement(name = "TransformerID")
    protected Long transformerID;
    @XmlElement(name = "ServicePtAttribute1")
    protected String servicePtAttribute1;
    @XmlElement(name = "ServicePtAttribute2")
    protected String servicePtAttribute2;
    @XmlElement(name = "ServicePtAttribute3")
    protected String servicePtAttribute3;
    @XmlElement(name = "ServicePtAttribute4")
    protected String servicePtAttribute4;
    @XmlElement(name = "ServicePtAttribute5")
    protected String servicePtAttribute5;
    @XmlElement(name = "TenantId")
    protected String tenantId;

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the servicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServicePtID() {
        return servicePtID;
    }

    /**
     * Sets the value of the servicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServicePtID(Long value) {
        this.servicePtID = value;
    }

    /**
     * Gets the value of the utilServicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePtID() {
        return utilServicePtID;
    }

    /**
     * Sets the value of the utilServicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePtID(String value) {
        this.utilServicePtID = value;
    }

    /**
     * Gets the value of the serviceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * Sets the value of the serviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceType(String value) {
        this.serviceType = value;
    }

    /**
     * Gets the value of the accountID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAccountID() {
        return accountID;
    }

    /**
     * Sets the value of the accountID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAccountID(Long value) {
        this.accountID = value;
    }

    /**
     * Gets the value of the meterPhase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterPhase() {
        return meterPhase;
    }

    /**
     * Sets the value of the meterPhase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterPhase(String value) {
        this.meterPhase = value;
    }

    /**
     * Gets the value of the meterLocCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterLocCode() {
        return meterLocCode;
    }

    /**
     * Sets the value of the meterLocCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterLocCode(String value) {
        this.meterLocCode = value;
    }

    /**
     * Gets the value of the servicePhaseCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getServicePhaseCode() {
        return servicePhaseCode;
    }

    /**
     * Sets the value of the servicePhaseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setServicePhaseCode(Integer value) {
        this.servicePhaseCode = value;
    }

    /**
     * Gets the value of the serviceVoltLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceVoltLevelCode() {
        return serviceVoltLevelCode;
    }

    /**
     * Sets the value of the serviceVoltLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceVoltLevelCode(String value) {
        this.serviceVoltLevelCode = value;
    }

    /**
     * Gets the value of the lineFreq property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLineFreq() {
        return lineFreq;
    }

    /**
     * Sets the value of the lineFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLineFreq(Integer value) {
        this.lineFreq = value;
    }

    /**
     * Gets the value of the currTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCurrTransRatio() {
        return currTransRatio;
    }

    /**
     * Sets the value of the currTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCurrTransRatio(Double value) {
        this.currTransRatio = value;
    }

    /**
     * Gets the value of the voltTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getVoltTransRatio() {
        return voltTransRatio;
    }

    /**
     * Sets the value of the voltTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setVoltTransRatio(Double value) {
        this.voltTransRatio = value;
    }

    /**
     * Gets the value of the spLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpLongitude() {
        return spLongitude;
    }

    /**
     * Sets the value of the spLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpLongitude(Double value) {
        this.spLongitude = value;
    }

    /**
     * Gets the value of the spLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpLatitude() {
        return spLatitude;
    }

    /**
     * Sets the value of the spLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpLatitude(Double value) {
        this.spLatitude = value;
    }

    /**
     * Gets the value of the spHeight property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpHeight() {
        return spHeight;
    }

    /**
     * Sets the value of the spHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpHeight(Double value) {
        this.spHeight = value;
    }

    /**
     * Gets the value of the spExtUrl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the spExtUrl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpExtUrl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSpExtUrl() {
        if (spExtUrl == null) {
            spExtUrl = new ArrayList<String>();
        }
        return this.spExtUrl;
    }

    /**
     * Gets the value of the spImage1 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getSpImage1() {
        return spImage1;
    }

    /**
     * Sets the value of the spImage1 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setSpImage1(byte[] value) {
        this.spImage1 = value;
    }

    /**
     * Gets the value of the spImage1Note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpImage1Note() {
        return spImage1Note;
    }

    /**
     * Sets the value of the spImage1Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpImage1Note(String value) {
        this.spImage1Note = value;
    }

    /**
     * Gets the value of the spImage2 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getSpImage2() {
        return spImage2;
    }

    /**
     * Sets the value of the spImage2 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setSpImage2(byte[] value) {
        this.spImage2 = value;
    }

    /**
     * Gets the value of the spImage2Note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpImage2Note() {
        return spImage2Note;
    }

    /**
     * Sets the value of the spImage2Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpImage2Note(String value) {
        this.spImage2Note = value;
    }

    /**
     * Gets the value of the spInsertTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpInsertTime() {
        return spInsertTime;
    }

    /**
     * Sets the value of the spInsertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpInsertTime(String value) {
        this.spInsertTime = value;
    }

    /**
     * Gets the value of the spInsertBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpInsertBy() {
        return spInsertBy;
    }

    /**
     * Sets the value of the spInsertBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpInsertBy(String value) {
        this.spInsertBy = value;
    }

    /**
     * Gets the value of the spUpdateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpUpdateTime() {
        return spUpdateTime;
    }

    /**
     * Sets the value of the spUpdateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpUpdateTime(String value) {
        this.spUpdateTime = value;
    }

    /**
     * Gets the value of the spUpdateBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpUpdateBy() {
        return spUpdateBy;
    }

    /**
     * Sets the value of the spUpdateBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpUpdateBy(String value) {
        this.spUpdateBy = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycle(String value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the transformerID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTransformerID() {
        return transformerID;
    }

    /**
     * Sets the value of the transformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTransformerID(Long value) {
        this.transformerID = value;
    }

    /**
     * Gets the value of the servicePtAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute1() {
        return servicePtAttribute1;
    }

    /**
     * Sets the value of the servicePtAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute1(String value) {
        this.servicePtAttribute1 = value;
    }

    /**
     * Gets the value of the servicePtAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute2() {
        return servicePtAttribute2;
    }

    /**
     * Sets the value of the servicePtAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute2(String value) {
        this.servicePtAttribute2 = value;
    }

    /**
     * Gets the value of the servicePtAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute3() {
        return servicePtAttribute3;
    }

    /**
     * Sets the value of the servicePtAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute3(String value) {
        this.servicePtAttribute3 = value;
    }

    /**
     * Gets the value of the servicePtAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute4() {
        return servicePtAttribute4;
    }

    /**
     * Sets the value of the servicePtAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute4(String value) {
        this.servicePtAttribute4 = value;
    }

    /**
     * Gets the value of the servicePtAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePtAttribute5() {
        return servicePtAttribute5;
    }

    /**
     * Sets the value of the servicePtAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePtAttribute5(String value) {
        this.servicePtAttribute5 = value;
    }

    /**
     * Gets the value of the tenantId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * Sets the value of the tenantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenantId(String value) {
        this.tenantId = value;
    }

}
