
package com.coned.aoccws.dao;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import com.coned.aoccws.beans.AoccRequest;
import com.coned.aoccws.beans.AoccResponse;
import com.coned.aoccws.error.AMMException;

@Repository
@Configuration
@PropertySource("file:${external.config}/queries.properties")
public class AMMDao {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	private TransactionTemplate txTemplate;

	/**
	 * @return the txTemplate
	 */
	public TransactionTemplate getTxTemplate() {
		return txTemplate;
	}

	@Autowired
	private Environment env;

	public DataSource getDataSource() {
		return dataSource;
	}

	/*
	 * @Bean public DataSource dataSource() { JndiDataSourceLookup
	 * dataSourceLookup = new JndiDataSourceLookup(); dataSource =
	 * dataSourceLookup.getDataSource("lsdbds"); return dataSource; }
	 */

	@Autowired
	public void setDataSource(DataSource datasource) {
		this.dataSource = datasource;
		this.jdbcTemplate = new JdbcTemplate(datasource);
		this.txTemplate = new TransactionTemplate(new DataSourceTransactionManager(datasource));
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public int saveRequest(AoccRequest req, Boolean isConnect) {
		return jdbcTemplate.update(
				(isConnect) ? env.getProperty("SAVE_AOCC_CONN_REQ") : env.getProperty("SAVE_AOCC_DISC_REQ"),
				new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement stmt) throws SQLException {
						stmt.setString(1, req.getEventName());
						stmt.setString(2, req.getBoro());
						stmt.setInt(3, (isConnect) ? 2 : 1);
						stmt.setTimestamp(4, req.getEventTime());
						if (isConnect) {
							stmt.setString(5, req.getSubEventName());
						}
					}
				});
	}

	public int saveDisconnMeters(BigDecimal requestIdx, AoccRequest req) {
		return jdbcTemplate.update(env.getProperty("SAVE_DISCONNECT_METERS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventType());
				stmt.setString(3, req.getEventName());
				stmt.setString(4, req.getBoro());
			}
		});
	}

	public int saveConnectMeters(BigDecimal requestIdx, AoccRequest req) {
		return jdbcTemplate.update(env.getProperty("SAVE_CONNECT_METERS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventType());
				stmt.setString(3, req.getEventName());
				stmt.setString(4, req.getSubEventName());
				stmt.setString(5, req.getBoro());
			}
		});
	}

	public void saveError(AoccRequest req) {
		logger.info("Before saving the request to the failure table");
		try {
			int failRows = jdbcTemplate.update(env.getProperty("SAVE_TO_REMOTEJOB_FAIL"),
					new PreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement stmt) throws SQLException {
							stmt.setString(1, req.getEventName());
							stmt.setString(2, req.getBoro());
							stmt.setString(3, req.getSubEventName());
							stmt.setString(4, req.getEventType());
							stmt.setInt(5, req.getEventId());
						}
					});
			logger.info("Total no of rows inserted to LS_AOCC_EXECUTE_REMOTEJOB_FAIL [" + failRows + "]");
		} catch (Exception e) {
			logger.error("" + e);
		}
	}

	private BigDecimal getRequestIdx(AoccRequest req) {
		NamedParameterJdbcTemplate namedParamTemplate = new NamedParameterJdbcTemplate(dataSource);
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("eventname", req.getEventName());
		params.addValue("boro", req.getBoro());
		params.addValue("type", req.getEventType().equalsIgnoreCase("D") ? 1 : 2);
		logger.info("Fetch the request id for  " + params);
		return namedParamTemplate.queryForObject(env.getProperty("GET_REQUEST_ID"), params, BigDecimal.class);
	}

	@Transactional(rollbackFor = AMMException.class)
	public AoccResponse saveAoccRequest(AoccRequest req) throws AMMException {
		BigDecimal requestIdx = null;
		AoccResponse res = new AoccResponse();
		Boolean isConnect = Boolean.FALSE;

		if (req.getEventType().equalsIgnoreCase("C")) {
			isConnect = Boolean.TRUE;
		}

		// Insert the request to the master table
		int aocc_row_cnt = saveRequest(req, isConnect);
		logger.info("Total no of rows inserted to LSB_AOCC_REQUESTS[" + aocc_row_cnt + "]");

		// Fetch the generated request Id from LSB_AOCC_REQUESTS
		try {
			requestIdx = getRequestIdx(req);
			logger.info("The Request id for event name [" + req.getEventName() + "] is [" + requestIdx + "]");
		} catch (IncorrectResultSizeDataAccessException e) {
			logger.error("Found an active record for the Request [" + req + "]; " + e);
			throw new AMMException("Found an active record for the Request " + req);
		}
		// Insert the request to the meter table
		int aocc_meter_cnt = (isConnect) ? saveConnectMeters(requestIdx, req) : saveDisconnMeters(requestIdx, req);
		logger.info("Total no of rows inserted to LSB_AOCC_METERS[" + aocc_meter_cnt + "]");

		if (aocc_row_cnt == 1 && aocc_meter_cnt >= 1) {
			res.setSuccess(Boolean.TRUE);
			res.setMessage((req.getEventType().equalsIgnoreCase("D") ? "Disconnect" : "Connect")
					+ " request registered successfully.");
		} else {
			logger.error("Error saving the request as few of the event details are missing in the EXECUTE tables...");
			res.setSuccess(Boolean.FALSE);
			res.setMessage("Error saving the request [" + req
					+ "] as few of the event details are missing in the EXECUTE tables.");
			throw new AMMException("Error saving the request [" + req + "] ");
		}
		return res;
	}

	public void saveRequestToNewDisconnectProcess(AoccRequest req) {
		BigDecimal requestIdx = null;	

		// Fetch the request Id from SEQUENCE
		try {
			requestIdx = jdbcTemplate.queryForObject(env.getProperty("GET_DISCONNECT_REQUEST_ID"), BigDecimal.class);
			logger.info("The Request id for event name [" + req.getEventName() + "] is [" + requestIdx + "]");
			
			// Insert the request to the master table
			int aocc_row_cnt = saveDiscRequest(req, requestIdx);
			logger.info("Total no of rows inserted to LSB_DISCONNECT_REQUESTS[" + aocc_row_cnt + "]");
			
			// Insert the request to the meter table
			int aocc_meter_cnt = saveDiscMeters(req, requestIdx);
			logger.info("Total no of rows inserted to LSB_DISCONNECT_METERS[" + aocc_meter_cnt + "]");
		} catch (Exception e) {
			logger.error("Error saving the Request [" + req + "]; " + e);
		}
	}
	
	public void saveRequestToNewConnectProcess(AoccRequest req) {
		BigDecimal requestIdx = null;	

		// Fetch the request Id from SEQUENCE
		try {
			requestIdx = jdbcTemplate.queryForObject(env.getProperty("GET_CONNECT_REQUEST_ID"), BigDecimal.class);
			logger.info("The Request id for event name [" + req.getEventName() + "] is [" + requestIdx + "]");
			
			// Insert the request to the master table
			int aocc_row_cnt = saveConnRequest(req, requestIdx);
			logger.info("Total no of rows inserted to LSB_CONNECT_REQUESTS[" + aocc_row_cnt + "]");
			
			// Insert the request to the meter table
			int aocc_meter_cnt = saveConnMeters(req, requestIdx);
			logger.info("Total no of rows inserted to LSB_CONNECT_METERS[" + aocc_meter_cnt + "]");
		} catch (Exception e) {
			logger.error("Error saving the Request [" + req + "]; " + e);
		}
	}


	private int saveDiscMeters(AoccRequest req, BigDecimal requestIdx) {
		return jdbcTemplate.update(env.getProperty("SAVE_DISCONNECT_METERS_TO_NEWPROCESS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventType());
				stmt.setString(3, req.getEventName());
				stmt.setString(4, req.getBoro());
			}
		});
	}

	public int saveDiscRequest(AoccRequest req, BigDecimal requestIdx) {
		return jdbcTemplate.update(env.getProperty("SAVE_DISCONNECT_REQUEST"), new PreparedStatementSetter() { 
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventName());
				stmt.setString(3, req.getBoro());
				stmt.setTimestamp(4, req.getEventTime());
			}
		});
	}
	
	public int saveConnRequest(AoccRequest req, BigDecimal requestIdx) {
		return jdbcTemplate.update(env.getProperty("SAVE_CONNECT_REQUEST"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventName());
				stmt.setString(3, req.getSubEventName());
				stmt.setString(4, req.getBoro());
				stmt.setTimestamp(5, req.getEventTime());
			}
		});
	}
	
	private int saveConnMeters(AoccRequest req, BigDecimal requestIdx) {
		return jdbcTemplate.update(env.getProperty("SAVE_CONNECT_METERS_TO_NEWPROCESS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, requestIdx);
				stmt.setString(2, req.getEventType());
				stmt.setString(3, req.getEventName());
				stmt.setString(4, req.getSubEventName());
				stmt.setString(5, req.getBoro());
			}
		});
	}
}
