/*package com.coned.ls.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadAction;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.JdbcMetersEventValidateRepository;
import com.coned.ls.repository.MeterEventValidateRepository;
import com.coned.ls.repository.MetersEventFinalizeRepository;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class MeterEventValidateServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private MeterEventValidateService meterEventValidateService = new MeterEventValidateServiceImpl();
	
	@Mock
	private MeterEventValidateRepository meterEventValidateRepository;
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	private MeterEventLoad  meterEventLoad;
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		meterEventLoad = meterEventLoadC;
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
	}
	@Test
	public void getValidateMeterTest() throws MeterValidateException, VcapRecordNotFoundException{
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper validateMeter = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString);
		
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
	}
	
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeterTest_Exception() throws MeterValidateException, VcapRecordNotFoundException{
		DateUtils.setDate(new Date());
		String fromDateAsString = DateUtils.get3DaysOldDateAsString();
		String toDateAsString = DateUtils.getCurrentDateAsString();
		meterValidateResponseMapper.getMeterEventLoads().clear();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString)).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper validateMeter = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,fromDateAsString, toDateAsString);
		
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getBorough(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBorough());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getEventName(),meterValidateResponseMapper.getMeterEventLoads().get(0).getEventName());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getDemand(),meterValidateResponseMapper.getMeterEventLoads().get(0).getDemand());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getFeeder(),meterValidateResponseMapper.getMeterEventLoads().get(0).getFeeder());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getBuildingNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getBuildingNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getServiceAddress(),meterValidateResponseMapper.getMeterEventLoads().get(0).getServiceAddress());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getCustomerZipCode(),meterValidateResponseMapper.getMeterEventLoads().get(0).getCustomerZipCode());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getMeterNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getMeterNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getAccountNumber(),meterValidateResponseMapper.getMeterEventLoads().get(0).getAccountNumber());
		Assert.assertEquals(validateMeter.getMeterEventLoads().get(0).getNetwork(),meterValidateResponseMapper.getMeterEventLoads().get(0).getNetwork());
	}
	
	@Test
	public void getOperatorLock_Mock() throws MeterValidateException, VcapRecordNotFoundException{	
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
			
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper operator1 = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString());
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), operator1.getMessage());
		meterValidateResponseMapper.setMessage("This event is locked.");
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper operator2 = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString());
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), operator2.getMessage());
	}
	
	@Test(expected = Exception.class)
	public void getOperatorLock_Mock_Exception() throws MeterValidateException, VcapRecordNotFoundException{	
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper operator1 = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString());
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), operator1.getMessage());
		Mockito.when(meterEventValidateRepository.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper operator2 = meterEventValidateService.getValidateMeter("C","SheepsheadBaySampleData7.27.20-1350", 1, 500,DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString());
		MeterValidateResponseMapper mockResult = Mockito.mock(MeterValidateResponseMapper.class);  
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), operator2.getMessage());
		Mockito.doThrow(new Exception()).when(mockResult).equals(mockResult.getMessage());
	}
}
*/