package com.oru.rest.dto;

import javax.validation.constraints.NotNull;

public class VerifyPoleRequest {
    @NotNull(message = "X coordinate is required")
    private Integer x;
    @NotNull(message = "Y coordinate is required")
    private Integer y;
    public VerifyPoleRequest() {}
    public VerifyPoleRequest(Integer x, Integer y) { this.x = x; this.y = y; }
    public Integer getX() { return x; }
    public void setX(Integer x) { this.x = x; }
    public Integer getY() { return y; }
    public void setY(Integer y) { this.y = y; }
}
