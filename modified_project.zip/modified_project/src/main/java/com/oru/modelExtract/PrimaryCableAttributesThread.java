/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author talatis
 */
public class PrimaryCableAttributesThread extends Thread {

    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    //HashMap<Integer, String> circuitBreakerHmap;
    
    private final static Logger logger = LoggerFactory.getLogger(PrimaryCableAttributesThread.class);

    PrimaryCableAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;
        this.assetToQuery = assetToQuery;
        //this.circuitBreakerHmap = circuitBreakerHmap;
    }

    public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {

            /*String connectionGeomQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,ST_AsText(geom.geom) from ed.geom geom, nrgcore.nrgfeaturetypedef def, ed.connection conn\n" +
             "where geom.featuretypeid = def.featuretypeid\n" +
             "and geom.fid = conn.fida\n" +
             "and geom.featuretypeid != 3500 and geom.featuretypeid != 3501\n" +
             "and geom.featuretypeid != 104 and geom.featuretypeid != 10063 \n" +
             "and geom.attributes like '%circuit:" + circuit + "%'";
             */

            /*
            
             Iterator<Map.Entry<Integer, String>> iterator = circuitBreakerHmap.entrySet().iterator();
             while (iterator.hasNext()) {
             Map.Entry<Integer, String> entry = iterator.next();
             System.out.printf("Key : %s and Value: %s %n", entry.getKey(),
             entry.getValue());

             circuit = entry.getValue();
             String connectionGeomQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue  from ed.geom geom, nrgcore.nrgfeaturetypedef def\n"
             + "where geom.featuretypeid = def.featuretypeid\n"
             + "and geom.featuretypeid != 3500 and geom.featuretypeid != 3501\n"
             + "and geom.featuretypeid != 104 and geom.featuretypeid != 10063 \n"
             + "and geom.featuretypeid != 105\n"
             + "and geom.featuretypeid != 10023\n"
             + "and geom.attributes like '%circuit:" + circuit + "%'";
             */
            /*
            String circuit = "";
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue  \n"
                    + " from ed.geom geom, nrgcore.nrgfeaturetypedef def\n"
                    + " where geom.featuretypeid = def.featuretypeid\n"
                    + " and geom.featuretypeid in (10076);";
*/
            //10025 - Primary meters , 133 - Capacitors , 10050 - Circuit Breaker , 109 fuse , 10162 Solar, 
            //10076 - trans supply switch, 6010 regulator
            
            // 109 is being extracted through UDGAttributes
            //6010 is being extracted through RegulatorAttributes
            // took ,108,107,103,10058,10052,10050 out of the list on included featuretypeids
            // 10058,10052,10054,10055,10064,10029 doesnt have any fids in the connection table
            //####logger.info(connectionGeomQuery);
            /*
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            int count = 1;
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //logger.info("attribute row count = " + count);
                    count++;
                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String attributes = rs.getString("attributes");
                    if (attributes != null) {
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            if (val[0].equalsIgnoreCase("circuit")) {
                                asset.setCircuit(val[1]);
                            }
                            asset.setNmsAttributes(val[0], val[1]);
                        }
                    }
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                }

            }
            rs.close();
            */

            /*
             logger.info("Processing the 105's");
             Iterator<Map.Entry<Integer, String>> lineIterator = circuitBreakerHmap.entrySet().iterator();
             while (lineIterator.hasNext()) {
             Map.Entry<Integer, String> entry = lineIterator.next();
             System.out.printf("Key : %s and Value: %s %n", entry.getKey(),
             entry.getValue());

             circuit = entry.getValue();
             */
            String connectionLineGeomQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,geom.rotation,ST_AsText(geom) geom,asset.circuit,asset.subseg,asset.mainline from ed.geom geom, nrgcore.nrgfeaturetypedef def,asset_ed.ed_primary asset \n"
                    + "where geom.featuretypeid = def.featuretypeid\n"
                    + "and geom.fid = asset.fid\n"
                    + "and geom.featuretypeid = 105\n"
                    + "and geometryType(geom) = 'LINESTRING' and \n" 
                    + "geom.fid in (" + assetToQuery + ")";
                        //+ "and geom.attributes like '%circuit:" + circuit + "%'";
            
            
/*            String connectionLineGeomQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,GeometryType(geom.geom) geomType,geom.rotation,ST_AsText(geom) geom,cable.circuit, cable.fid1, cable.fid2, cable.sotagged, cable.wafid1, cable.wafid2, cable.status, cable.primarytype, \n" +
"       cable.const, cable.encased, cable.wires, cable.conductor, cable.phase, cable.neutral, cable.div, cable.seg, cable.volt, \n" +
"       cable.rehab, cable.cadlength, cable.subseg, cable.currentdstat, cable.insultype, cable.insulsize, \n" +
"       cable.custowned, cable.condsize, cable.condmat, cable.installyear, cable.rehabyear, cable.rebuildyear, \n" +
"       cable.manufacturer, cable.conduits, cable.conduitsize, cable.neutralsize, cable.neutralmat, \n" +
"       cable.type \n" +
"from ed.geom geom, nrgcore.nrgfeaturetypedef def,asset_ed.ed_primary cable \n" +
"                    where geom.featuretypeid = def.featuretypeid\n" +
"                    and geom.fid = cable.fid\n" +
"                    and geom.featuretypeid = 105\n" +
"                    and geometryType(geom) = 'LINESTRING'";             
*/
            //####logger.info(connectionLineGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(connectionLineGeomQuery);
            rs = connectionGeomStmt.executeQuery(connectionLineGeomQuery);
            while (rs.next()) {
                int fid = rs.getInt("fid");
                //logger.info(fid);
                Asset asset = assetMaster.get(fid);
                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    //logger.info(attributes);
                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String circuit = rs.getString("circuit");   
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsGeomAttributes("circuit", circuit);
                    
                /*    String attributes = rs.getString("attributes");
                    if (attributes != null) {
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            if (val.length == 2) {
                                asset.setNmsAttributes(val[0], val[1]);
                                if (val[0].equalsIgnoreCase("circuit")) {
                                    asset.setCircuit(val[1]);
                                }
                            } else {
                                //logger.info(" not enough attribute values");
                                //logger.info(attributes);
                            }
                        }
                    }
                */    
                    String subSeg = rs.getString("subseg");
                    asset.setNmsAttributes("subSegment", subSeg);
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);                    

                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    //                            if(geomType.equalsIgnoreCase("LINESTRING"))
                    //                            {
                    String lineGeometry = rs.getString("geom");
                    lineGeometry = lineGeometry.replaceFirst("LINESTRING", "");
                    lineGeometry = lineGeometry.replace(",", "),(");
                    lineGeometry = lineGeometry.replace(" ", ",");
                    asset.setNmsGeomAttributes("geometry", lineGeometry);
                    //                            }                           

                }

            }
            rs.close();
            //}

            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }
}
