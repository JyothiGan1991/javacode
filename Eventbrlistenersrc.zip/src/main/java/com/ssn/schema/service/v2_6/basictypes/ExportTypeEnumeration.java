
package com.ssn.schema.service.v2_6.basictypes;

import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlEnumValue;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for ExportTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExportTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Informational"/>
 *     &lt;enumeration value="Authoritative"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ExportTypeEnumeration")
@XmlEnum
public enum ExportTypeEnumeration {

    @XmlEnumValue("Informational")
    INFORMATIONAL("Informational"),
    @XmlEnumValue("Authoritative")
    AUTHORITATIVE("Authoritative");
    private final String value;

    ExportTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ExportTypeEnumeration fromValue(String v) {
        for (ExportTypeEnumeration c: ExportTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
