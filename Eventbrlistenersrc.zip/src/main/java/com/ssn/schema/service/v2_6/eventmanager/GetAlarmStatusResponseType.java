
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.commonenumerations.AlarmStatusEnum;


/**
 * <p>Java class for GetAlarmStatusResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetAlarmStatusResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Status" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}AlarmStatusEnum"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetAlarmStatusResponseType", propOrder = {
    "status"
})
public class GetAlarmStatusResponseType {

    @XmlElement(name = "Status", required = true)
    @XmlSchemaType(name = "string")
    protected AlarmStatusEnum status;

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmStatusEnum }
     *     
     */
    public AlarmStatusEnum getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmStatusEnum }
     *     
     */
    public void setStatus(AlarmStatusEnum value) {
        this.status = value;
    }

}
