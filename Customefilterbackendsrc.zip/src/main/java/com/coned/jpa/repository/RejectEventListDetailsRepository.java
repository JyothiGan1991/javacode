package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coned.model.RejectEventListDetails;

@Repository
public interface RejectEventListDetailsRepository extends JpaRepository<RejectEventListDetails, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
}