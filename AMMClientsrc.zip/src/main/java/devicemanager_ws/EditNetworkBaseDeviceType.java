
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditNetworkBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditNetworkBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkBaseDeviceType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NetDeviceID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="NicTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="NicSoftwareTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="BatteryTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditNetworkBaseDeviceType", propOrder = {
    "guid",
    "netDeviceID",
    "nicTypeConfigID",
    "nicSoftwareTypeConfigID",
    "batteryTypeConfigID"
})
public class EditNetworkBaseDeviceType
    extends NetworkBaseDeviceType
{

    @XmlElement(name = "GUID", required = true)
    protected String guid;
    @XmlElement(name = "NetDeviceID")
    protected long netDeviceID;
    @XmlElement(name = "NicTypeConfigID")
    protected long nicTypeConfigID;
    @XmlElement(name = "NicSoftwareTypeConfigID")
    protected long nicSoftwareTypeConfigID;
    @XmlElement(name = "BatteryTypeConfigID")
    protected Long batteryTypeConfigID;

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGUID() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGUID(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the netDeviceID property.
     * 
     */
    public long getNetDeviceID() {
        return netDeviceID;
    }

    /**
     * Sets the value of the netDeviceID property.
     * 
     */
    public void setNetDeviceID(long value) {
        this.netDeviceID = value;
    }

    /**
     * Gets the value of the nicTypeConfigID property.
     * 
     */
    public long getNicTypeConfigID() {
        return nicTypeConfigID;
    }

    /**
     * Sets the value of the nicTypeConfigID property.
     * 
     */
    public void setNicTypeConfigID(long value) {
        this.nicTypeConfigID = value;
    }

    /**
     * Gets the value of the nicSoftwareTypeConfigID property.
     * 
     */
    public long getNicSoftwareTypeConfigID() {
        return nicSoftwareTypeConfigID;
    }

    /**
     * Sets the value of the nicSoftwareTypeConfigID property.
     * 
     */
    public void setNicSoftwareTypeConfigID(long value) {
        this.nicSoftwareTypeConfigID = value;
    }

    /**
     * Gets the value of the batteryTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBatteryTypeConfigID() {
        return batteryTypeConfigID;
    }

    /**
     * Sets the value of the batteryTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBatteryTypeConfigID(Long value) {
        this.batteryTypeConfigID = value;
    }

}
