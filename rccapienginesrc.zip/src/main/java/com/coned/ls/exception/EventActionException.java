package com.coned.ls.exception;

public class EventActionException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public EventActionException() {
		super();
	}

	public EventActionException(final String message, final int exceptionCode) {
		super(message);
		switch (exceptionCode) {
			case 4500:{
				break;
			}

			default:
				break;
		}
	}
}