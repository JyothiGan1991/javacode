package com.oru.rest.controller;

import com.oru.rest.dto.BooleanResponse;
import com.oru.rest.dto.IncidentCountRequest;
import com.oru.rest.dto.IntegerResponse;
import com.oru.rest.dto.IsGasMainRequest;
import com.oru.rest.dto.VerifyPoleRequest;
import com.oru.rest.service.poe.PoeSoapService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/poe")
public class PoeController {

    private final PoeSoapService poeSoapService;

    public PoeController(PoeSoapService poeSoapService) {
        this.poeSoapService = poeSoapService;
    }

    @PostMapping(value = "/is-gas-main", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> isGasMain(@Valid @RequestBody IsGasMainRequest request) {
        return ResponseEntity.ok(new BooleanResponse(poeSoapService.isGasMain(request)));
    }

    @GetMapping(value = "/is-gas-main", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> isGasMainGet(
            @RequestParam(required = false) String premise, @RequestParam int radius) {
        return ResponseEntity.ok(new BooleanResponse(poeSoapService.isGasMain(new IsGasMainRequest(premise, radius))));
    }

    @PostMapping(value = "/verify-pole", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> verifyPole(@Valid @RequestBody VerifyPoleRequest request) {
        return ResponseEntity.ok(new BooleanResponse(poeSoapService.verifyPole(request)));
    }

    @GetMapping(value = "/verify-pole", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BooleanResponse> verifyPoleGet(@RequestParam int x, @RequestParam int y) {
        return ResponseEntity.ok(new BooleanResponse(poeSoapService.verifyPole(new VerifyPoleRequest(x, y))));
    }

    @PostMapping(value = "/incident-count", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IntegerResponse> incidentCount(@RequestBody IncidentCountRequest request) {
        return ResponseEntity.ok(new IntegerResponse(poeSoapService.incidentCount(request)));
    }

    @GetMapping(value = "/incident-count", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IntegerResponse> incidentCountGet(
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String endTime) {
        return ResponseEntity.ok(new IntegerResponse(
                poeSoapService.incidentCount(new IncidentCountRequest(startDate, startTime, endDate, endTime))));
    }
}
