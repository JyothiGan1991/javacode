package com.coned.ls.repository;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.MetersEventLoad;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { MetersEventLoadRepository.class })
@AutoConfigureMockMvc
public class MetersEventLoadRepositoryTest {

	@Autowired
	private WebApplicationContext wac;

	@MockBean
	private MetersEventLoadRepository metersEventLoadRepository;

	private OpenEvent openEvent;

	private List<MetersEventLoad> metersEventLoad;

	@InjectMocks
	private JdbcMetersEventLoadRepository jdbcMetersEventLoadRepo;

	private MockMvc mockMvc;

	MeterEventFinalize meterEventFinalize;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	protected JdbcTemplate sqlServerJdbcTemplate;

	@Mock
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	protected JdbcTemplate oracleCommonJdbcTemplate;

	@Test
	@Before
	public void setup() {
		//ReflectionTestUtils.setField(jdbcMetersEventLoadRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		ReflectionTestUtils.setField(jdbcMetersEventLoadRepo, "sqlServerJdbcTemplate", sqlServerJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void findAll() {
		List<MetersEventLoad> lst = new ArrayList<MetersEventLoad> ();
		MetersEventLoad mel=new MetersEventLoad("test","test","test");
		lst.add(mel);		
	    Mockito.when(sqlServerJdbcTemplate.query("select * from meters_event_load", (metersEventLoad, rowNum) -> new MetersEventLoad(metersEventLoad.getString("meter_type"),metersEventLoad.getString("demand"),metersEventLoad.getString("boro_muni")))).thenReturn(lst);
		List<MetersEventLoad> response = jdbcMetersEventLoadRepo.findAll();
		Assert.assertNotNull(response);
	}
	
}
