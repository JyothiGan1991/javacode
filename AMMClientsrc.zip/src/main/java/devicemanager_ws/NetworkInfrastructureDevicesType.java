
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkInfrastructureDevicesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkInfrastructureDevicesType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Gateways" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureGatewaysType" minOccurs="0"/&gt;
 *         &lt;element name="Relays" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureRelaysType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInfrastructureDevicesType", propOrder = {
    "gateways",
    "relays"
})
public class NetworkInfrastructureDevicesType {

    @XmlElement(name = "Gateways")
    protected NetworkInfrastructureGatewaysType gateways;
    @XmlElement(name = "Relays")
    protected NetworkInfrastructureRelaysType relays;

    /**
     * Gets the value of the gateways property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfrastructureGatewaysType }
     *     
     */
    public NetworkInfrastructureGatewaysType getGateways() {
        return gateways;
    }

    /**
     * Sets the value of the gateways property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfrastructureGatewaysType }
     *     
     */
    public void setGateways(NetworkInfrastructureGatewaysType value) {
        this.gateways = value;
    }

    /**
     * Gets the value of the relays property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfrastructureRelaysType }
     *     
     */
    public NetworkInfrastructureRelaysType getRelays() {
        return relays;
    }

    /**
     * Sets the value of the relays property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfrastructureRelaysType }
     *     
     */
    public void setRelays(NetworkInfrastructureRelaysType value) {
        this.relays = value;
    }

}
