
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseNicTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseNicTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConfigName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ConfigDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicMfgCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NicMfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicMfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicHardwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseNicTypeConfig", propOrder = {
    "configName",
    "configDesc",
    "nicMfgCode",
    "nicMfgName",
    "nicMfgModel",
    "nicHardwareVersion",
    "nicHardwareRev",
    "nicHardwarePatch"
})
@XmlSeeAlso({
    NicTypeConfig.class
})
public class BaseNicTypeConfig {

    @XmlElement(name = "ConfigName", required = true)
    protected String configName;
    @XmlElement(name = "ConfigDesc")
    protected String configDesc;
    @XmlElement(name = "NicMfgCode", required = true)
    protected String nicMfgCode;
    @XmlElement(name = "NicMfgName")
    protected String nicMfgName;
    @XmlElement(name = "NicMfgModel")
    protected String nicMfgModel;
    @XmlElement(name = "NicHardwareVersion")
    protected String nicHardwareVersion;
    @XmlElement(name = "NicHardwareRev")
    protected String nicHardwareRev;
    @XmlElement(name = "NicHardwarePatch")
    protected String nicHardwarePatch;

    /**
     * Gets the value of the configName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigName() {
        return configName;
    }

    /**
     * Sets the value of the configName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigName(String value) {
        this.configName = value;
    }

    /**
     * Gets the value of the configDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigDesc() {
        return configDesc;
    }

    /**
     * Sets the value of the configDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigDesc(String value) {
        this.configDesc = value;
    }

    /**
     * Gets the value of the nicMfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgCode() {
        return nicMfgCode;
    }

    /**
     * Sets the value of the nicMfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgCode(String value) {
        this.nicMfgCode = value;
    }

    /**
     * Gets the value of the nicMfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgName() {
        return nicMfgName;
    }

    /**
     * Sets the value of the nicMfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgName(String value) {
        this.nicMfgName = value;
    }

    /**
     * Gets the value of the nicMfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicMfgModel() {
        return nicMfgModel;
    }

    /**
     * Sets the value of the nicMfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicMfgModel(String value) {
        this.nicMfgModel = value;
    }

    /**
     * Gets the value of the nicHardwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareVersion() {
        return nicHardwareVersion;
    }

    /**
     * Sets the value of the nicHardwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareVersion(String value) {
        this.nicHardwareVersion = value;
    }

    /**
     * Gets the value of the nicHardwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwareRev() {
        return nicHardwareRev;
    }

    /**
     * Sets the value of the nicHardwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwareRev(String value) {
        this.nicHardwareRev = value;
    }

    /**
     * Gets the value of the nicHardwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicHardwarePatch() {
        return nicHardwarePatch;
    }

    /**
     * Sets the value of the nicHardwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicHardwarePatch(String value) {
        this.nicHardwarePatch = value;
    }

}
