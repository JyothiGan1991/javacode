
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceIdentifier complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceIdentifier"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="SerialNumber" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}SerialNumberType"/&gt;
 *           &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="UtilID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="NicSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceIdentifier", propOrder = {
    "macID",
    "serialNumber",
    "name",
    "utilID",
    "utilDeviceID",
    "nicSerialNumber"
})
public class DeviceIdentifier {

    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "SerialNumber")
    protected SerialNumberType serialNumber;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "UtilID")
    protected String utilID;
    @XmlElement(name = "UtilDeviceID")
    protected String utilDeviceID;
    @XmlElement(name = "NicSerialNumber")
    protected String nicSerialNumber;

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link SerialNumberType }
     *     
     */
    public SerialNumberType getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link SerialNumberType }
     *     
     */
    public void setSerialNumber(SerialNumberType value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the utilID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilID() {
        return utilID;
    }

    /**
     * Sets the value of the utilID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilID(String value) {
        this.utilID = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the nicSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSerialNumber() {
        return nicSerialNumber;
    }

    /**
     * Sets the value of the nicSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSerialNumber(String value) {
        this.nicSerialNumber = value;
    }

}
