package com.coned.rc;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@EnableAutoConfiguration
@SpringBootApplication(scanBasePackages = { "com.coned" })
public class RetryConnectApplication {

	@Value("${connect_timeout}")
	private long connectTimeout;

	@Value("${read_timeout}")
	private long readTimeout;

	/**
	 * Builder used to configure and create this template to perform HTTP requests.
	 * Configured the connect and read timeouts.
	 * 
	 * @param builder the rest template builder
	 * @return the rest template
	 */
	@Bean
	public RestTemplate getRestTemplate(RestTemplateBuilder builder) {

		return builder.setConnectTimeout(Duration.ofMillis(connectTimeout))
				.setReadTimeout(Duration.ofMillis(readTimeout)).build();
	}

	public static void main(String[] args) {
		SpringApplication.run(RetryConnectApplication.class, args);
	}

}
