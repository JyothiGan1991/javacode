
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateGatewayTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateGatewayTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RootPassword" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocalSecret" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="RemoteSecret" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ChapUsername" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LocalChapPassword" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="RemoteChapPassword" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="IPV6Address" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="NetworkMask" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableNetworkMaskType" minOccurs="0"/&gt;
 *         &lt;element name="UiqIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqIPPort" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="UiqPhoneNum" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="UiqPhoneNumSec" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPPort" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPV6WANAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayPhoneNum" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="WANHardwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="WANSoftwareConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SocketAP" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBoolean" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="WANTypeConfigID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *           &lt;element name="WANTypeConfigName" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;choice&gt;
 *           &lt;element name="GWTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="GWTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateGatewayTypeReq", propOrder = {
    "rootPassword",
    "localSecret",
    "remoteSecret",
    "chapUsername",
    "localChapPassword",
    "remoteChapPassword",
    "ipv6Address",
    "networkMask",
    "uiqIPAddress",
    "uiqIPPort",
    "uiqPhoneNum",
    "uiqPhoneNumSec",
    "gatewayIPPort",
    "gatewayIPAddress",
    "gatewayIPV6WANAddress",
    "gatewayPhoneNum",
    "wanHardwareConfig",
    "wanSoftwareConfig",
    "socketAP",
    "wanTypeConfigID",
    "wanTypeConfigName",
    "gwTypeConfigID",
    "gwTypeConfigName"
})
public class UpdateGatewayTypeReq {

    @XmlElement(name = "RootPassword")
    protected NullableString rootPassword;
    @XmlElement(name = "LocalSecret")
    protected NullableString localSecret;
    @XmlElement(name = "RemoteSecret")
    protected NullableString remoteSecret;
    @XmlElement(name = "ChapUsername")
    protected NullableString chapUsername;
    @XmlElement(name = "LocalChapPassword")
    protected NullableString localChapPassword;
    @XmlElement(name = "RemoteChapPassword")
    protected NullableString remoteChapPassword;
    @XmlElement(name = "IPV6Address")
    protected NullableString ipv6Address;
    @XmlElement(name = "NetworkMask")
    protected NullableNetworkMaskType networkMask;
    @XmlElement(name = "UiqIPAddress")
    protected String uiqIPAddress;
    @XmlElement(name = "UiqIPPort")
    protected Integer uiqIPPort;
    @XmlElement(name = "UiqPhoneNum")
    protected NullableString uiqPhoneNum;
    @XmlElement(name = "UiqPhoneNumSec")
    protected NullableString uiqPhoneNumSec;
    @XmlElement(name = "GatewayIPPort")
    protected Integer gatewayIPPort;
    @XmlElement(name = "GatewayIPAddress")
    protected String gatewayIPAddress;
    @XmlElement(name = "GatewayIPV6WANAddress")
    protected String gatewayIPV6WANAddress;
    @XmlElement(name = "GatewayPhoneNum")
    protected NullableString gatewayPhoneNum;
    @XmlElement(name = "WANHardwareConfig")
    protected NullableString wanHardwareConfig;
    @XmlElement(name = "WANSoftwareConfig")
    protected NullableString wanSoftwareConfig;
    @XmlElement(name = "SocketAP")
    protected NullableBoolean socketAP;
    @XmlElement(name = "WANTypeConfigID")
    protected NullableLong wanTypeConfigID;
    @XmlElement(name = "WANTypeConfigName")
    protected NullableString wanTypeConfigName;
    @XmlElement(name = "GWTypeConfigID")
    protected Long gwTypeConfigID;
    @XmlElement(name = "GWTypeConfigName")
    protected String gwTypeConfigName;

    /**
     * Gets the value of the rootPassword property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRootPassword() {
        return rootPassword;
    }

    /**
     * Sets the value of the rootPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRootPassword(NullableString value) {
        this.rootPassword = value;
    }

    /**
     * Gets the value of the localSecret property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocalSecret() {
        return localSecret;
    }

    /**
     * Sets the value of the localSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocalSecret(NullableString value) {
        this.localSecret = value;
    }

    /**
     * Gets the value of the remoteSecret property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRemoteSecret() {
        return remoteSecret;
    }

    /**
     * Sets the value of the remoteSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRemoteSecret(NullableString value) {
        this.remoteSecret = value;
    }

    /**
     * Gets the value of the chapUsername property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getChapUsername() {
        return chapUsername;
    }

    /**
     * Sets the value of the chapUsername property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setChapUsername(NullableString value) {
        this.chapUsername = value;
    }

    /**
     * Gets the value of the localChapPassword property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getLocalChapPassword() {
        return localChapPassword;
    }

    /**
     * Sets the value of the localChapPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setLocalChapPassword(NullableString value) {
        this.localChapPassword = value;
    }

    /**
     * Gets the value of the remoteChapPassword property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRemoteChapPassword() {
        return remoteChapPassword;
    }

    /**
     * Sets the value of the remoteChapPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRemoteChapPassword(NullableString value) {
        this.remoteChapPassword = value;
    }

    /**
     * Gets the value of the ipv6Address property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getIPV6Address() {
        return ipv6Address;
    }

    /**
     * Sets the value of the ipv6Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setIPV6Address(NullableString value) {
        this.ipv6Address = value;
    }

    /**
     * Gets the value of the networkMask property.
     * 
     * @return
     *     possible object is
     *     {@link NullableNetworkMaskType }
     *     
     */
    public NullableNetworkMaskType getNetworkMask() {
        return networkMask;
    }

    /**
     * Sets the value of the networkMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableNetworkMaskType }
     *     
     */
    public void setNetworkMask(NullableNetworkMaskType value) {
        this.networkMask = value;
    }

    /**
     * Gets the value of the uiqIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqIPAddress() {
        return uiqIPAddress;
    }

    /**
     * Sets the value of the uiqIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqIPAddress(String value) {
        this.uiqIPAddress = value;
    }

    /**
     * Gets the value of the uiqIPPort property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUiqIPPort() {
        return uiqIPPort;
    }

    /**
     * Sets the value of the uiqIPPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUiqIPPort(Integer value) {
        this.uiqIPPort = value;
    }

    /**
     * Gets the value of the uiqPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getUiqPhoneNum() {
        return uiqPhoneNum;
    }

    /**
     * Sets the value of the uiqPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setUiqPhoneNum(NullableString value) {
        this.uiqPhoneNum = value;
    }

    /**
     * Gets the value of the uiqPhoneNumSec property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getUiqPhoneNumSec() {
        return uiqPhoneNumSec;
    }

    /**
     * Sets the value of the uiqPhoneNumSec property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setUiqPhoneNumSec(NullableString value) {
        this.uiqPhoneNumSec = value;
    }

    /**
     * Gets the value of the gatewayIPPort property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGatewayIPPort() {
        return gatewayIPPort;
    }

    /**
     * Sets the value of the gatewayIPPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGatewayIPPort(Integer value) {
        this.gatewayIPPort = value;
    }

    /**
     * Gets the value of the gatewayIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPAddress() {
        return gatewayIPAddress;
    }

    /**
     * Sets the value of the gatewayIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPAddress(String value) {
        this.gatewayIPAddress = value;
    }

    /**
     * Gets the value of the gatewayIPV6WANAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPV6WANAddress() {
        return gatewayIPV6WANAddress;
    }

    /**
     * Sets the value of the gatewayIPV6WANAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPV6WANAddress(String value) {
        this.gatewayIPV6WANAddress = value;
    }

    /**
     * Gets the value of the gatewayPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getGatewayPhoneNum() {
        return gatewayPhoneNum;
    }

    /**
     * Sets the value of the gatewayPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setGatewayPhoneNum(NullableString value) {
        this.gatewayPhoneNum = value;
    }

    /**
     * Gets the value of the wanHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getWANHardwareConfig() {
        return wanHardwareConfig;
    }

    /**
     * Sets the value of the wanHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setWANHardwareConfig(NullableString value) {
        this.wanHardwareConfig = value;
    }

    /**
     * Gets the value of the wanSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getWANSoftwareConfig() {
        return wanSoftwareConfig;
    }

    /**
     * Sets the value of the wanSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setWANSoftwareConfig(NullableString value) {
        this.wanSoftwareConfig = value;
    }

    /**
     * Gets the value of the socketAP property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBoolean }
     *     
     */
    public NullableBoolean getSocketAP() {
        return socketAP;
    }

    /**
     * Sets the value of the socketAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBoolean }
     *     
     */
    public void setSocketAP(NullableBoolean value) {
        this.socketAP = value;
    }

    /**
     * Gets the value of the wanTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getWANTypeConfigID() {
        return wanTypeConfigID;
    }

    /**
     * Sets the value of the wanTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setWANTypeConfigID(NullableLong value) {
        this.wanTypeConfigID = value;
    }

    /**
     * Gets the value of the wanTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getWANTypeConfigName() {
        return wanTypeConfigName;
    }

    /**
     * Sets the value of the wanTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setWANTypeConfigName(NullableString value) {
        this.wanTypeConfigName = value;
    }

    /**
     * Gets the value of the gwTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getGWTypeConfigID() {
        return gwTypeConfigID;
    }

    /**
     * Sets the value of the gwTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setGWTypeConfigID(Long value) {
        this.gwTypeConfigID = value;
    }

    /**
     * Gets the value of the gwTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGWTypeConfigName() {
        return gwTypeConfigName;
    }

    /**
     * Sets the value of the gwTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGWTypeConfigName(String value) {
        this.gwTypeConfigName = value;
    }

}
