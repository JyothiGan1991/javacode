package com.coned.ls.mapper;

import java.util.List;

import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadIdAndDemand;

/**
 * 
 * Class to return response for meter event requests.
 *
 */
public class MeterEventResponseMapper {

	private List<MeterEventLoad> meterEventLoads;
	private List<MeterEventLoadIdAndDemand> meterEventLoadIds;
	private int pageNumber;
	private int pageSize;
	private long totalRecord;
	private long totalMeterCount;
	private long totalExecutedMeterCount;
	private String recordOffsetRange;
	private String insertTime;
	private String borough;
	private String eventName;
	private String network;
	private int remainingRow; 
	private String message;
	private boolean isValidResponse;
	private int totalValidRecord;
	private int countOfMeters;
	private int totalConnectedMeters;
	private String totalKVA;
	
	private long totalSubEventMeters;
	private int kva;
	
	private long connectedTotalRecords;
	private long totalFinalizeRecordInEvent;
	
	private boolean isEventLocked;
	
	private boolean isEventFinalized;

	public List<MeterEventLoadIdAndDemand> getMeterEventLoadIds() {
		return meterEventLoadIds;
	}
	public void setMeterEventLoadIds(List<MeterEventLoadIdAndDemand> meterEventLoadIds) {
		this.meterEventLoadIds = meterEventLoadIds;
	}
	public int getTotalValidRecord() {
		return totalValidRecord;
	}
	public void setTotalValidRecord(int totalValidRecord) {
		this.totalValidRecord = totalValidRecord;
	}
	public String getTotalKVA() {
		return totalKVA;
	}
	public void setTotalKVA(String totalKVA) {
		this.totalKVA = totalKVA;
	}
	public int getCountOfMeters() {
		return countOfMeters;
	}
	public void setCountOfMeters(int countOfMeters) {
		this.countOfMeters = countOfMeters;
	}
	public int getTotalConnectedMeters() {
		return totalConnectedMeters;
	}
	public void setTotalConnectedMeters(int totalConnectedMeters) {
		this.totalConnectedMeters = totalConnectedMeters;
	}
	public int getRemainingRow() {
		return remainingRow;
	}
	public void setRemainingRow(int remainingRow) {
		this.remainingRow = remainingRow;
	}
	public List<MeterEventLoad> getMeterEventLoads() {
		return meterEventLoads;
	}
	public void setMeterEventLoads(List<MeterEventLoad> meterEventLoads) {
		this.meterEventLoads = meterEventLoads;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public long getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(long totalRecord) {
		this.totalRecord = totalRecord;
	}
	public long getTotalMeterCount() {
		return totalMeterCount;
	}
	public void setTotalMeterCount(long totalMeterCount) {
		this.totalMeterCount = totalMeterCount;
	}
	public long getTotalExecutedMeterCount() {
		return totalExecutedMeterCount;
	}
	public void setTotalExecutedMeterCount(long totalExecutedMeterCount) {
		this.totalExecutedMeterCount = totalExecutedMeterCount;
	}
	public String getRecordOffsetRange() {
		return recordOffsetRange;
	}
	public void setRecordOffsetRange(String recordOffsetRange) {
		this.recordOffsetRange = recordOffsetRange;
	}
	public String getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(String insertTime) {
		this.insertTime = insertTime;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValidResponse() {
		return isValidResponse;
	}
	public void setValidResponse(boolean isValidResponse) {
		this.isValidResponse = isValidResponse;
	}
	public long getTotalSubEventMeters() {
		return totalSubEventMeters;
	}
	public void setTotalSubEventMeters(long totalSubEventMeters) {
		this.totalSubEventMeters = totalSubEventMeters;
	}
	public int getKva() {
		return kva;
	}
	public void setKva(int kva) {
		this.kva = kva;
	}
	
	public long getConnectedTotalRecords() {
		return connectedTotalRecords;
	}
	public void setConnectedTotalRecords(long connectedTotalRecords) {
		this.connectedTotalRecords = connectedTotalRecords;
	}
	public long getTotalFinalizeRecordInEvent() {
		return totalFinalizeRecordInEvent;
	}
	public void setTotalFinalizeRecordInEvent(long totalFinalizeRecordInEvent) {
		this.totalFinalizeRecordInEvent = totalFinalizeRecordInEvent;
	}
	public boolean isEventLocked() {
		return isEventLocked;
	}
	public void setEventLocked(boolean isEventLocked) {
		this.isEventLocked = isEventLocked;
	}
	public MeterEventResponseMapper(String message) {
		super();
		this.message = message;
	}	
	
	public MeterEventResponseMapper() {
		super();
	}
	public boolean getIsEventFinalized() {
		return isEventFinalized;
	}
	public void setIsEventFinalized(boolean isEventFinalized) {
		this.isEventFinalized = isEventFinalized;
	}

}
