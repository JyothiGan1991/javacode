package com.oru.poe.rest.service;

import com.oru.poe.rest.dto.IncidentCountRequest;
import com.oru.poe.rest.dto.IsGasMainRequest;
import com.oru.poe.rest.dto.VerifyPoleRequest;
import com.oru.poe.rest.exception.SoapServiceException;
import com.oru.poe.soap.generated.POEServiceException_Exception;
import com.oru.poe.soap.generated.POEWebServicesSEI;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PoeSoapServiceTest {

    @Mock
    private POEWebServicesSEI soapClient;

    private PoeSoapService service;

    @BeforeEach
    void setUp() {
        service = new PoeSoapService(soapClient);
    }

    @Test
    void isGasMain_success() throws Exception {
        when(soapClient.isGasMain("123 Main", 50)).thenReturn(true);

        boolean result = service.isGasMain(new IsGasMainRequest("123 Main", 50));

        assertTrue(result);
        verify(soapClient).isGasMain("123 Main", 50);
    }

    @Test
    void isGasMain_nullPremise() throws Exception {
        when(soapClient.isGasMain(null, 10)).thenReturn(false);

        boolean result = service.isGasMain(new IsGasMainRequest(null, 10));

        assertFalse(result);
        verify(soapClient).isGasMain(null, 10);
    }

    @Test
    void isGasMain_soapFault() throws Exception {
        when(soapClient.isGasMain(any(), anyInt()))
                .thenThrow(new POEServiceException_Exception("fault", new com.oru.poe.soap.generated.POEServiceException()));

        SoapServiceException ex = assertThrows(SoapServiceException.class,
                () -> service.isGasMain(new IsGasMainRequest("p", 1)));

        assertTrue(ex.getMessage().contains("SOAP fault on isGasMain"));
    }

    @Test
    void isGasMain_runtimeException() throws Exception {
        when(soapClient.isGasMain(any(), anyInt()))
                .thenThrow(new RuntimeException("connection refused"));

        SoapServiceException ex = assertThrows(SoapServiceException.class,
                () -> service.isGasMain(new IsGasMainRequest("p", 1)));

        assertTrue(ex.getMessage().contains("Failed to call isGasMain"));
    }

    @Test
    void verifyPole_success() throws Exception {
        when(soapClient.verifyPole(100, 200)).thenReturn(true);

        boolean result = service.verifyPole(new VerifyPoleRequest(100, 200));

        assertTrue(result);
        verify(soapClient).verifyPole(100, 200);
    }

    @Test
    void verifyPole_soapFault() throws Exception {
        when(soapClient.verifyPole(anyInt(), anyInt()))
                .thenThrow(new POEServiceException_Exception("fault", new com.oru.poe.soap.generated.POEServiceException()));

        assertThrows(SoapServiceException.class,
                () -> service.verifyPole(new VerifyPoleRequest(1, 2)));
    }

    @Test
    void incidentCount_success() throws Exception {
        when(soapClient.incidentCount("2024-01-01", "00:00:00", "2024-12-31", "23:59:59"))
                .thenReturn(42);

        int result = service.incidentCount(
                new IncidentCountRequest("2024-01-01", "00:00:00", "2024-12-31", "23:59:59"));

        assertEquals(42, result);
        verify(soapClient).incidentCount("2024-01-01", "00:00:00", "2024-12-31", "23:59:59");
    }

    @Test
    void incidentCount_nullParams() throws Exception {
        when(soapClient.incidentCount(null, null, null, null)).thenReturn(0);

        int result = service.incidentCount(new IncidentCountRequest(null, null, null, null));

        assertEquals(0, result);
    }

    @Test
    void incidentCount_soapFault() throws Exception {
        when(soapClient.incidentCount(any(), any(), any(), any()))
                .thenThrow(new POEServiceException_Exception("fault", new com.oru.poe.soap.generated.POEServiceException()));

        assertThrows(SoapServiceException.class,
                () -> service.incidentCount(new IncidentCountRequest("a", "b", "c", "d")));
    }
}

