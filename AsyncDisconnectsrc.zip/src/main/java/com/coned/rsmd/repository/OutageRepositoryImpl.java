package com.coned.rsmd.repository;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.coned.rsmd.domain.Meter;

@Repository
@PropertySource({ "classpath:queries.properties" })
public class OutageRepositoryImpl implements OutageRepository {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private Environment env;

	private JdbcTemplate jdbcTemplate;

	private DataSource datasource;

	@Autowired
	private void setDataSource(DataSource datasource) {
		this.datasource = datasource;
		this.jdbcTemplate = new JdbcTemplate(datasource);
	}

	private NamedParameterJdbcTemplate getNamedParamTemplate() {
		return new NamedParameterJdbcTemplate(this.datasource);
	}

	public List<Meter> getMeters() {
		return jdbcTemplate.query(env.getProperty("GET_DISCONNECT_METERS"), new EventMacRowMapper());
	}

	@Transactional(rollbackFor = { Exception.class })
	public void saveJob(List<Meter> disconnectMetersList) {
		updateMeterStatus(disconnectMetersList);
		saveJobId(disconnectMetersList);
	}

	private void updateMeterStatus(final List<Meter> disconnectMetersList) {
		int[] batchupdatedRows = jdbcTemplate.batchUpdate(env.getProperty("UPDATE_METER_STATUS"),
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Meter m = disconnectMetersList.get(i);
						ps.setString(1, env.getProperty("complete_status"));
						ps.setBigDecimal(2, m.getId());
					}

					public int getBatchSize() {
						return disconnectMetersList.size();
					}
				});
		if (batchupdatedRows.length > 0) {
			logger.info("Successfully updated [" + batchupdatedRows.length
					+ "] records in AMI_LOAD_SHEDDING.LSB_DISCONNECT_METERS table.");
		}
	}

	private void saveJobId(final List<Meter> disconnectMetersList) {
		int[] batchInsertedRows = jdbcTemplate.batchUpdate(env.getProperty("SAVE_JOB_ID"),
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Meter m = disconnectMetersList.get(i);
						ps.setBigDecimal(1, m.getRequestId());
						ps.setString(2, m.getEventName());
						ps.setString(3, m.getBoro());
						ps.setString(4, m.getMeterNumber());
						ps.setString(5, m.getMacAddress());
						ps.setLong(6, m.getJobId());
						ps.setTimestamp(7, m.getDisconnectTime());
					}

					public int getBatchSize() {
						return disconnectMetersList.size();
					}
				});
		if (batchInsertedRows.length > 0) {
			logger.info("Successfully inserted [" + batchInsertedRows.length
					+ "] records to AMI_LOAD_SHEDDING.LSB_DISC_JOB table.");
		}
	}

	@Transactional(rollbackFor = { Exception.class })
	public void updateMeters(List<Meter> mList, List<BigDecimal> ids, String finalStatus) throws Exception {
		int updatedRows = updateFailedMeterStatus(ids);
		int[] batchupdatedRows = saveMeters(mList, finalStatus);

		if (updatedRows > 0 && batchupdatedRows.length > 0) {
			logger.info("Successfully marked [" + updatedRows
					+ "] records as Failed in AMI_LOAD_SHEDDING.LSB_DISCONNECT_METERS table.");

			logger.info("Successfully inserted [" + batchupdatedRows.length
					+ "] records to AMI_LOAD_SHEDDING.LSB_DISC_JOB table.");
		} else {

			logger.error(
					"Error updating the status of meters. Few rows are not updated/inserted to LSB_DISCONNECT_METERS["
							+ updatedRows + "] and LSB_DISC_JOB tables[" + batchupdatedRows.length + "]");

			throw new Exception("Error marking the meters to Fail status");
		}
	}

	private int updateFailedMeterStatus(List<BigDecimal> ids) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", ids);
		return getNamedParamTemplate().update(env.getProperty("UPDATE_MSTATUS_TO_FAIL"), (SqlParameterSource) params);
	}

	private int[] saveMeters(final List<Meter> mList, final String finalStatus) {
		return jdbcTemplate.batchUpdate(env.getProperty("SAVE_METER_STATUS"), new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setBigDecimal(1, ((Meter) mList.get(i)).getRequestId());
				ps.setString(2, ((Meter) mList.get(i)).getEventName());
				ps.setString(3, ((Meter) mList.get(i)).getBoro());
				ps.setString(4, ((Meter) mList.get(i)).getMeterNumber());
				ps.setString(5, ((Meter) mList.get(i)).getMacAddress());
				ps.setLong(6, finalStatus.equalsIgnoreCase("F") ? 0 : ((Meter) mList.get(i)).getJobId());
			}

			public int getBatchSize() {
				return mList.size();
			}
		});
	}

	public List<Meter> getMetersWithNullMacAddr() {
		return jdbcTemplate.query(env.getProperty("GET_METERS_WITH_NULL_MACID"), new EventRowMapper());
	}

}
