
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CachedResultsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CachedResultsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchKey" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="StartRow" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CachedResultsType", namespace = "urn:com:ssn:schema:service:v2.5:BasicTypes.xsd", propOrder = {
    "searchKey",
    "startRow"
})
public class CachedResultsType {

    @XmlElement(name = "SearchKey")
    protected long searchKey;
    @XmlElement(name = "StartRow")
    protected int startRow;

    /**
     * Gets the value of the searchKey property.
     * 
     */
    public long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     */
    public void setSearchKey(long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the startRow property.
     * 
     */
    public int getStartRow() {
        return startRow;
    }

    /**
     * Sets the value of the startRow property.
     * 
     */
    public void setStartRow(int value) {
        this.startRow = value;
    }

}
