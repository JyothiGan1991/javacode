package com.coned.util;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.coned.exception.UserAuthorizationException;
import com.coned.jpa.controller.FinalizeEventListDetailsController;

import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class AOCCWebUtil {
	private HttpServletRequest request;
	private static final Logger logger = LoggerFactory.getLogger(AOCCWebUtil.class);

	@Autowired
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public String getClientIp() {
		String remoteAddr = "";
		try {
			logger.debug("request? "+request);
			if (request != null) {
				remoteAddr = request.getHeader("X-FORWARDED-FOR");
				logger.debug("remoteAddr? "+remoteAddr);
				if (remoteAddr == null || "".equals(remoteAddr)) {
					remoteAddr = request.getRemoteAddr();
				}
				logger.debug("remoteAddr-2? "+remoteAddr);
			}		
		} catch (Exception e) {
			logger.error(" ** Exception: "+e);
		}
		return remoteAddr;
	}
	public String getUrl(HttpServletRequest request) {
	    HttpRequest httpRequest = new ServletServerHttpRequest(request);
	    UriComponents uriComponents = UriComponentsBuilder.fromHttpRequest(httpRequest).build();

	    String scheme = uriComponents.getScheme();             // http / https
	    String serverName = request.getServerName();     // hostname.com
	    int serverPort = request.getServerPort();        // 80
	    String contextPath = request.getContextPath();   // /app

	    StringBuilder url = new StringBuilder();
	    url.append(scheme).append("://");
	    url.append(serverName);

	    if (serverPort != 80 && serverPort != 443) {
	        url.append(":").append(serverPort);
	    }
//	    url.append(contextPath);
	    return url.toString();
	}
	public Map<String, String> readAuthHeader() throws UserAuthorizationException {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new UserAuthorizationException("unauthorized", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new UserAuthorizationException("unauthorized", HttpStatus.UNAUTHORIZED);
		}
		logger.debug("header? "+header);
		String[] keys = header.split("-", 2);

		/*
		 * String apiKey = keys[0]; String userName = keys[1];
		 */
//		logger.debug(" Inside the RESTAPIInterceptor: apikey: " + apiKey + " adid: " + userName);
		Map<String, String> authHeaders = new HashMap<String, String>();
		authHeaders.put("apiKey", keys[0]);
		authHeaders.put("userName", keys[1]);
		logger.debug("userName? "+keys[1]);
		return authHeaders;
	}
	public String getMethName() {
		int depth = 2;
		//String name = new Object(){}.getClass().getEnclosingMethod().getName();
		  final StackTraceElement[] ste = Thread.currentThread().getStackTrace();

		  //System. out.println(ste[ste.length-depth].getClassName()+"#"+ste[ste.length-depth].getMethodName());
		  // return ste[ste.length - depth].getMethodName();  //Wrong, fails for depth = 0
		  return ste[ste.length - 1 - depth].getMethodName(); //Thank you Tom Tresansky
//		return name;
	}
}