package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

/**
 * 
 * Service class for RCC Disconnect and RCC Connect.
 *
 */
@Component
public class OpenEventServiceTmp {

	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	RESTActionExecutorConnect restActionExecutorConnect = new  RESTActionExecutorConnect();
	
	/*
	 * This method read list of borough or event names for RCC Disconnect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getBoroughAndEventName(final String fields){
		return restActionExecutor.getBoroughAndEventNameTmp(fields);
	}
	
	/*
	 * This method read list of open events by borough for RCC Disconnect.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getOpenEvent(final String fields){
		return restActionExecutor.getOpenEventTmp(fields);
	}
}
