package com.coned.ls.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.AuthorizationService;
import com.coned.ls.service.ReportService;
import com.coned.ls.controller.ReportController;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = ReportController.class)
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class })
@WebMvcTest(ReportController.class)
public class ReportControllerTest {

	@Autowired
	private WebApplicationContext wac;

	private MockMvc mockMvc;
	
	@MockBean
	private ReportService reportService;

	@InjectMocks
	private ReportController reportController;

	@Test
	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		reportController = new ReportController();
		System.out.println("@Before annotation method is being called ....");

		ReflectionTestUtils.setField(reportController, "reportService", reportService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	@Test
	public void getEvents() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		String report_name = "crr";
		Mockito.when(reportService.getEvents(null)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getEvents(report_name);
		Assert.assertEquals("", "");
	}
		
	@Test
	public void getCER() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCERData(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = reportController.getCER(payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void getCDR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCDRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCDR(payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void getCRR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		Mockito.when(reportService.getCRRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCRR(payload);
		Assert.assertEquals("", "");
	}	
	@Test
	public void getCWR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCWRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportController.getCWR(payload);
		Assert.assertEquals("", "");
	}
	
	@Test
	public void getCMR() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(new HttpHeaders(),HttpStatus.OK);
        Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCMRData(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = reportController.getCMR(payload);
		Assert.assertEquals("", "");
	}
}
