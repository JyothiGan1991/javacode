
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ModeTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ModeTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="METER_MODE_TYPE_DEMAND"/&gt;
 *     &lt;enumeration value="METER_MODE_TYPE_DEMANDLP"/&gt;
 *     &lt;enumeration value="METER_MODE_TYPE_TOU"/&gt;
 *     &lt;enumeration value="METER_MODE_TYPE_UNKNOWN"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ModeTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd")
@XmlEnum
public enum ModeTypeEnum {

    METER_MODE_TYPE_DEMAND("METER_MODE_TYPE_DEMAND"),
    METER_MODE_TYPE_DEMANDLP("METER_MODE_TYPE_DEMANDLP"),
    METER_MODE_TYPE_TOU("METER_MODE_TYPE_TOU"),
    METER_MODE_TYPE_UNKNOWN("METER_MODE_TYPE_UNKNOWN"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ModeTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ModeTypeEnum fromValue(String v) {
        for (ModeTypeEnum c: ModeTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
