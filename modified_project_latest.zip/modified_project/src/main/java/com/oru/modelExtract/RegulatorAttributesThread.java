/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class RegulatorAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(RegulatorAttributesThread.class);

    RegulatorAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select distinct geom.fid,geom.featuretypeid,def.featuretypename,GeometryType(geom.geom) geomType,\n" +
                                "       geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue,r.circuit, r.sotagged, r.gridx, r.gridy, r.division, \n" +
                                "       r.street, r.city, r.voltage, r.voltageclass, r.seg, r.manufacturer, r.ratedvoltage, \n" +
                                "       r.kvarating, r.load, r.serialnumber, r.catalognumber, r.modelnumber, r.ctratio, \n" +
                                "       r.controltype, r.notes, r.maximumboost, r.maximumbuck, \n" +
                                "       r.presenttaponarrival, r.setvoltageforward, r.bandwidth, r.timedelay, \n" +
                                "       r.resistance, r.reactance, r.loadvoltage, r.sourcevoltage, r.regulatorconfiguration, \n" +
                                "       r.controloperatingmode, r.systemlinevoltage, r.ptratio, r.setvoltagereverse, \n" +
                                "       r.bandwidthreverse, r.timedelayreverse, r.resistancereverse, r.reactancereverse, \n" +
                                "       r.reversesensingmethod, r.current, r.reversethreshold, r.ckttieflag, \n" +
                                "       r.phase, r.regphase, r.contype, r.wafid1, r.wafid2, r.dstat,r.designdstat,  \n" +
                                "       r.subseg, r.scada,r.equipmenttype,r.controlserialnumber,r.maximumbuck,r.mainline  \n" +
                                " FROM ed.geom geom, nrgcore.nrgfeaturetypedef def,asset_ed.regulator r, ed.connection conn\n" +
                                "where geom.fid = r.fid \n" +
                                "and geom.fid = conn.fida\n" +
                                "and r.fid = conn.fida \n" +
                                "and geom.featuretypeid = def.featuretypeid\n" +
                                "and r.fid in (" + assetToQuery + ") \n" +                    
                                "order by geom.fid";

            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                                        
                    boolean sotagged = rs.getBoolean("sotagged");
                    asset.setNmsAttributes("sotagged", String.valueOf(sotagged));
                    
                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    String division = rs.getString("division");
                    asset.setNmsAttributes("division", division);
                    
                    String street = rs.getString("street");
                    asset.setNmsAttributes("street", street);

                    String city = rs.getString("city");
                    asset.setNmsAttributes("city", city);
                    
                    String voltage = rs.getString("voltage");
                    asset.setNmsAttributes("voltage", voltage);
                    
                    String voltageclass = rs.getString("voltageclass");
                    asset.setNmsAttributes("voltageclass", voltageclass);
                    
                    String seg = rs.getString("seg");
                    asset.setNmsAttributes("seg", seg);                    
                    
                    String manufacturer = rs.getString("manufacturer");
                    asset.setNmsAttributes("manufacturer", manufacturer);                    
                    
                    String ratedvoltage = rs.getString("ratedvoltage");
                    asset.setNmsAttributes("ratedvoltage", ratedvoltage);                    
                    
                    String kvarating = rs.getString("kvarating");
                    asset.setNmsAttributes("kvarating", kvarating);                    
                    
                    String load = rs.getString("load");
                    asset.setNmsAttributes("load", load);                    
                    
                    String serialnumber = rs.getString("serialnumber");
                    asset.setNmsAttributes("serialnumber", serialnumber);                    
                    
                    String catalognumber = rs.getString("catalognumber");
                    asset.setNmsAttributes("catalognumber", catalognumber);                    
                    
                    String modelnumber = rs.getString("modelnumber");
                    asset.setNmsAttributes("modelnumber", modelnumber);    
                    
                    String ctratio = rs.getString("ctratio");
                    asset.setNmsAttributes("ctratio", ctratio);    
                    
                    String controltype = rs.getString("controltype");
                    asset.setNmsAttributes("controltype", controltype);    
                    
                    String notes = rs.getString("notes");
                    asset.setNmsAttributes("notes", notes); 
                    
                    int maximumboost = rs.getInt("maximumboost");
                    asset.setNmsAttributes("maximumboost", Integer.toString(maximumboost));

                    int maximumbuck = rs.getInt("maximumbuck");
                    asset.setNmsAttributes("maximumbuck", Integer.toString(maximumbuck));     
                    
                    String presenttaponarrival = rs.getString("presenttaponarrival");
                    asset.setNmsAttributes("presenttaponarrival", presenttaponarrival);    
                    
                    int setvoltageforward = rs.getInt("setvoltageforward");
                    asset.setNmsAttributes("setvoltageforward", Integer.toString(setvoltageforward));
                    
                    int bandwidth = rs.getInt("bandwidth");
                    asset.setNmsAttributes("bandwidth", Integer.toString(bandwidth));
                    
                    int timedelay = rs.getInt("timedelay");
                    asset.setNmsAttributes("timedelay", Integer.toString(timedelay));
                    
                    int resistance = rs.getInt("resistance");
                    asset.setNmsAttributes("resistance", Integer.toString(resistance));
                    
                    int reactance = rs.getInt("reactance");
                    asset.setNmsAttributes("reactance", Integer.toString(reactance));
                    
                    int loadvoltage = rs.getInt("loadvoltage");
                    asset.setNmsAttributes("loadvoltage", Integer.toString(loadvoltage));
                    
                    int sourcevoltage = rs.getInt("sourcevoltage");
                    asset.setNmsAttributes("sourcevoltage", Integer.toString(sourcevoltage));
                   
                    int regulatorconfiguration = rs.getInt("regulatorconfiguration");
                    asset.setNmsAttributes("regulatorconfiguration", Integer.toString(regulatorconfiguration));

                    int controloperatingmode = rs.getInt("controloperatingmode");
                    asset.setNmsAttributes("controloperatingmode", Integer.toString(controloperatingmode));
                    
                    double systemlinevoltage = rs.getInt("systemlinevoltage");
                    asset.setNmsAttributes("systemlinevoltage", String.valueOf(systemlinevoltage));                      
                    
                    int ptratio = rs.getInt("ptratio");
                    asset.setNmsAttributes("ptratio", Integer.toString(ptratio));
                    
                    int setvoltagereverse = rs.getInt("setvoltagereverse");
                    asset.setNmsAttributes("setvoltagereverse", Integer.toString(setvoltagereverse));
                    
                    int bandwidthreverse = rs.getInt("bandwidthreverse");
                    asset.setNmsAttributes("bandwidthreverse", Integer.toString(bandwidthreverse));
                    
                    int timedelayreverse = rs.getInt("timedelayreverse");
                    asset.setNmsAttributes("timedelayreverse", Integer.toString(timedelayreverse));
                    
                    int resistancereverse = rs.getInt("resistancereverse");
                    asset.setNmsAttributes("resistancereverse", Integer.toString(resistancereverse));
                    
                    int reactancereverse = rs.getInt("reactancereverse");
                    asset.setNmsAttributes("reactancereverse", Integer.toString(reactancereverse));
                    
                    int reversesensingmethod = rs.getInt("reversesensingmethod");
                    asset.setNmsAttributes("reversesensingmethod", Integer.toString(reversesensingmethod));

                    String current = rs.getString("current");
                    asset.setNmsAttributes("current", current);   

                    int reversethreshold = rs.getInt("reversethreshold");
                    asset.setNmsAttributes("reversethreshold", Integer.toString(reversethreshold));
                    
                    String ckttieflag = rs.getString("ckttieflag");
                    asset.setNmsAttributes("ckttieflag", ckttieflag);   
                    
                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));
                    
                    int regphase = rs.getInt("regphase");
                    asset.setNmsAttributes("regphase", Integer.toString(regphase));
                    
                    String contype = rs.getString("contype");
                    asset.setNmsAttributes("contype", contype);   
                    
                    int wafid1 = rs.getInt("wafid1");
                    asset.setNmsAttributes("wafid1", Integer.toString(wafid1));
                    
                    int wafid2 = rs.getInt("wafid2");
                    asset.setNmsAttributes("wafid2", Integer.toString(wafid2));
                    
                    String dstat = rs.getString("dstat");
                    asset.setNmsAttributes("dstat", dstat);   
                    
                    String subseg = rs.getString("subseg");
                    asset.setNmsAttributes("subseg", subseg);   
                    
                    String scada = rs.getString("scada");
                    asset.setNmsAttributes("scada", scada);    
                    
                    String equipmenttype = rs.getString("equipmenttype");
                    asset.setNmsAttributes("equipmenttype", equipmenttype);    
                    
                    String controlserialnumber = rs.getString("controlserialnumber");
                    asset.setNmsAttributes("controlserialnumber", controlserialnumber);    

                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);    
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);    

                    
                    
                    
                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}









  


