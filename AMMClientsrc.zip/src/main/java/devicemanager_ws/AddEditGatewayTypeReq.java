
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditGatewayTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditGatewayTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditGatewayType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="WANTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="GWTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditGatewayTypeReq", propOrder = {
    "wanTypeConfigID",
    "gwTypeConfigID"
})
public class AddEditGatewayTypeReq
    extends AddEditGatewayType
{

    @XmlElement(name = "WANTypeConfigID")
    protected Long wanTypeConfigID;
    @XmlElement(name = "GWTypeConfigID")
    protected long gwTypeConfigID;

    /**
     * Gets the value of the wanTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getWANTypeConfigID() {
        return wanTypeConfigID;
    }

    /**
     * Sets the value of the wanTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setWANTypeConfigID(Long value) {
        this.wanTypeConfigID = value;
    }

    /**
     * Gets the value of the gwTypeConfigID property.
     * 
     */
    public long getGWTypeConfigID() {
        return gwTypeConfigID;
    }

    /**
     * Sets the value of the gwTypeConfigID property.
     * 
     */
    public void setGWTypeConfigID(long value) {
        this.gwTypeConfigID = value;
    }

}
