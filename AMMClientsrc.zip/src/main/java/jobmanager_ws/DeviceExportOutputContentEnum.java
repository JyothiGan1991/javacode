
package jobmanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceExportOutputContentEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeviceExportOutputContentEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="DevicesAndLocations"/&gt;
 *     &lt;enumeration value="DevicesOnly"/&gt;
 *     &lt;enumeration value="LocationsOnly"/&gt;
 *     &lt;enumeration value="NiclessDevices"/&gt;
 *     &lt;enumeration value="DevicelessNics"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DeviceExportOutputContentEnum")
@XmlEnum
public enum DeviceExportOutputContentEnum {

    @XmlEnumValue("DevicesAndLocations")
    DEVICES_AND_LOCATIONS("DevicesAndLocations"),
    @XmlEnumValue("DevicesOnly")
    DEVICES_ONLY("DevicesOnly"),
    @XmlEnumValue("LocationsOnly")
    LOCATIONS_ONLY("LocationsOnly"),
    @XmlEnumValue("NiclessDevices")
    NICLESS_DEVICES("NiclessDevices"),
    @XmlEnumValue("DevicelessNics")
    DEVICELESS_NICS("DevicelessNics"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DeviceExportOutputContentEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeviceExportOutputContentEnum fromValue(String v) {
        for (DeviceExportOutputContentEnum c: DeviceExportOutputContentEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
