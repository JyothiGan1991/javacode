package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

@RunWith(MockitoJUnitRunner.class)
public class RCCMeterEventServiceTest {

	@InjectMocks
	MeterEventService meterEventService;
	
	@Mock
	RESTActionExecutorConnect restActionExecutorConnect;
	
	@Test
	public void getValidMetersForConnect(){
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("P");
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("P");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		ResponseEntity<MeterEventResponseMapper> result = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);//ResponseEntity<MeterEventResponseMapper>
		Mockito.when(restActionExecutorConnect.getValidMetersForConnect(meterOpenEvent)).thenReturn(result);
		ResponseEntity<MeterEventResponseMapper> response = meterEventService.getValidMetersForConnect(meterOpenEvent);
		Assert.assertEquals(merp.getBorough(), response.getBody().getBorough());
	}
	
	
	@Test
	public void getConnectdMeters(){
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("P");
		ResponseEntity<MeterEventResponseMapper> result = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();

		meterOpenEvent.setBorough("P");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		Mockito.when(restActionExecutorConnect.getConnectdMeters(meterOpenEvent)).thenReturn(result);
		ResponseEntity<MeterEventResponseMapper> response = meterEventService.getConnectdMeters(meterOpenEvent);
		Assert.assertEquals(merp.getBorough(), response.getBody().getBorough());
	}
	
	@Test
	public void finalizeSubEventMeter() throws Exception{
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Ridgewood.09.10/11/20-09:27:18.AUTO");
		subEvent.setSubEventName("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<MeterFinalizeResponseMapper> result = new ResponseEntity<MeterFinalizeResponseMapper>(merp,HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.finalizeSubEventMeter(subEvent,"Test")).thenReturn(result);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "Test");
		ResponseEntity<MeterFinalizeResponseMapper> response = meterEventService.finalizeSubEventMeter(subEvent,"Test");
		Assert.assertEquals(result.getBody(), response.getBody());
	}
	
	@Test
	public void getSubEventSuffix() throws Exception {

		String borough = "B";
		String eventName = "Flatbush.23.11/08/20-23:24:06.KUMARM";
		String items = "Suffix";

		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.getSubEventSuffix(borough, eventName, items)).thenReturn(mockData);
		ResponseEntity<Long> response = meterEventService.getSubEventSuffix(borough, eventName, items);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());

	}
	
	@Test
	public void getSubEventMeters(){
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("P");
		Mockito.when(restActionExecutorConnect.getSubEventMeters(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),Mockito.anyInt())).thenReturn(merp);
		MeterEventResponseMapper response = meterEventService.getSubEventMeters(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt());
		Assert.assertEquals(merp.getBorough(), response.getBorough());
	}
	
	
	@Test
	public void searchMeters(){
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("P");
		ResponseEntity<MeterEventResponseMapper> result = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
		MeterSearch ms = new MeterSearch();
		Mockito.when(restActionExecutorConnect.searchMeter(ms)).thenReturn(result);
		ResponseEntity<MeterEventResponseMapper> response = meterEventService.searchMeters(ms);
		Assert.assertEquals(merp.getBorough(), response.getBody().getBorough());
	}
	
	@Test
	public void searchMeterConnected() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("Flatbush.23.11/08/20-23:24:06");
		meterSearch.setMeters("009445720");
		meterSearch.setSubEvent("Zone00323");
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();

		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,
				HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.searchMeterConnected(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = meterEventService.searchMetersConnected(meterSearch);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test
	public void getSubEventMetersTest() throws Exception {

		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Flatbush.23.11/08/20-23:24:06");
		subEvent.setMeters("009445720");
		subEvent.setSubEventName("Zone00323");
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.getSubEventMeters(subEvent)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = meterEventService.getSubEventMeters(subEvent);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	@Test
	public void getFieldValuesByBoroughAndEventNameTest(){
		List<String> expected = new ArrayList<>();
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(restActionExecutorConnect.getFieldValuesByBoroughAndEventName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(result);
		ResponseEntity<List<String>> response = meterEventService.getFieldValuesByBoroughAndEventName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
		Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
    public void isEventLocked(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
		Mockito.when(restActionExecutorConnect.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = meterEventService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK");
		Assert.assertEquals(mlsp.getMessage(),response.getMessage());
		
    }
	@Test
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doNothing().when(restActionExecutorConnect).unlockEvents(adid);
		meterEventService.unlockEvents(adid);
	}
	
}
