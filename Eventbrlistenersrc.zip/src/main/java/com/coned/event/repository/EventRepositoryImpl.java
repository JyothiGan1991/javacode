/**
 * 
 */
package com.coned.event.repository;

import java.sql.Types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ssn.schema.service.v2_6.eventmanager.FindEventResultType;

@Repository
@PropertySource(value = { "classpath:queries.properties" })
public class EventRepositoryImpl implements EventRepository {

	@Autowired
	private Environment env;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * This persists the event status
	 */
	@Override
	public int saveEventStatus(FindEventResultType result) {
		Object[] params = new Object[] { result.getEventId(), result.getSourceUtilID(), result.getSourceId(),
				result.getJobId(), result.getEventTime().getDate(), result.getEventName(), result.getEventCode() };

		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR,
				Types.VARCHAR, Types.VARCHAR };

		return jdbcTemplate.update(env.getProperty("SAVE_EVENT_STATUS"), params, types);

	}

}
