/*package com.coned.ls.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.MeterRejectResponseMapper;
import com.coned.ls.repository.MetersEventRejectRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class MeterEventRejectServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private MetersEventRejectService meterEventRejectService = new MetersEventRejectServiceImpl();
	
	@Mock
	private MetersEventRejectRepository metersEventRejectRepository;
	
	private MockMvc mockMvc;
	
	MeterRejectResponseMapper  meterRejectResponseMapper = new MeterRejectResponseMapper();
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterRejectResponseMapper.setSuccess(true);
		meterRejectResponseMapper.setMessage("Event has been rejected. Please notify Operator.");
	}
	@Test
	public void rejectMeterEventListTest() throws MeterRejectException{
		Mockito.when(metersEventRejectRepository.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterRejectResponseMapper);
		MeterRejectResponseMapper rejectMeterEventList = meterEventRejectService.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350");
		Assert.assertEquals(rejectMeterEventList.getMessage(), meterRejectResponseMapper.getMessage());
	}
	
	@Test
	public void rejectMeterEventListTest_Exception_DuplicateRecord() throws MeterRejectException{
		String exception = "DUPLICATE_RECORD_FOUND";
		meterRejectResponseMapper.setSuccess(false);
		meterRejectResponseMapper.setMessage(exception);
		Mockito.when(metersEventRejectRepository.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterRejectResponseMapper);
		MeterRejectResponseMapper rejectMeterEventList = meterEventRejectService.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350");
		Assert.assertEquals(rejectMeterEventList.getMessage(), meterRejectResponseMapper.getMessage());
		Assert.assertEquals(rejectMeterEventList.isSuccess(), meterRejectResponseMapper.isSuccess());
	}
	
	@Test
	public void rejectMeterEventListTest_Exception_NoRecord() throws MeterRejectException{
		String exception = "RECORD_NOT_FOUND";
		meterRejectResponseMapper.setSuccess(false);
		meterRejectResponseMapper.setMessage(exception);
		Mockito.when(metersEventRejectRepository.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350")).thenReturn(meterRejectResponseMapper);
		MeterRejectResponseMapper rejectMeterEventList = meterEventRejectService.rejectMeterEventList("C","SheepsheadBaySampleData7.27.20-1350");
		Assert.assertEquals(rejectMeterEventList.getMessage(), meterRejectResponseMapper.getMessage());
		Assert.assertEquals(rejectMeterEventList.isSuccess(), meterRejectResponseMapper.isSuccess());
	}
	
}
*/