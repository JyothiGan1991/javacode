
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JobTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="JobTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_OP_TYPE_CRON_JOB"/>
 *     &lt;enumeration value="JOB_OP_TYPE_METER_READ"/>
 *     &lt;enumeration value="JOB_OP_TYPE_EXPORT"/>
 *     &lt;enumeration value="JOB_OP_TYPE_IMPORT"/>
 *     &lt;enumeration value="JOB_OP_TYPE_REPORT"/>
 *     &lt;enumeration value="JOB_OP_TYPE_PING"/>
 *     &lt;enumeration value="JOB_OP_TYPE_NCC_ALARM_CLEAR"/>
 *     &lt;enumeration value="JOB_OP_TYPE_DEV_PROG_READ"/>
 *     &lt;enumeration value="JOB_OP_TYPE_REMOTE_PROVISION"/>
 *     &lt;enumeration value="JOB_OP_TYPE_ARB_METER_COMMAND"/>
 *     &lt;enumeration value="JOB_OP_TYPE_DEMAND_RESET"/>
 *     &lt;enumeration value="JOB_OP_TYPE_BRIDGE_CONFIGURE"/>
 *     &lt;enumeration value="JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"/>
 *     &lt;enumeration value="JOB_OP_TYPE_DEVICE_DATA_IMPORT"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "JobTypeEnumeration")
@XmlEnum
public enum JobTypeEnumeration {

    JOB_OP_TYPE_CRON_JOB("JOB_OP_TYPE_CRON_JOB"),
    JOB_OP_TYPE_METER_READ("JOB_OP_TYPE_METER_READ"),
    JOB_OP_TYPE_EXPORT("JOB_OP_TYPE_EXPORT"),
    JOB_OP_TYPE_IMPORT("JOB_OP_TYPE_IMPORT"),
    JOB_OP_TYPE_REPORT("JOB_OP_TYPE_REPORT"),
    JOB_OP_TYPE_PING("JOB_OP_TYPE_PING"),
    JOB_OP_TYPE_NCC_ALARM_CLEAR("JOB_OP_TYPE_NCC_ALARM_CLEAR"),
    JOB_OP_TYPE_DEV_PROG_READ("JOB_OP_TYPE_DEV_PROG_READ"),
    JOB_OP_TYPE_REMOTE_PROVISION("JOB_OP_TYPE_REMOTE_PROVISION"),
    JOB_OP_TYPE_ARB_METER_COMMAND("JOB_OP_TYPE_ARB_METER_COMMAND"),
    JOB_OP_TYPE_DEMAND_RESET("JOB_OP_TYPE_DEMAND_RESET"),
    JOB_OP_TYPE_BRIDGE_CONFIGURE("JOB_OP_TYPE_BRIDGE_CONFIGURE"),
    JOB_OP_TYPE_TRGGR_BRDG_NTFCTN("JOB_OP_TYPE_TRGGR_BRDG_NTFCTN"),
    JOB_OP_TYPE_DEVICE_DATA_IMPORT("JOB_OP_TYPE_DEVICE_DATA_IMPORT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    JobTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JobTypeEnumeration fromValue(String v) {
        for (JobTypeEnumeration c: JobTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
