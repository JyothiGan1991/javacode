
package com.ssn.schema.service.v2_6.basictypes;

import jakarta.xml.bind.annotation.XmlRegistry;

/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ssn.schema.service.v2_6.basictypes package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ssn.schema.service.v2_6.basictypes
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JobIDType }
     * 
     */
    public JobIDType createJobIDType() {
        return new JobIDType();
    }

    /**
     * Create an instance of {@link CachedResultsType }
     * 
     */
    public CachedResultsType createCachedResultsType() {
        return new CachedResultsType();
    }

    /**
     * Create an instance of {@link TotalCountType }
     * 
     */
    public TotalCountType createTotalCountType() {
        return new TotalCountType();
    }

}
