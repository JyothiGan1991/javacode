package com.coned.ls.service;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.coned.ls.rest.RESTActionExecutor;

/**
 * 
 * Service class for RCC UserManagement.
 *
 */
@Component
public class UserManagementService {

	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	
	public ResponseEntity<List<Object>> getUsers(){
		return restActionExecutor.getUsers();
	}
	
	public ResponseEntity<Map<String, Object>> listLDAPUser(String username){
		return restActionExecutor.listLDAPUser(username);
	}
	
	public ResponseEntity<Map<String, Object>> createUser(Map<String, Object> payload){
		return restActionExecutor.createUser(payload);
	} 
	public ResponseEntity<Map<String, Object>> updateUser(String username, Map<String, Object> payload){
		return restActionExecutor.updateUser(username, payload);
	} 
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy){
		return restActionExecutor.deleteUser(username, updatedBy);
	}

}