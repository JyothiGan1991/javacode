
package com.ssn.schema.service.v2_6.devicetypes;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ssn.schema.service.v2_6.devicetypes package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ssn.schema.service.v2_6.devicetypes
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link WANType }
     * 
     */
    public WANType createWANType() {
        return new WANType();
    }

    /**
     * Create an instance of {@link DefinedLocationType }
     * 
     */
    public DefinedLocationType createDefinedLocationType() {
        return new DefinedLocationType();
    }

    /**
     * Create an instance of {@link DeviceSubTypeType }
     * 
     */
    public DeviceSubTypeType createDeviceSubTypeType() {
        return new DeviceSubTypeType();
    }

    /**
     * Create an instance of {@link MeterModeType }
     * 
     */
    public MeterModeType createMeterModeType() {
        return new MeterModeType();
    }

}
