
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DevicePingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DevicePingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ExecutionStatus" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}ExecutionStatusType" minOccurs="0"/&gt;
 *         &lt;element name="Ping" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}PingType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="GatewaySerialNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="GatewayName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="LocLongitude" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="LocLatitude" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="PacketSize" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="JobID" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="JobName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobCreator" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobExecutionTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CustomerID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DevicePingType", propOrder = {
    "executionStatus",
    "ping"
})
public class DevicePingType {

    @XmlElement(name = "ExecutionStatus")
    protected ExecutionStatusType executionStatus;
    @XmlElement(name = "Ping")
    protected List<PingType> ping;
    @XmlAttribute(name = "GatewaySerialNumber", required = true)
    protected String gatewaySerialNumber;
    @XmlAttribute(name = "GatewayName", required = true)
    protected String gatewayName;
    @XmlAttribute(name = "DeviceMacID")
    protected String deviceMacID;
    @XmlAttribute(name = "DeviceName")
    protected String deviceName;
    @XmlAttribute(name = "LocLongitude")
    protected Double locLongitude;
    @XmlAttribute(name = "LocLatitude")
    protected Double locLatitude;
    @XmlAttribute(name = "PacketSize")
    protected Integer packetSize;
    @XmlAttribute(name = "JobID", required = true)
    protected long jobID;
    @XmlAttribute(name = "JobName", required = true)
    protected String jobName;
    @XmlAttribute(name = "JobCreator", required = true)
    protected String jobCreator;
    @XmlAttribute(name = "JobExecutionTime")
    protected String jobExecutionTime;
    @XmlAttribute(name = "CustomerID")
    protected String customerID;

    /**
     * Gets the value of the executionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ExecutionStatusType }
     *     
     */
    public ExecutionStatusType getExecutionStatus() {
        return executionStatus;
    }

    /**
     * Sets the value of the executionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExecutionStatusType }
     *     
     */
    public void setExecutionStatus(ExecutionStatusType value) {
        this.executionStatus = value;
    }

    /**
     * Gets the value of the ping property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ping property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPing().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PingType }
     * 
     * 
     */
    public List<PingType> getPing() {
        if (ping == null) {
            ping = new ArrayList<PingType>();
        }
        return this.ping;
    }

    /**
     * Gets the value of the gatewaySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewaySerialNumber() {
        return gatewaySerialNumber;
    }

    /**
     * Sets the value of the gatewaySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewaySerialNumber(String value) {
        this.gatewaySerialNumber = value;
    }

    /**
     * Gets the value of the gatewayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayName() {
        return gatewayName;
    }

    /**
     * Sets the value of the gatewayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayName(String value) {
        this.gatewayName = value;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMacID() {
        return deviceMacID;
    }

    /**
     * Sets the value of the deviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMacID(String value) {
        this.deviceMacID = value;
    }

    /**
     * Gets the value of the deviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Sets the value of the deviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Gets the value of the locLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocLongitude() {
        return locLongitude;
    }

    /**
     * Sets the value of the locLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocLongitude(Double value) {
        this.locLongitude = value;
    }

    /**
     * Gets the value of the locLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocLatitude() {
        return locLatitude;
    }

    /**
     * Sets the value of the locLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocLatitude(Double value) {
        this.locLatitude = value;
    }

    /**
     * Gets the value of the packetSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPacketSize() {
        return packetSize;
    }

    /**
     * Sets the value of the packetSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPacketSize(Integer value) {
        this.packetSize = value;
    }

    /**
     * Gets the value of the jobID property.
     * 
     */
    public long getJobID() {
        return jobID;
    }

    /**
     * Sets the value of the jobID property.
     * 
     */
    public void setJobID(long value) {
        this.jobID = value;
    }

    /**
     * Gets the value of the jobName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the value of the jobName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets the value of the jobCreator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobCreator() {
        return jobCreator;
    }

    /**
     * Sets the value of the jobCreator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobCreator(String value) {
        this.jobCreator = value;
    }

    /**
     * Gets the value of the jobExecutionTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobExecutionTime() {
        return jobExecutionTime;
    }

    /**
     * Sets the value of the jobExecutionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobExecutionTime(String value) {
        this.jobExecutionTime = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerID(String value) {
        this.customerID = value;
    }

}
