package com.oru.ui;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import java.util.Map;
import com.oru.modelExtract.EntryPoint; 

@Controller
public class UiController {
    @GetMapping("/")
    public String home(){
        return "index";
    }

    @PostMapping("/run")
    public String run(@RequestParam Map<String,String> params, Model model){
        System.setProperty("db.url", params.get("url"));
        System.setProperty("db.user", params.get("user"));
        System.setProperty("db.pass", params.get("pass"));
        try{
        	EntryPoint.main(new String[]{});
            model.addAttribute("msg","Execution started");
        }catch(Exception e){
            model.addAttribute("msg", "Error: "+e.getMessage());
        }
        return "index";
    }
}
