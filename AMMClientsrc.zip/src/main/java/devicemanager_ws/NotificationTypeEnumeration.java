
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NotificationTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="NotificationTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_BRDG_NTFCTN_LINK_STATE"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "NotificationTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum NotificationTypeEnumeration {

    JOB_OP_BRDG_NTFCTN_LINK_STATE("JOB_OP_BRDG_NTFCTN_LINK_STATE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    NotificationTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NotificationTypeEnumeration fromValue(String v) {
        for (NotificationTypeEnumeration c: NotificationTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
