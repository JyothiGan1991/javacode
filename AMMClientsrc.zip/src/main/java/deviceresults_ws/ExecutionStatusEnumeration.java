
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExecutionStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExecutionStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_EXEC_STATUS_NOT_STARTED"/&gt;
 *     &lt;enumeration value="JOB_EXEC_STATUS_RUNNING"/&gt;
 *     &lt;enumeration value="JOB_EXEC_STATUS_COMPLETE"/&gt;
 *     &lt;enumeration value="JOB_EXEC_STATUS_FAILURE"/&gt;
 *     &lt;enumeration value="JOB_EXEC_STATUS_UNKNOWN"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ExecutionStatusEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum ExecutionStatusEnumeration {

    JOB_EXEC_STATUS_NOT_STARTED("JOB_EXEC_STATUS_NOT_STARTED"),
    JOB_EXEC_STATUS_RUNNING("JOB_EXEC_STATUS_RUNNING"),
    JOB_EXEC_STATUS_COMPLETE("JOB_EXEC_STATUS_COMPLETE"),
    JOB_EXEC_STATUS_FAILURE("JOB_EXEC_STATUS_FAILURE"),
    JOB_EXEC_STATUS_UNKNOWN("JOB_EXEC_STATUS_UNKNOWN"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ExecutionStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ExecutionStatusEnumeration fromValue(String v) {
        for (ExecutionStatusEnumeration c: ExecutionStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
