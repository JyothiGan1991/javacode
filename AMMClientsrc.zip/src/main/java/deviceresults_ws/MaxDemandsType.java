
package deviceresults_ws;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MaxDemandsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MaxDemandsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MaximumDemand" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="MaximumDemandTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MaxDemandTimeIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MaxDemandIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MaxDemandsType", propOrder = {
    "maximumDemand",
    "maximumDemandTime",
    "maxDemandTimeIEEExportChannelID",
    "maxDemandIEEExportChannelID"
})
public class MaxDemandsType {

    @XmlElement(name = "MaximumDemand")
    protected BigDecimal maximumDemand;
    @XmlElement(name = "MaximumDemandTime")
    protected String maximumDemandTime;
    @XmlElement(name = "MaxDemandTimeIEEExportChannelID")
    protected String maxDemandTimeIEEExportChannelID;
    @XmlElement(name = "MaxDemandIEEExportChannelID")
    protected String maxDemandIEEExportChannelID;

    /**
     * Gets the value of the maximumDemand property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumDemand() {
        return maximumDemand;
    }

    /**
     * Sets the value of the maximumDemand property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumDemand(BigDecimal value) {
        this.maximumDemand = value;
    }

    /**
     * Gets the value of the maximumDemandTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumDemandTime() {
        return maximumDemandTime;
    }

    /**
     * Sets the value of the maximumDemandTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumDemandTime(String value) {
        this.maximumDemandTime = value;
    }

    /**
     * Gets the value of the maxDemandTimeIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxDemandTimeIEEExportChannelID() {
        return maxDemandTimeIEEExportChannelID;
    }

    /**
     * Sets the value of the maxDemandTimeIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxDemandTimeIEEExportChannelID(String value) {
        this.maxDemandTimeIEEExportChannelID = value;
    }

    /**
     * Gets the value of the maxDemandIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxDemandIEEExportChannelID() {
        return maxDemandIEEExportChannelID;
    }

    /**
     * Sets the value of the maxDemandIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxDemandIEEExportChannelID(String value) {
        this.maxDemandIEEExportChannelID = value;
    }

}
