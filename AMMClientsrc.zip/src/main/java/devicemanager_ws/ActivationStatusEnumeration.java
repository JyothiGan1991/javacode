
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ActivationStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ActivationStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_STATUS_DEFINED"/&gt;
 *     &lt;enumeration value="JOB_STATUS_ACTIVE"/&gt;
 *     &lt;enumeration value="JOB_STATUS_SUSPENDED"/&gt;
 *     &lt;enumeration value="JOB_STATUS_COMPLETED"/&gt;
 *     &lt;enumeration value="JOB_STATUS_ARCHIVED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ActivationStatusEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum ActivationStatusEnumeration {

    JOB_STATUS_DEFINED("JOB_STATUS_DEFINED"),
    JOB_STATUS_ACTIVE("JOB_STATUS_ACTIVE"),
    JOB_STATUS_SUSPENDED("JOB_STATUS_SUSPENDED"),
    JOB_STATUS_COMPLETED("JOB_STATUS_COMPLETED"),
    JOB_STATUS_ARCHIVED("JOB_STATUS_ARCHIVED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ActivationStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ActivationStatusEnumeration fromValue(String v) {
        for (ActivationStatusEnumeration c: ActivationStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
