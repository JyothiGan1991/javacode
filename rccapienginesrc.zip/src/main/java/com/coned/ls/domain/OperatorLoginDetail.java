package com.coned.ls.domain;

import java.util.Date;

public class OperatorLoginDetail {

	private String adid;
	private String role;
	private int userRoleId;
	private Date loginTimeStamp;
	private String apiKey;
	private int apiKeyStatus;
	private int loginStatus;
	private boolean responseStatus;
	private int roleId;
	private String userClaim;
	private String loginTimeAsString;
	
	
	
	
	public String getLoginTimeAsString() {
		return loginTimeAsString;
	}
	public void setLoginTimeAsString(String loginTimeAsString) {
		this.loginTimeAsString = loginTimeAsString;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public int getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}
	public Date getLoginTimeStamp() {
		return loginTimeStamp;
	}
	public void setLoginTimeStamp(Date loginTimeStamp) {
		this.loginTimeStamp = loginTimeStamp;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public int getApiKeyStatus() {
		return apiKeyStatus;
	}
	public void setApiKeyStatus(int apiKeyStatus) {
		this.apiKeyStatus = apiKeyStatus;
	}
	public int getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(int loginStatus) {
		this.loginStatus = loginStatus;
	}
	public String getUserClaim() {
		return userClaim;
	}
	public void setUserClaim(String userClaim) {
		this.userClaim = userClaim;
	}
	
	
	public String getAdid() {
		return adid;
	}
	public void setAdid(String adid) {
		this.adid = adid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	public boolean isResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(boolean responseStatus) {
		this.responseStatus = responseStatus;
	}
	public OperatorLoginDetail() {
		super();
	}
	public OperatorLoginDetail(String adid, String role, int userRoleId,
			Date loginTimeStamp, String apiKey, int apiKeyStatus,
			int loginStatus, boolean responseStatus, int roleId) {
		super();
		this.adid = adid;
		this.role = role;
		this.userRoleId = userRoleId;
		this.loginTimeStamp = loginTimeStamp;
		this.apiKey = apiKey;
		this.apiKeyStatus = apiKeyStatus;
		this.loginStatus = loginStatus;
		this.responseStatus = responseStatus;
		this.roleId = roleId;
	}
	@Override
	public String toString() {
		return "OperatorLoginDetail [adid=" + adid + ", role=" + role + ", userRoleId=" + userRoleId
				+ ", loginTimeStamp=" + loginTimeStamp + ", apiKey=" + apiKey + ", apiKeyStatus=" + apiKeyStatus
				+ ", loginStatus=" + loginStatus + ", responseStatus=" + responseStatus + ", roleId=" + roleId
				+ ", loginTimeAsString=" + loginTimeAsString + "]";
	}
	
	
	
}
