
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateDistNetworkType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateDistNetworkType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DistNetworkID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="SubstationID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SubstationFeederCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Attribute1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Attribute2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Attribute3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="TransformerID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateDistNetworkType", propOrder = {
    "distNetworkID",
    "substationID",
    "substationFeederCode",
    "attribute1",
    "attribute2",
    "attribute3",
    "transformerID"
})
@XmlSeeAlso({
    NullableDistNetworkType.class
})
public class UpdateDistNetworkType {

    @XmlElement(name = "DistNetworkID")
    protected Integer distNetworkID;
    @XmlElement(name = "SubstationID")
    protected NullableString substationID;
    @XmlElement(name = "SubstationFeederCode")
    protected NullableString substationFeederCode;
    @XmlElement(name = "Attribute1")
    protected NullableString attribute1;
    @XmlElement(name = "Attribute2")
    protected NullableString attribute2;
    @XmlElement(name = "Attribute3")
    protected NullableString attribute3;
    @XmlElement(name = "TransformerID")
    protected NullableString transformerID;

    /**
     * Gets the value of the distNetworkID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDistNetworkID() {
        return distNetworkID;
    }

    /**
     * Sets the value of the distNetworkID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDistNetworkID(Integer value) {
        this.distNetworkID = value;
    }

    /**
     * Gets the value of the substationID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSubstationID() {
        return substationID;
    }

    /**
     * Sets the value of the substationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSubstationID(NullableString value) {
        this.substationID = value;
    }

    /**
     * Gets the value of the substationFeederCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSubstationFeederCode() {
        return substationFeederCode;
    }

    /**
     * Sets the value of the substationFeederCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSubstationFeederCode(NullableString value) {
        this.substationFeederCode = value;
    }

    /**
     * Gets the value of the attribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getAttribute1() {
        return attribute1;
    }

    /**
     * Sets the value of the attribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setAttribute1(NullableString value) {
        this.attribute1 = value;
    }

    /**
     * Gets the value of the attribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getAttribute2() {
        return attribute2;
    }

    /**
     * Sets the value of the attribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setAttribute2(NullableString value) {
        this.attribute2 = value;
    }

    /**
     * Gets the value of the attribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getAttribute3() {
        return attribute3;
    }

    /**
     * Sets the value of the attribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setAttribute3(NullableString value) {
        this.attribute3 = value;
    }

    /**
     * Gets the value of the transformerID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getTransformerID() {
        return transformerID;
    }

    /**
     * Sets the value of the transformerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setTransformerID(NullableString value) {
        this.transformerID = value;
    }

}
