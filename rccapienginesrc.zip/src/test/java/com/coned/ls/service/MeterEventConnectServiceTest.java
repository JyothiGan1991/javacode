package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.repository.MeterEventConnectRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={MeterEventConnectService.class})
@AutoConfigureMockMvc
public class MeterEventConnectServiceTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private MeterEventConnectService meterEventConnectService = new MeterEventConnectServiceImpl();
	
	@Mock
	private MeterEventConnectRepository meterEventConnectRepository;
	
	private MockMvc mockMvc;
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void getValidMetersForConnect() throws Exception{
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		mcrm.setBorough("P");
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterConnectResponseMapper> result = new ResponseEntity<MeterConnectResponseMapper>(mcrm,HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		Mockito.when(meterEventConnectRepository.getValidMetersForConnect(meterOpenEvent)).thenReturn(result);
		ResponseEntity<MeterConnectResponseMapper> response = meterEventConnectService.getValidMetersForConnect(meterOpenEvent);
		Assert.assertEquals(mcrm.getBorough(), response.getBody().getBorough());
	}
	
	@Test
	public void getConnectedMeters() throws Exception{
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		mcrm.setBorough("P");
		ResponseEntity<MeterConnectResponseMapper> result = new ResponseEntity<MeterConnectResponseMapper>(mcrm,HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough("B");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(10);
		
			Mockito.when(meterEventConnectRepository.getConnectedMeters(meterOpenEvent)).thenReturn(result);
			
			
			
			ResponseEntity<MeterConnectResponseMapper> response = meterEventConnectService.getConnectedMeters(meterOpenEvent);
		    Assert.assertEquals(mcrm.getBorough(), response.getBody().getBorough());
		} 

	
	@Test
	public void getSubEventMeters() throws MeterEventConnectException{
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		mcrm.setBorough("P");
		ResponseEntity<MeterConnectResponseMapper> result = new ResponseEntity<MeterConnectResponseMapper>(mcrm,HttpStatus.OK);
		Mockito.when(meterEventConnectRepository.getSubEventMeters(Mockito.anyString(), Mockito.anyString(),  Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(result);
		ResponseEntity<MeterConnectResponseMapper> response = meterEventConnectService.getSubEventMeters(Mockito.anyString(), Mockito.anyString(),  Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt());
		Assert.assertEquals(mcrm.getBorough(), response.getBody().getBorough());
	}
	
	@Test
	public void searchMeters() throws MeterEventConnectException{
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		mcrm.setBorough("P");
		mcrm.setValidResponse(true);
		ResponseEntity<MeterConnectResponseMapper> response = new ResponseEntity<MeterConnectResponseMapper>(mcrm, HttpStatus.OK);
		MeterSearch ms = new MeterSearch();
		Mockito.when(meterEventConnectRepository.searchMeters(ms)).thenReturn(mcrm);
		ResponseEntity<MeterConnectResponseMapper> result = meterEventConnectService.searchMeters(ms);
		Assert.assertEquals(response.getBody().getBorough(), result.getBody().getBorough());
	}
	
	@Test
	public void getFieldValuesByBoroughAndEventNameTest(){
		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String fieldname = "fieldname";
		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,HttpStatus.OK);
		Mockito.when(meterEventConnectRepository.getFieldValuesByBoroughAndEventName(borough, eventName,fieldname)).thenReturn(expectedEventNameList);
		ResponseEntity<List<String>> response = meterEventConnectService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldname);
		Assert.assertEquals(result.getBody().size(), response.getBody().size());
		
	}
	
	@Test
	public void searchMeterConnectedTest() throws MeterEventConnectException{
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		mcrm.setBorough("P");
		mcrm.setValidResponse(true);
		ResponseEntity<MeterConnectResponseMapper> response = new ResponseEntity<MeterConnectResponseMapper>(mcrm, HttpStatus.OK);
		MeterSearch ms = new MeterSearch();
		Mockito.when(meterEventConnectRepository.searchMeterConnected(ms)).thenReturn(mcrm);
		ResponseEntity<MeterConnectResponseMapper> result = meterEventConnectService.searchMeterConnected(ms);
		Assert.assertEquals(response.getBody().getBorough(), result.getBody().getBorough());
	}
	
	/*@Test
	public void finalizeSubEventMeterTest() throws Exception{
		MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
		mfrp.setMessage("SUCCESS");
		ResponseEntity<MeterFinalizeResponseMapper> result = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp, HttpStatus.OK);
			SubEvent subevent = new SubEvent();
			Mockito.when(meterEventConnectRepository.finalizeSubEventMeter(subevent)).thenReturn(result);
			ResponseEntity<MeterConnectResponseMapper> response = meterEventConnectService.getConnectedMeters(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt());
		    Assert.assertEquals(result.getBody().getMessage(), response.getBody());
		} */
	@Test
	public void finalizeSubEventMeterTest() throws Exception{
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Ridgewood.09.10/11/20-09:27:18.AUTO");
		subEvent.setSubEventName("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<MeterFinalizeResponseMapper> result = new ResponseEntity<MeterFinalizeResponseMapper>(merp,HttpStatus.OK);
		Mockito.when(meterEventConnectRepository.finalizeSubEventMeter(subEvent)).thenReturn(result);
		ResponseEntity<MeterFinalizeResponseMapper> response = meterEventConnectService.finalizeSubEventMeter(subEvent);
		Assert.assertEquals(result.getBody(), response.getBody());
	}
	
	@Test
	public void getSubEventSuffixTest() throws Exception {

		String borough = "B";
		String eventName = "Flatbush.23.11/08/20-23:24:06.KUMARM";
		String items = "Suffix";

		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(meterEventConnectRepository.getSubEventSuffix(borough, eventName)).thenReturn(mockData);
		ResponseEntity<Long> response = meterEventConnectService.getSubEventSuffix(borough, eventName);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());

	}

	@Test
	public void getSubEventMetersTest() throws Exception {

		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Flatbush.23.11/08/20-23:24:06");
		subEvent.setMeters("009445720");
		subEvent.setSubEventName("Zone00323");
		
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockdata = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectRepository.getSubEventMeters(subEvent)).thenReturn(mapper);
		ResponseEntity<MeterConnectResponseMapper> response = meterEventConnectService.getSubEventMeters(subEvent);
		Assert.assertEquals(mockdata.getStatusCode(), response.getStatusCode());
	}
	
	@Test
    public void isEventLocked(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
		Mockito.when(meterEventConnectRepository.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = meterEventConnectService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK");
		Assert.assertEquals(mlsp.getMessage(),response.getMessage());
    }
	
	@Test
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doNothing().when(meterEventConnectRepository).unlockEvents(adid);
		meterEventConnectService.unlockEvents(adid);
	}

}
