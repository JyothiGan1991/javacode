
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ResponseStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ResponseStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="C1219_OVERALL_STAT_GOOD"/&gt;
 *     &lt;enumeration value="C1219_OVERALL_STAT_INTERNAL_ERROR"/&gt;
 *     &lt;enumeration value="C1219_OVERALL_STAT_RESPONSE_TOO_LARGE"/&gt;
 *     &lt;enumeration value="C1219_OP_TLV_NO_SEAL_RESP"/&gt;
 *     &lt;enumeration value="C1219_OVERALL_STAT_METER_NOT_READY"/&gt;
 *     &lt;enumeration value="UNKNOWN_ERROR"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ResponseStatusEnumeration")
@XmlEnum
public enum ResponseStatusEnumeration {

    @XmlEnumValue("C1219_OVERALL_STAT_GOOD")
    C_1219_OVERALL_STAT_GOOD("C1219_OVERALL_STAT_GOOD"),
    @XmlEnumValue("C1219_OVERALL_STAT_INTERNAL_ERROR")
    C_1219_OVERALL_STAT_INTERNAL_ERROR("C1219_OVERALL_STAT_INTERNAL_ERROR"),
    @XmlEnumValue("C1219_OVERALL_STAT_RESPONSE_TOO_LARGE")
    C_1219_OVERALL_STAT_RESPONSE_TOO_LARGE("C1219_OVERALL_STAT_RESPONSE_TOO_LARGE"),
    @XmlEnumValue("C1219_OP_TLV_NO_SEAL_RESP")
    C_1219_OP_TLV_NO_SEAL_RESP("C1219_OP_TLV_NO_SEAL_RESP"),
    @XmlEnumValue("C1219_OVERALL_STAT_METER_NOT_READY")
    C_1219_OVERALL_STAT_METER_NOT_READY("C1219_OVERALL_STAT_METER_NOT_READY"),
    UNKNOWN_ERROR("UNKNOWN_ERROR"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ResponseStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ResponseStatusEnumeration fromValue(String v) {
        for (ResponseStatusEnumeration c: ResponseStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
