@javax.xml.bind.annotation.XmlSchema(namespace = "http://oss.oru.com/")
package com.oru.soap.nucon.generated;
