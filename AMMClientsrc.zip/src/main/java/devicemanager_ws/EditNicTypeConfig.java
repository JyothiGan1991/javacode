
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditNicTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditNicTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NicTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NicTypeConfig"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditNicTypeConfig", propOrder = {
    "nicTypeConfig"
})
public class EditNicTypeConfig {

    @XmlElement(name = "NicTypeConfig", required = true)
    protected NicTypeConfig nicTypeConfig;

    /**
     * Gets the value of the nicTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link NicTypeConfig }
     *     
     */
    public NicTypeConfig getNicTypeConfig() {
        return nicTypeConfig;
    }

    /**
     * Sets the value of the nicTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link NicTypeConfig }
     *     
     */
    public void setNicTypeConfig(NicTypeConfig value) {
        this.nicTypeConfig = value;
    }

}
