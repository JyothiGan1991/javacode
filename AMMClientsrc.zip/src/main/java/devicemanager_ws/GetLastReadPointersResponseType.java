
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetLastReadPointersResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetLastReadPointersResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LastReadPointers" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}LastReadPointersType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetLastReadPointersResponseType", propOrder = {
    "lastReadPointers"
})
public class GetLastReadPointersResponseType {

    @XmlElement(name = "LastReadPointers")
    protected List<LastReadPointersType> lastReadPointers;

    /**
     * Gets the value of the lastReadPointers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lastReadPointers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLastReadPointers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LastReadPointersType }
     * 
     * 
     */
    public List<LastReadPointersType> getLastReadPointers() {
        if (lastReadPointers == null) {
            lastReadPointers = new ArrayList<LastReadPointersType>();
        }
        return this.lastReadPointers;
    }

}
