
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DefinedContactTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DefinedContactTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CONTACT_TYPE_OWNER"/&gt;
 *     &lt;enumeration value="CONTACT_TYPE_LOCATION"/&gt;
 *     &lt;enumeration value="CONTACT_TYPE_BILLING"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DefinedContactTypeEnum")
@XmlEnum
public enum DefinedContactTypeEnum {

    CONTACT_TYPE_OWNER("CONTACT_TYPE_OWNER"),
    CONTACT_TYPE_LOCATION("CONTACT_TYPE_LOCATION"),
    CONTACT_TYPE_BILLING("CONTACT_TYPE_BILLING"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DefinedContactTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DefinedContactTypeEnum fromValue(String v) {
        for (DefinedContactTypeEnum c: DefinedContactTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
