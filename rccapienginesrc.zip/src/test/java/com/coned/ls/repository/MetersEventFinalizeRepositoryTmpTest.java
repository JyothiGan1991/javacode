package com.coned.ls.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

//import com.coned.ls.controller.AOCCDisconnectController;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { MetersEventFinalizeRepositoryTmp.class })
@AutoConfigureMockMvc
public class MetersEventFinalizeRepositoryTmpTest {

	@Autowired
	private WebApplicationContext wac;

	@InjectMocks
	private JdbcMetersEventFinalizeRepositoryTmp jdbcMetersFinalizeRepo;

	private MockMvc mockMvc;

	MeterEventFinalize meterEventFinalize;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcMetersFinalizeRepo, "oracleJdbcTemplate", oracleJdbcTemplate);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300",
				"Success", true);
	}

	@Test
	public void findMeterEventFinalizeDetailsTest_True() {
		Assert.assertEquals(10, meterEventFinalize.getCountOfMeters());
		Assert.assertEquals("AN20025372", meterEventFinalize.getOperatorAdId());
		Assert.assertEquals("B", meterEventFinalize.getBorough());
		Assert.assertEquals("SheepsheadBaySampleData7.27.20-1300", meterEventFinalize.getEventName());
		Assert.assertEquals("Success", meterEventFinalize.getMessage());
		Assert.assertEquals(true, meterEventFinalize.isValid());
	}

	@Test
	public void finalizeMeterEvent() throws Exception {
		List<String> listOfMeters = new ArrayList<String>();
		listOfMeters.add("12345");
		listOfMeters.add("12");
		listOfMeters.add("13");

		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		meterEventFinalize.setBorough("B");
		meterEventFinalize.setEventName("Flatbush.01.10/27/20-12:05:45.ZHUT");
		meterEventFinalize.setIsSelectAll(false);
		meterEventFinalize.setListOfMeters(listOfMeters);
		meterEventFinalize.setCountOfMeters(1);

		/*Mockito.when(ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventList", "Test",
				"Test", "Test-Test,Test-Test", "Test.Test", 1)).thenReturn(true);

		Mockito.when(ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventDetails",
				Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		Mockito.when(ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "unlockEvent", Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(true);*/		
		
		/*ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "varifyIfEventIsAlreadyFinalized", "B",
				"Test");
		
		ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getFinalizedEventId", "Test","test","Test");
		ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventList", "Test",
				"Test","Test",1);*/

		String adid = "TestUser";
		MeterFinalizeResponseMapper expected = new MeterFinalizeResponseMapper();
		expected.setMessage("Test");
		expected.setResult(true);

		ReflectionTestUtils.setField(jdbcMetersFinalizeRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		Mockito.when(jdbcMetersFinalizeRepo.finalizeMeterEvent(meterEventFinalize, adid)).thenReturn(expected);
		// Mockito.when(jdbcMetersFinalizeRepo.finalizeMeterEvent(meterEventFinalize,adid)).thenReturn(expected);

		Assert.assertEquals(expected.getMessage(), "Test");
		Assert.assertTrue(expected.isResult());

	}

	@Test
	public void getCountOfValidMeters() {
		List<String> eventLoadIdLst = new ArrayList<>();
		eventLoadIdLst.add("1234");
		eventLoadIdLst.add("5678");
		eventLoadIdLst.add("Test1");
		eventLoadIdLst.add("Test2");
		String query = "SELECT FK_METER_EVENT_LOAD_ID FROM ls_validate_event_list WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Mockito.when(oracleJdbcTemplate.queryForList(query, new Object[] { "Test", "Test" }, String.class))
				.thenReturn(eventLoadIdLst);
		int eventLoadIdLstSize = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getCountOfValidMeters",
				"Test", "Test", "", "");
		Assert.assertEquals(eventLoadIdLstSize, 0);
	}

	@Test
	public void persistFinalizeMeterEventList() {
		String filterStr = "XYZ";
		Boolean actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventList",
				"Test", "Test", "", "Test1,Test2", 1);
		Assert.assertEquals(actual, false);
	}

	@Test
	public void persistFinalizeMeterEventDetails() {
		Boolean actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventDetails",
				10, "B", "Test1", "BUDIDHAK");
		Assert.assertEquals(actual, true);
	}

	@Test
	public void unlockEvent() {
		ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "unlockEvent", "B", "Test1", "BUDIDHAK");
	}

	/*
	 * @Test(expected= MeterFinalizeException.class) public void
	 * InvvalidunlockEvent() throws MeterFinalizeException { String query
	 * ="UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForList(query, new
	 * Object[]{"Test", "Test"}, String.class));
	 * ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo,
	 * "unlockEvent","","","BUDIDHAK"); }
	 */

	@Test
	public void persistFinalizeMeterEventSelectAll() {
		int countOfMeters = 0;
		List<String> eventLoadIdLst = new ArrayList<>();
		eventLoadIdLst.add("1234");
		eventLoadIdLst.add("5678");
		eventLoadIdLst.add("Test1");
		eventLoadIdLst.add("Test2");
		String query = "SELECT FK_METER_EVENT_LOAD_ID FROM ls_validate_event_list WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Mockito.when(oracleJdbcTemplate.queryForList(query, new Object[] { "Test", "Test" }, String.class))
				.thenReturn(eventLoadIdLst);
		countOfMeters = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventSelectAll",
				"Test", "Test", "", "Test1,Test2", 1);
		Assert.assertEquals(0, countOfMeters);
	}

	@Test
	public void persistFinalizeMeterEventSelectAllWithNull() {
		int countOfMeters = 0;
		String filterStr = "XYZ";
		List<String> eventLoadIdLst = new ArrayList<>();
		eventLoadIdLst.add("1234");
		eventLoadIdLst.add("5678");
		eventLoadIdLst.add("Test1");
		eventLoadIdLst.add("Test2");
		String query = "insert into LS_FINALIZE_EVENT_LIST (FK_METER_EVENT_LOAD_ID,BORO_MUNI,event_name,FK_FINALIZED_EVENT_ID,METER_NUMBER) select vel.FK_METER_EVENT_LOAD_ID,vel.BORO_MUNI,vel.EVENT_NAME, ?, vel.METER_NUMBER from ls_validate_event_list vel where vel.boro_muni=? and vel.event_name=? "
				+ " AND vel.FK_METER_EVENT_LOAD_ID NOT IN (SELECT fel.FK_METER_EVENT_LOAD_ID FROM LS_FINALIZE_EVENT_LIST fel WHERE vel.boro_muni = fel.boro_muni AND vel.event_name = fel.event_name)";
		Mockito.when(oracleJdbcTemplate.queryForList(query, new Object[] { "Test1", "Test2", "Test3" }, String.class))
				.thenReturn(eventLoadIdLst);
		countOfMeters = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "persistFinalizeMeterEventSelectAll",
				"Test", "Test", "", null, 1);
		Assert.assertEquals(0, countOfMeters);
	}

	@Test
	public void buildFilterQuery() {
		String actual = "[ AND  IN ('test', 'test')  AND  IN ('test', 'test') ]";
		final String test1 = "test:test-test,test:test-test";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "buildFilterQuery", test1);
		Assert.assertEquals(" AND  IN ('test', 'test')  AND  IN ('test', 'test') ", actual);

	}

	/*
	 * @Test public void buildFilterQueryWithParams(){ final int begin =0; final
	 * boolean isMeters =true; final String filterList ="Test";
	 * 
	 * String actual ="test"; List<String> eventLoadIdsList=new ArrayList<>();
	 * eventLoadIdsList.add("2004368"); eventLoadIdsList.add("2004370");
	 * eventLoadIdsList.add("2004372"); eventLoadIdsList.add("2004446");
	 * String[] meterArry = new String[eventLoadIdsList.size()]; meterArry =
	 * eventLoadIdsList.toArray(meterArry);
	 * 
	 * final String test1 = "test1:test-test,test:test-test"; actual =
	 * ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo,
	 * "buildFilterQuery",meterArry,begin,isMeters,filterList); Assert.
	 * assertEquals(" AND  IN ('test', 'test')  AND  IN ('test', 'test') ",
	 * actual);
	 * 
	 * }
	 */
	@Test
	public void getDatabaseFieldName() {

		String fieldName = "meterEventLoadId";
		String actual = "METER_EVENT_LOAD_ID";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("METER_EVENT_LOAD_ID", actual);
	}

	@Test
	public void getDatabaseFieldNameTest() {
		String fieldName = "borough";
		String actual = "boro_muni";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("boro_muni", actual);
	}

	@Test
	public void getDatabaseFieldName1() {

		String fieldName = "eventName";
		String actual = "event_name";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("event_name", actual);
	}

	@Test
	public void getDatabaseFieldName2() {

		String fieldName = "demand";
		String actual = "demand";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("demand", actual);
	}

	@Test
	public void getDatabaseFieldName3() {

		String fieldName = "feeder";
		String actual = "feeder";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("feeder", actual);
	}

	@Test
	public void getDatabaseFieldName4() {

		String fieldName = "buildingNumber";
		String actual = "building_num";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("building_num", actual);
	}

	@Test
	public void getDatabaseFieldName5() {

		String fieldName = "serviceAddress";
		String actual = "service_address";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("service_address", actual);
	}

	@Test
	public void getDatabaseFieldName6() {

		String fieldName = "customerZipCode";
		String actual = "cust_zip_code";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("cust_zip_code", actual);
	}

	@Test
	public void getDatabaseFieldName7() {

		String fieldName = "meterNumber";
		String actual = "meter_number";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("meter_number", actual);
	}

	@Test
	public void getDatabaseFieldName8() {

		String fieldName = "accountNumber";
		String actual = "account_number";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("account_number", actual);
	}

	@Test
	public void getDatabaseFieldName9() {

		String fieldName = "network";
		String actual = "network";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("network", actual);
	}

	@Test
	public void getDatabaseFieldName10() {

		String fieldName = "eventStatus";
		String actual = "FK_EVENT_STATUS";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("FK_EVENT_STATUS", actual);
	}

	@Test
	public void getDatabaseFieldName11() {

		String fieldName = "vcapInsertTime";
		String actual = "VCAP_INSERT_TIME";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("VCAP_INSERT_TIME", actual);
	}

	@Test
	public void getDatabaseFieldName12() {

		String fieldName = "transformer";
		String actual = "TRANSFORMER";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("TRANSFORMER", actual);
	}

	@Test
	public void getDatabaseFieldName13() {

		String fieldName = "structureName";
		String actual = "STRUCTURE";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersFinalizeRepo, "getDatabaseFieldName", fieldName);
		Assert.assertEquals("STRUCTURE", actual);
	}
}
