
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddPingJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddPingJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JobInfo" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}JobInfoType"/&gt;
 *         &lt;element name="PingJob" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}PingJobType"/&gt;
 *         &lt;element name="Schedule" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ScheduleChoiceType"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="AutoActivate" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddPingJobType", propOrder = {
    "jobInfo",
    "pingJob",
    "schedule"
})
@XmlSeeAlso({
    EditPingJobType.class
})
public class AddPingJobType {

    @XmlElement(name = "JobInfo", required = true)
    protected JobInfoType jobInfo;
    @XmlElement(name = "PingJob", required = true)
    protected PingJobType pingJob;
    @XmlElement(name = "Schedule", required = true)
    protected ScheduleChoiceType schedule;
    @XmlAttribute(name = "AutoActivate")
    protected Boolean autoActivate;

    /**
     * Gets the value of the jobInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JobInfoType }
     *     
     */
    public JobInfoType getJobInfo() {
        return jobInfo;
    }

    /**
     * Sets the value of the jobInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JobInfoType }
     *     
     */
    public void setJobInfo(JobInfoType value) {
        this.jobInfo = value;
    }

    /**
     * Gets the value of the pingJob property.
     * 
     * @return
     *     possible object is
     *     {@link PingJobType }
     *     
     */
    public PingJobType getPingJob() {
        return pingJob;
    }

    /**
     * Sets the value of the pingJob property.
     * 
     * @param value
     *     allowed object is
     *     {@link PingJobType }
     *     
     */
    public void setPingJob(PingJobType value) {
        this.pingJob = value;
    }

    /**
     * Gets the value of the schedule property.
     * 
     * @return
     *     possible object is
     *     {@link ScheduleChoiceType }
     *     
     */
    public ScheduleChoiceType getSchedule() {
        return schedule;
    }

    /**
     * Sets the value of the schedule property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScheduleChoiceType }
     *     
     */
    public void setSchedule(ScheduleChoiceType value) {
        this.schedule = value;
    }

    /**
     * Gets the value of the autoActivate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isAutoActivate() {
        if (autoActivate == null) {
            return false;
        } else {
            return autoActivate;
        }
    }

    /**
     * Sets the value of the autoActivate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAutoActivate(Boolean value) {
        this.autoActivate = value;
    }

}
