/*package com.coned.ls.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadAction;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.JdbcMetersEventValidateRepository;
import com.coned.ls.repository.MeterEventValidateRepository;
import com.coned.ls.repository.MetersEventFinalizeRepository;
import com.coned.ls.repository.OpenEventRepository;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
//@ContextConfiguration(classes={ApiEngineApplication.class})
@ContextConfiguration(classes={RCCApplication.class})
@AutoConfigureMockMvc
public class OpenEventServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private OpenEventService openEventService = new OpenEventServiceImpl();
	
	@Mock
	private OpenEventRepository openEventRepository;
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	private MeterEventLoad  meterEventLoad;
	
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		meterEventLoad = meterEventLoadC;
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
	}
	
	@Test
	public void getOpenEventTest(){
		Set<String> borough = new HashSet<>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		Set<String> openEvent2 = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(openEvent2, borough);
	}
	@Test
	public void getOpenEventException(){
		Set<String> borough = new HashSet<>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		Set<String> responseBorough = new HashSet<>();
		responseBorough.add("A");
		borough.clear();
		Set<String> openEvent2 = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(openEvent2, borough);
	}
	
	
	@Test
	public void getOpenEventForEventTest(){
		Set<String> borough = new HashSet<>();
		borough.add("B");borough.add("G");borough.add("E");borough.add("A");
		Mockito.when(openEventRepository.getNewAndActiveBorough()).thenReturn(borough);
		Set<String> openEvent2 = openEventService.getNewAndActiveBorough();
		Assert.assertEquals(openEvent2, borough);
	}
	
	@Test
	public void getOpenEventForEventException(){
		Set<String> event = new HashSet<>();
		event.add("SheepsheadBaySampleData7.27.20-1701");event.add("SheepsheadBaySampleData7.27.20-1703");event.add("SheepsheadBaySampleData7.27.20-1704");
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(event);
		Set<String> responseEvent = new HashSet<>();
		responseEvent.add("SheepsheadBaySampleData7.27.20-1701");
		Set<String> openEvent2 = openEventService.getNewAndActiveEvent();
		Assert.assertEquals(openEvent2, openEvent2);
	}
	
	
}  */
