/**
 * 
 */
package com.coned.odsListener.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

@Service
public class JMSErrorHandler implements ErrorHandler {
	private static Logger logger = LoggerFactory.getLogger(JMSErrorHandler.class);

	@Override
	public void handleError(Throwable err) {
		logger.error(err.getCause().getMessage());
	}
}
