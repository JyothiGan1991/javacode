package com.coned.jpa.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXPrincipal;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import javax.security.auth.Subject;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.apache.commons.codec.digest.DigestUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.coned.exception.ResourceMissingException;
import com.coned.model.FinalizeEventListDetails;
import com.coned.model.User;
import com.coned.service.BaseService;
import com.coned.service.ExecuteEventUtil;
import com.coned.service.FinalizedEventService;
import com.coned.um.controller.CustCallbackHandler;
import com.coned.um.controller.CustLoginConfig;
import com.coned.um.controller.LoginRequest;
import com.coned.um.controller.LoginResponseMapper;
import com.coned.um.controller.LogoutResponseMapper;
//import com.coned.um.controller.SearchDetailsModel;
import com.coned.util.AOCCWebUtil;

import weblogic.jndi.Environment;
import weblogic.management.MBeanHome;
import weblogic.management.security.authentication.AuthenticationProviderMBean;
import weblogic.management.security.authentication.UserAttributeReaderMBean;
import weblogic.management.security.authentication.UserReaderMBean;
import weblogic.security.providers.authentication.DefaultAuthenticatorMBean;

//@EnableEncryptableProperties
//@RequestMapping("/user")
@CrossOrigin
@RestController
public class UserMgmtController {
	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";

	//@Value("${aocc.app.name}")
	private String APP_NAME = "AOCCApp";
	private static final Logger logger = LoggerFactory.getLogger(UserMgmtController.class);

	/*@Value("${aocc.server.hostname}")
	private String hostname;
	@Value("${aocc.server.portnumber}")
	private String portString;

	@Value("${aocc.ldap.username}")
	private String ldapUsername;
	@Value("${aocc.ldap.password}")
	private String ldapPassword;*/

	/*private String hostname = System.getProperty("aocc.server.hostname");
	private String portString = System.getProperty("aocc.server.portnumber");

	private String ldapUsername = System.getProperty("aocc.ldap.username");
	private String ldapPassword = System.getProperty("aocc.ldap.password");*/
	
	private static MBeanServerConnection connection;
	private static JMXConnector connector;
	private static final ObjectName service = null;
	ObjectName[] atnProviders = null;
	ObjectName mBeanTypeService = null;

	@Autowired
	ExecuteEventUtil eutil;

	@Autowired
	AOCCWebUtil util;

	@Autowired
	private org.springframework.core.env.Environment env;

	@PersistenceContext
	private EntityManager em;

	@PostMapping("/users")
	@CrossOrigin
	@Transactional
	public Map<String, Object> createUser(@RequestBody Map<String, Object> payload) {
		logger.debug("---------------------- START - createUser ------------------------");
		Map<String, Object> response = new HashMap<>();
		try {
			response.put("result", FAILED);
			response.put("status", "other");
			String userName = (String) payload.get("userName");
			/*
			 * String firstName = (String) payload.get("firstName"); String lastName =
			 * (String) payload.get("lastName"); String email = (String)
			 * payload.get("email");
			 */
			Query q = null;
			String qstr = (String) env.getProperty("aocc.user.getUserByName");
			logger.debug("qstr? " + qstr);
			q = em.createNativeQuery(qstr);
			q.setParameter("userName", userName);
			boolean userExist = true;
			boolean isActive = true;
			try { 
				Object[] result = (Object[]) q.getSingleResult();
				logger.debug("userid? " + result[0] + " status? " + result[1]);
				int status = ((Number)result[1]).intValue();
				if(status != 1)
					isActive = false;
				response.put("result", FAILED);
				response.put("status", "user already exits");
			} catch (NoResultException e) {
				userExist = false;
			}
			
			String createdBy = "";
			Map<String, String> hmap = util.readAuthHeader();
			if (hmap != null) {
				if (hmap.containsKey("userName"))
					createdBy = hmap.get("userName");
			}
			q = null;
			qstr = (String) env.getProperty("aocc.user.getUserByName");
			logger.debug("qstr? " + qstr);
			q = em.createNativeQuery(qstr);
			q.setParameter("userName", createdBy);
			Object[] result = (Object[]) q.getSingleResult();
			int createdById = ((Number)result[0]).intValue();

			logger.debug(" createdById: " + createdById);
			
			String roleName = (String) payload.get("roleName");
			int role_id = 2;
			if (roleName.equalsIgnoreCase("Admin"))
				role_id = 1;
			else if (roleName.equalsIgnoreCase("Operator"))
				role_id = 2;
			
			logger.debug("userName? " + userName +" userExist? " + userExist + " isActive? "+isActive+" role_id? "+role_id);
			if(userExist && !isActive) {
				qstr = (String) env.getProperty("aocc.user.activeUserByName");
				String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
				logger.debug("qstr? " + qstr);
				q = em.createNativeQuery(qstr);
				q.setParameter("userName", userName);
				q.setParameter("status", 1);
				q.setParameter("roleId", role_id);
				q.setParameter("updatedBy", createdById);
				q.setParameter("updatedAt", updateAtStr);
				logger.debug("userName "+userName+" updateAt"+updateAtStr+" updatedBy? "+createdBy);
				logger.debug("updateUser - query " + qstr);
				int res = q.executeUpdate();
				logger.debug("---Update User-> Result: " + res);
				response.put("result", SUCCESS);
				response.put("status", "");
			}
			if (!userExist) {
				logger.debug(" userName: " + userName + " roleName: " + roleName + " createdBy: " + createdBy);
				if (userName.isEmpty()) {
					response.put("result", FAILED);
					response.put("status", "other");
				} else {
					q = null;
					qstr = (String) env.getProperty("aocc.user.createUser");
					logger.debug("qstr? " + qstr);
					q = em.createNativeQuery(qstr);
					q.setParameter("userName", userName.toUpperCase());
					q.setParameter("role_id", role_id);
					q.setParameter("createdBy", createdById);

					logger.debug("saveUser - query " + qstr);
					int res = q.executeUpdate();
					logger.debug("---Create User-> Result: " + res);

					response.put("result", SUCCESS);
					response.put("status", "");
					logger.debug("---------------------- END - createUser ------------------------");
				}
			}
		} catch (Exception e) {
			logger.debug("**Exception - " + e);
		}
		return response;
	}

    @PutMapping("/users/{username}")
	@CrossOrigin
	@Transactional
    public Map<String, Object> updateUser(@PathVariable("username") String username, @RequestBody Map<String, Object> payload) {
		logger.debug("---------------------- START - updateUser ------------------------");
		Map<String, Object> response = new HashMap<>();
		try {
			response.put("result", FAILED);
			response.put("status", "other");	
//			String userName = (String) payload.get("userName");

			Query q = null;
			String qstr = (String) env.getProperty("aocc.user.getUserByName");
			logger.debug("qstr? " + qstr);
			q = em.createNativeQuery(qstr);
			q.setParameter("userName", username);
			boolean userExist = true;
			try {
				Object[] result = (Object[]) q.getSingleResult();
				logger.debug("userid? " + result[0] + " status? " + result[1]);
			} catch (NoResultException e) {
				userExist = false;
			}
			
			String updatedBy = "";
			Map<String, String> hmap = util.readAuthHeader();
			if (hmap != null) {
				if (hmap.containsKey("userName"))
					updatedBy = hmap.get("userName");
			}
			q = null;
			qstr = (String) env.getProperty("aocc.user.getUserByName");
			logger.debug("qstr? " + qstr);
			q = em.createNativeQuery(qstr);
			q.setParameter("userName", updatedBy);
			logger.debug("updatedBy? "+updatedBy);
			Object[] result = (Object[]) q.getSingleResult();
			int updatedById = ((Number)result[0]).intValue();

			logger.debug(" createdById: " + updatedById);
			
			String roleName = (String) payload.get("roleName");
			int role_id = 2;
			if (roleName.equalsIgnoreCase("Admin"))
				role_id = 1;
			else if (roleName.equalsIgnoreCase("Operator"))
				role_id = 2;
			logger.debug("role_id? "+role_id);
			int status_id = 1;
			if(payload.get("isActive") != null) {
				boolean isActive = (boolean) payload.get("isActive");
				logger.debug("status? "+isActive);
				if (!isActive)
					status_id = 0;
			}
			
			logger.debug("userName? " + username +" userExist? " + userExist + " role_id? "+role_id);
			if(userExist) {
				qstr = (String) env.getProperty("aocc.user.updateUserByName");
				String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
				logger.debug("qstr? " + qstr);
				q = em.createNativeQuery(qstr);
				q.setParameter("userName", username);
				q.setParameter("roleId", role_id);
				q.setParameter("updatedBy", updatedById);
				q.setParameter("updatedAt", updateAtStr);
				logger.debug("userName "+username+" updateAt? "+updateAtStr+" updatedBy? "+updatedBy+" updatedById? "+updatedById);
				logger.debug("updateUser - query " + qstr);
				int res = q.executeUpdate();
				logger.debug("---Update User-> Result: " + res);
				response.put("result", SUCCESS);
				response.put("status", "");
			} else {
				response.put("result", FAILED);
				response.put("status", "other");			
			}
		} catch (Exception e) {
			logger.debug("**Exception - " + e);
		}
		logger.debug("---------------------- End - updateUser ------------------------");
		return response;
    }
	
    @DeleteMapping("/users/{username}")
 	@CrossOrigin
 	@Transactional
     public Map<String, Object> deleteUser(@PathVariable("username") String username) {
 		logger.debug("---------------------- START - deleteUser ------------------------");
 		Map<String, Object> response = new HashMap<>();
 		try {
 			response.put("result", FAILED);
 			response.put("status", "other");	

 			Query q = null;
 			String qstr = (String) env.getProperty("aocc.user.getUserByName");
 			logger.debug("qstr? " + qstr);
 			q = em.createNativeQuery(qstr);
 			q.setParameter("userName", username);
 			boolean userExist = true;
 			try {
 				Object[] result = (Object[]) q.getSingleResult();
 				logger.debug("userid? " + result[0] + " status? " + result[1]);
 			} catch (NoResultException e) {
 				userExist = false;
 			}
 			
 			String updatedBy = "";
 			Map<String, String> hmap = util.readAuthHeader();
 			if (hmap != null) {
 				if (hmap.containsKey("userName"))
 					updatedBy = hmap.get("userName");
 			}
 			q = null;
 			qstr = (String) env.getProperty("aocc.user.getUserByName");
 			logger.debug("qstr? " + qstr);
 			q = em.createNativeQuery(qstr);
 			q.setParameter("userName", updatedBy);
 			Object[] result = (Object[]) q.getSingleResult();
 			int updatedById = ((Number)result[1]).intValue();

 			logger.debug(" createdById: " + updatedById);
 			
 			logger.debug("userName? " + username +" userExist? " + userExist );
 			if(userExist) {
 				qstr = (String) env.getProperty("aocc.user.disableUserByName");
 				String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
 				logger.debug("qstr? " + qstr);
 				q = em.createNativeQuery(qstr);
 				q.setParameter("userName", username);
 				q.setParameter("status", 0);
 				q.setParameter("updatedBy", updatedById);
 				q.setParameter("updatedAt", updateAtStr);
 				logger.debug("userName "+username+" updateAt? "+updateAtStr+" updatedBy? "+updatedBy+" updatedById? "+updatedById);
 				logger.debug("updateUser - query " + qstr);
 				int res = q.executeUpdate();
 				logger.debug("---Update User-> Result: " + res);
 				response.put("result", SUCCESS);
 				response.put("status", "");
 			} else {
 				response.put("result", FAILED);
 				response.put("status", "other");			
 			}
 		} catch (Exception e) {
 			logger.debug("**Exception - " + e);
 		}
 		logger.debug("---------------------- End - deleteUser ------------------------");
 		return response;
     }
    
	@GetMapping("/users")
	@CrossOrigin
	@Transactional
	public List getUsers() {
		logger.debug("---------------------- START - " + util.getMethName() + " ------------------------");
		try {
			Query q = null;
			String qstr = (String) env.getProperty("aocc.user.getUsers");
			
			logger.debug("qstr? " + qstr);
			q = em.createNativeQuery(qstr);
			List<Object[]> rows = q.getResultList();
			List<Map<String, Object>> result = new ArrayList<>(rows.size());
			for (Object[] row : rows) {
				logger.debug(((BigDecimal) row[0]).intValue() + "" + (String) row[1] + ""
						+ ((BigDecimal) row[2]).intValue() + " " + (String) row[3]);

				int userId = ((BigDecimal) row[0]).intValue();
				String userName = (String) row[1];
				int isActive = ((BigDecimal) row[2]).intValue();
				String isActiveStr = "Active";
				if (isActive != 1)
					isActiveStr = "InActive";
				String roleName = (String) row[3];
				String createdBy = "";
				if (row[4] != null)
					createdBy = (String) row[4];

				Date createdAt = (Date) row[6];
				String createdAtStr = "";
				if (createdAt != null)
					createdAtStr = createdAt.toString();

				String updatedBy = "";
				if (row[5] != null)
					createdBy = (String) row[5];

				Date updatedAt = (Date) row[7];
				String updatedAtStr = "";
				if (updatedAt != null)
					updatedAtStr = updatedAt.toString();

				Map<String, Object> user = new HashMap();
				user.put("updatedAt", updatedAtStr);
				user.put("createdAt", createdAtStr);
				user.put("updatedBy", updatedBy);
				user.put("createdBy", createdBy);
				user.put("roleName", roleName);
				user.put("isActive", isActiveStr);
				user.put("userName", userName);
				user.put("userId", userId);

				result.add(user);
			}

			logger.debug(" -- users size: " + rows.size());
			return result;
//			int createdById = ((Number)q.getSingleResult()).intValue();
		} catch (Exception e) {
			logger.debug("**Exception " + util.getMethName() + " - " + e);
		}
		return null;
	}

	@GetMapping("/adusers/{username}")
	public ResponseEntity<Map<String, Object>> listLDAPUsers(@PathVariable("username") String username) {
		logger.debug(" ---- START listLDAPUsers ----- ");
		UserMgmtController c = new UserMgmtController();
		Map<String, Object> users = new HashMap<String, Object>();
		try {
			initConnection();
			c.getAuthprovider();

			ObjectName userReader = c.getUserreader();
			ObjectName userAttrReader = c.getUserAttrReader();
			String uCurName = (String) connection.invoke(userReader, "listUsers", new Object[] { username, 100 },
					new String[] { "java.lang.String", "java.lang.Integer" });
			logger.debug(uCurName);

			boolean hasCurrent = (Boolean) connection.invoke(userReader, "haveCurrent", new Object[] { uCurName },
					new String[] { "java.lang.String" });
			logger.debug("---- before loop hasCurrent? " + hasCurrent);
			boolean userExists = false;

			while (hasCurrent) {
				userExists = (boolean) connection.invoke(userReader, "userExists", new Object[] { username },
						new String[] { "java.lang.String" });
				username = (String) connection.invoke(userReader, "getCurrentName", new Object[] { uCurName },
						new String[] { "java.lang.String" });

				logger.debug("  -- user? " + username + " userExists? " + userExists);

				/*
				 * c.getAuthprovider(); user = (String) connection.invoke(userAttrReader,
				 * "getUserAttributeValue", new Object[] { user, "mail" }, new String[] {
				 * "java.lang.String", "java.lang.String" });
				 * 
				 * user = (String) connection.invoke(userReader, "getUserDescription", new
				 * Object[] { user }, new String[] { "java.lang.String" });
				 * logger.debug("  -- getUserAttributeValue? " + user);
				 */

				/*
				 * connection.invoke(userReader, "advance", new Object[] { uCurName }, new
				 * String[] { "java.lang.String" }); hasCurrent = (Boolean)
				 * connection.invoke(userReader, "haveCurrent", new Object[] { uCurName }, new
				 * String[] { "java.lang.String" });
				 */
				break;
			}
			users.put("userName", username);
			users.put("userExists", userExists);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception listLDAPUsers: " + e);
		}
		logger.debug(" ---- END listLDAPUsers ----- ");
		return ResponseEntity.ok().body(users);
	}

	public void initConnection() throws Exception {
		logger.debug(" ---- START initConnection() ---- ");
		FileInputStream fis = null;
		try {
			getUserName();
			String protocol = "t3";
			Properties prop = null;
			String path = env.getProperty("config.file.path");
			fis = new FileInputStream(path);
			prop = new Properties();
			prop.load(fis);
			String hostname = prop.getProperty("weblogic.jmx.host");
			String portString = prop.getProperty("weblogic.jmx.port");
			logger.debug("hostname: " + hostname + " portString: " + portString);

			String userName = prop.getProperty("ldap.search.user");
			String password = prop.getProperty("ldap.search.user.pwd");

//			logger.debug("userName: "+userName+" password: "+password);

			Integer portInteger = Integer.valueOf(portString);
			int port = portInteger.intValue();
			String jndiroot = "/jndi/";
			String mserver = "weblogic.management.mbeanservers.domainruntime";
			JMXServiceURL serviceURL = new JMXServiceURL(protocol, hostname, port, jndiroot + mserver);

			Hashtable h = new Hashtable();
			logger.debug(" ---- Username? " + userName);
			h.put(Context.SECURITY_PRINCIPAL, userName);
			h.put(Context.SECURITY_CREDENTIALS, password);
			h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
			h.put("jmx.remote.x.request.waiting.timeout", new Long(10000));
			connector = JMXConnectorFactory.connect(serviceURL, h);
			connection = connector.getMBeanServerConnection();
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			throw new Exception(fnfe.getMessage());
		} catch (IOException ioe) {
			ioe.printStackTrace();
			throw new Exception(ioe.getMessage());
		} catch (Exception e) {
			logger.error("**Exception initConnection(): " + e);
			throw e;
		} finally {
			fis.close();
		}
		logger.debug(" ---- END initConnection() ----- ");
	}

	private String getUserName() {
		logger.debug("---------------------- START - " + util.getMethName() + " ------------------------");
		AccessControlContext acc = AccessController.getContext();
		Subject subject = Subject.getSubject(acc);
		logger.debug("subject? " + subject);
		if (subject != null) {
			Set<JMXPrincipal> principals = subject.getPrincipals(JMXPrincipal.class);
			JMXPrincipal principal = principals.iterator().next();
			logger.debug("principal " + principal);
			logger.debug("principal " + principal.getName());
			return principal.getName();
		}
		logger.debug("---------------------- END - " + util.getMethName() + " ------------------------");
		return "";
	}

	ObjectName[] getAuthprovider() {
		logger.debug("---- START getAuthprovider() ----");
		try {
			mBeanTypeService = new ObjectName(
					"com.bea:Name=MBeanTypeService,Type=weblogic.management.mbeanservers.MBeanTypeService");
			ObjectName service = new ObjectName(
					"com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
			ObjectName domainMBean = (ObjectName) connection.getAttribute(service, "DomainConfiguration");
			ObjectName securityConfiguration = (ObjectName) connection.getAttribute(domainMBean,
					"SecurityConfiguration");
			// DefaultRealm
			ObjectName defaultRealm = (ObjectName) connection.getAttribute(securityConfiguration, "DefaultRealm");
			logger.debug("defaultRealm? " + defaultRealm);
			atnProviders = (ObjectName[]) connection.getAttribute(defaultRealm, "AuthenticationProviders");
//			atnProviders.remove(int index);
			logger.debug("atnProviders? " + atnProviders.length);
			logger.debug("atnProviders[0]? " + atnProviders[0] + " atnProviders[1]: " + atnProviders[1]
					+ " atnProviders[2]? " + atnProviders[2]);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getAuthprovider(): " + e);
		}
		logger.debug("---- END getAuthprovider() ----");
		return atnProviders;
	}

	ObjectName getUserreader() {
		logger.debug("---- START getUserreader() ----");
		ObjectName userReader = null;
		try {
			for (ObjectName provider : atnProviders) {
				if (userReader == null) {
					ModelMBeanInfo info = (ModelMBeanInfo) connection.getMBeanInfo(provider);
					String className = (String) info.getMBeanDescriptor().getFieldValue("interfaceClassName");
					logger.debug("className? " + className);
					if (className != null) {
						String[] beans = (String[]) connection.invoke(mBeanTypeService, "getSubtypes",
								new Object[] { "weblogic.management.security.authentication.UserReaderMBean" },
								new String[] { "java.lang.String" });
//						logger.debug("beans? "+beans.toString());
						for (String bean : beans) {
							logger.debug("bean? " + bean);
							if (bean.equals(className)) {
								userReader = provider;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getUserreader(): " + e);
		}
		logger.debug("---- END getUserreader() ----");
		return userReader;
	}

	ObjectName getUserAttrReader() {
		logger.debug("---- START getUserAttrReader() ----");
		ObjectName userAttrReader = null;
		try {
			for (ObjectName provider : atnProviders) {
				if (userAttrReader == null) {
					ModelMBeanInfo info = (ModelMBeanInfo) connection.getMBeanInfo(provider);
					String className = (String) info.getMBeanDescriptor().getFieldValue("interfaceClassName");
					logger.debug("className? " + className);
					if (className != null) {
						String[] beans = (String[]) connection.invoke(mBeanTypeService, "getSubtypes",
								new Object[] { "weblogic.management.security.authentication.UserAttributeReaderMBean" },
								new String[] { "java.lang.String" });
//						logger.debug("beans? "+beans.toString());
						for (String bean : beans) {
							logger.debug("bean? " + bean);
							if (bean.equals(className)) {
								userAttrReader = provider;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("** Exception getUserAttrReader(): " + e);
		}
		logger.debug("---- END getUserAttrReader() ----");
		return userAttrReader;
	}

//	@GetMapping(value = "/listUsers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<String> listUsers() {
		logger.debug("--- START listUsers() ---");
		MBeanHome home = null;
		try {

			Hashtable env = new Hashtable(5);
			env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
			env.put(Context.PROVIDER_URL, "t3://localhost:7001");
			/*
			 * env.put(Context.SECURITY_PRINCIPAL, "weblogic");
			 * env.put(Context.SECURITY_CREDENTIALS, "");
			 */
			Context ctx = new InitialContext(env);

			/*
			 * Environment env = new Environment();
			 * env.setProviderUrl("t3://localhost:7001");
			 * env.setSecurityPrincipal(ldapUsername);
			 * env.setSecurityCredentials(ldapPassword); Context ctx =
			 * env.getInitialContext();
			 */
			home = (MBeanHome) ctx.lookup("weblogic.management.adminhome");

//			home = (MBeanHome) ctx.lookup("weblogic.management.adminhome");

			weblogic.management.security.RealmMBean rmBean = home.getActiveDomain().getSecurityConfiguration()
					.getDefaultRealm();

			AuthenticationProviderMBean[] authenticationBeans = rmBean.getAuthenticationProviders();

			DefaultAuthenticatorMBean defaultAuthenticationMBean = (DefaultAuthenticatorMBean) authenticationBeans[0];
			UserAttributeReaderMBean userAttrReaderMBean = (UserAttributeReaderMBean) defaultAuthenticationMBean;
			logger.debug("email? " + userAttrReaderMBean.getUserAttributeValue("VARANGALR", "mail"));

			UserReaderMBean userReaderMBean = (UserReaderMBean) defaultAuthenticationMBean;

			String userCurName = userReaderMBean.listUsers("*", 100);
			while (userReaderMBean.haveCurrent(userCurName)) {
				String user = userReaderMBean.getCurrentName(userCurName);
				logger.debug("\n User: " + user);
				userReaderMBean.advance(userCurName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("**Exception: " + e);
		}
		logger.debug("--- END listUsers() ---");
		return new ResponseEntity<String>("List Users", HttpStatus.OK);
	}

	/*@GetMapping("/search")
	public String search(@RequestParam String username) {
		logger.debug("--- START search() ---");
		MBeanHome home = null;

		String hostname = "localhost";
		String portString = "7001";
		String uname = "";
		String password = "";

		JMXConnector connector;
		final ObjectName service = null;
		ObjectName[] atnProviders = null;
		ObjectName mBeanTypeService = null;

		try {
			String protocol = "t3";
			Integer portInteger = Integer.valueOf(portString);
			int port = portInteger.intValue();
			String jndiroot = "/jndi/";
			String mserver = "weblogic.management.mbeanservers.domainruntime";
			JMXServiceURL serviceURL = new JMXServiceURL(protocol, hostname, port, jndiroot + mserver);

			Hashtable h = new Hashtable();
			h.put(Context.SECURITY_PRINCIPAL, "aoccsampleuser");
			h.put(Context.SECURITY_CREDENTIALS, "");
			h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
			h.put("jmx.remote.x.request.waiting.timeout", new Long(10000));
			connector = JMXConnectorFactory.connect(serviceURL, h);
			connection = connector.getMBeanServerConnection();
			logger.debug(" connection: " + connection);
			mBeanTypeService = new ObjectName(
					"com.bea:Name=MBeanTypeService,Type=weblogic.management.mbeanservers.MBeanTypeService");

			AuthenticationProviderMBean[] authenticationBeans = (AuthenticationProviderMBean[]) getAuthprovider();

			DefaultAuthenticatorMBean defaultAuthenticationMBean = (DefaultAuthenticatorMBean) authenticationBeans[0];
			UserAttributeReaderMBean userAttrReaderMBean = (UserAttributeReaderMBean) defaultAuthenticationMBean;
			logger.debug("email? " + userAttrReaderMBean.getUserAttributeValue("VARANGALR", "mail"));

			UserReaderMBean userReaderMBean = (UserReaderMBean) defaultAuthenticationMBean;

			String userCurName = userReaderMBean.listUsers("*", 100);
			while (userReaderMBean.haveCurrent(userCurName)) {
				String user = userReaderMBean.getCurrentName(userCurName);
				logger.debug("\n User: " + user);
				userReaderMBean.advance(userCurName);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.debug("--- END search() ---");
		return "";
	}*/

}