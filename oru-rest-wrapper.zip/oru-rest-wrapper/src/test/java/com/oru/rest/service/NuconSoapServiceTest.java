package com.oru.rest.service;

import com.oru.rest.dto.AccountRequest;
import com.oru.rest.dto.ElectricInfoDto;
import com.oru.rest.dto.SendToNrgRequest;
import com.oru.rest.exception.SoapServiceException;
import com.oru.rest.service.nucon.NuconSoapService;
import com.oru.soap.nucon.generated.ElectricInfo;
import com.oru.soap.nucon.generated.NuconWS;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NuconSoapServiceTest {

    @Mock private NuconWS soapClient;
    private NuconSoapService service;

    @BeforeEach
    void setUp() { service = new NuconSoapService(soapClient); }

    @Test
    void byAccount_success() {
        ElectricInfo info = new ElectricInfo();
        info.setCircuit("C1");
        info.setInvolt(120.0);
        when(soapClient.getElectricInfoByAccount("A1")).thenReturn(info);
        ElectricInfoDto dto = service.getElectricInfoByAccount(new AccountRequest("A1"));
        assertEquals("C1", dto.getCircuit());
        assertEquals(120.0, dto.getInvolt(), 0.001);
    }

    @Test
    void byAccount_error() {
        when(soapClient.getElectricInfoByAccount(anyString())).thenThrow(new RuntimeException("down"));
        assertThrows(SoapServiceException.class, () -> service.getElectricInfoByAccount(new AccountRequest("x")));
    }

    @Test
    void sendToNRG_success() {
        doNothing().when(soapClient).sendToNRG(anyString(), any(), anyString());
        service.sendToNRG(new SendToNrgRequest("a", 1, "b"));
        verify(soapClient).sendToNRG("a", 1, "b");
    }
}
