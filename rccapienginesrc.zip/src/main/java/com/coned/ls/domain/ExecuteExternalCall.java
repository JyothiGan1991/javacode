package com.coned.ls.domain;

public class ExecuteExternalCall {

	private String callName;
	private String borough;
	private String eventName;
	
	
	public String getCallName() {
		return callName;
	}
	public void setCallName(String callName) {
		this.callName = callName;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	public ExecuteExternalCall() {
		super();
	}
	
	
}
