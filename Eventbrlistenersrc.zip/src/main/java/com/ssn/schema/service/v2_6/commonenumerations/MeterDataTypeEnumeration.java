
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterDataTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MeterDataTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="METER_DATA_TYPE_INTERVAL"/>
 *     &lt;enumeration value="METER_DATA_TYPE_REGISTER"/>
 *     &lt;enumeration value="METER_DATA_TYPE_SECURITYLOG"/>
 *     &lt;enumeration value="METER_DATA_TYPE_GENERIC"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MeterDataTypeEnumeration")
@XmlEnum
public enum MeterDataTypeEnumeration {

    METER_DATA_TYPE_INTERVAL("METER_DATA_TYPE_INTERVAL"),
    METER_DATA_TYPE_REGISTER("METER_DATA_TYPE_REGISTER"),
    METER_DATA_TYPE_SECURITYLOG("METER_DATA_TYPE_SECURITYLOG"),
    METER_DATA_TYPE_GENERIC("METER_DATA_TYPE_GENERIC"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MeterDataTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MeterDataTypeEnumeration fromValue(String v) {
        for (MeterDataTypeEnumeration c: MeterDataTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
