package com.oru.poe.rest.config;

import com.oru.poe.soap.generated.POEWebServicesSEI;
import com.oru.poe.soap.generated.POEWebServicesService;
import jakarta.xml.ws.BindingProvider;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SoapClientConfig {

    private static final Logger log = LoggerFactory.getLogger(SoapClientConfig.class);

    @Value("${poe.soap.endpoint-url}")
    private String endpointUrl;

    @Value("${poe.soap.connect-timeout-ms:5000}")
    private long connectTimeoutMs;

    @Value("${poe.soap.read-timeout-ms:10000}")
    private long readTimeoutMs;

    @Bean
    public POEWebServicesSEI poeWebServicesClient() {
        log.info("Creating SOAP client for endpoint: {}", endpointUrl);

        POEWebServicesService service = new POEWebServicesService();
        POEWebServicesSEI port = service.getPOEWebServicesPort();

        BindingProvider bp = (BindingProvider) port;
        bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

        // Configure timeouts via CXF
        try {
            org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(connectTimeoutMs);
            httpClientPolicy.setReceiveTimeout(readTimeoutMs);
            http.setClient(httpClientPolicy);
        } catch (Exception e) {
            log.warn("Could not configure CXF HTTP timeouts: {}", e.getMessage());
        }

        return port;
    }
}
