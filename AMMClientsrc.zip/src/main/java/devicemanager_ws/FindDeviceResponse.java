
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindDeviceResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindDeviceResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqDeviceStateID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType"/&gt;
 *         &lt;element name="UtilDeviceStateID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType"/&gt;
 *         &lt;element name="LastOpStateChangeTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType"/&gt;
 *         &lt;element name="MfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CatalogNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountryID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="Latitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="Longitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointLatitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointLongitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="WANType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}WANType" minOccurs="0"/&gt;
 *         &lt;element name="WANIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANPhoneNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPPool" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RFChannel" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RelayType" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="RelayTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BridgeTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UtilPremiseID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UIQProgramID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ProgramSeal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsSelected" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="IsReadOnly" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="UtilServicePointID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Suspect" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SuspectReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FormType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AmpClass" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="VoltType" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="LastCommTimeSearch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsMicroAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="IsMicroAPAPMode" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="IsSocketAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindDeviceResponse", propOrder = {
    "name",
    "uiqDeviceStateID",
    "utilDeviceStateID",
    "lastOpStateChangeTime",
    "didType",
    "didSubtype",
    "mfgModel",
    "mfgName",
    "utilDeviceID",
    "macID",
    "serialNumber",
    "catalogNumber",
    "ipAddress",
    "address1",
    "address2",
    "city",
    "state",
    "postalCode",
    "countryID",
    "latitude",
    "longitude",
    "servicePointLatitude",
    "servicePointLongitude",
    "wanType",
    "wanipAddress",
    "wanPhoneNum",
    "gatewayIPPool",
    "rfChannel",
    "relayType",
    "relayTypeName",
    "imuTypeName",
    "bridgeTypeName",
    "billingCycle",
    "utilPremiseID",
    "locationID",
    "uiqProgramID",
    "programSeal",
    "isSelected",
    "isReadOnly",
    "utilServicePointID",
    "suspect",
    "suspectReason",
    "meterTypeName",
    "formType",
    "baseType",
    "ampClass",
    "voltType",
    "lastCommTimeSearch",
    "isMicroAP",
    "isMicroAPAPMode",
    "isSocketAP"
})
public class FindDeviceResponse {

    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "UiqDeviceStateID", required = true)
    protected UIQDeviceStateType uiqDeviceStateID;
    @XmlElement(name = "UtilDeviceStateID", required = true)
    protected UtilDeviceStateType utilDeviceStateID;
    @XmlElement(name = "LastOpStateChangeTime")
    protected String lastOpStateChangeTime;
    @XmlElement(name = "DidType", required = true)
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype", required = true)
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "MfgModel")
    protected String mfgModel;
    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "UtilDeviceID", required = true)
    protected String utilDeviceID;
    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "SerialNumber", required = true)
    protected String serialNumber;
    @XmlElement(name = "CatalogNumber")
    protected String catalogNumber;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "Address1")
    protected String address1;
    @XmlElement(name = "Address2")
    protected String address2;
    @XmlElement(name = "City")
    protected String city;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "PostalCode")
    protected String postalCode;
    @XmlElement(name = "CountryID")
    protected Integer countryID;
    @XmlElement(name = "Latitude")
    protected Double latitude;
    @XmlElement(name = "Longitude")
    protected Double longitude;
    @XmlElement(name = "ServicePointLatitude")
    protected Double servicePointLatitude;
    @XmlElement(name = "ServicePointLongitude")
    protected Double servicePointLongitude;
    @XmlElement(name = "WANType")
    protected WANType wanType;
    @XmlElement(name = "WANIPAddress")
    protected String wanipAddress;
    @XmlElement(name = "WANPhoneNum")
    protected String wanPhoneNum;
    @XmlElement(name = "GatewayIPPool")
    protected String gatewayIPPool;
    @XmlElement(name = "RFChannel")
    protected Integer rfChannel;
    @XmlElement(name = "RelayType")
    protected Long relayType;
    @XmlElement(name = "RelayTypeName")
    protected String relayTypeName;
    @XmlElement(name = "IMUTypeName")
    protected String imuTypeName;
    @XmlElement(name = "BridgeTypeName")
    protected String bridgeTypeName;
    @XmlElement(name = "BillingCycle")
    protected String billingCycle;
    @XmlElement(name = "UtilPremiseID")
    protected String utilPremiseID;
    @XmlElement(name = "LocationID")
    protected Long locationID;
    @XmlElement(name = "UIQProgramID")
    protected Integer uiqProgramID;
    @XmlElement(name = "ProgramSeal")
    protected String programSeal;
    @XmlElement(name = "IsSelected")
    protected boolean isSelected;
    @XmlElement(name = "IsReadOnly")
    protected boolean isReadOnly;
    @XmlElement(name = "UtilServicePointID")
    protected String utilServicePointID;
    @XmlElement(name = "Suspect")
    protected Boolean suspect;
    @XmlElement(name = "SuspectReason")
    protected String suspectReason;
    @XmlElement(name = "MeterTypeName")
    protected String meterTypeName;
    @XmlElement(name = "FormType")
    protected String formType;
    @XmlElement(name = "BaseType")
    protected String baseType;
    @XmlElement(name = "AmpClass")
    protected Integer ampClass;
    @XmlElement(name = "VoltType")
    protected Integer voltType;
    @XmlElement(name = "LastCommTimeSearch")
    protected String lastCommTimeSearch;
    @XmlElement(name = "IsMicroAP")
    protected Boolean isMicroAP;
    @XmlElement(name = "IsMicroAPAPMode")
    protected Boolean isMicroAPAPMode;
    @XmlElement(name = "IsSocketAP", defaultValue = "false")
    protected Boolean isSocketAP;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the uiqDeviceStateID property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUiqDeviceStateID() {
        return uiqDeviceStateID;
    }

    /**
     * Sets the value of the uiqDeviceStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUiqDeviceStateID(UIQDeviceStateType value) {
        this.uiqDeviceStateID = value;
    }

    /**
     * Gets the value of the utilDeviceStateID property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceStateID() {
        return utilDeviceStateID;
    }

    /**
     * Sets the value of the utilDeviceStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceStateID(UtilDeviceStateType value) {
        this.utilDeviceStateID = value;
    }

    /**
     * Gets the value of the lastOpStateChangeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastOpStateChangeTime() {
        return lastOpStateChangeTime;
    }

    /**
     * Sets the value of the lastOpStateChangeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastOpStateChangeTime(String value) {
        this.lastOpStateChangeTime = value;
    }

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the mfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgModel() {
        return mfgModel;
    }

    /**
     * Sets the value of the mfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgModel(String value) {
        this.mfgModel = value;
    }

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the catalogNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCatalogNumber() {
        return catalogNumber;
    }

    /**
     * Sets the value of the catalogNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCatalogNumber(String value) {
        this.catalogNumber = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the countryID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCountryID() {
        return countryID;
    }

    /**
     * Sets the value of the countryID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCountryID(Integer value) {
        this.countryID = value;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLatitude() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLatitude(Double value) {
        this.latitude = value;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLongitude() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLongitude(Double value) {
        this.longitude = value;
    }

    /**
     * Gets the value of the servicePointLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getServicePointLatitude() {
        return servicePointLatitude;
    }

    /**
     * Sets the value of the servicePointLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setServicePointLatitude(Double value) {
        this.servicePointLatitude = value;
    }

    /**
     * Gets the value of the servicePointLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getServicePointLongitude() {
        return servicePointLongitude;
    }

    /**
     * Sets the value of the servicePointLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setServicePointLongitude(Double value) {
        this.servicePointLongitude = value;
    }

    /**
     * Gets the value of the wanType property.
     * 
     * @return
     *     possible object is
     *     {@link WANType }
     *     
     */
    public WANType getWANType() {
        return wanType;
    }

    /**
     * Sets the value of the wanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WANType }
     *     
     */
    public void setWANType(WANType value) {
        this.wanType = value;
    }

    /**
     * Gets the value of the wanipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANIPAddress() {
        return wanipAddress;
    }

    /**
     * Sets the value of the wanipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANIPAddress(String value) {
        this.wanipAddress = value;
    }

    /**
     * Gets the value of the wanPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANPhoneNum() {
        return wanPhoneNum;
    }

    /**
     * Sets the value of the wanPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANPhoneNum(String value) {
        this.wanPhoneNum = value;
    }

    /**
     * Gets the value of the gatewayIPPool property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPPool() {
        return gatewayIPPool;
    }

    /**
     * Sets the value of the gatewayIPPool property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPPool(String value) {
        this.gatewayIPPool = value;
    }

    /**
     * Gets the value of the rfChannel property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRFChannel() {
        return rfChannel;
    }

    /**
     * Sets the value of the rfChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRFChannel(Integer value) {
        this.rfChannel = value;
    }

    /**
     * Gets the value of the relayType property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRelayType() {
        return relayType;
    }

    /**
     * Sets the value of the relayType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRelayType(Long value) {
        this.relayType = value;
    }

    /**
     * Gets the value of the relayTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelayTypeName() {
        return relayTypeName;
    }

    /**
     * Sets the value of the relayTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelayTypeName(String value) {
        this.relayTypeName = value;
    }

    /**
     * Gets the value of the imuTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeName() {
        return imuTypeName;
    }

    /**
     * Sets the value of the imuTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeName(String value) {
        this.imuTypeName = value;
    }

    /**
     * Gets the value of the bridgeTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBridgeTypeName() {
        return bridgeTypeName;
    }

    /**
     * Sets the value of the bridgeTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBridgeTypeName(String value) {
        this.bridgeTypeName = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycle(String value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the utilPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilPremiseID() {
        return utilPremiseID;
    }

    /**
     * Sets the value of the utilPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilPremiseID(String value) {
        this.utilPremiseID = value;
    }

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

    /**
     * Gets the value of the uiqProgramID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUIQProgramID() {
        return uiqProgramID;
    }

    /**
     * Sets the value of the uiqProgramID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUIQProgramID(Integer value) {
        this.uiqProgramID = value;
    }

    /**
     * Gets the value of the programSeal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramSeal() {
        return programSeal;
    }

    /**
     * Sets the value of the programSeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramSeal(String value) {
        this.programSeal = value;
    }

    /**
     * Gets the value of the isSelected property.
     * 
     */
    public boolean isIsSelected() {
        return isSelected;
    }

    /**
     * Sets the value of the isSelected property.
     * 
     */
    public void setIsSelected(boolean value) {
        this.isSelected = value;
    }

    /**
     * Gets the value of the isReadOnly property.
     * 
     */
    public boolean isIsReadOnly() {
        return isReadOnly;
    }

    /**
     * Sets the value of the isReadOnly property.
     * 
     */
    public void setIsReadOnly(boolean value) {
        this.isReadOnly = value;
    }

    /**
     * Gets the value of the utilServicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePointID() {
        return utilServicePointID;
    }

    /**
     * Sets the value of the utilServicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePointID(String value) {
        this.utilServicePointID = value;
    }

    /**
     * Gets the value of the suspect property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSuspect() {
        return suspect;
    }

    /**
     * Sets the value of the suspect property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSuspect(Boolean value) {
        this.suspect = value;
    }

    /**
     * Gets the value of the suspectReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuspectReason() {
        return suspectReason;
    }

    /**
     * Sets the value of the suspectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuspectReason(String value) {
        this.suspectReason = value;
    }

    /**
     * Gets the value of the meterTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterTypeName() {
        return meterTypeName;
    }

    /**
     * Sets the value of the meterTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterTypeName(String value) {
        this.meterTypeName = value;
    }

    /**
     * Gets the value of the formType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormType() {
        return formType;
    }

    /**
     * Sets the value of the formType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormType(String value) {
        this.formType = value;
    }

    /**
     * Gets the value of the baseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseType() {
        return baseType;
    }

    /**
     * Sets the value of the baseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseType(String value) {
        this.baseType = value;
    }

    /**
     * Gets the value of the ampClass property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAmpClass() {
        return ampClass;
    }

    /**
     * Sets the value of the ampClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAmpClass(Integer value) {
        this.ampClass = value;
    }

    /**
     * Gets the value of the voltType property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getVoltType() {
        return voltType;
    }

    /**
     * Sets the value of the voltType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVoltType(Integer value) {
        this.voltType = value;
    }

    /**
     * Gets the value of the lastCommTimeSearch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastCommTimeSearch() {
        return lastCommTimeSearch;
    }

    /**
     * Sets the value of the lastCommTimeSearch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastCommTimeSearch(String value) {
        this.lastCommTimeSearch = value;
    }

    /**
     * Gets the value of the isMicroAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsMicroAP() {
        return isMicroAP;
    }

    /**
     * Sets the value of the isMicroAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsMicroAP(Boolean value) {
        this.isMicroAP = value;
    }

    /**
     * Gets the value of the isMicroAPAPMode property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsMicroAPAPMode() {
        return isMicroAPAPMode;
    }

    /**
     * Sets the value of the isMicroAPAPMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsMicroAPAPMode(Boolean value) {
        this.isMicroAPAPMode = value;
    }

    /**
     * Gets the value of the isSocketAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSocketAP() {
        return isSocketAP;
    }

    /**
     * Sets the value of the isSocketAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSocketAP(Boolean value) {
        this.isSocketAP = value;
    }

}
