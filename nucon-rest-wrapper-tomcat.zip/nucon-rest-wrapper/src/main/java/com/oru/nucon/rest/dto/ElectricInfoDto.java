package com.oru.nucon.rest.dto;

/**
 * REST DTO mirroring SOAP electricInfo complex type.
 */
public class ElectricInfoDto {

    private Integer partiality;
    private String circuit;
    private String code;
    private Integer hgridX;
    private Integer hgridY;
    private double involt;
    private String kva1;
    private String kva2;
    private String kva3;
    private String kyBa;
    private String kyPremNo;
    private String phase;
    private String phase3;
    private String segment;
    private String service;
    private Integer servpoleX;
    private Integer servpoleY;
    private Integer tranGridX;
    private Integer tranGridY;
    private String transformer;
    private String transtype;

    public Integer getPartiality() { return partiality; }
    public void setPartiality(Integer partiality) { this.partiality = partiality; }

    public String getCircuit() { return circuit; }
    public void setCircuit(String circuit) { this.circuit = circuit; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public Integer getHgridX() { return hgridX; }
    public void setHgridX(Integer hgridX) { this.hgridX = hgridX; }

    public Integer getHgridY() { return hgridY; }
    public void setHgridY(Integer hgridY) { this.hgridY = hgridY; }

    public double getInvolt() { return involt; }
    public void setInvolt(double involt) { this.involt = involt; }

    public String getKva1() { return kva1; }
    public void setKva1(String kva1) { this.kva1 = kva1; }

    public String getKva2() { return kva2; }
    public void setKva2(String kva2) { this.kva2 = kva2; }

    public String getKva3() { return kva3; }
    public void setKva3(String kva3) { this.kva3 = kva3; }

    public String getKyBa() { return kyBa; }
    public void setKyBa(String kyBa) { this.kyBa = kyBa; }

    public String getKyPremNo() { return kyPremNo; }
    public void setKyPremNo(String kyPremNo) { this.kyPremNo = kyPremNo; }

    public String getPhase() { return phase; }
    public void setPhase(String phase) { this.phase = phase; }

    public String getPhase3() { return phase3; }
    public void setPhase3(String phase3) { this.phase3 = phase3; }

    public String getSegment() { return segment; }
    public void setSegment(String segment) { this.segment = segment; }

    public String getService() { return service; }
    public void setService(String service) { this.service = service; }

    public Integer getServpoleX() { return servpoleX; }
    public void setServpoleX(Integer servpoleX) { this.servpoleX = servpoleX; }

    public Integer getServpoleY() { return servpoleY; }
    public void setServpoleY(Integer servpoleY) { this.servpoleY = servpoleY; }

    public Integer getTranGridX() { return tranGridX; }
    public void setTranGridX(Integer tranGridX) { this.tranGridX = tranGridX; }

    public Integer getTranGridY() { return tranGridY; }
    public void setTranGridY(Integer tranGridY) { this.tranGridY = tranGridY; }

    public String getTransformer() { return transformer; }
    public void setTransformer(String transformer) { this.transformer = transformer; }

    public String getTranstype() { return transtype; }
    public void setTranstype(String transtype) { this.transtype = transtype; }
}
