package com.coned.ls.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.coned.ls.domain.MeterEventFinalize;

import com.coned.ls.rest.RESTActionExecutor;

/**
 * 
 * Service class for RCC Disconnect finalize meters.
 *
 */
@Component
public class MeterEventFinalizeService {
	
	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	
	/*
	 * Method to finalize the meters for disconnect.
	 * 
	 * @param  meterEventFinalize MeterEventFinalize
	 * @param  adid 	 		  String
     * @return 			     	  ResponseEntity<String> 
	 */	
	public ResponseEntity<String> finalizeValidateMeter(final MeterEventFinalize meterEventFinalize, final String adid) throws Exception {
		return restActionExecutor.finalizeValidateMeters(meterEventFinalize, adid);
	}
}