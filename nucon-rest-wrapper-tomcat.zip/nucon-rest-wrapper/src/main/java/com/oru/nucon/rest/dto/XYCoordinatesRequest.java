package com.oru.nucon.rest.dto;

public class XYCoordinatesRequest {
    private String x;
    private String y;

    public XYCoordinatesRequest() {}
    public XYCoordinatesRequest(String x, String y) {
        this.x = x;
        this.y = y;
    }

    public String getX() { return x; }
    public void setX(String x) { this.x = x; }
    public String getY() { return y; }
    public void setY(String y) { this.y = y; }
}
