package com.coned.um.model;
/*
 * package com.coned.um.model;
 * 
 * import java.sql.Date;
 * 
 * import javax.persistence.CascadeType; import javax.persistence.Column; import
 * javax.persistence.Entity; import javax.persistence.GeneratedValue; import
 * javax.persistence.GenerationType; import javax.persistence.Id; import
 * javax.persistence.JoinColumn; import javax.persistence.ManyToOne; import
 * javax.persistence.Table;
 * 
 * import com.fasterxml.jackson.annotation.JsonBackReference;
 * 
 * @Entity
 * 
 * @Table(name = "ls_aocc_user_login") public class UserLogin extends AuditModel
 * {
 * 
 * @Id
 * 
 * @GeneratedValue(strategy = GenerationType.AUTO)
 * 
 * @Column(name = "id") private int id;
 * 
 * @Column(name = "username") private String username;
 * 
 * @Column(name = "token") private String token;
 * 
 * @Column(name = "login_time") private Date logintime;
 * 
 * @Column(name = "logout_time") private Date logouttime;
 * 
 * @Column(name = "status") private String status;
 * 
 * 
 * @JsonBackReference
 * 
 * @ManyToOne(cascade = CascadeType.ALL)
 * 
 * @JoinColumn(name = "role_id") private Role role;
 * 
 * public UserLogin() {
 * 
 * }
 * 
 * public UserLogin(String username, String token, Date logintime, Date
 * logouttime, String status) { this.username = username; this.token = token;
 * this.logintime = logintime; this.logouttime = logouttime; this.status =
 * status; }
 * 
 * public int getId() { return id; }
 * 
 * public void setId(int id) { this.id = id; }
 * 
 * public String getStatus() { return status; }
 * 
 * public void setStatus(String status) { this.status = status; }
 * 
 * public String getUsername() { return username; }
 * 
 * public void setUsername(String username) { this.username = username; }
 * 
 * public String getToken() { return token; }
 * 
 * public void setToken(String token) { this.token = token; }
 * 
 * public Date getLogintime() { return logintime; }
 * 
 * public void setLogintime(Date logintime) { this.logintime = logintime; }
 * 
 * public Date getLogouttime() { return logouttime; }
 * 
 * public void setLogouttime(Date logouttime) { this.logouttime = logouttime; }
 * 
 * 
 * public Role getRole() { return role; }
 * 
 * public void setRole(Role role) { this.role = role; }
 * 
 * 
 * @Override public String toString() { return "User [id=" + id + ", username="
 * + username + ", logintime=" + logintime + ", logouttime=" + logouttime +
 * ", status=" + status + "]"; } }
 */