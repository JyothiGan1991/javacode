
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceExportFileSegmentingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceExportFileSegmentingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="DevicesPerFile" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceExportFileSegmentingType", propOrder = {
    "devicesPerFile"
})
public class DeviceExportFileSegmentingType {

    @XmlElement(name = "DevicesPerFile")
    protected Integer devicesPerFile;

    /**
     * Gets the value of the devicesPerFile property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDevicesPerFile() {
        return devicesPerFile;
    }

    /**
     * Sets the value of the devicesPerFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDevicesPerFile(Integer value) {
        this.devicesPerFile = value;
    }

}
