
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OperatorEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OperatorEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SQL_EQUAL_TO"/&gt;
 *     &lt;enumeration value="SQL_NOT_EQUAL_TO"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "OperatorEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum OperatorEnumeration {

    SQL_EQUAL_TO("SQL_EQUAL_TO"),
    SQL_NOT_EQUAL_TO("SQL_NOT_EQUAL_TO"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    OperatorEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static OperatorEnumeration fromValue(String v) {
        for (OperatorEnumeration c: OperatorEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
