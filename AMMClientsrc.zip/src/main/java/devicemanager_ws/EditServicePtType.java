
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditServicePtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditServicePtType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ServicePtType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Account" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AccountType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointTransformer" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ServicePtTransformerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditServicePtType", propOrder = {
    "account",
    "servicePointTransformer"
})
public class EditServicePtType
    extends ServicePtType
{

    @XmlElement(name = "Account")
    protected AccountType account;
    @XmlElement(name = "ServicePointTransformer")
    protected ServicePtTransformerType servicePointTransformer;

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link AccountType }
     *     
     */
    public AccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountType }
     *     
     */
    public void setAccount(AccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the servicePointTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link ServicePtTransformerType }
     *     
     */
    public ServicePtTransformerType getServicePointTransformer() {
        return servicePointTransformer;
    }

    /**
     * Sets the value of the servicePointTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServicePtTransformerType }
     *     
     */
    public void setServicePointTransformer(ServicePtTransformerType value) {
        this.servicePointTransformer = value;
    }

}
