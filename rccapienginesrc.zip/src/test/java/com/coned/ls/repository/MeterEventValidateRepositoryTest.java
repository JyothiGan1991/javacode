package com.coned.ls.repository;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SimpleJdbcCallFactory;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { MeterEventValidateRepository.class })
@AutoConfigureMockMvc
public class MeterEventValidateRepositoryTest {

	@Autowired
	private WebApplicationContext wac;

	@MockBean
	private MeterEventValidateRepository meterEventValidateRepository;

	private OpenEvent openEvent;

	private List<MeterEventLoad> meterEventLoads;

	@InjectMocks
	private JdbcMetersEventValidateRepository jdbcMetersValidateRepo;

	private MockMvc mockMvc;

	MeterEventFinalize meterEventFinalize;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	protected JdbcTemplate sqlServerJdbcTemplate;

	@Mock
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	protected JdbcTemplate oracleCommonJdbcTemplate;
	
	@Mock
	private SimpleJdbcCall simpleJdbcCall;
	
	@Mock
	private SimpleJdbcCallFactory simpleJdbcCallFactory;

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcMetersValidateRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		ReflectionTestUtils.setField(jdbcMetersValidateRepo, "sqlServerJdbcTemplate", sqlServerJdbcTemplate);
		ReflectionTestUtils.setField(jdbcMetersValidateRepo, "starJdbcTemplate", starJdbcTemplate);
		ReflectionTestUtils.setField(jdbcMetersValidateRepo, "oracleCommonJdbcTemplate", oracleCommonJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();

		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);

		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);

		openEvent = new OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
	}

	@Test
	public void getValidateMeterTest() {

		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		Assert.assertEquals(meterEventLoads.get(0), meterEventLoad);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void getValidateMeterEventList() {
		MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper();
		List<MeterEventLoad> meterEventLoadList = new ArrayList<MeterEventLoad>();
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		/*
		 * Map<String, Object> map = new HashMap<String, Object>();
		 * map.put("test", ""); List<Map<String, Object>> queryResp = new
		 * ArrayList<Map<String,Object>>(); queryResp.add(map);
		 */
		String query = "select * from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,mel.building_num,mel.service_address,mel.cust_zip_code,mel.meter_number,mel.account_number,mel.network,mel.FK_EVENT_STATUS,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.TRANSFORMER,mel.STRUCTURE from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ";
		// Mockito.when(oracleJdbcTemplate.query(query, new Object[]{"Test",
		// "Test", 10,1},
		// Mockito.any(RowMapper.class))).thenReturn(meterEventLoadList);
		// Mockito.when(oracleJdbcTemplate.query(query, new Object[]{"Test",
		// "Test", 10,1}, RowMapper.class)).thenReturn(meterEventLoadList);
		// Mockito.when(oracleJdbcTemplate.query(Mockito.anyString(),Mockito.any(),
		// Mockito.any(RowMapper.class))).thenReturn(meterEventLoadList);
		mvrm = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getValidateMeterEventList", "B", "Test", 10, 1,
				"", "");
		Assert.assertNotNull(mvrm);
	}

	@Test
	public void searchMeters() {
		MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper(); 
		mvrm.setCountOfMeters(5);
		List<MeterEventLoad> meterEventLoadList = new ArrayList<MeterEventLoad>();
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setMeterEventLoadId(12344);
		meterEventLoad.setBorough("boro_muni");
		meterEventLoad.setEventName("event_name");
		meterEventLoad.setDemand("demand");
		meterEventLoad.setFeeder("feeder");
		meterEventLoad.setBuildingNumber("building_num");
		meterEventLoad.setServiceAddress("service_address");
		meterEventLoad.setCustomerZipCode("cust_zip_code");
		meterEventLoad.setMeterNumber("meter_number");
		meterEventLoad.setAccountNumber("account_number");
		meterEventLoad.setNetwork("network");
		meterEventLoad.setEventStatus(5);
		meterEventLoad.setVcapInsertTime("VCAP_INSERT_TIME");
		meterEventLoadList.add(meterEventLoad);
		mvrm.setMeterEventLoads(meterEventLoadList);
		
		
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("SheepsheadBaySampleData7.27.20-1300");
		meterSearch.setMeters("");
		meterSearch.setSubEvent("SheepsheadBaySampleData7.27.20-1300");

		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and mel.meter_number IN (" +  "" + ") ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[]{"B", "SheepsheadBaySampleData7.27.20-1300"},String.class)).thenReturn("10");
		
		String query2 = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and  mel.meter_number IN (" +  "" + ")";
		Mockito.when(oracleJdbcTemplate.queryForObject(query2, new Object[]{"B", "SheepsheadBaySampleData7.27.20-1300"},Integer.class)).thenReturn(10);
		
		mvrm = jdbcMetersValidateRepo.searchMeters(meterSearch);
		Assert.assertEquals(mvrm.getBorough(), null);
	}

	@Test
	public void verifyNewEventEntryInLS() {

		String borough = "B";
		String eventName = "Test";
		String query = "SELECT COUNT(EVENT_NAME) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND REMAINING_ROW_COUNT = 0";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(1);
		// Mockito.when(jdbcMetersValidateRepo.verifyNewEventEntryInLS(borough,
		// eventName)).thenReturn(true);
		// ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,
		// "getBoroughAndEventName", "B","Test");
		boolean res = jdbcMetersValidateRepo.verifyNewEventEntryInLS(borough, eventName);
		Assert.assertEquals(res, true);
	}

	@Test
	public void verifyNewEventEntryInLSTest() {

		String borough = "B";
		String eventName = "Test";
		MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper();
		String query = "SELECT COUNT(EVENT_NAME) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND REMAINING_ROW_COUNT = 0";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(0);
		boolean res = jdbcMetersValidateRepo.verifyNewEventEntryInLS(borough, eventName);
		Assert.assertEquals(res, false);
	}

	/*
	 * //@Test public void pushMeterEventFromVcapToLS() throws
	 * MeterValidateException, VcapRecordNotFoundException{
	 * MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper();
	 * String borough="B"; String eventName = "Test"; String fromDate = "Test";
	 * String toDate= "Test"; String adid="BUDIDHAK"; int batchSize = 100;
	 * List<MeterEventLoad> meterEventLoadNewEvents = new
	 * ArrayList<MeterEventLoad>();
	 * Mockito.when(jdbcMetersValidateRepo.isInsertBoroughAndEventName(borough,
	 * eventName,mvrm.getTotalRecord(), mvrm.getMeterEventLoads().size(),
	 * mvrm.getRemainingRow(), adid)).thenReturn(false);
	 * Mockito.when(jdbcMetersValidateRepo.batchInsertMeterEventLoad(
	 * meterEventLoadNewEvents,batchSize,adid)).thenReturn(1); //String
	 * query="SELECT COUNT(EVENT_NAME) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND REMAINING_ROW_COUNT = 0"
	 * ; //Mockito.when(oracleJdbcTemplate.batchUpdate(query ,
	 * meterEventLoadNewEvents,batchSize, new
	 * ParameterizedPreparedStatementSetter<MeterEventLoad>())).thenReturn(0);
	 * boolean flag = jdbcMetersValidateRepo.pushMeterEventFromVcapToLS(borough,
	 * eventName, fromDate, toDate, adid); Assert.assertEquals(flag, true); }
	 */

	@Test // (expected = IndexOutOfBoundsException.class)
	public void getValidateMeterList() throws MeterValidateException {
		MeterValidateResponseMapper mvrp = new MeterValidateResponseMapper();
		String borough = "B";
		String eventName = "Test";
		int startRowIndex = 1;
		int batchSize = 100;
		String filterList = "";
		String sortList = "";
		MeterValidateResponseMapper resp = jdbcMetersValidateRepo.getValidateMeterList(borough, eventName,
				startRowIndex, batchSize, filterList, sortList);
		Assert.assertNotNull(resp);
	}

	@Test
	public void isEventLocked() {
		String borough = "B";
		String eventName = "Test";
		String adid = "budidhak";
		Integer CountOfOperator = 1;
		String lockOperatorADID = "Test";
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Mockito.when((Integer) oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName },
				Integer.class)).thenReturn(CountOfOperator);
		Mockito.when(
				oracleJdbcTemplate.queryForObject(operatorADIDQuery, new Object[] { "Test", "Test" }, String.class))
				.thenReturn(lockOperatorADID);
		MeterValidateResponseMapper mvrp = jdbcMetersValidateRepo.isEventLocked(borough, eventName, adid);
		Assert.assertNotNull(mvrp);
	}

	@Test
	public void getInValidateMeterList() {
		MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper();
		String borough = "B";
		String eventName = "Test";
		int startRowIndex = 1;
		int batchSize = 100;
		MeterValidateResponseMapper resp = jdbcMetersValidateRepo.getInValidateMeterList(borough, eventName,
				startRowIndex, batchSize);
		// mvrm = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,
		// "getInValidateMeterEventList", "B","Test",10,1);
		Assert.assertNotNull(resp);
	}

	@Test
	public void validateMeterEventWithStar() {
		String borough = "B";
		String eventName = "Test";
		MeterValidateResponseMapper mvrm = new MeterValidateResponseMapper();
		String query = "insert into AMI_LOAD_SHEDDING.ls_validate_event_list (FK_METER_EVENT_LOAD_ID,BORO_MUNI,EVENT_NAME,METER_NUMBER) select ls.meter_event_load_id,ls.boro_muni,ls.event_name,ls.meter_number from AMI_LOAD_SHEDDING.ls_meter_event_load ls, cesconed.cu_meters cu, cesconed.customer cust where  ls.account_number = cu.meter_user_def_3 and ls.boro_muni = ? AND ls.event_name = ?  and cu.meter_user_def_3 = to_char(cust.account_number) and ls.account_number = to_char(cust.account_number) and (cust.lse = '00' and cust.critical = '0') and ls.meter_number = cu.meter_no ";
		// Mockito.when(oracleCommonJdbcTemplate.execute(Mockito.anyString() ,
		// Mockito.anyObject())).thenReturn(false);
		boolean res = jdbcMetersValidateRepo.validateMeterEventWithStar(borough, eventName);
		Assert.assertEquals(res, false);
	}

	@Test
	public void getLockedStatusByBoroughAndEventName() {
		String borough = "B";
		String eventName = "Test";
		String adid = "budidhak";
		Integer CountOfOperator = 1;
		String lockOperatorADID = "Test";
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Mockito.when((Integer) oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName },
				Integer.class)).thenReturn(CountOfOperator);
		Mockito.when(
				oracleJdbcTemplate.queryForObject(operatorADIDQuery, new Object[] { "Test", "Test" }, String.class))
				.thenReturn(lockOperatorADID);
		MeterLockedStatusResponseMapper mvrp = jdbcMetersValidateRepo.getLockedStatusByBoroughAndEventName(borough,
				eventName, adid);
		Assert.assertNotNull(mvrp);

	}

	@Test
	public void getFieldValuesByBoroughAndEventName1() {
		String fieldName = "meterEventLoadId";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName2() {
String fieldName = "borough";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName3() {
String fieldName = "eventName";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName4() {
String fieldName = "demand";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName5() {
String fieldName = "feeder";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName6() {
String fieldName = "buildingNumber";
		
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName7() {
        String fieldName = "serviceAddress";
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName8() {
        String fieldName = "customerZipCode";
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName9() {
        String fieldName = "meterNumber";
		String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
		Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName10() {
		 String fieldName = "accountNumber";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName11() {
		 String fieldName = "network";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName12() {
		 String fieldName = "eventStatus";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName13() {
		 String fieldName = "vcapInsertTime";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName14() {
		 String fieldName = "transformer";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName15() {
		 String fieldName = "structureName";
			String fieldname =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getDatabaseFieldName", fieldName);
			Assert.assertNotNull(fieldname);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName() throws IllegalArgumentException {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "VCAP_INSERT_TIME";
		fieldValueList = jdbcMetersValidateRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getCountOfMeters() {
		String borough = "B";
		String eventName = "Test";
		String meters = "Test";
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and  mel.meter_number IN ("
				+ meters + ")";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(1);
		Integer count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getCountOfMeters", "B", "Test",
				"Test");
		Assert.assertNotNull(count);
	}
	
	 @Test 
	 public void getValidSearchedTotalKVA(){ 
     String borough = "B";
	 String eventName = "Test";
	 String meters = "Test"; 
	 String query ="select sum(mel.demand) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? and mel.meter_number IN ("+ meters + ") "; 
	 Mockito.when(oracleJdbcTemplate.queryForObject(query,new Object[]{borough, eventName},String.class)).thenReturn("test");
	 String count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getValidSearchedTotalKVA", "B","Test","Test");
	 Assert.assertNotNull(count); 
	 }
	 
	 @Test 
	 public void getValidSearchTotalRecord(){ 
	     String borough = "B";
		 String eventName = "Test";
		 String query ="select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ?";
		 Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class)).thenReturn(1);
		 Integer count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getValidSearchTotalRecord", "B","Test");
		 Assert.assertNotNull(count); 
		 }
	 
	 @Test 
	 public void totalSearchCount(){ 
	     String borough = "B";
		 String eventName = "Test"; 
		 String totalCountQuery ="select count(*) from LS_METER_EVENT_LOAD mel where mel.boro_muni = ? and mel.event_name = ?"; 
		 Mockito.when(oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class)).thenReturn(1);
		 Integer count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"totalSearchCount", "B","Test");
		 Assert.assertNotNull(count); 
		 }
	 
	 @Test 
	 public void getTotalInvalidRecord(){ 
	     String borough = "B";
		 String eventName = "Test"; 
		 String query ="select count(mel.METER_EVENT_LOAD_ID) from AMI_LOAD_SHEDDING.ls_meter_event_load mel where NOT EXISTS(select VEL.FK_METER_EVENT_LOAD_ID from AMI_LOAD_SHEDDING.ls_validate_event_list VEL where mel.meter_event_load_id = VEL.FK_METER_EVENT_LOAD_ID and VEL.event_name = ? AND VEL.BORO_MUNI = ?) AND mel.event_name = ? AND mel.BORO_MUNI = ? group by mel.event_name"; 
		 Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[]{eventName, borough,eventName, borough},Integer.class)).thenReturn(1);
		 Integer count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getTotalInvalidRecord", "B","Test");
		 Assert.assertNotNull(count); 
		 }
	 

	@Test
	public void getValidateMeter() throws MeterValidateException, VcapRecordNotFoundException {
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setValidResponse(true);
		// Mockito.when(jdbcMetersValidateRepo.getValidateMeter("Test","Test",1,
		// 100, "Test","Test")).thenReturn(meterValidateResponseMapper);
		MeterValidateResponseMapper actual = jdbcMetersValidateRepo.getValidateMeter("Test", "Test", 1, 100, "Test",
				"Test");
		Assert.assertNotNull(actual);
	}

	@Test
	public void batchInsertMeterEventLoad() {
		// oracleJdbcTemplate.batchUpdate("INSERT INTO LS_METER_EVENT_LOAD
		// (METER_TYPE,DEMAND,BORO_MUNI,NETWORK,FEEDER,FEEDER_NETWORK_ABBR,SDPID,METER_NUMBER,ACCOUNT_NUMBER,CUSTOMER_NAME,PHONE1,CUST_ZIP_CODE,BUILDING_NUM,PHONE2,SERVICE_ADDRESS,EVENT_NAME,VCAP_INSERT_TIME,OPERATOR_AD_ID,TRANSFORMER,STRUCTURE,NETWORK_ABBR,FK_EVENT_STATUS,INSERT_TIME)
		// values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
		// meterEventLoadNewEvents, batchSize,
		int count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "batchInsertMeterEventLoad",
				Mockito.any(MeterEventLoad.class), Mockito.anyInt(), Mockito.anyString());
		Assert.assertNotNull(count);
	}

	@Test
	public void getValidTotalKVA() {
		String borough = "B";
		String eventName = "Test";
		String filterAndOrderQuery = "Test";
		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? "
				+ filterAndOrderQuery;
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, String.class))
				.thenReturn("test");
		String count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getValidTotalKVA", "B", "Test",
				"Test");
		Assert.assertNotNull(count);
	}

	/*@Test
	public void getValidTotalRecord() {
		String borough = "B";
		String eventName = "Test";
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(1);
		int count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getValidTotalRecord",borough, eventName);
		Assert.assertNotNull(count);

	}*/

	@Test
	public void totalCount() {
		String borough = "B";
		String eventName = "Test";
		String totalCountQuery = "SELECT bem.total_row_count FROM LS_BOROUGH_EVENT_MAPPING bem WHERE bem.boro_muni = ? AND bem.event_name = ?";
		Mockito.when(
				oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(1);
		Integer count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "totalCount", borough, eventName);
		Assert.assertNotNull(count);
	}

	@Test
	public void buildFilterAndOrderQuery() {
		String actual = "[ AND  IN ('test', 'test')  AND  IN ('test', 'test') ][ ORDER BY  DESC,  DESC]";
		final String test1 = "test:test-test,test:test-test";
		final String test2 = "test:test,test:test";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "buildFilterAndOrderQuery", test1, test2);
		Assert.assertEquals(" AND mel. IN ('test', 'test')  AND mel. IN ('test', 'test')  ORDER BY mel. DESC, mel. DESC", actual);

	}
	
	/*@Test
	public void buildFilterAndOrderQuery(){
		String actual = "[ AND  IN ('test', 'test')  AND  IN ('test', 'test') ]";
		final String test1 = "test:test-test,test:test-test";
		actual = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "buildFilterAndOrderQuery",test1);
		Assert.assertEquals(" AND  IN ('test', 'test')  AND  IN ('test', 'test') ", actual);
		
	}
	*/
	@Test
	public void getMeterEventLoad(){
		//List<MeterEventLoad> list = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getMeterEventLoad",Mockito.anyString(), Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyString(),Mockito.anyString());
		List<MeterEventLoad> list = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getMeterEventLoad","Test","Test" ,1,100,"Test","Test");
		Assert.assertNotNull(list);
	}
	
	@Test(expected=UndeclaredThrowableException.class)
	public void getNewEventFromVCAP() throws VcapRecordNotFoundException{
		List<MeterEventLoad> meterEventLoads = new ArrayList<>();
		MeterValidateResponseMapper mvrp = new MeterValidateResponseMapper();
		mvrp.setTotalRecord(1);
		mvrp.setMeterEventLoads(meterEventLoads);
		mvrp.setRemainingRow(1);
		
		MeterValidateResponseMapper response = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getNewEventFromVCAP","Test","Test" ,1,100,"Test","Test",mvrp);
		Assert.assertNotNull(response);
	}

	/*@Test
	public void getNewEventFromVCAPTest() throws VcapRecordNotFoundException, MeterValidateException{
		MeterValidateResponseMapper mvrparm = new MeterValidateResponseMapper() ;
		List<MeterEventLoad> meterEventLoads = new ArrayList<>();
		MeterEventLoad mel = new MeterEventLoad();
		mel.setAccountNumber("Test");
		mel.setBorough("B");
		mel.setEventName("Test");
		meterEventLoads.add(mel);
		MeterValidateResponseMapper mvrp = new MeterValidateResponseMapper();
		mvrp.setTotalRecord(1);
		mvrp.setMeterEventLoads(meterEventLoads);
		mvrp.setRemainingRow(1);
		String totalCountQuery = "SELECT COUNT(mel.Meter) FROM ami_meters_event_load mel WHERE mel.Boro = ? AND mel.EventName = ? AND mel.InsertTime >= ? and mel.InsertTime < ?";
		Mockito.when((Integer)sqlServerJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{"test", "test","test", "test"}, Integer.class)).thenReturn(1);
		mvrp = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getNewEventFromVCAP","Test","Test" ,1,100,"Test","Test",mvrparm);
		//Mockito.when(jdbcMetersValidateRepo.getNewEventFromVCAP("Test","Test" ,1,100,"Test","Test",mvrp))).then
		Assert.assertNotNull(mvrp);
	}*/
	
	
	@Test
	public void getRemainingRowToBeFetch(){
		int count = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getRemainingRowToBeFetch",100,49,1);
		Assert.assertNotNull(count);
	}
	
	@Test
	public void getMeterEventLoadIds(){
	List<MeterEventLoadIdAndDemand> mvl = new ArrayList<MeterEventLoadIdAndDemand>();
	mvl =ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo,"getMeterEventLoadIds", "B","Test", "","");
	Assert.assertNotNull(mvl);
	}
	
	
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeterTest_Empty() {
		List<MeterEventLoad> meterEventLoadTemp = meterEventLoads;
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoadTemp.clear();
		Assert.assertEquals(meterEventLoads.get(0), meterEventLoad);
	}

	@Test
	public void getValidateMeter_Mock() throws MeterValidateException, VcapRecordNotFoundException {
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300", 0, 500,
				DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString()))
				.thenReturn(meterValidateResponseMapper);
		Assert.assertEquals(meterValidateResponseMapper.getMeterEventLoads().get(0), meterEventLoads.get(0));
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeter_IndexOutOfBoundsException()
			throws MeterValidateException, VcapRecordNotFoundException {
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		List<MeterEventLoad> meterEventLoadTemp = meterEventLoads;
		meterEventLoadTemp.clear();
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoadTemp);
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300", 0, 500,
				DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString()))
				.thenReturn(meterValidateResponseMapper);
		Assert.assertEquals(meterValidateResponseMapper.getMeterEventLoads().get(0), meterEventLoads.get(0));
	}

	@Test
	public void getOperatorLock_Mock() throws MeterValidateException, VcapRecordNotFoundException {
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMessage("This event is locked.");
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300", 0, 500,
				DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString()))
				.thenReturn(meterValidateResponseMapper);
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), "This event is locked.");
	}
	
	@Test
	public void unlockEvents(){
		jdbcMetersValidateRepo.unlockEvents("BUDIDHAK");
	}
	
	@Test
	public void isEventFinalized(){
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setIsEventFinalized(true);
		meterValidateResponseMapper.setMessage("This event is already finalized.");	
		String totalCountQuery = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_EVENT_LIST_DETAILS WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		String borough ="B";
		String eventName ="Test";
		Mockito.when((Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class)).thenReturn(1);
		meterValidateResponseMapper = jdbcMetersValidateRepo.isEventFinalized("B", "Test");
		
        Assert.assertNotNull(meterValidateResponseMapper);
		
	}
	@Test
	public void isEventFinalized2(){
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setIsEventFinalized(false);
		String totalCountQuery = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_EVENT_LIST_DETAILS WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		String borough ="B";
		String eventName ="Test";
		Mockito.when((Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class))
		.thenReturn(0);
		meterValidateResponseMapper = jdbcMetersValidateRepo.isEventFinalized("B", "Test");
        Assert.assertNotNull(meterValidateResponseMapper);	
	}

	@Test
	public void getValidTotalRecord() {
		String borough = "B";
		String eventName = "Test";
		String query = "select count(vel.FK_METER_EVENT_LOAD_ID) from ls_validate_event_list vel where vel.boro_muni= ? and vel.event_name = ? ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class))
				.thenReturn(1);
		int response = ReflectionTestUtils.invokeMethod(jdbcMetersValidateRepo, "getValidTotalRecord", "B",
				"Test");
		Assert.assertNotNull(response);
	}
	
	@Test
	public void pushMeterEventFromVcapToLS() throws MeterValidateException, VcapRecordNotFoundException{
		String borough = "B";
		String eventName = "Test";
		String fromDate = "Test";
		String toDate = "Test";
		String adid = "Test";
		boolean response = jdbcMetersValidateRepo.pushMeterEventFromVcapToLS(borough, eventName,fromDate,toDate,adid);
		Assert.assertEquals(response, false);
	}
	
	@Test(expected = MeterValidateException.class)
	public void isInsertBoroughAndEventName() throws MeterValidateException {
		List<String> boroughList = new ArrayList<String>();
		SimpleJdbcCall mockedCall = Mockito.mock(SimpleJdbcCall.class);
		Mockito.when( simpleJdbcCall.withProcedureName(Mockito.any())).thenReturn(mockedCall);
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("Borough", "borough");
		inParamMap.put("Event", "eventName");	
		inParamMap.put("OpeartorADID", "adid");	
		inParamMap.put("TotalRowCount", "totalROwCount");
		inParamMap.put("NextFetchSize", "nextFetchSize");
		inParamMap.put("RemainingRowToBeFetch", "remainingRow");
				
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);

		List<LinkedCaseInsensitiveMap<String>> list = new ArrayList<LinkedCaseInsensitiveMap<String>>();
		LinkedCaseInsensitiveMap<String> lList = new LinkedCaseInsensitiveMap<String>();
		lList.put("BORO_MUNI", "Test");
		list.add(lList);
		map.put("BORO", list);
		Mockito.when(simpleJdbcCall.execute(inParamSql)).thenReturn(map);
		boolean response = jdbcMetersValidateRepo.isInsertBoroughAndEventName("Test","Test",0,0,0,"Test");
		Assert.assertNotNull(response);
	}
}
