
package com.ssn.schema.service.v2_6.eventmanager;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.commonenumerations.EventCategoryTypeEnum;
import com.ssn.schema.service.v2_6.commonenumerations.SeverityTypeEnum;


/**
 * <p>Java class for EventSearchParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EventSearchParametersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EventLogId" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="EventId" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="EventStartTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EventEndTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceType" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}SourceTypeEnum" minOccurs="0"/>
 *         &lt;element name="EmitterName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmitterId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmitterType" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}SourceTypeEnum" minOccurs="0"/>
 *         &lt;element name="Severity" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}SeverityTypeEnum" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="EventVisibility" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="EventCategoryType" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}EventCategoryTypeEnum" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="JobId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="Ack" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}AckType" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignedTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceUIQDeviceState" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}UIQDeviceStateType" minOccurs="0"/>
 *         &lt;element name="Alarm" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}AlarmType" minOccurs="0"/>
 *         &lt;element name="EventToClear" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EventSearchParametersType", propOrder = {
    "eventLogId",
    "eventId",
    "eventStartTime",
    "eventEndTime",
    "sourceName",
    "sourceId",
    "sourceType",
    "emitterName",
    "emitterId",
    "emitterType",
    "severity",
    "eventVisibility",
    "eventCategoryType",
    "jobId",
    "ack",
    "updatedBy",
    "assignedTo",
    "sourceUIQDeviceState",
    "alarm",
    "eventToClear"
})
public class EventSearchParametersType {

    @XmlElement(name = "EventLogId")
    protected List<String> eventLogId;
    @XmlElement(name = "EventId", type = Long.class)
    protected List<Long> eventId;
    @XmlElement(name = "EventStartTime")
    protected String eventStartTime;
    @XmlElement(name = "EventEndTime")
    protected String eventEndTime;
    @XmlElement(name = "SourceName")
    protected String sourceName;
    @XmlElement(name = "SourceId")
    protected String sourceId;
    @XmlElement(name = "SourceType")
    @XmlSchemaType(name = "string")
    protected SourceTypeEnum sourceType;
    @XmlElement(name = "EmitterName")
    protected String emitterName;
    @XmlElement(name = "EmitterId")
    protected String emitterId;
    @XmlElement(name = "EmitterType")
    @XmlSchemaType(name = "string")
    protected SourceTypeEnum emitterType;
    @XmlElement(name = "Severity")
    @XmlSchemaType(name = "string")
    protected List<SeverityTypeEnum> severity;
    @XmlElement(name = "EventVisibility")
    protected Integer eventVisibility;
    @XmlElement(name = "EventCategoryType")
    @XmlSchemaType(name = "string")
    protected List<EventCategoryTypeEnum> eventCategoryType;
    @XmlElement(name = "JobId")
    protected Long jobId;
    @XmlElement(name = "Ack")
    protected AckType ack;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "AssignedTo")
    protected String assignedTo;
    @XmlElement(name = "SourceUIQDeviceState")
    protected UIQDeviceStateType sourceUIQDeviceState;
    @XmlElement(name = "Alarm")
    protected AlarmType alarm;
    @XmlElement(name = "EventToClear")
    protected Integer eventToClear;

    /**
     * Gets the value of the eventLogId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventLogId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventLogId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEventLogId() {
        if (eventLogId == null) {
            eventLogId = new ArrayList<String>();
        }
        return this.eventLogId;
    }

    /**
     * Gets the value of the eventId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getEventId() {
        if (eventId == null) {
            eventId = new ArrayList<Long>();
        }
        return this.eventId;
    }

    /**
     * Gets the value of the eventStartTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventStartTime() {
        return eventStartTime;
    }

    /**
     * Sets the value of the eventStartTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventStartTime(String value) {
        this.eventStartTime = value;
    }

    /**
     * Gets the value of the eventEndTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventEndTime() {
        return eventEndTime;
    }

    /**
     * Sets the value of the eventEndTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventEndTime(String value) {
        this.eventEndTime = value;
    }

    /**
     * Gets the value of the sourceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * Sets the value of the sourceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceName(String value) {
        this.sourceName = value;
    }

    /**
     * Gets the value of the sourceId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * Sets the value of the sourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceId(String value) {
        this.sourceId = value;
    }

    /**
     * Gets the value of the sourceType property.
     * 
     * @return
     *     possible object is
     *     {@link SourceTypeEnum }
     *     
     */
    public SourceTypeEnum getSourceType() {
        return sourceType;
    }

    /**
     * Sets the value of the sourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SourceTypeEnum }
     *     
     */
    public void setSourceType(SourceTypeEnum value) {
        this.sourceType = value;
    }

    /**
     * Gets the value of the emitterName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmitterName() {
        return emitterName;
    }

    /**
     * Sets the value of the emitterName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmitterName(String value) {
        this.emitterName = value;
    }

    /**
     * Gets the value of the emitterId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmitterId() {
        return emitterId;
    }

    /**
     * Sets the value of the emitterId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmitterId(String value) {
        this.emitterId = value;
    }

    /**
     * Gets the value of the emitterType property.
     * 
     * @return
     *     possible object is
     *     {@link SourceTypeEnum }
     *     
     */
    public SourceTypeEnum getEmitterType() {
        return emitterType;
    }

    /**
     * Sets the value of the emitterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SourceTypeEnum }
     *     
     */
    public void setEmitterType(SourceTypeEnum value) {
        this.emitterType = value;
    }

    /**
     * Gets the value of the severity property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the severity property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSeverity().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SeverityTypeEnum }
     * 
     * 
     */
    public List<SeverityTypeEnum> getSeverity() {
        if (severity == null) {
            severity = new ArrayList<SeverityTypeEnum>();
        }
        return this.severity;
    }

    /**
     * Gets the value of the eventVisibility property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEventVisibility() {
        return eventVisibility;
    }

    /**
     * Sets the value of the eventVisibility property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEventVisibility(Integer value) {
        this.eventVisibility = value;
    }

    /**
     * Gets the value of the eventCategoryType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventCategoryType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventCategoryType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EventCategoryTypeEnum }
     * 
     * 
     */
    public List<EventCategoryTypeEnum> getEventCategoryType() {
        if (eventCategoryType == null) {
            eventCategoryType = new ArrayList<EventCategoryTypeEnum>();
        }
        return this.eventCategoryType;
    }

    /**
     * Gets the value of the jobId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobId(Long value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the ack property.
     * 
     * @return
     *     possible object is
     *     {@link AckType }
     *     
     */
    public AckType getAck() {
        return ack;
    }

    /**
     * Sets the value of the ack property.
     * 
     * @param value
     *     allowed object is
     *     {@link AckType }
     *     
     */
    public void setAck(AckType value) {
        this.ack = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the assignedTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets the value of the assignedTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets the value of the sourceUIQDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getSourceUIQDeviceState() {
        return sourceUIQDeviceState;
    }

    /**
     * Sets the value of the sourceUIQDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setSourceUIQDeviceState(UIQDeviceStateType value) {
        this.sourceUIQDeviceState = value;
    }

    /**
     * Gets the value of the alarm property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmType }
     *     
     */
    public AlarmType getAlarm() {
        return alarm;
    }

    /**
     * Sets the value of the alarm property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmType }
     *     
     */
    public void setAlarm(AlarmType value) {
        this.alarm = value;
    }

    /**
     * Gets the value of the eventToClear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEventToClear() {
        return eventToClear;
    }

    /**
     * Sets the value of the eventToClear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEventToClear(Integer value) {
        this.eventToClear = value;
    }

}
