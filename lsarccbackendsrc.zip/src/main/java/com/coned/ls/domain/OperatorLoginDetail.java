package com.coned.ls.domain;

import java.util.Date;

/**
 * 
 * Class to store user login details.
 *
 */
public class OperatorLoginDetail {

	private String adid;
	private String role;
	private long userRoleId;
	private Date loginTimeStamp;
	private String apiKey;
	private int apiKeyStatus;
	private int loginStatus;
	private boolean responseStatus;
	private String userClaim;
	
	public long getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(long userRoleId) {
		this.userRoleId = userRoleId;
	}
	public Date getLoginTimeStamp() {
		return loginTimeStamp;
	}
	public void setLoginTimeStamp(Date loginTimeStamp) {
		this.loginTimeStamp = loginTimeStamp;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public int getApiKeyStatus() {
		return apiKeyStatus;
	}
	public void setApiKeyStatus(int apiKeyStatus) {
		this.apiKeyStatus = apiKeyStatus;
	}
	public int getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(int loginStatus) {
		this.loginStatus = loginStatus;
	}
		
	public String getAdid() {
		return adid;
	}
	public void setAdid(String adid) {
		this.adid = adid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserClaim() {
		return userClaim;
	}
	public void setUserClaim(String userClaim) {
		this.userClaim = userClaim;
	}
	
	public boolean isResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(boolean responseStatus) {
		this.responseStatus = responseStatus;
	}
	public OperatorLoginDetail() {
		super();
	}
}
