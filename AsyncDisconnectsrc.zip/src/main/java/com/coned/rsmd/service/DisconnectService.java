package com.coned.rsmd.service;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.coned.rsmd.domain.Meter;
import com.coned.rsmd.repository.OutageRepository;

@Service
public class DisconnectService {

	private static final Logger logger = LoggerFactory.getLogger(DisconnectService.class);

	@Autowired
	private Environment env;

	@Autowired
	private OutageRepository outRepo;

	/**
	 * Fetch the meters that need to be disconnected
	 * 
	 * @return the list of meters
	 */
	public List<Meter> pendingMeters() {
		return outRepo.getMeters();
	}

	/**
	 * Persist the disconnect job id's to the respective tables
	 * 
	 * @param jobidList the list of disconnect job id's
	 * @throws Exception
	 */
	public void processJobs(List<Meter> jobidList) throws Exception {
		// Extract the job ids with 0 and save them with Unknown status

		List<Meter> metersWithJobid = extractValidJobIds(jobidList);
		List<Meter> metersWithZeroJobid = extractZeroJobIds(jobidList);

		if (metersWithJobid != null && metersWithJobid.size() > 0) {
			logger.info("Meter List size with Job Id [" + metersWithJobid.size() + "]");
			logger.debug("Meter List with Job Id [" + metersWithJobid + "]");
			// Save the disconnect job id list to the LSB_DISCONNECT_JOB_STATUS table
			outRepo.saveJob(metersWithJobid);
		}

		if (metersWithZeroJobid != null && metersWithZeroJobid.size() > 0) {
			logger.info("*** START -> Process Failed meter List of Size [" + metersWithZeroJobid.size() + "]");
			logger.debug("Failed Meter List [" + metersWithZeroJobid + "]");

			List<BigDecimal> ids = (List<BigDecimal>) metersWithZeroJobid.stream().map(Meter::getId)
					.collect(Collectors.toList());
			logger.info("List of ids that needs to be marked as Fail [" + ids + "]");

			outRepo.updateMeters(metersWithZeroJobid, ids, env.getProperty("unknown_status"));
			logger.info("*** END of Failed meter List");
		}
	}

	/**
	 * Fetch the meters that does not have an associated mac address. Mark the
	 * meters as Failed in the respective table.
	 */
	public void processMetersWithNullMacAddr() {
		try {
			List<Meter> mList = outRepo.getMetersWithNullMacAddr();
			if (mList.size() > 0) {
				logger.info("*** START -> List of meters with null mac address [" + mList + "]");

				List<BigDecimal> ids = (List<BigDecimal>) mList.stream().map(Meter::getId).collect(Collectors.toList());
				logger.info("List of ids that needs to be marked as Fail [" + ids + "]");

				outRepo.updateMeters(mList, ids, env.getProperty("failed_status"));
				logger.info("*** END -> procesing the meters with Null mac Address");
			}
		} catch (Exception e) {
			logger.error("Error processing the meters that does not have associated mac address ", e);
		}
	}

	private List<Meter> extractZeroJobIds(List<Meter> disConnectMetersList) {
		return (List<Meter>) disConnectMetersList.stream().filter(d -> d.getJobId() == 0).collect(Collectors.toList());
	}

	private List<Meter> extractValidJobIds(List<Meter> disConnectMetersList) {
		return (List<Meter>) disConnectMetersList.stream().filter(d -> d.getJobId() > 0).collect(Collectors.toList());
	}

	public Collection<List<Meter>> splitListBySize(List<Meter> intList, int size) {

		if (!intList.isEmpty() && size > 0) {
			final AtomicInteger counter = new AtomicInteger(0);
			return intList.stream().collect(Collectors.groupingBy(it -> counter.getAndIncrement() / size)).values();
		}
		return Collections.emptyList();
	}

}