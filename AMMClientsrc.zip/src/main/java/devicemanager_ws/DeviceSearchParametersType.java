
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceSearchParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceSearchParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindBaseDeviceType" minOccurs="0"/&gt;
 *         &lt;element name="Gateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindGatewayType" minOccurs="0"/&gt;
 *         &lt;element name="Meter" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindMeterType" minOccurs="0"/&gt;
 *         &lt;element name="IMU" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindIMUType" minOccurs="0"/&gt;
 *         &lt;element name="WaterModule" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindIMUType" minOccurs="0"/&gt;
 *         &lt;element name="Bridge" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindBridgeType" minOccurs="0"/&gt;
 *         &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindLocationType" minOccurs="0"/&gt;
 *         &lt;element name="Contacts" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindDeviceContactListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceSearchParametersType", propOrder = {
    "commonAttributes",
    "gateway",
    "meter",
    "imu",
    "waterModule",
    "bridge",
    "location",
    "contacts"
})
public class DeviceSearchParametersType {

    @XmlElement(name = "CommonAttributes")
    protected FindBaseDeviceType commonAttributes;
    @XmlElement(name = "Gateway")
    protected FindGatewayType gateway;
    @XmlElement(name = "Meter")
    protected FindMeterType meter;
    @XmlElement(name = "IMU")
    protected FindIMUType imu;
    @XmlElement(name = "WaterModule")
    protected FindIMUType waterModule;
    @XmlElement(name = "Bridge")
    protected FindBridgeType bridge;
    @XmlElement(name = "Location")
    protected FindLocationType location;
    @XmlElement(name = "Contacts")
    protected FindDeviceContactListType contacts;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link FindBaseDeviceType }
     *     
     */
    public FindBaseDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindBaseDeviceType }
     *     
     */
    public void setCommonAttributes(FindBaseDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link FindGatewayType }
     *     
     */
    public FindGatewayType getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindGatewayType }
     *     
     */
    public void setGateway(FindGatewayType value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the meter property.
     * 
     * @return
     *     possible object is
     *     {@link FindMeterType }
     *     
     */
    public FindMeterType getMeter() {
        return meter;
    }

    /**
     * Sets the value of the meter property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindMeterType }
     *     
     */
    public void setMeter(FindMeterType value) {
        this.meter = value;
    }

    /**
     * Gets the value of the imu property.
     * 
     * @return
     *     possible object is
     *     {@link FindIMUType }
     *     
     */
    public FindIMUType getIMU() {
        return imu;
    }

    /**
     * Sets the value of the imu property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindIMUType }
     *     
     */
    public void setIMU(FindIMUType value) {
        this.imu = value;
    }

    /**
     * Gets the value of the waterModule property.
     * 
     * @return
     *     possible object is
     *     {@link FindIMUType }
     *     
     */
    public FindIMUType getWaterModule() {
        return waterModule;
    }

    /**
     * Sets the value of the waterModule property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindIMUType }
     *     
     */
    public void setWaterModule(FindIMUType value) {
        this.waterModule = value;
    }

    /**
     * Gets the value of the bridge property.
     * 
     * @return
     *     possible object is
     *     {@link FindBridgeType }
     *     
     */
    public FindBridgeType getBridge() {
        return bridge;
    }

    /**
     * Sets the value of the bridge property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindBridgeType }
     *     
     */
    public void setBridge(FindBridgeType value) {
        this.bridge = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link FindLocationType }
     *     
     */
    public FindLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindLocationType }
     *     
     */
    public void setLocation(FindLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * @return
     *     possible object is
     *     {@link FindDeviceContactListType }
     *     
     */
    public FindDeviceContactListType getContacts() {
        return contacts;
    }

    /**
     * Sets the value of the contacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindDeviceContactListType }
     *     
     */
    public void setContacts(FindDeviceContactListType value) {
        this.contacts = value;
    }

}
