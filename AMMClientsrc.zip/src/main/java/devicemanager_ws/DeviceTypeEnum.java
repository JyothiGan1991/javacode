
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeviceTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="DID_TYPE_GATEWAY"/&gt;
 *     &lt;enumeration value="DID_TYPE_RELAY"/&gt;
 *     &lt;enumeration value="DID_TYPE_METER"/&gt;
 *     &lt;enumeration value="DID_TYPE_GAS"/&gt;
 *     &lt;enumeration value="DID_TYPE_WATER"/&gt;
 *     &lt;enumeration value="DID_TYPE_BRIDGE"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DeviceTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum DeviceTypeEnum {

    DID_TYPE_GATEWAY("DID_TYPE_GATEWAY"),
    DID_TYPE_RELAY("DID_TYPE_RELAY"),
    DID_TYPE_METER("DID_TYPE_METER"),
    DID_TYPE_GAS("DID_TYPE_GAS"),
    DID_TYPE_WATER("DID_TYPE_WATER"),
    DID_TYPE_BRIDGE("DID_TYPE_BRIDGE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DeviceTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeviceTypeEnum fromValue(String v) {
        for (DeviceTypeEnum c: DeviceTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
