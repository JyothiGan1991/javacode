
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PingResultsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PingResultsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DevicePing" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}DevicePingType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PartialResultDeviceList" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}DeviceListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SearchKey" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="RowCount" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="ExceededMaximumNumberOfRows" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PingResultsType", propOrder = {
    "devicePing",
    "partialResultDeviceList"
})
public class PingResultsType {

    @XmlElement(name = "DevicePing")
    protected List<DevicePingType> devicePing;
    @XmlElement(name = "PartialResultDeviceList")
    protected DeviceListType partialResultDeviceList;
    @XmlAttribute(name = "SearchKey")
    protected String searchKey;
    @XmlAttribute(name = "RowCount")
    protected Long rowCount;
    @XmlAttribute(name = "ExceededMaximumNumberOfRows")
    protected Boolean exceededMaximumNumberOfRows;

    /**
     * Gets the value of the devicePing property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the devicePing property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDevicePing().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DevicePingType }
     * 
     * 
     */
    public List<DevicePingType> getDevicePing() {
        if (devicePing == null) {
            devicePing = new ArrayList<DevicePingType>();
        }
        return this.devicePing;
    }

    /**
     * Gets the value of the partialResultDeviceList property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceListType }
     *     
     */
    public DeviceListType getPartialResultDeviceList() {
        return partialResultDeviceList;
    }

    /**
     * Sets the value of the partialResultDeviceList property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceListType }
     *     
     */
    public void setPartialResultDeviceList(DeviceListType value) {
        this.partialResultDeviceList = value;
    }

    /**
     * Gets the value of the searchKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchKey(String value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRowCount(Long value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the exceededMaximumNumberOfRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isExceededMaximumNumberOfRows() {
        if (exceededMaximumNumberOfRows == null) {
            return false;
        } else {
            return exceededMaximumNumberOfRows;
        }
    }

    /**
     * Sets the value of the exceededMaximumNumberOfRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExceededMaximumNumberOfRows(Boolean value) {
        this.exceededMaximumNumberOfRows = value;
    }

}
