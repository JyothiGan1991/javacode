/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class CircuitBreakerAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(CircuitBreakerAttributesThread.class);
    

    CircuitBreakerAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;  
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = " select geom.fid,geom.featuretypeid,def.featuretypename,GeometryType(geom.geom) geomType,     \n" +
"                                     geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, circuitbreaker.circuit,     \n" +
"                                     circuitbreaker.breaker,circuitbreaker.pidpointnumber,circuitbreaker.pidlayoutnumber,circuitbreaker.pidpointposition,     \n" +
"                                     circuitbreaker.stationid,circuitbreaker.volt,circuitbreaker.phase,circuitbreaker.remarks,circuitbreaker.designdstat,circuitbreaker.dstat,circuitbreaker.feeder,     \n" +
"                                     circuitbreaker.sendtodew,circuitbreaker.lpgasarea,circuitbreaker.subcolorid,circuitbreaker.colorid,circuitbreaker.sotagged,circuitbreaker.pidlayoutnumber,devAddress.town,devAddress.state,devAddress.street,circuitbreaker.hexcolor,circuitbreaker.protection3v0      \n" +
"                                     from      \n" +
"                                     ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_circuitbreaker circuitbreaker, ed_assetlocation devAddress   \n" +
"                                     where geom.fid = circuitbreaker.fid                          \n" +
"                                     and geom.featuretypeid = def.featuretypeid      \n" +
"                                     and geom.fid = devAddress.fid \n" +
"                                    and circuitbreaker.fid in (" + assetToQuery + ")";

            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                    
                    
                    String breaker = rs.getString("breaker");
                    asset.setNmsAttributes("breaker", breaker);

                    int pidpointnumber = rs.getInt("pidpointnumber");
                    asset.setNmsAttributes("pidpointnumber", Integer.toString(pidpointnumber));                    

                    String pidlayoutnumber = rs.getString("pidlayoutnumber");
                    asset.setNmsAttributes("pidlayoutnumber", pidlayoutnumber);
                    
                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);

                    String dstat = rs.getString("dstat");
                    asset.setNmsAttributes("dstat", dstat);                    
                    
                    String lpgasarea = rs.getString("lpgasarea");
                    asset.setNmsAttributes("lpgasarea", lpgasarea);

                    boolean sendtodew = rs.getBoolean("sendtodew");
                    asset.setNmsAttributes("sendtodew", String.valueOf(sendtodew));

                    /*add code for 3v0 here*/
                    String protection3v0 = rs.getString("protection3v0");
                    asset.setNmsAttributes("protection3v0", protection3v0);
                    /*end new code*/

                    boolean sotagged = rs.getBoolean("sotagged");
                    asset.setNmsAttributes("sotagged", String.valueOf(sotagged));

                    int colorid = rs.getInt("colorid");
                    asset.setNmsAttributes("colorid", Integer.toString(colorid));                    

                    int subcolorid = rs.getInt("subcolorid");
                    asset.setNmsAttributes("subcolorid", Integer.toString(subcolorid));                    
                    
                    int pidpointposition = rs.getInt("pidpointposition");
                    asset.setNmsAttributes("pidpointposition", Integer.toString(pidpointposition));                    
                    
                    String stationid = rs.getString("stationid");
                    asset.setNmsAttributes("stationid", stationid);
                    
                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));  
                    
                    int feeder = rs.getInt("feeder");
                    asset.setNmsAttributes("feeder", Integer.toString(feeder));                        

                    String remarks = rs.getString("remarks");
                    asset.setNmsAttributes("remarks", remarks);

                    String location = rs.getString("street");
                    asset.setNmsAttributes("location", location);
                    
                    double volt = rs.getFloat("volt");
                    asset.setNmsAttributes("volt", String.format("%.2f", volt));  
                    
                    
                    String town = rs.getString("town");
                    asset.setNmsAttributes("town", town);     
                    
                    String hexcolor = rs.getString("hexcolor");
                    asset.setNmsAttributes("hexcolor", hexcolor);                        
                    
                    
                    String state = rs.getString("state");
                    asset.setNmsAttributes("state", state);                                        
                    
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));                   
                    

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
