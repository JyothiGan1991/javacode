package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;


import org.apache.commons.codec.digest.DigestUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.login.CustomLoginConfig;
import com.coned.ls.login.SampleCallbackHandler;
import com.coned.ls.mapper.LoginResponseMapper;

import com.coned.ls.rest.RESTActionExecutor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Rest Controller to implement login and logout API.
 *
 */
@RestController
public class BaseController {

	private static final Logger LOGGER = LogManager.getLogger(BaseController.class);
	
	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	private final  static String RCC = "RCC";

	/*
	 * API to expire the Api Key and logout the user from the application.
     * 
     * @param request HttpServletRequest
     * @return        ResponseEntity<OperatorLoginDetail>
	 */ 
	@PostMapping(value = "/rcclogout")
	public ResponseEntity<OperatorLoginDetail> logout(HttpServletRequest request) {

		ResponseEntity<OperatorLoginDetail> response = null;
		OperatorLoginDetail detail = null;
		
		try {
			String header = request.getHeader("Authorization");

			String[] keys = header.split("-");

			String apiKey = keys[0];
			String username = keys[1];
			
			detail = restActionExecutor.persistAPIKey(username, apiKey, "logout");
			response = new ResponseEntity<OperatorLoginDetail>(detail, new HttpHeaders(), HttpStatus.OK);
		} catch (Exception e) {
			response = new ResponseEntity<OperatorLoginDetail>(detail, new HttpHeaders(),
					HttpStatus.INTERNAL_SERVER_ERROR);// Status code: 500
		}
		
		return response;
	}
	
	/*
	 * API to call Weblogic server to authenticate the user against LDAP server and check user is 
	 * authorized to access RCC API's. If User is valid and authorized then generate the API Key 
	 * and store it in the database and return the login status to UI.
     * 
     * @param request HttpServletRequest
     * @return        ResponseEntity<LoginResponseMapper>
	 */ 
	@PostMapping("/login")
	public ResponseEntity<LoginResponseMapper> login(@RequestParam String username, @RequestParam String password, HttpServletRequest request) throws Exception{
		LoginContext lc = null;
		ResponseEntity<LoginResponseMapper> response = null;
		
		LoginResponseMapper lrs = new LoginResponseMapper();
		lrs.setAuthenticated(false);
		lrs.setToken(null);
	    lrs.setName(username);

		try {
			HttpSession session = request.getSession(false);

			lc = new LoginContext("MyApp", null, new SampleCallbackHandler(username, password), new CustomLoginConfig());
			lc.login();

			Subject subject = lc.getSubject(); 	// User meta data or roles defined for user in the LDAP
			session = request.getSession(); 	// Get the current Session and sessionID

			String jSessionID = RequestContextHolder.currentRequestAttributes().getSessionId();
			String currentTimeStamp =  new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());  
			String uniqueKey = jSessionID + currentTimeStamp;
			String APIKey = DigestUtils.sha256Hex(uniqueKey);

			lrs.setAuthenticated(true);
			
			// Check user is authorized to access RCC Api's
			if(restActionExecutor.isOperatorAuthorized(username, RCC)){
				// Returning the APIKey to UI 
				OperatorLoginDetail opdet = restActionExecutor.persistAPIKey(username,APIKey, "login");
				lrs.setToken(APIKey);				
				lrs.setUserClaim(Arrays.asList(opdet.getUserClaim()));
				lrs.setMessage("success");
			    response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.OK); // Status code : 200
			}else{
				lrs.setMessage("Access not allowed. User not available in the System");
			    response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.UNAUTHORIZED); // Status code : 401
			}
		} catch (LoginException e) {
		    lrs.setMessage("Incorrect username or password. User unable to login");
		    response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.BAD_REQUEST); //Status code: 400
		} catch (Exception e) {
		    lrs.setMessage("Please contact the administrator.");
		    response = new ResponseEntity<LoginResponseMapper>(lrs, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR); //Status code: 500
		}

		return response;
	}
	
	public boolean isEmptyOrNull(String string){
		return (isNull(string) || isEmpty(string));
	}
	
	public boolean isNull(final String string){
		return (null==string);
	}
	
	public boolean isEmpty(final String string){
		return (string.trim().length()<=0);
	}
	
	@RequestMapping("/")
	public ModelAndView loginInit(HttpServletRequest request){
		return new ModelAndView("welcome");
	}
}
