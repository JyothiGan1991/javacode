@jakarta.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.6:BasicTypes.xsd", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ssn.schema.service.v2_6.basictypes;
