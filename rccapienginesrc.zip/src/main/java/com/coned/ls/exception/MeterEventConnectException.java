package com.coned.ls.exception;

public class MeterEventConnectException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public MeterEventConnectException() {
		super();
	}

	public MeterEventConnectException(final String message) {
		super(message);
	}
	public MeterEventConnectException(String message,Throwable cause) {
	   super(message,cause);
	}
}
