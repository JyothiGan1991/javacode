
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkInfrastructureRelayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkInfrastructureRelayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetDeviceType"/&gt;
 *         &lt;element name="Relay" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetRelayType"/&gt;
 *         &lt;element name="Alarms" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AlarmsType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInfrastructureRelayType", propOrder = {
    "commonAttributes",
    "relay",
    "alarms"
})
public class NetworkInfrastructureRelayType {

    @XmlElement(name = "CommonAttributes", required = true)
    protected GetDeviceType commonAttributes;
    @XmlElement(name = "Relay", required = true)
    protected GetRelayType relay;
    @XmlElement(name = "Alarms")
    protected AlarmsType alarms;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link GetDeviceType }
     *     
     */
    public GetDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetDeviceType }
     *     
     */
    public void setCommonAttributes(GetDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the relay property.
     * 
     * @return
     *     possible object is
     *     {@link GetRelayType }
     *     
     */
    public GetRelayType getRelay() {
        return relay;
    }

    /**
     * Sets the value of the relay property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetRelayType }
     *     
     */
    public void setRelay(GetRelayType value) {
        this.relay = value;
    }

    /**
     * Gets the value of the alarms property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmsType }
     *     
     */
    public AlarmsType getAlarms() {
        return alarms;
    }

    /**
     * Sets the value of the alarms property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmsType }
     *     
     */
    public void setAlarms(AlarmsType value) {
        this.alarms = value;
    }

}
