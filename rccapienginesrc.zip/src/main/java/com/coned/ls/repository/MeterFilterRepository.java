package com.coned.ls.repository;

import java.util.List;

import com.coned.ls.domain.FilterAttribute;

/**
 * 
 * Interface for Meter filter repository class.
 *
 */
public interface MeterFilterRepository {
	
	public List<FilterAttribute> initMeterFilter(final String borough, final String eventName, final String filterAttribute, final int startIndex, final int fetchNext);
	
}
