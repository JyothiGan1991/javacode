
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindIMUType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindIMUType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UIQProgramID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ZeroFlowThreshold" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="LeakDetectionThreshold" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="EncoderNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EncoderType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PulseWeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="RouteNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult1" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult2" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult3" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="IMUGroupID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TransmitDayStartMin" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TransmitIntervalMin" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TransmitOffsetMin" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TransmitRandSec" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="Pressure" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="TemperatureCompensated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RolloverPoint" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MechanismType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MechanismType" minOccurs="0"/&gt;
 *         &lt;element name="ServiceRate" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypeMfgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypeMfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypePartNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IMUTypeRevisionNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindIMUType", propOrder = {
    "name",
    "uiqProgramID",
    "zeroFlowThreshold",
    "leakDetectionThreshold",
    "encoderNumber",
    "encoderType",
    "pulseWeight",
    "routeNumber",
    "radioLinkResult1",
    "radioLinkResult2",
    "radioLinkResult3",
    "imuGroupID",
    "transmitDayStartMin",
    "transmitIntervalMin",
    "transmitOffsetMin",
    "transmitRandSec",
    "pressure",
    "temperatureCompensated",
    "rolloverPoint",
    "mechanismType",
    "serviceRate",
    "imuTypeConfigName",
    "imuTypeMfgCode",
    "imuTypeMfgName",
    "imuTypePartNumber",
    "imuTypeRevisionNumber"
})
public class FindIMUType {

    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "UIQProgramID")
    protected Integer uiqProgramID;
    @XmlElement(name = "ZeroFlowThreshold")
    protected Double zeroFlowThreshold;
    @XmlElement(name = "LeakDetectionThreshold")
    protected Double leakDetectionThreshold;
    @XmlElement(name = "EncoderNumber")
    protected String encoderNumber;
    @XmlElement(name = "EncoderType")
    protected String encoderType;
    @XmlElement(name = "PulseWeight")
    protected Double pulseWeight;
    @XmlElement(name = "RouteNumber")
    protected String routeNumber;
    @XmlElement(name = "RadioLinkResult1")
    protected Double radioLinkResult1;
    @XmlElement(name = "RadioLinkResult2")
    protected Double radioLinkResult2;
    @XmlElement(name = "RadioLinkResult3")
    protected Double radioLinkResult3;
    @XmlElement(name = "IMUGroupID")
    protected Integer imuGroupID;
    @XmlElement(name = "TransmitDayStartMin")
    protected Integer transmitDayStartMin;
    @XmlElement(name = "TransmitIntervalMin")
    protected Integer transmitIntervalMin;
    @XmlElement(name = "TransmitOffsetMin")
    protected Integer transmitOffsetMin;
    @XmlElement(name = "TransmitRandSec")
    protected Integer transmitRandSec;
    @XmlElement(name = "Pressure")
    protected Double pressure;
    @XmlElement(name = "TemperatureCompensated")
    protected Boolean temperatureCompensated;
    @XmlElement(name = "RolloverPoint")
    protected Integer rolloverPoint;
    @XmlElement(name = "MechanismType")
    protected MechanismType mechanismType;
    @XmlElement(name = "ServiceRate")
    protected MeterModeType serviceRate;
    @XmlElement(name = "IMUTypeConfigName")
    protected String imuTypeConfigName;
    @XmlElement(name = "IMUTypeMfgCode")
    protected String imuTypeMfgCode;
    @XmlElement(name = "IMUTypeMfgName")
    protected String imuTypeMfgName;
    @XmlElement(name = "IMUTypePartNumber")
    protected String imuTypePartNumber;
    @XmlElement(name = "IMUTypeRevisionNumber")
    protected String imuTypeRevisionNumber;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the uiqProgramID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUIQProgramID() {
        return uiqProgramID;
    }

    /**
     * Sets the value of the uiqProgramID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUIQProgramID(Integer value) {
        this.uiqProgramID = value;
    }

    /**
     * Gets the value of the zeroFlowThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getZeroFlowThreshold() {
        return zeroFlowThreshold;
    }

    /**
     * Sets the value of the zeroFlowThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setZeroFlowThreshold(Double value) {
        this.zeroFlowThreshold = value;
    }

    /**
     * Gets the value of the leakDetectionThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLeakDetectionThreshold() {
        return leakDetectionThreshold;
    }

    /**
     * Sets the value of the leakDetectionThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLeakDetectionThreshold(Double value) {
        this.leakDetectionThreshold = value;
    }

    /**
     * Gets the value of the encoderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncoderNumber() {
        return encoderNumber;
    }

    /**
     * Sets the value of the encoderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncoderNumber(String value) {
        this.encoderNumber = value;
    }

    /**
     * Gets the value of the encoderType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncoderType() {
        return encoderType;
    }

    /**
     * Sets the value of the encoderType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncoderType(String value) {
        this.encoderType = value;
    }

    /**
     * Gets the value of the pulseWeight property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPulseWeight() {
        return pulseWeight;
    }

    /**
     * Sets the value of the pulseWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPulseWeight(Double value) {
        this.pulseWeight = value;
    }

    /**
     * Gets the value of the routeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouteNumber() {
        return routeNumber;
    }

    /**
     * Sets the value of the routeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouteNumber(String value) {
        this.routeNumber = value;
    }

    /**
     * Gets the value of the radioLinkResult1 property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRadioLinkResult1() {
        return radioLinkResult1;
    }

    /**
     * Sets the value of the radioLinkResult1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRadioLinkResult1(Double value) {
        this.radioLinkResult1 = value;
    }

    /**
     * Gets the value of the radioLinkResult2 property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRadioLinkResult2() {
        return radioLinkResult2;
    }

    /**
     * Sets the value of the radioLinkResult2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRadioLinkResult2(Double value) {
        this.radioLinkResult2 = value;
    }

    /**
     * Gets the value of the radioLinkResult3 property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRadioLinkResult3() {
        return radioLinkResult3;
    }

    /**
     * Sets the value of the radioLinkResult3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRadioLinkResult3(Double value) {
        this.radioLinkResult3 = value;
    }

    /**
     * Gets the value of the imuGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIMUGroupID() {
        return imuGroupID;
    }

    /**
     * Sets the value of the imuGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIMUGroupID(Integer value) {
        this.imuGroupID = value;
    }

    /**
     * Gets the value of the transmitDayStartMin property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransmitDayStartMin() {
        return transmitDayStartMin;
    }

    /**
     * Sets the value of the transmitDayStartMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransmitDayStartMin(Integer value) {
        this.transmitDayStartMin = value;
    }

    /**
     * Gets the value of the transmitIntervalMin property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransmitIntervalMin() {
        return transmitIntervalMin;
    }

    /**
     * Sets the value of the transmitIntervalMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransmitIntervalMin(Integer value) {
        this.transmitIntervalMin = value;
    }

    /**
     * Gets the value of the transmitOffsetMin property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransmitOffsetMin() {
        return transmitOffsetMin;
    }

    /**
     * Sets the value of the transmitOffsetMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransmitOffsetMin(Integer value) {
        this.transmitOffsetMin = value;
    }

    /**
     * Gets the value of the transmitRandSec property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransmitRandSec() {
        return transmitRandSec;
    }

    /**
     * Sets the value of the transmitRandSec property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransmitRandSec(Integer value) {
        this.transmitRandSec = value;
    }

    /**
     * Gets the value of the pressure property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPressure() {
        return pressure;
    }

    /**
     * Sets the value of the pressure property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPressure(Double value) {
        this.pressure = value;
    }

    /**
     * Gets the value of the temperatureCompensated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTemperatureCompensated() {
        return temperatureCompensated;
    }

    /**
     * Sets the value of the temperatureCompensated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTemperatureCompensated(Boolean value) {
        this.temperatureCompensated = value;
    }

    /**
     * Gets the value of the rolloverPoint property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRolloverPoint() {
        return rolloverPoint;
    }

    /**
     * Sets the value of the rolloverPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRolloverPoint(Integer value) {
        this.rolloverPoint = value;
    }

    /**
     * Gets the value of the mechanismType property.
     * 
     * @return
     *     possible object is
     *     {@link MechanismType }
     *     
     */
    public MechanismType getMechanismType() {
        return mechanismType;
    }

    /**
     * Sets the value of the mechanismType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MechanismType }
     *     
     */
    public void setMechanismType(MechanismType value) {
        this.mechanismType = value;
    }

    /**
     * Gets the value of the serviceRate property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getServiceRate() {
        return serviceRate;
    }

    /**
     * Sets the value of the serviceRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setServiceRate(MeterModeType value) {
        this.serviceRate = value;
    }

    /**
     * Gets the value of the imuTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeConfigName() {
        return imuTypeConfigName;
    }

    /**
     * Sets the value of the imuTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeConfigName(String value) {
        this.imuTypeConfigName = value;
    }

    /**
     * Gets the value of the imuTypeMfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeMfgCode() {
        return imuTypeMfgCode;
    }

    /**
     * Sets the value of the imuTypeMfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeMfgCode(String value) {
        this.imuTypeMfgCode = value;
    }

    /**
     * Gets the value of the imuTypeMfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeMfgName() {
        return imuTypeMfgName;
    }

    /**
     * Sets the value of the imuTypeMfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeMfgName(String value) {
        this.imuTypeMfgName = value;
    }

    /**
     * Gets the value of the imuTypePartNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypePartNumber() {
        return imuTypePartNumber;
    }

    /**
     * Sets the value of the imuTypePartNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypePartNumber(String value) {
        this.imuTypePartNumber = value;
    }

    /**
     * Gets the value of the imuTypeRevisionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeRevisionNumber() {
        return imuTypeRevisionNumber;
    }

    /**
     * Sets the value of the imuTypeRevisionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeRevisionNumber(String value) {
        this.imuTypeRevisionNumber = value;
    }

}
