/*package com.coned.ls.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoadAction;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterRejectResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.JdbcMetersEventFinalizeRepository;
import com.coned.ls.repository.JdbcMetersEventValidateRepository;
import com.coned.ls.repository.MetersEventFinalizeRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc

public class MetersEventFinalizeServiceTest {
	@Mock
    private MetersEventFinalizeRepository metersEventFinalizeRepository;

	@InjectMocks
    private MetersEventFinalizeService  metersEventFinalizeService = new MetersEventFinalizeServiceImpl();
    
	MeterEventFinalize meterEventFinalize;
	String expectedTestResult =  "{\"countOfMeters\":10,\"finalizeTime\":null,\"operatorAdId\":\"AN20025372\",\"borough\":\"B\",\"eventName\":\"SheepsheadBaySampleData7.27.20-1300\",\"message\":\"Success\",\"valid\":true}";
	
	@Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
	@Test
	public void findMeterEventFinalizeDetailsTest_True() throws MeterFinalizeException{
		meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300","Success",true);
		Mockito.when(metersEventFinalizeRepository.findMeterEventFinalizeDetails("B", "SheepsheadBaySampleData7.27.20-1300")).thenReturn(meterEventFinalize);
		MeterEventFinalize findMeterEventFinalizeDetails = metersEventFinalizeService.findMeterEventFinalizeDetails("B", "SheepsheadBaySampleData7.27.20-1300");
		Assert.assertEquals(findMeterEventFinalizeDetails.getCountOfMeters(), meterEventFinalize.getCountOfMeters());
		Assert.assertEquals(findMeterEventFinalizeDetails.getOperatorAdId(), meterEventFinalize.getOperatorAdId());
		Assert.assertEquals(findMeterEventFinalizeDetails.getBorough(), meterEventFinalize.getBorough());
		Assert.assertEquals(findMeterEventFinalizeDetails.getEventName(), meterEventFinalize.getEventName());
		Assert.assertEquals(findMeterEventFinalizeDetails.getMessage(), meterEventFinalize.getMessage());
		Assert.assertEquals(findMeterEventFinalizeDetails.isValid(), meterEventFinalize.isValid());
	}
	
	@Test
	public void findMeterEventFinalizeDetailsTest_False() throws MeterFinalizeException{
		meterEventFinalize = new MeterEventFinalize(0, null, null, "B", "SheepsheadBaySampleData7.27.20-1300","Failed",false);
		Mockito.when(metersEventFinalizeRepository.findMeterEventFinalizeDetails("B", "SheepsheadBaySampleData7.27.20-1300")).thenReturn(meterEventFinalize);
		MeterEventFinalize findMeterEventFinalizeDetails = metersEventFinalizeService.findMeterEventFinalizeDetails("B", "SheepsheadBaySampleData7.27.20-1300");
		Assert.assertEquals(findMeterEventFinalizeDetails.getCountOfMeters(), meterEventFinalize.getCountOfMeters());
		Assert.assertEquals(findMeterEventFinalizeDetails.getMessage(), meterEventFinalize.getMessage());
		Assert.assertEquals(findMeterEventFinalizeDetails.isValid(), meterEventFinalize.isValid());
	}
	
	@Test
	public void finalizeMeterEventList() throws MeterFinalizeException{     		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMessage("Finalize action has been done successfully");
		String listOfMeters = "92764,94364,72787";
		String[] finalizeMeterList = listOfMeters.split(",");
		List<String> finalizeMetersList = new ArrayList<String>(Arrays.asList(finalizeMeterList));	
		//Mockito.when(metersEventFinalizeRepository.finalizeMeterEventList("B", "SheepsheadBaySampleData7.27.20-1300", finalizeMetersList)).thenReturn(meterValidateResponseMapper);
		//MeterValidateResponseMapper finalizeMeterEventList = metersEventFinalizeService.finalizeMeterEventList("B", "SheepsheadBaySampleData7.27.20-1300", finalizeMetersList);
		//Assert.assertEquals(finalizeMeterEventList.getMessage(), meterValidateResponseMapper.getMessage());
	}
	
	@Test(expected = MeterFinalizeException.class)
	public void finalizeMeterEventList_Exception() throws MeterFinalizeException{     		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		String listOfMeters = "";
		String[] finalizeMeterList = listOfMeters.split(",");
		List<String> finalizeMetersList = new ArrayList<String>(Arrays.asList(finalizeMeterList));	
		//Mockito.when(metersEventFinalizeRepository.finalizeMeterEventList("B", "SheepsheadBaySampleData7.27.20-1300", finalizeMetersList)).thenReturn(meterValidateResponseMapper);
		//metersEventFinalizeService.finalizeMeterEventList("B", "SheepsheadBaySampleData7.27.20-1300", finalizeMetersList);
		if( (finalizeMetersList.get(0).trim()!="") ){
			finalizeMetersList.get(0);
		}else{
			throw new MeterFinalizeException();
		}
	}
}
*/