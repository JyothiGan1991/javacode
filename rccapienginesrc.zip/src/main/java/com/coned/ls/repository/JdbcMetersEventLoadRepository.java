package com.coned.ls.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.coned.ls.domain.MetersEventLoad;

/**
 * 
 * Repository class to read meter event load data from database.
 *
 */
@Repository
public class JdbcMetersEventLoadRepository  implements MetersEventLoadRepository{

	@Autowired
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	 
    /*
     * Method to read meter event load data from database.
     * 
     * @return List<MetersEventLoad> 
     *                         
     */
	@Override
	public List<MetersEventLoad> findAll() {
		return sqlServerJdbcTemplate.query("select * from meters_event_load", (metersEventLoad, rowNum) -> new MetersEventLoad(metersEventLoad.getString("meter_type"),metersEventLoad.getString("demand"),metersEventLoad.getString("boro_muni")));
	}
}
