
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AlarmStatusEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AlarmStatusEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ALARM_RINGING"/>
 *     &lt;enumeration value="ALARM_CLEAR_IN_PROGRESS"/>
 *     &lt;enumeration value="ALARM_CLEARED"/>
 *     &lt;enumeration value="ALARM_CLEAR_FAILED"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AlarmStatusEnum")
@XmlEnum
public enum AlarmStatusEnum {

    ALARM_RINGING("ALARM_RINGING"),
    ALARM_CLEAR_IN_PROGRESS("ALARM_CLEAR_IN_PROGRESS"),
    ALARM_CLEARED("ALARM_CLEARED"),
    ALARM_CLEAR_FAILED("ALARM_CLEAR_FAILED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    AlarmStatusEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AlarmStatusEnum fromValue(String v) {
        for (AlarmStatusEnum c: AlarmStatusEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
