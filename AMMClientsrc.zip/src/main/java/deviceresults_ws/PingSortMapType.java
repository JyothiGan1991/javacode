
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PingSortMapType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PingSortMapType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}PingSortColumnEnumeration"/&gt;
 *         &lt;element name="IsAscending" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PingSortMapType", propOrder = {
    "name",
    "isAscending"
})
public class PingSortMapType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected PingSortColumnEnumeration name;
    @XmlElement(name = "IsAscending")
    protected boolean isAscending;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link PingSortColumnEnumeration }
     *     
     */
    public PingSortColumnEnumeration getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link PingSortColumnEnumeration }
     *     
     */
    public void setName(PingSortColumnEnumeration value) {
        this.name = value;
    }

    /**
     * Gets the value of the isAscending property.
     * 
     */
    public boolean isIsAscending() {
        return isAscending;
    }

    /**
     * Sets the value of the isAscending property.
     * 
     */
    public void setIsAscending(boolean value) {
        this.isAscending = value;
    }

}
