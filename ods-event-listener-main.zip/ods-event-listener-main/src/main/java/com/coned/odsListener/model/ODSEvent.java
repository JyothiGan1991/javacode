/**
 * 
 */
package com.coned.odsListener.model;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * @author DATHATHRIA
 *
 */
public class ODSEvent {
	
	private String deviceUtilId;
	private String eventType;
	private String deviceType;
	private String macId;
	private String macAddress;
	private String regionCode;
	private String reason;
	private String servicePointId;
	private String rebootCounter;
	private Integer isStatusDateTimeEstimated;
	private String endDeviceEventTypeRef;
	private XMLGregorianCalendar eventTime;
	
	/**
	 * 
	 */
	public ODSEvent() {
		super();
	}

	/**
	 * @param deviceUtilId
	 * @param eventType
	 * @param deviceType
	 * @param macId
	 * @param macAddress
	 * @param regionCode
	 * @param reason
	 * @param servicePointId
	 * @param rebootCounter
	 * @param isStatusDateTimeEstimated
	 * @param endDeviceEventTypeRef
	 * @param eventTime
	 */
//	public ODSEvent(String deviceUtilId, String eventType, String deviceType, String macId, String macAddress,
//			String regionCode, String reason, String servicePointId, String rebootCounter,
//			Integer isStatusDateTimeEstimated, String endDeviceEventTypeRef, String eventTime) {
//		super();
//		this.deviceUtilId = deviceUtilId;
//		this.eventType = eventType;
//		this.deviceType = deviceType;
//		this.macId = macId;
//		this.macAddress = macAddress;
//		this.regionCode = regionCode;
//		this.reason = reason;
//		this.servicePointId = servicePointId;
//		this.rebootCounter = rebootCounter;
//		this.isStatusDateTimeEstimated = isStatusDateTimeEstimated;
//		this.endDeviceEventTypeRef = endDeviceEventTypeRef;
//		this.eventTime = eventTime;
//	}

	/**
	 * @return the deviceUtilId
	 */
	public String getDeviceUtilId() {
		return deviceUtilId;
	}
	
	/**
	 * @param deviceUtilId the deviceUtilId to set
	 */
	public void setDeviceUtilId(String deviceUtilId) {
		this.deviceUtilId = deviceUtilId;
	}
	
	/**
	 * @return the eventType
	 */
	public String getEventType() {
		return eventType;
	}
	
	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
		return deviceType;
	}
	
	/**
	 * @param deviceType the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	
	/**
	 * @return the macId
	 */
	public String getMacId() {
		return macId;
	}
	
	/**
	 * @param macId the macId to set
	 */
	public void setMacId(String macId) {
		this.macId = macId;
	}
	
	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}
	
	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	
	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	
	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}
	
	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	/**
	 * @return the servicePointId
	 */
	public String getServicePointId() {
		return servicePointId;
	}
	
	/**
	 * @param servicePointId the servicePointId to set
	 */
	public void setServicePointId(String servicePointId) {
		this.servicePointId = servicePointId;
	}
	
	/**
	 * @return the rebootCounter
	 */
	public String getRebootCounter() {
		return rebootCounter;
	}
	
	/**
	 * @param rebootCounter the rebootCounter to set
	 */
	public void setRebootCounter(String rebootCounter) {
		this.rebootCounter = rebootCounter;
	}
	
	/**
	 * @return the isStatusDateTimeEstimated
	 */
	public Integer getIsStatusDateTimeEstimated() {
		return isStatusDateTimeEstimated;
	}
	
	/**
	 * @param isStatusDateTimeEstimated the isStatusDateTimeEstimated to set
	 */
	public void setIsStatusDateTimeEstimated(Integer isStatusDateTimeEstimated) {
		this.isStatusDateTimeEstimated = isStatusDateTimeEstimated;
	}
	
	/**
	 * @return the endDeviceEventTypeRef
	 */
	public String getEndDeviceEventTypeRef() {
		return endDeviceEventTypeRef;
	}
	/**
	 * @param endDeviceEventTypeRef the endDeviceEventTypeRef to set
	 */
	public void setEndDeviceEventTypeRef(String endDeviceEventTypeRef) {
		this.endDeviceEventTypeRef = endDeviceEventTypeRef;
	}
	
	/**
	 * @return the eventTime
	 */
	public XMLGregorianCalendar getEventTime() {
		return eventTime;
	}
	
	/**
	 * @param eventTime the eventTime to set
	 */
	public void setEventTime(XMLGregorianCalendar eventTime) {
		this.eventTime = eventTime;
	}

}
