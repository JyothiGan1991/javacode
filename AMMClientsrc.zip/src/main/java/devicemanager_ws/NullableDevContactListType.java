
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NullableDevContactListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NullableDevContactListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EditDevContactListType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditDevContactListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Null" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NullableDevContactListType", propOrder = {
    "editDevContactListType"
})
public class NullableDevContactListType {

    @XmlElement(name = "EditDevContactListType")
    protected EditDevContactListType editDevContactListType;
    @XmlAttribute(name = "Null")
    protected Boolean _null;

    /**
     * Gets the value of the editDevContactListType property.
     * 
     * @return
     *     possible object is
     *     {@link EditDevContactListType }
     *     
     */
    public EditDevContactListType getEditDevContactListType() {
        return editDevContactListType;
    }

    /**
     * Sets the value of the editDevContactListType property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditDevContactListType }
     *     
     */
    public void setEditDevContactListType(EditDevContactListType value) {
        this.editDevContactListType = value;
    }

    /**
     * Gets the value of the null property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isNull() {
        if (_null == null) {
            return false;
        } else {
            return _null;
        }
    }

    /**
     * Sets the value of the null property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNull(Boolean value) {
        this._null = value;
    }

}
