package com.coned.ls.exception;

import java.util.Date;

public class MeterRejectException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public MeterRejectException() {
		super();
	}
	
	public MeterRejectException(String message) {
		super(message);
		
	}
	public MeterRejectException(String message,Throwable cause) {
		   super(message,cause);
		}
}
