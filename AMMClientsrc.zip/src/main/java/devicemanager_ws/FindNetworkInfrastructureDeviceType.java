
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindNetworkInfrastructureDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindNetworkInfrastructureDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AP" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureDeviceType"/&gt;
 *         &lt;element name="Relays" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureDeviceType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindNetworkInfrastructureDeviceType", propOrder = {
    "ap",
    "relays"
})
public class FindNetworkInfrastructureDeviceType {

    @XmlElement(name = "AP", required = true)
    protected NetworkInfrastructureDeviceType ap;
    @XmlElement(name = "Relays")
    protected List<NetworkInfrastructureDeviceType> relays;

    /**
     * Gets the value of the ap property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfrastructureDeviceType }
     *     
     */
    public NetworkInfrastructureDeviceType getAP() {
        return ap;
    }

    /**
     * Sets the value of the ap property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfrastructureDeviceType }
     *     
     */
    public void setAP(NetworkInfrastructureDeviceType value) {
        this.ap = value;
    }

    /**
     * Gets the value of the relays property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relays property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelays().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkInfrastructureDeviceType }
     * 
     * 
     */
    public List<NetworkInfrastructureDeviceType> getRelays() {
        if (relays == null) {
            relays = new ArrayList<NetworkInfrastructureDeviceType>();
        }
        return this.relays;
    }

}
