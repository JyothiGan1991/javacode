
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SelectDevicesFromSearchResultResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SelectDevicesFromSearchResultResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SelectedDeviceCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SelectDevicesFromSearchResultResponseType", propOrder = {
    "selectedDeviceCount"
})
public class SelectDevicesFromSearchResultResponseType {

    @XmlElement(name = "SelectedDeviceCount")
    protected int selectedDeviceCount;

    /**
     * Gets the value of the selectedDeviceCount property.
     * 
     */
    public int getSelectedDeviceCount() {
        return selectedDeviceCount;
    }

    /**
     * Sets the value of the selectedDeviceCount property.
     * 
     */
    public void setSelectedDeviceCount(int value) {
        this.selectedDeviceCount = value;
    }

}
