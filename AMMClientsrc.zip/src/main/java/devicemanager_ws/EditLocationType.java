
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditLocationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditLocationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}LocationType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServicePoint" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditServicePtType" minOccurs="0"/&gt;
 *         &lt;element name="DistNetwork" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DistNetworkType" minOccurs="0"/&gt;
 *         &lt;element name="Contacts" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditDevContactListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditLocationType", propOrder = {
    "servicePoint",
    "distNetwork",
    "contacts"
})
public class EditLocationType
    extends LocationType
{

    @XmlElement(name = "ServicePoint")
    protected EditServicePtType servicePoint;
    @XmlElement(name = "DistNetwork")
    protected DistNetworkType distNetwork;
    @XmlElement(name = "Contacts")
    protected EditDevContactListType contacts;

    /**
     * Gets the value of the servicePoint property.
     * 
     * @return
     *     possible object is
     *     {@link EditServicePtType }
     *     
     */
    public EditServicePtType getServicePoint() {
        return servicePoint;
    }

    /**
     * Sets the value of the servicePoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditServicePtType }
     *     
     */
    public void setServicePoint(EditServicePtType value) {
        this.servicePoint = value;
    }

    /**
     * Gets the value of the distNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link DistNetworkType }
     *     
     */
    public DistNetworkType getDistNetwork() {
        return distNetwork;
    }

    /**
     * Sets the value of the distNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistNetworkType }
     *     
     */
    public void setDistNetwork(DistNetworkType value) {
        this.distNetwork = value;
    }

    /**
     * Gets the value of the contacts property.
     * 
     * @return
     *     possible object is
     *     {@link EditDevContactListType }
     *     
     */
    public EditDevContactListType getContacts() {
        return contacts;
    }

    /**
     * Sets the value of the contacts property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditDevContactListType }
     *     
     */
    public void setContacts(EditDevContactListType value) {
        this.contacts = value;
    }

}
