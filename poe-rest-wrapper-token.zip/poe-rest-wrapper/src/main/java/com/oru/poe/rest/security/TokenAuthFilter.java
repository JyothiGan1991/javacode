package com.oru.poe.rest.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oru.poe.rest.dto.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Validates Authorization: Bearer &lt;token&gt; header against configured api.auth.token.
 * Applies to all requests under /api/.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TokenAuthFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(TokenAuthFilter.class);
    private static final String BEARER_PREFIX = "Bearer ";

    @Value("${api.auth.enabled:true}")
    private boolean authEnabled;

    @Value("${api.auth.token:}")
    private String configuredToken;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        // Only protect /api/** paths
        return path == null || !path.contains("/api/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        if (!authEnabled) {
            filterChain.doFilter(request, response);
            return;
        }

        if (!StringUtils.hasText(configuredToken)) {
            log.error("api.auth.token is not configured");
            writeUnauthorized(response, request.getRequestURI(), "Authentication configuration error");
            return;
        }

        String authHeader = request.getHeader("Authorization");
        if (!StringUtils.hasText(authHeader) || !authHeader.startsWith(BEARER_PREFIX)) {
            log.warn("Missing or invalid Authorization header for {}", request.getRequestURI());
            writeUnauthorized(response, request.getRequestURI(), "Authentication failed");
            return;
        }

        String token = authHeader.substring(BEARER_PREFIX.length()).trim();
        if (!configuredToken.equals(token)) {
            log.warn("Invalid Bearer token for {}", request.getRequestURI());
            writeUnauthorized(response, request.getRequestURI(), "Authentication failed");
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void writeUnauthorized(HttpServletResponse response, String path, String message) throws IOException {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        ErrorResponse body = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Unauthorized",
                message,
                path);
        objectMapper.writeValue(response.getOutputStream(), body);
    }
}
