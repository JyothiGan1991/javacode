package com.coned.ls.interceptor;



import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.rest.RESTActionExecutor;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 
 * Intercepter to check user is valid and authorized to access RCC Disconnect and Connect API's.
 *
 */
@Aspect
@Component
public class APISecurityInterceptor {

	RESTActionExecutor restActionExecutor = new RESTActionExecutor();
	
	@Before(value = "execution(* com.coned.ls.controller.RCCDisconnectController.*(..)) || execution(* com.coned.ls.controller.RCCConnectController.*(..))"
			+ " || execution(* com.coned.ls.controller.RCCConnectControllerTmp.*(..))" 
			+ " || execution(* com.coned.ls.controller.ReportController.*(..)) || execution(* com.coned.ls.controller.UserManagementController.*(..))")
	public boolean before(JoinPoint joinPoint) throws OperatorAuthorizationException {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		
		// Get the Authorization Header ( Split the APIKey and UserName )
		String header = request.getHeader("Authorization");
		
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}

		String[] keys = header.split("-");

		String apiKey = keys[0];
		String adid = keys[1];

		boolean apiEndpointAuthorized = restActionExecutor.isAPIEndpointAuthorized(adid, apiKey, 13, 10);

		if (!apiEndpointAuthorized) {
			throw new OperatorAuthorizationException("ACCESS_DENIED", HttpStatus.UNAUTHORIZED);// API_KEY_EXPIRE
		}
		
		return apiEndpointAuthorized;
	}
}
