package com.oru.rest.okta;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Obtains Okta access tokens using OAuth 2.0 client_credentials grant
 * (service-to-service), matching the Okta document flow.
 */
@Service
public class OktaTokenClient {

    private static final Logger log = LoggerFactory.getLogger(OktaTokenClient.class);

    private final OktaProperties properties;
    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;

    public OktaTokenClient(OktaProperties properties, ObjectMapper objectMapper) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.restTemplate = createRestTemplate(properties);
    }

    /**
     * Request an access token from Okta using client_id / client_secret.
     */
    public OktaTokenResponse requestAccessToken() {
        return requestAccessToken(properties.getScope());
    }

    public OktaTokenResponse requestAccessToken(String scope) {
        if (!StringUtils.hasText(properties.getClientId())
                || !StringUtils.hasText(properties.getClientSecret())) {
            throw new IllegalStateException(
                    "Okta client-id and client-secret must be configured to request tokens");
        }

        String tokenUri = properties.getTokenUri();
        log.debug("Requesting Okta access token from {}", tokenUri);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Authorization", "Basic " + basicAuth(
                properties.getClientId(), properties.getClientSecret()));

        String body = "grant_type=client_credentials";
        if (StringUtils.hasText(scope)) {
            body = body + "&scope=" + urlEncode(scope);
        }

        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    tokenUri,
                    HttpMethod.POST,
                    new HttpEntity<String>(body, headers),
                    String.class);

            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                throw new IllegalStateException(
                        "Okta token request failed. HTTP " + response.getStatusCodeValue());
            }

            OktaTokenResponse tokenResponse =
                    objectMapper.readValue(response.getBody(), OktaTokenResponse.class);
            if (tokenResponse.getAccessToken() == null
                    || tokenResponse.getAccessToken().trim().isEmpty()) {
                throw new IllegalStateException("Okta token response did not contain access_token");
            }
            log.info("Okta access token acquired (expires_in={}s)", tokenResponse.getExpiresIn());
            return tokenResponse;
        } catch (RestClientException e) {
            throw new IllegalStateException("Okta token request failed: " + e.getMessage(), e);
        } catch (IllegalStateException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException("Failed to parse Okta token response: " + e.getMessage(), e);
        }
    }

    private static RestTemplate createRestTemplate(OktaProperties properties) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) properties.getConnectTimeoutMs());
        factory.setReadTimeout((int) properties.getReadTimeoutMs());
        return new RestTemplate(factory);
    }

    private static String basicAuth(String clientId, String clientSecret) {
        String credentials = clientId + ":" + clientSecret;
        return Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
    }

    private static String urlEncode(String value) {
        try {
            return java.net.URLEncoder.encode(value, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return value;
        }
    }
}
