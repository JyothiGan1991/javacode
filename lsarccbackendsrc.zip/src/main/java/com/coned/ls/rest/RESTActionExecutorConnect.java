package com.coned.ls.rest;

import java.net.URI;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import org.springframework.web.client.RestTemplate;

import com.coned.ls.controller.RCCDisconnectController;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;

import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

/**
 * 
 * Class to call API Engine and return the response for RCC Connect.
 *
 */
public class RESTActionExecutorConnect {
	
	private static final Logger logger = LogManager.getLogger(RCCDisconnectController.class);
	
	private static RestTemplate restTemplate = new RestTemplate();
	
	/*
	 * This method call API Engine to read list of borough or event.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getBoroughAndEventNameForConnect(final String fields){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/meters?fields="+fields);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	    
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * This method call API Engine to read list of open events by borough.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>>  getOpenEventForConnect(final String fields){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));

		Map<String, String> params = new HashMap<String, String>();
		params.put("borough", fields);
		URI uri = RestClientBuilder.buildURI("/rcc/connect/events/open/meters/{borough}", params);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to read list of disconnected meters created for the event.
	 * 
	 * @param  meterOpenEvent MeterOpenEvent
     * @return 				  ResponseEntity<MeterEventResponseMapper>
	 */	
	public ResponseEntity<MeterEventResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent){
		logger.info(String.format("Preparing REST API endpoint for getValidMetersForConnect"));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/meters");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", meterOpenEvent.getAdid());
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterOpenEvent, headers);

		    return restTemplate.postForEntity(uri, entity, MeterEventResponseMapper.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
			
			return ResponseEntity.status(ex.getRawStatusCode()).body(new MeterEventResponseMapper("Exception occured : "+ex.getResponseBodyAsString()));
		}
	}
	
	/*
	 * Method to call API Engine to read list of connected meters created for the event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 				 ResponseEntity<MeterEventResponseMapper>
	 */	
	public ResponseEntity<MeterEventResponseMapper> getConnectdMeters(final MeterOpenEvent meterOpenEvent){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/meters");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterOpenEvent, headers);

		    return restTemplate.postForEntity(uri, entity, MeterEventResponseMapper.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
			
			return ResponseEntity.status(ex.getRawStatusCode()).body(new MeterEventResponseMapper("Exception occured : "+ex.getResponseBodyAsString()));
		}		
	}
	
	/*
	 * Method to call API Engine to finalize the meters in the sub event for connect.
	 * 
	 * @param  subEvent SubEvent
	 * @param  adid 	String
     * @return 			ResponseEntity<MeterFinalizeResponseMapper> 
	 */	
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(final SubEvent subEvent, final String adid){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/finalize-sub/meters/");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(subEvent, headers);
		    
			ResponseEntity<MeterFinalizeResponseMapper> response = restTemplate.postForEntity(uri, entity, MeterFinalizeResponseMapper.class);
			if(!response.getBody().isResult() && (response.getBody().getMessage().startsWith("No data found") || 
					response.getBody().getMessage().startsWith("No meters found"))){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}return response;
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
	 
		MeterFinalizeResponseMapper finalizeMeter = new MeterFinalizeResponseMapper();
		finalizeMeter.setMessage("No data found.");
		
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(finalizeMeter);
	}
	
	/*
	 * Method to call API Engine to read suffix for sub event.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  items 	 String
     * @return 			 ResponseEntity<Long>
	 */		
	public ResponseEntity<Long> getSubEventSuffix(final String borough,final String eventName,final String items){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
	
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);
		stringBuilder.append("&items="+items);
	
		Long forObject =  new Long(0);
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/finalize/sub-event/suffix?", stringBuilder.toString());

			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
	
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	
		    ResponseEntity<Long> response = restTemplate.exchange(uri, HttpMethod.GET, entity, Long.class);
		    
		    if(response.getBody().longValue() == 0){
		    	return ResponseEntity.status(HttpStatus.OK).body(new Long(1));
		    }else{
		    	Long suffix = response.getBody();
		    	suffix = suffix+1;
		    	return ResponseEntity.status(HttpStatus.OK).body(new Long(suffix));
		    }
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		} 
		 
		MeterFinalizeResponseMapper finalizeMeter = new MeterFinalizeResponseMapper();
		finalizeMeter.setMessage("No data found.");
		
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(forObject);
	}
	
	/*
	 * Method to call API Engine to read list of sub borough.
	 * 
	 * @param  fields String
     * @return 		  ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubFinalizeBorough(final String fields){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
		
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/sub-event/meters?fields="+fields);
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);

		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		    
		    if(responseEntity.getBody().isEmpty()){
		    	return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseEntity.getBody());
		    }else{
		    	return ResponseEntity.ok().body(responseEntity.getBody());
		    }
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to read list of sub event.
	 * 
	 * @param  fields String
     * @return 		  ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubFinalizeEvent(final String fields){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
		
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/sub-event/meters?fields="+fields);
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);

		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		    
		    if(responseEntity.getBody().isEmpty()){
		    	return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseEntity.getBody());
		    }else{
		    	return ResponseEntity.ok().body(responseEntity.getBody());
		    }
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to read list of sub event by borough.
	 * 
	 * @param  borough String
     * @return 		   ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(final String borough){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
		
		try{
			Map<String, String> params = new HashMap<String, String>();
			params.put("borough", borough);
			
			URI uri = RestClientBuilder.buildURI("/rcc/connect/events/open/sub-event/meters/{borough}", params);
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);

		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		    
		    if(responseEntity.getBody().isEmpty()){
		    	return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseEntity.getBody());
		    }else{
		    	return ResponseEntity.ok().body(responseEntity.getBody());
		    }
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to read list of Sub Event names for the event.
	 * 
	 * @param  borough   String
	 * @param  eventName String
     * @return 			 ResponseEntity<List<String>> 
	 */	
	public ResponseEntity<List<String>> getSubFinalizeEventByEventAndBorough(final String borough,final String eventName){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/open/finalize/sub-event/meters?", stringBuilder.toString());
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);

		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		    if(responseEntity.getBody().isEmpty()){
		    	return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseEntity.getBody());
		    }else{
		    	return responseEntity;
		    }
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to read list of meters in the Sub Event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  subEventName  String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 			     MeterEventResponseMapper 
	 */	
	public MeterEventResponseMapper getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex,final int batchSize){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[0]));
		
		MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);
		stringBuilder.append("&subEventName="+subEventName);
		stringBuilder.append("&startRowIndex="+String.valueOf(startRowIndex));
		stringBuilder.append("&batchSize="+String.valueOf(batchSize));
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/sub-event/meters?", stringBuilder.toString());
		try{
			meterEventResponseMapper = restTemplate.getForObject(uri, MeterEventResponseMapper.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}	 
		
		return meterEventResponseMapper;
	}

	/*
	 * Method to call API Engine to search list of disconnected meters created for event.
	 * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterEventResponseMapper> 
	 */	
	public ResponseEntity<MeterEventResponseMapper> searchMeter(final MeterSearch meterSearch){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));
		MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/search/meters");
			
			ResponseEntity<MeterEventResponseMapper> postForEntity = restTemplate.postForEntity(uri, meterSearch, MeterEventResponseMapper.class);
			System.out.println("postForEntity.getBody() : "+postForEntity.getBody());
			meterEventResponseMapper = postForEntity.getBody();
			
			if(!postForEntity.getBody().isValidResponse()){
				ResponseEntity.status(HttpStatus.NO_CONTENT).body(meterEventResponseMapper);
			}else{
				return postForEntity;
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to search list of connected meters created for the event.
	 * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterEventResponseMapper> 
	 */		
	public ResponseEntity<MeterEventResponseMapper> searchMeterConnected(final MeterSearch meterSearch){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));
		MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/search/meters");
			
			ResponseEntity<MeterEventResponseMapper> postForEntity = restTemplate.postForEntity(uri, meterSearch, MeterEventResponseMapper.class);
			meterEventResponseMapper = postForEntity.getBody();
			
			if(!postForEntity.getBody().isValidResponse()){
				ResponseEntity.status(HttpStatus.NO_CONTENT).body(meterEventResponseMapper);
			}else{
				return postForEntity;
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/*
	 * Method to call API Engine to create Sub Event.
	 * 
	 * @param  subEvent   	 SubEvent
     * @return 			     ResponseEntity<MeterEventResponseMapper>
	 */	 
	public ResponseEntity<MeterEventResponseMapper> getSubEventMeters(final SubEvent subEvent){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));
		
		MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/sub-event/meters");
			
			ResponseEntity<MeterEventResponseMapper> postForEntity = restTemplate.postForEntity(uri, subEvent, MeterEventResponseMapper.class);
			meterEventResponseMapper = postForEntity.getBody();
			
			if(!postForEntity.getBody().isValidResponse()){
				ResponseEntity.status(HttpStatus.NO_CONTENT).body(meterEventResponseMapper);
			}else{
				return postForEntity;
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	/*
	 * Method to call API Engine to read list of values for a given field.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  fieldName String
     * @return 			 ResponseEntity<List<String>>
	 */	
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		logger.info(String.format("Preparing REST API endpoint for getFieldValuesByBoroughAndEventName()"));
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("eventName="+eventName);
		stringBuilder.append("&fieldName="+fieldName);
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/meters/fields/" + borough + "?", stringBuilder.toString());
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		
		return responseEntity;		
	}

    /*
     * Method to return list of values for a given field for Connected Meters.
     * 
     * @Parm borough  	String 
     * @Parm eventName  String
     * @Parm fieldName  String
     * 
     * @return 			ResponseEntity<List<String>>  
     *                         
     */
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		logger.info(String.format("Preparing REST API endpoint for getConnectedMetersFieldValuesByBoroughAndEventName()"));
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("eventName="+eventName);
		stringBuilder.append("&fieldName="+fieldName);
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/connected/meters/fields/" + borough + "?", stringBuilder.toString());
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		
		return responseEntity;	
	}
	
	/*
	 * Method to call API Engine to check event is locked.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  adid		 String
     * @return 			 MeterLockedStatusResponseMapper 
	 */	
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid) {
		logger.info("Preparing REST API endpoint for getLockedStatusByBoroughAndEventName");
		
		MeterLockedStatusResponseMapper meterLockedStatusResponseMapper = new MeterLockedStatusResponseMapper();
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/status/meters?", stringBuilder.toString());
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    return restTemplate.exchange(uri, HttpMethod.GET, entity, MeterLockedStatusResponseMapper.class).getBody();
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		return meterLockedStatusResponseMapper;		
	}
	
	/*
	 * Method to call API Engine to unlocked the events.
	 * 
	 * @param  adid	String
     * @return 		void 
	 */	
	public void unlockEvents(final String adid) {
		logger.info("Preparing REST API endpoint for unlockEvents");
		
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect/events/status/meters?");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    restTemplate.put(uri, entity);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}		
	}
}
