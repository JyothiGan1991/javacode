
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TOUTierWeekdayEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TOUTierWeekdayEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_SATURDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_SUNDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_WEEKDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_WEEKEND"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_MONDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_TUESDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_WEDNESDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_THURSDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_FRIDAY"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY_1"/&gt;
 *     &lt;enumeration value="TOU_TIER_DAY_HOLIDAY_2"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TOUTierWeekdayEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum TOUTierWeekdayEnum {

    TOU_TIER_DAY_SATURDAY("TOU_TIER_DAY_SATURDAY"),
    TOU_TIER_DAY_SUNDAY("TOU_TIER_DAY_SUNDAY"),
    TOU_TIER_DAY_WEEKDAY("TOU_TIER_DAY_WEEKDAY"),
    TOU_TIER_DAY_HOLIDAY("TOU_TIER_DAY_HOLIDAY"),
    TOU_TIER_DAY_WEEKEND("TOU_TIER_DAY_WEEKEND"),
    TOU_TIER_DAY_MONDAY("TOU_TIER_DAY_MONDAY"),
    TOU_TIER_DAY_TUESDAY("TOU_TIER_DAY_TUESDAY"),
    TOU_TIER_DAY_WEDNESDAY("TOU_TIER_DAY_WEDNESDAY"),
    TOU_TIER_DAY_THURSDAY("TOU_TIER_DAY_THURSDAY"),
    TOU_TIER_DAY_FRIDAY("TOU_TIER_DAY_FRIDAY"),
    TOU_TIER_DAY_HOLIDAY_1("TOU_TIER_DAY_HOLIDAY_1"),
    TOU_TIER_DAY_HOLIDAY_2("TOU_TIER_DAY_HOLIDAY_2"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    TOUTierWeekdayEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TOUTierWeekdayEnum fromValue(String v) {
        for (TOUTierWeekdayEnum c: TOUTierWeekdayEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
