package com.coned.amm.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coned.amm.config.AppConfig;

import devicemanager_ws.DeviceManagerPortType;
import devicemanager_ws.DeviceSearchParametersType;
import devicemanager_ws.ErrorCodeFault;
import devicemanager_ws.FindBaseDeviceType;
import devicemanager_ws.FindDeviceReqType;
import devicemanager_ws.FindDeviceResponse;
import devicemanager_ws.FindDeviceResponseType;

@Service
public class DmgrService {
	private static final Logger logger = LoggerFactory.getLogger(DmgrService.class);
	// private static final String DM_URL =
	// "https://mt.devl01.con.ssnsgs.net:3009/amm/webservice/v2_2/DeviceManagerPort";

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private DeviceManagerPortType deviceManagerService;

	public Optional<Object> findDevice(String UtilDeviceId) {
		DeviceSearchParametersType dspt = populateDSPT(UtilDeviceId);
		FindDeviceReqType fdrt = populateFDRT(dspt);
		FindDeviceResponseType device = new FindDeviceResponseType();

		try {
			logger.info("DeviceManagerPortType: " + this.deviceManagerService);
			if (this.deviceManagerService != null) {
				device = this.deviceManagerService.findDevice(fdrt);
			} else {
				device = this.appConfig.deviceManagerService().findDevice(fdrt);
			}
			logger.info("device response size[" + device.getSearchResponse().size() + "]");

			if (device.getSearchResponse().size() == 1) {
				FindDeviceResponse fdr = device.getSearchResponse().get(0);
				String status = fdr.getUiqDeviceStateID().getName().toString();
				logger.info("Status for the device: " + status);
				logger.info("MAC ID: " + fdr.getMacID());
				return Optional.of(fdr.getMacID());

			}
		} catch (ErrorCodeFault errorCodeFault) {
			logger.error("Error retrieving the MAC ID: " + errorCodeFault);
			return Optional.of(errorCodeFault);
		}
		return Optional.empty();
	}

	private FindDeviceReqType populateFDRT(DeviceSearchParametersType dspt) {
		FindDeviceReqType fdrt = new FindDeviceReqType();
		fdrt.setNumberRows(1);
		fdrt.setSearchParameters(dspt);
		return fdrt;
	}

	private DeviceSearchParametersType populateDSPT(String UtilDeviceId) {
		FindBaseDeviceType dt = new FindBaseDeviceType();
		dt.setUtilDeviceID(UtilDeviceId);
		DeviceSearchParametersType dspt = new DeviceSearchParametersType();
		dspt.setCommonAttributes(dt);
		return dspt;
	}
}
