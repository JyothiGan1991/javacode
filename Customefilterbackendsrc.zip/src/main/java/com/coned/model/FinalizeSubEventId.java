package com.coned.model;

import java.io.Serializable;

public class FinalizeSubEventId implements Serializable {

	public Long getId() {
		return id;
	}

	public String getSubEventName() {
		return subEventName;
	}

	private Long id;

	private String subEventName;

	public FinalizeSubEventId() {

	}
	public FinalizeSubEventId(Long id, String subEventName) {
		this.id = id;
		this.subEventName = subEventName;
	}

	public boolean equals(final Object inObject) {
		if (null != inObject) {
			if (inObject.getClass().equals(this.getClass())) {
				FinalizeSubEventListDetails siteKey = (FinalizeSubEventListDetails) inObject;
				return (null != this.getId()
						&& this.getId().equals(siteKey.getId())
						&& null != this.getSubEventName() && this.getSubEventName().equals(siteKey.getSubEventName()));
			}
		}
		return super.equals(inObject);
	}

	public int hashCode() {
		if (this.getId() != null && this.getSubEventName() != null) {
			return this.getId().hashCode() + this.getSubEventName().hashCode();
		}
		return super.hashCode();
	}
}
