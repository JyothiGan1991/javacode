
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningModeStatusTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RemoteProvisioningModeStatusTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="RMT_PROV_MODE_STATUS_UNKNOWN"/>
 *     &lt;enumeration value="RMT_PROV_MODE_STATUS_ENABLED"/>
 *     &lt;enumeration value="RMT_PROV_MODE_STATUS_DISABLED"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RemoteProvisioningModeStatusTypeEnum")
@XmlEnum
public enum RemoteProvisioningModeStatusTypeEnum {

    RMT_PROV_MODE_STATUS_UNKNOWN("RMT_PROV_MODE_STATUS_UNKNOWN"),
    RMT_PROV_MODE_STATUS_ENABLED("RMT_PROV_MODE_STATUS_ENABLED"),
    RMT_PROV_MODE_STATUS_DISABLED("RMT_PROV_MODE_STATUS_DISABLED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    RemoteProvisioningModeStatusTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RemoteProvisioningModeStatusTypeEnum fromValue(String v) {
        for (RemoteProvisioningModeStatusTypeEnum c: RemoteProvisioningModeStatusTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
