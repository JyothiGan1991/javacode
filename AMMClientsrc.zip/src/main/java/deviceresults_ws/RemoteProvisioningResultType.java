
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningResultType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RemoteProvisioningResultType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RequestedProvisioningAction" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}ProvisioningActionType"/&gt;
 *         &lt;element name="ProvisioningCommandStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ProvisioningCommandStatusType"/&gt;
 *         &lt;element name="MeterConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterConnectionStatusType"/&gt;
 *         &lt;element name="LC1ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterConnectionStatusType" minOccurs="0"/&gt;
 *         &lt;element name="LC2ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterConnectionStatusType" minOccurs="0"/&gt;
 *         &lt;element name="OverallStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PrepayEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="PrepayBalanceInKWh" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="PrepayOverdraftLimitInKWh" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitingEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitingThresholdInKW" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitingCalculationPeriod" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitingDisconnectPeriod" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitingCalculationDelayPeriod" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="SwitchLockoutEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlActivated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlThresholdInKW" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlCalculationPeriod" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlDisconnectPeriod" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityControlRandomizedStartOnActivate" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="LoadControlRandomizedStartTimeInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="BoostEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RemoteProvisioningDataType" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RemoteProvisioningDataTypeType"/&gt;
 *         &lt;element name="RemoteProvisioningErrorStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RemoteProvisioningErrorStatusType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LoadControlPrimaryGroupID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="LoadControlSecondaryGroupID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="LoadControlTertiaryGroupID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IgnoreTamperDetectionStartTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IgnoreTamperDetectionEndTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IgnoreTamperDetectionEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DoorSensorEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DoorOpen" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="TamperStateEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="NicDesiredConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MeterConnectionStatusType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="DeviceMacID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="DeviceName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobID" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="JobName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobCreator" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="JobExecutionTime" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CustomerID" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RemoteProvisioningResultType", propOrder = {
    "requestedProvisioningAction",
    "provisioningCommandStatus",
    "meterConnectionStatus",
    "lc1ConnectionStatus",
    "lc2ConnectionStatus",
    "overallStatusMessage",
    "prepayEnabled",
    "prepayBalanceInKWh",
    "prepayOverdraftLimitInKWh",
    "demandLimitingEnabled",
    "demandLimitingThresholdInKW",
    "demandLimitingCalculationPeriod",
    "demandLimitingDisconnectPeriod",
    "demandLimitingCalculationDelayPeriod",
    "switchLockoutEnabled",
    "emergencySupplyCapacityControlEnabled",
    "emergencySupplyCapacityControlActivated",
    "emergencySupplyCapacityControlThresholdInKW",
    "emergencySupplyCapacityControlCalculationPeriod",
    "emergencySupplyCapacityControlDisconnectPeriod",
    "emergencySupplyCapacityControlRandomizedStartOnActivate",
    "loadControlRandomizedStartTimeInMinutes",
    "boostEnabled",
    "remoteProvisioningDataType",
    "remoteProvisioningErrorStatus",
    "loadControlPrimaryGroupID",
    "loadControlSecondaryGroupID",
    "loadControlTertiaryGroupID",
    "ignoreTamperDetectionStartTime",
    "ignoreTamperDetectionEndTime",
    "ignoreTamperDetectionEnabled",
    "doorSensorEnabled",
    "doorOpen",
    "tamperStateEnabled",
    "nicDesiredConnectionStatus"
})
public class RemoteProvisioningResultType {

    @XmlElement(name = "RequestedProvisioningAction", required = true)
    protected ProvisioningActionType requestedProvisioningAction;
    @XmlElement(name = "ProvisioningCommandStatus", required = true)
    protected ProvisioningCommandStatusType provisioningCommandStatus;
    @XmlElement(name = "MeterConnectionStatus", required = true)
    protected MeterConnectionStatusType meterConnectionStatus;
    @XmlElement(name = "LC1ConnectionStatus")
    protected MeterConnectionStatusType lc1ConnectionStatus;
    @XmlElement(name = "LC2ConnectionStatus")
    protected MeterConnectionStatusType lc2ConnectionStatus;
    @XmlElement(name = "OverallStatusMessage")
    protected String overallStatusMessage;
    @XmlElement(name = "PrepayEnabled")
    protected Boolean prepayEnabled;
    @XmlElement(name = "PrepayBalanceInKWh")
    protected Double prepayBalanceInKWh;
    @XmlElement(name = "PrepayOverdraftLimitInKWh")
    protected Double prepayOverdraftLimitInKWh;
    @XmlElement(name = "DemandLimitingEnabled")
    protected Boolean demandLimitingEnabled;
    @XmlElement(name = "DemandLimitingThresholdInKW")
    protected Double demandLimitingThresholdInKW;
    @XmlElement(name = "DemandLimitingCalculationPeriod")
    protected Integer demandLimitingCalculationPeriod;
    @XmlElement(name = "DemandLimitingDisconnectPeriod")
    protected Integer demandLimitingDisconnectPeriod;
    @XmlElement(name = "DemandLimitingCalculationDelayPeriod")
    protected Integer demandLimitingCalculationDelayPeriod;
    @XmlElement(name = "SwitchLockoutEnabled")
    protected Boolean switchLockoutEnabled;
    @XmlElement(name = "EmergencySupplyCapacityControlEnabled")
    protected Boolean emergencySupplyCapacityControlEnabled;
    @XmlElement(name = "EmergencySupplyCapacityControlActivated")
    protected Boolean emergencySupplyCapacityControlActivated;
    @XmlElement(name = "EmergencySupplyCapacityControlThresholdInKW")
    protected Double emergencySupplyCapacityControlThresholdInKW;
    @XmlElement(name = "EmergencySupplyCapacityControlCalculationPeriod")
    protected Integer emergencySupplyCapacityControlCalculationPeriod;
    @XmlElement(name = "EmergencySupplyCapacityControlDisconnectPeriod")
    protected Integer emergencySupplyCapacityControlDisconnectPeriod;
    @XmlElement(name = "EmergencySupplyCapacityControlRandomizedStartOnActivate")
    protected Boolean emergencySupplyCapacityControlRandomizedStartOnActivate;
    @XmlElement(name = "LoadControlRandomizedStartTimeInMinutes")
    protected Integer loadControlRandomizedStartTimeInMinutes;
    @XmlElement(name = "BoostEnabled")
    protected Boolean boostEnabled;
    @XmlElement(name = "RemoteProvisioningDataType", required = true)
    protected RemoteProvisioningDataTypeType remoteProvisioningDataType;
    @XmlElement(name = "RemoteProvisioningErrorStatus")
    protected List<RemoteProvisioningErrorStatusType> remoteProvisioningErrorStatus;
    @XmlElement(name = "LoadControlPrimaryGroupID")
    protected Integer loadControlPrimaryGroupID;
    @XmlElement(name = "LoadControlSecondaryGroupID")
    protected Integer loadControlSecondaryGroupID;
    @XmlElement(name = "LoadControlTertiaryGroupID")
    protected Integer loadControlTertiaryGroupID;
    @XmlElement(name = "IgnoreTamperDetectionStartTime")
    protected String ignoreTamperDetectionStartTime;
    @XmlElement(name = "IgnoreTamperDetectionEndTime")
    protected String ignoreTamperDetectionEndTime;
    @XmlElement(name = "IgnoreTamperDetectionEnabled")
    protected Boolean ignoreTamperDetectionEnabled;
    @XmlElement(name = "DoorSensorEnabled")
    protected Boolean doorSensorEnabled;
    @XmlElement(name = "DoorOpen")
    protected Boolean doorOpen;
    @XmlElement(name = "TamperStateEnabled")
    protected Boolean tamperStateEnabled;
    @XmlElement(name = "NicDesiredConnectionStatus")
    protected MeterConnectionStatusType nicDesiredConnectionStatus;
    @XmlAttribute(name = "DeviceMacID", required = true)
    protected String deviceMacID;
    @XmlAttribute(name = "DeviceName", required = true)
    protected String deviceName;
    @XmlAttribute(name = "JobID", required = true)
    protected long jobID;
    @XmlAttribute(name = "JobName", required = true)
    protected String jobName;
    @XmlAttribute(name = "JobCreator", required = true)
    protected String jobCreator;
    @XmlAttribute(name = "JobExecutionTime", required = true)
    protected String jobExecutionTime;
    @XmlAttribute(name = "CustomerID")
    protected String customerID;

    /**
     * Gets the value of the requestedProvisioningAction property.
     * 
     * @return
     *     possible object is
     *     {@link ProvisioningActionType }
     *     
     */
    public ProvisioningActionType getRequestedProvisioningAction() {
        return requestedProvisioningAction;
    }

    /**
     * Sets the value of the requestedProvisioningAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProvisioningActionType }
     *     
     */
    public void setRequestedProvisioningAction(ProvisioningActionType value) {
        this.requestedProvisioningAction = value;
    }

    /**
     * Gets the value of the provisioningCommandStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ProvisioningCommandStatusType }
     *     
     */
    public ProvisioningCommandStatusType getProvisioningCommandStatus() {
        return provisioningCommandStatus;
    }

    /**
     * Sets the value of the provisioningCommandStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProvisioningCommandStatusType }
     *     
     */
    public void setProvisioningCommandStatus(ProvisioningCommandStatusType value) {
        this.provisioningCommandStatus = value;
    }

    /**
     * Gets the value of the meterConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public MeterConnectionStatusType getMeterConnectionStatus() {
        return meterConnectionStatus;
    }

    /**
     * Sets the value of the meterConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public void setMeterConnectionStatus(MeterConnectionStatusType value) {
        this.meterConnectionStatus = value;
    }

    /**
     * Gets the value of the lc1ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public MeterConnectionStatusType getLC1ConnectionStatus() {
        return lc1ConnectionStatus;
    }

    /**
     * Sets the value of the lc1ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public void setLC1ConnectionStatus(MeterConnectionStatusType value) {
        this.lc1ConnectionStatus = value;
    }

    /**
     * Gets the value of the lc2ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public MeterConnectionStatusType getLC2ConnectionStatus() {
        return lc2ConnectionStatus;
    }

    /**
     * Sets the value of the lc2ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public void setLC2ConnectionStatus(MeterConnectionStatusType value) {
        this.lc2ConnectionStatus = value;
    }

    /**
     * Gets the value of the overallStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOverallStatusMessage() {
        return overallStatusMessage;
    }

    /**
     * Sets the value of the overallStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOverallStatusMessage(String value) {
        this.overallStatusMessage = value;
    }

    /**
     * Gets the value of the prepayEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPrepayEnabled() {
        return prepayEnabled;
    }

    /**
     * Sets the value of the prepayEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPrepayEnabled(Boolean value) {
        this.prepayEnabled = value;
    }

    /**
     * Gets the value of the prepayBalanceInKWh property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrepayBalanceInKWh() {
        return prepayBalanceInKWh;
    }

    /**
     * Sets the value of the prepayBalanceInKWh property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrepayBalanceInKWh(Double value) {
        this.prepayBalanceInKWh = value;
    }

    /**
     * Gets the value of the prepayOverdraftLimitInKWh property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrepayOverdraftLimitInKWh() {
        return prepayOverdraftLimitInKWh;
    }

    /**
     * Sets the value of the prepayOverdraftLimitInKWh property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrepayOverdraftLimitInKWh(Double value) {
        this.prepayOverdraftLimitInKWh = value;
    }

    /**
     * Gets the value of the demandLimitingEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDemandLimitingEnabled() {
        return demandLimitingEnabled;
    }

    /**
     * Sets the value of the demandLimitingEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDemandLimitingEnabled(Boolean value) {
        this.demandLimitingEnabled = value;
    }

    /**
     * Gets the value of the demandLimitingThresholdInKW property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDemandLimitingThresholdInKW() {
        return demandLimitingThresholdInKW;
    }

    /**
     * Sets the value of the demandLimitingThresholdInKW property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDemandLimitingThresholdInKW(Double value) {
        this.demandLimitingThresholdInKW = value;
    }

    /**
     * Gets the value of the demandLimitingCalculationPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDemandLimitingCalculationPeriod() {
        return demandLimitingCalculationPeriod;
    }

    /**
     * Sets the value of the demandLimitingCalculationPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDemandLimitingCalculationPeriod(Integer value) {
        this.demandLimitingCalculationPeriod = value;
    }

    /**
     * Gets the value of the demandLimitingDisconnectPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDemandLimitingDisconnectPeriod() {
        return demandLimitingDisconnectPeriod;
    }

    /**
     * Sets the value of the demandLimitingDisconnectPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDemandLimitingDisconnectPeriod(Integer value) {
        this.demandLimitingDisconnectPeriod = value;
    }

    /**
     * Gets the value of the demandLimitingCalculationDelayPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDemandLimitingCalculationDelayPeriod() {
        return demandLimitingCalculationDelayPeriod;
    }

    /**
     * Sets the value of the demandLimitingCalculationDelayPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDemandLimitingCalculationDelayPeriod(Integer value) {
        this.demandLimitingCalculationDelayPeriod = value;
    }

    /**
     * Gets the value of the switchLockoutEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSwitchLockoutEnabled() {
        return switchLockoutEnabled;
    }

    /**
     * Sets the value of the switchLockoutEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSwitchLockoutEnabled(Boolean value) {
        this.switchLockoutEnabled = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEmergencySupplyCapacityControlEnabled() {
        return emergencySupplyCapacityControlEnabled;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEmergencySupplyCapacityControlEnabled(Boolean value) {
        this.emergencySupplyCapacityControlEnabled = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlActivated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEmergencySupplyCapacityControlActivated() {
        return emergencySupplyCapacityControlActivated;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlActivated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEmergencySupplyCapacityControlActivated(Boolean value) {
        this.emergencySupplyCapacityControlActivated = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlThresholdInKW property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getEmergencySupplyCapacityControlThresholdInKW() {
        return emergencySupplyCapacityControlThresholdInKW;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlThresholdInKW property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setEmergencySupplyCapacityControlThresholdInKW(Double value) {
        this.emergencySupplyCapacityControlThresholdInKW = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlCalculationPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEmergencySupplyCapacityControlCalculationPeriod() {
        return emergencySupplyCapacityControlCalculationPeriod;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlCalculationPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEmergencySupplyCapacityControlCalculationPeriod(Integer value) {
        this.emergencySupplyCapacityControlCalculationPeriod = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlDisconnectPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEmergencySupplyCapacityControlDisconnectPeriod() {
        return emergencySupplyCapacityControlDisconnectPeriod;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlDisconnectPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEmergencySupplyCapacityControlDisconnectPeriod(Integer value) {
        this.emergencySupplyCapacityControlDisconnectPeriod = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityControlRandomizedStartOnActivate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEmergencySupplyCapacityControlRandomizedStartOnActivate() {
        return emergencySupplyCapacityControlRandomizedStartOnActivate;
    }

    /**
     * Sets the value of the emergencySupplyCapacityControlRandomizedStartOnActivate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEmergencySupplyCapacityControlRandomizedStartOnActivate(Boolean value) {
        this.emergencySupplyCapacityControlRandomizedStartOnActivate = value;
    }

    /**
     * Gets the value of the loadControlRandomizedStartTimeInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLoadControlRandomizedStartTimeInMinutes() {
        return loadControlRandomizedStartTimeInMinutes;
    }

    /**
     * Sets the value of the loadControlRandomizedStartTimeInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLoadControlRandomizedStartTimeInMinutes(Integer value) {
        this.loadControlRandomizedStartTimeInMinutes = value;
    }

    /**
     * Gets the value of the boostEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBoostEnabled() {
        return boostEnabled;
    }

    /**
     * Sets the value of the boostEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBoostEnabled(Boolean value) {
        this.boostEnabled = value;
    }

    /**
     * Gets the value of the remoteProvisioningDataType property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningDataTypeType }
     *     
     */
    public RemoteProvisioningDataTypeType getRemoteProvisioningDataType() {
        return remoteProvisioningDataType;
    }

    /**
     * Sets the value of the remoteProvisioningDataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningDataTypeType }
     *     
     */
    public void setRemoteProvisioningDataType(RemoteProvisioningDataTypeType value) {
        this.remoteProvisioningDataType = value;
    }

    /**
     * Gets the value of the remoteProvisioningErrorStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the remoteProvisioningErrorStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRemoteProvisioningErrorStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RemoteProvisioningErrorStatusType }
     * 
     * 
     */
    public List<RemoteProvisioningErrorStatusType> getRemoteProvisioningErrorStatus() {
        if (remoteProvisioningErrorStatus == null) {
            remoteProvisioningErrorStatus = new ArrayList<RemoteProvisioningErrorStatusType>();
        }
        return this.remoteProvisioningErrorStatus;
    }

    /**
     * Gets the value of the loadControlPrimaryGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLoadControlPrimaryGroupID() {
        return loadControlPrimaryGroupID;
    }

    /**
     * Sets the value of the loadControlPrimaryGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLoadControlPrimaryGroupID(Integer value) {
        this.loadControlPrimaryGroupID = value;
    }

    /**
     * Gets the value of the loadControlSecondaryGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLoadControlSecondaryGroupID() {
        return loadControlSecondaryGroupID;
    }

    /**
     * Sets the value of the loadControlSecondaryGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLoadControlSecondaryGroupID(Integer value) {
        this.loadControlSecondaryGroupID = value;
    }

    /**
     * Gets the value of the loadControlTertiaryGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLoadControlTertiaryGroupID() {
        return loadControlTertiaryGroupID;
    }

    /**
     * Sets the value of the loadControlTertiaryGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLoadControlTertiaryGroupID(Integer value) {
        this.loadControlTertiaryGroupID = value;
    }

    /**
     * Gets the value of the ignoreTamperDetectionStartTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIgnoreTamperDetectionStartTime() {
        return ignoreTamperDetectionStartTime;
    }

    /**
     * Sets the value of the ignoreTamperDetectionStartTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIgnoreTamperDetectionStartTime(String value) {
        this.ignoreTamperDetectionStartTime = value;
    }

    /**
     * Gets the value of the ignoreTamperDetectionEndTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIgnoreTamperDetectionEndTime() {
        return ignoreTamperDetectionEndTime;
    }

    /**
     * Sets the value of the ignoreTamperDetectionEndTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIgnoreTamperDetectionEndTime(String value) {
        this.ignoreTamperDetectionEndTime = value;
    }

    /**
     * Gets the value of the ignoreTamperDetectionEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIgnoreTamperDetectionEnabled() {
        return ignoreTamperDetectionEnabled;
    }

    /**
     * Sets the value of the ignoreTamperDetectionEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIgnoreTamperDetectionEnabled(Boolean value) {
        this.ignoreTamperDetectionEnabled = value;
    }

    /**
     * Gets the value of the doorSensorEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDoorSensorEnabled() {
        return doorSensorEnabled;
    }

    /**
     * Sets the value of the doorSensorEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDoorSensorEnabled(Boolean value) {
        this.doorSensorEnabled = value;
    }

    /**
     * Gets the value of the doorOpen property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDoorOpen() {
        return doorOpen;
    }

    /**
     * Sets the value of the doorOpen property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDoorOpen(Boolean value) {
        this.doorOpen = value;
    }

    /**
     * Gets the value of the tamperStateEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTamperStateEnabled() {
        return tamperStateEnabled;
    }

    /**
     * Sets the value of the tamperStateEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTamperStateEnabled(Boolean value) {
        this.tamperStateEnabled = value;
    }

    /**
     * Gets the value of the nicDesiredConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public MeterConnectionStatusType getNicDesiredConnectionStatus() {
        return nicDesiredConnectionStatus;
    }

    /**
     * Sets the value of the nicDesiredConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterConnectionStatusType }
     *     
     */
    public void setNicDesiredConnectionStatus(MeterConnectionStatusType value) {
        this.nicDesiredConnectionStatus = value;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceMacID() {
        return deviceMacID;
    }

    /**
     * Sets the value of the deviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceMacID(String value) {
        this.deviceMacID = value;
    }

    /**
     * Gets the value of the deviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Sets the value of the deviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Gets the value of the jobID property.
     * 
     */
    public long getJobID() {
        return jobID;
    }

    /**
     * Sets the value of the jobID property.
     * 
     */
    public void setJobID(long value) {
        this.jobID = value;
    }

    /**
     * Gets the value of the jobName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the value of the jobName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets the value of the jobCreator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobCreator() {
        return jobCreator;
    }

    /**
     * Sets the value of the jobCreator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobCreator(String value) {
        this.jobCreator = value;
    }

    /**
     * Gets the value of the jobExecutionTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobExecutionTime() {
        return jobExecutionTime;
    }

    /**
     * Sets the value of the jobExecutionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobExecutionTime(String value) {
        this.jobExecutionTime = value;
    }

    /**
     * Gets the value of the customerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerID(String value) {
        this.customerID = value;
    }

}
