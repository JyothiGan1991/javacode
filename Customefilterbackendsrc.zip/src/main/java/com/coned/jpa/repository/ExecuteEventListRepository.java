package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coned.model.ExecuteEventList;

@Repository
public interface ExecuteEventListRepository extends JpaRepository<ExecuteEventList, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
}