
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterScheduleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterScheduleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ScheduleID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="ScheduleName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="LastReadTime" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="LastReadValue" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterScheduleType", propOrder = {
    "scheduleID",
    "scheduleName",
    "lastReadTime",
    "lastReadValue"
})
public class MeterScheduleType {

    @XmlElement(name = "ScheduleID")
    protected int scheduleID;
    @XmlElement(name = "ScheduleName", required = true)
    protected String scheduleName;
    @XmlElement(name = "LastReadTime", required = true)
    protected String lastReadTime;
    @XmlElement(name = "LastReadValue")
    protected int lastReadValue;

    /**
     * Gets the value of the scheduleID property.
     * 
     */
    public int getScheduleID() {
        return scheduleID;
    }

    /**
     * Sets the value of the scheduleID property.
     * 
     */
    public void setScheduleID(int value) {
        this.scheduleID = value;
    }

    /**
     * Gets the value of the scheduleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScheduleName() {
        return scheduleName;
    }

    /**
     * Sets the value of the scheduleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScheduleName(String value) {
        this.scheduleName = value;
    }

    /**
     * Gets the value of the lastReadTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastReadTime() {
        return lastReadTime;
    }

    /**
     * Sets the value of the lastReadTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastReadTime(String value) {
        this.lastReadTime = value;
    }

    /**
     * Gets the value of the lastReadValue property.
     * 
     */
    public int getLastReadValue() {
        return lastReadValue;
    }

    /**
     * Sets the value of the lastReadValue property.
     * 
     */
    public void setLastReadValue(int value) {
        this.lastReadValue = value;
    }

}
