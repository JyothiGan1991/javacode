package com.coned.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coned.model.FinalizedEventList;
import com.coned.model.MeterEventLoad;

@Repository
public interface MeterEventLoadRepository extends JpaRepository<MeterEventLoad, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
	MeterEventLoad findByIdAndEventnameAndBorough(Long id, String eventname, String borough);
	
}