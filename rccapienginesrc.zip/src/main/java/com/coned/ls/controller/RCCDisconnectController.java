package com.coned.ls.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.MetersEventFinalizeService;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.utility.DateUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller to implement Rest Api's for RCC Disconnect.
 * 
 */
@RestController
@RequestMapping("rcc/disconnect")
public class RCCDisconnectController extends BaseController{
	private static final Logger LOGGER = LogManager.getLogger(RCCDisconnectController.class);

	@Autowired
	private MetersEventFinalizeService metersEventFinalizeService;
	
	@Autowired
	private OpenEventService openEventService; 
	
	@Autowired
	private MeterEventValidateService meterEventValidateService;  
		
    /*
     * API will return list of borough if the value of parameter is boro or list of event names if 
     * the value is event_name. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields  	Valid input for this parameter are boro and event_name. 
     * 
     * @return 				 	ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/meters")
	public ResponseEntity<List<String>> getNewAndActiveBorough(@RequestParam(name = "fields") String fields) {
		LOGGER.info(String.format("Request for list of borough or event names"));
		
		if (fields.equalsIgnoreCase("boro")) {
			return openEventService.getNewAndActiveBorough();
		} else if(fields.equalsIgnoreCase("event_name")) {
			return openEventService.getNewAndActiveEvent();
		}
		
		throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
	}
	
    /*
     * API to return list of event names for given borough.
     * 
     * @RequestParam borough 	Name of the borough. 
     * 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/meters/{borough}")
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(@PathVariable(name = "borough") String borough) {
		LOGGER.info(String.format("Request for open event by borough : %s", borough));
		
		return openEventService.getNewAndActiveEventByBorough(borough);
	}
	
    /*
     * API to return list of meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @RequestBody meterOpenEvent  MeterOpenEvent 
     * 
     * @return 						ResponseEntity<MeterValidateResponseMapper> 
     *                         
     */
	@PostMapping("/events/meters")
	public ResponseEntity<MeterValidateResponseMapper> getValidateMeter(HttpServletRequest request,@RequestBody MeterOpenEvent meterOpenEvent) throws MeterValidateException, VcapRecordNotFoundException{
		long processStartTime = DateUtils.processStartTime();
		LOGGER.info(String.format("Request for list of meters created for borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == adid || adid.equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		ResponseEntity<MeterValidateResponseMapper> validateMeter = meterEventValidateService.getValidateMeter(meterOpenEvent);
		LOGGER.info(String.format("LogWriter ----> Controller - getValidateMeter : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return validateMeter;
	}
	
    /*
     * API to finalize the list of meters for disconnect.
     * 
     * @RequestBody meterEventFinalize  MeterEventFinalize 
     * 
     * @return 							ResponseEntity<MeterFinalizeResponseMapper> 
     *                         
     */
	@PostMapping("/events/finalize/meters")
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeValidateMeters(HttpServletRequest request,@RequestBody MeterEventFinalize meterEventFinalize) throws Exception {
		//LOGGER.info(String.format("Request for finalizing the list of meters created for borough : %s", meterEventFinalize.getBorough(), " eventName : %s", meterEventFinalize.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return metersEventFinalizeService.finalizeMeterEvent(meterEventFinalize, adid);
	}
	
    /*
     * API to search list of meters.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * 
     * @return 					 ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@PostMapping("/events/search/meters")
	public ResponseEntity<MeterValidateResponseMapper> searchMeter(@RequestBody MeterSearch meterSearch) throws Exception {
		LOGGER.info(String.format("Request for searching list of meters created for borough : %s", meterSearch.getBorough(), " eventName : %s", meterSearch.getEvent()));

		if(null!=meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			return meterEventValidateService.searchMeters(meterSearch);
		}else{
			throw new IllegalArgumentException();
		}
	}

    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/meters/fields/{borough}")
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		LOGGER.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));
		String decodeEventName=decodeEventname(eventName);
		return meterEventValidateService.getFieldValuesByBoroughAndEventName(borough, decodeEventName, fieldName);
	}

    /*
     * API to return locked status of the event.
     * 
     * @RequestParam borough  	String
     * @RequestParam eventName  String
     * 
     * @return 					MeterLockedStatusResponseMapper  
     *                         
     */
	@GetMapping("/events/status/meters")
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(HttpServletRequest request,@RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName){
		LOGGER.info(String.format("Request for locked status of the event by borough : %s", borough, " eventName : %s", eventName));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		String decodedEventName=decodeEventname(eventName);
		return meterEventValidateService.getLockedStatusByBoroughAndEventName(borough, decodedEventName, adid);
	}

    /*
     * API to unlock events.
     * 
     * @Param request  	HttpServletRequest
     * 
     * @return 			void  
     *                         
     */
	@PutMapping("/events/status/meters")
	public void unlockEvents(HttpServletRequest request) {
		LOGGER.info(String.format("Request to unlock the events"));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		meterEventValidateService.unlockEvents(adid);
	}
	private String decodeEventname(String eventName){
		String decodedEventName=eventName;
		if(eventName!=null){
			 try {
				decodedEventName=URLDecoder.decode(eventName,StandardCharsets.UTF_8.name());
			} catch (UnsupportedEncodingException e) {
				LOGGER.error("Unsupported encoding:", e);
			}

		}
		return decodedEventName;
	}
}