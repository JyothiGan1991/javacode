package com.coned.ls.repository;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.tree.RowMapper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito.Then;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { MeterEventConnectRepository.class })
@AutoConfigureMockMvc

public class MeterEventConnectRepositoryTest {
	@Autowired
	private WebApplicationContext wac;

	@MockBean
	private MeterEventConnectRepository meterEventConnectRepository; //= new JdbcMeterEventConnectRepository();

	private OpenEvent openEvent;

	private List<MeterEventLoad> meterEventLoads;

	@InjectMocks
	private JdbcMeterEventConnectRepository jdbcMeterEventConnectRepo;

	private MockMvc mockMvc;

	MeterEventFinalize meterEventFinalize;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	protected JdbcTemplate sqlServerJdbcTemplate;

	@Mock
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	protected JdbcTemplate oracleCommonJdbcTemplate;

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcMeterEventConnectRepo, "oracleJdbcTemplate", oracleJdbcTemplate);
		// ReflectionTestUtils.setField(jdbcMeterEventConnectRepo,
		// "sqlServerJdbcTemplate", sqlServerJdbcTemplate);
		// ReflectionTestUtils.setField(jdbcMeterEventConnectRepo,
		// "starJdbcTemplate", starJdbcTemplate);
		// ReflectionTestUtils.setField(jdbcMeterEventConnectRepo,
		// "oracleCommonJdbcTemplate", oracleCommonJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

	}

	@Test(expected = NullPointerException.class)
	public void getValidMetersForConnect() throws Exception {
		String borough = "B";
		String eventName = "Test";
		int startRowIndex = 1;
		int batchSize = 100;
		String filterList = "";
		String sortList = "test1:test-test,test:test-test";
		String adid = "BUDIDHAK";

		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);

		ResponseEntity<MeterConnectResponseMapper> actual = jdbcMeterEventConnectRepo
				.getValidMetersForConnect(meterOpenEvent);
		Assert.assertEquals(actual, null);
	}

	@Test
	public void searchMeters() {
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("SheepsheadBaySampleData7.27.20-1300");
		meterSearch.setMeters("test,test");
		meterSearch.setSubEvent("SheepsheadBaySampleData7.27.20-1300");
		mcrm = jdbcMeterEventConnectRepo.searchMeters(meterSearch);
		Assert.assertEquals(mcrm.getBorough(), "B");
	}

	@Test
	public void getConnectedMeters() throws MeterEventConnectException {
		MeterConnectResponseMapper mc = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mcrm = new ResponseEntity<MeterConnectResponseMapper>(mc,
				HttpStatus.OK);
		String query = "select METER_EVENT_LOAD_ID,boro_muni,event_name,demand,feeder,building_num,service_address,cust_zip_code,meter_number,account_number,network,VCAP_INSERT_TIME,transformer,structure,req_status from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,mel.building_num,mel.service_address,mel.cust_zip_code,mel.meter_number,mel.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure, msv.req_status from ls_meter_event_load mel inner join lsb_meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where msv.REQUEST_TYPE = 2 AND msv.boro_muni=? and msv.event_name = ? ) t1 where rownum<=?) where rn>=?";
		Object borough = "B";
		Object eventName = "SheepsheadBaySampleData7.27.20-1300";
		int end = 10;
		int begin = 0;
		// Mockito.when(oracleJdbcTemplate.query(query, new Object[]{borough,
		// eventName,end,begin},new RowMapper<MeterEventLoad>()
		// )).thenReturn((mcrm));
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough("B");
		meterOpenEvent.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(10);
		
		mcrm = jdbcMeterEventConnectRepo.getConnectedMeters(meterOpenEvent);
		Assert.assertNotNull(mcrm.getStatusCode());
		
	}

	@Test
	public void finalizeSubEventMeter() throws Exception {
		MeterFinalizeResponseMapper mc = new MeterFinalizeResponseMapper();
		ResponseEntity<MeterFinalizeResponseMapper> mfrm = new ResponseEntity<MeterFinalizeResponseMapper>(mc,
				HttpStatus.OK);
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Test");
		subEvent.setSubEventName("Test");
		subEvent.setExclude(true);
		subEvent.setSelectAll(true);
		subEvent.setSubEventPrefix((long) 2);
		subEvent.setCountOfMeters((long) 10);

		// Mockito.when(oracleJdbcTemplate.queryForObject("select
		// count(FINALIZED_EVENT_ID) from LS_FINALIZE_SUB_EVENT_LIST_DET where
		// boro_muni = ? and event_name = ? and sub_event_name = ?", new
		// Object[]{"B", "Test" , "Test"}, Long.class)).thenReturn((long) 1);
		// Mockito.when(oracleJdbcTemplate.queryForObject("select
		// count(fk_finalized_event_id) from LS_EXECUTE_EVENT_LIST_DETAILS where
		// boro_muni = ? and event_name = ?", new Object[]{"B", "Test"},
		// Long.class)).thenReturn((long) 1);

		// Mockito.when(ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
		// "persistFinalizeMeterSubEventListDept",
		// subEvent.getSubEventName(),subEvent.getBorough(),
		// subEvent.getEvent(),
		// subEvent.getCountOfMeters(),subEvent.getSubEventPrefix())).thenReturn(true);
		Mockito.when(oracleJdbcTemplate.execute(
				"INSERT INTO LS_FINALIZE_SUB_EVENT_LIST_DET (FINALIZED_EVENT_ID, SUB_EVENT_TIME, SUB_EVENT_NAME, BORO_MUNI,EVENT_NAME,OPERATOR_AD_ID, COUNT_OF_METER, SUB_EVENT_SUFFIX) "
						+ "SELECT EELD.FK_FINALIZED_EVENT_ID,EELD.EXECUTE_TIME,?,EELD.BORO_MUNI,EELD.EVENT_NAME,EELD.OPERATOR_AD_ID, ?,? FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD "
						+ "WHERE EXISTS (SELECT EELD2.FK_FINALIZED_EVENT_ID, EELD2.BORO_MUNI,EELD2.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD2 "
						+ "WHERE EELD.BORO_MUNI = EELD2.BORO_MUNI AND EELD.EVENT_NAME = EELD2.EVENT_NAME AND EELD2.BORO_MUNI = ? AND EELD2.EVENT_NAME = ? AND EVENT_TYPE = 'D' AND EELD2.EVENT_TYPE = EELD.EVENT_TYPE) ",
				(PreparedStatementCallback<Boolean>) ps -> {
					ps.setString(1, Mockito.anyString());
					ps.setLong(2, Mockito.anyLong());
					ps.setLong(3, Mockito.anyLong());
					ps.setString(4, Mockito.anyString());
					ps.setString(5, Mockito.anyString());
					ps.execute();
					return true;
				})).thenReturn(true);

		Mockito.when(oracleJdbcTemplate.execute(
				"INSERT INTO LS_FINALIZE_SUB_EVENT_LIST_DET (FINALIZED_EVENT_ID, SUB_EVENT_TIME, SUB_EVENT_NAME, BORO_MUNI,EVENT_NAME,OPERATOR_AD_ID, COUNT_OF_METER, SUB_EVENT_SUFFIX) "
						+ "SELECT EELD.FK_FINALIZED_EVENT_ID,EELD.EXECUTE_TIME,?,EELD.BORO_MUNI,EELD.EVENT_NAME,EELD.OPERATOR_AD_ID, ?,? FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD "
						+ "WHERE EXISTS (SELECT EELD2.FK_FINALIZED_EVENT_ID, EELD2.BORO_MUNI,EELD2.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD2 "
						+ "WHERE EELD.BORO_MUNI = EELD2.BORO_MUNI AND EELD.EVENT_NAME = EELD2.EVENT_NAME AND EELD2.BORO_MUNI = ? AND EELD2.EVENT_NAME = ? AND EVENT_TYPE = 'D' AND EELD2.EVENT_TYPE = EELD.EVENT_TYPE) ",
				(PreparedStatementCallback<Boolean>) ps -> {
					ps.setString(1, "Test");
					ps.setLong(2, (long) 10);
					ps.setLong(3, (long) 2);
					ps.setString(4, "B");
					ps.setString(5, "Test");
					ps.execute();
					return true;
				})).thenReturn(true);

		String SELECT_DET_SQL = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_SUB_EVENT_LIST_DET WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_DET_SQL,
				new Object[] { subEvent.getBorough(), subEvent.getEvent() }, Integer.class)).thenReturn(-1);

		mfrm = jdbcMeterEventConnectRepo.finalizeSubEventMeter(subEvent);
		Assert.assertNotNull(mfrm);
	}

	@Test
	public void finalizeSubEventMeter2() throws Exception {
		MeterFinalizeResponseMapper mc = new MeterFinalizeResponseMapper();
		ResponseEntity<MeterFinalizeResponseMapper> mfrm = new ResponseEntity<MeterFinalizeResponseMapper>(mc,
				HttpStatus.OK);
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Test");
		subEvent.setSubEventName("Test");
		subEvent.setExclude(true);
		subEvent.setSelectAll(true);
		subEvent.setSubEventPrefix((long) 2);
		subEvent.setCountOfMeters((long) 10);

		Mockito.when(oracleJdbcTemplate.queryForObject(
				"select count(FINALIZED_EVENT_ID) from LS_FINALIZE_SUB_EVENT_LIST_DET where boro_muni = ? and event_name = ? and sub_event_name = ?",
				new Object[] { "B", "Test", "Test" }, Long.class)).thenReturn((long) 0);
		Mockito.when(oracleJdbcTemplate.queryForObject(
				"select count(fk_finalized_event_id) from LS_EXECUTE_EVENT_LIST_DETAILS where boro_muni = ? and event_name = ?",
				new Object[] { "B", "Test" }, Long.class)).thenReturn((long) 0);

		// Mockito.when(ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
		// "persistFinalizeMeterSubEventListDept",
		// subEvent.getSubEventName(),subEvent.getBorough(),
		// subEvent.getEvent(),
		// subEvent.getCountOfMeters(),subEvent.getSubEventPrefix())).thenReturn(false);
		Mockito.when(oracleJdbcTemplate.execute(
				"INSERT INTO LS_FINALIZE_SUB_EVENT_LIST_DET (FINALIZED_EVENT_ID, SUB_EVENT_TIME, SUB_EVENT_NAME, BORO_MUNI,EVENT_NAME,OPERATOR_AD_ID, COUNT_OF_METER, SUB_EVENT_SUFFIX) "
						+ "SELECT EELD.FK_FINALIZED_EVENT_ID,EELD.EXECUTE_TIME,?,EELD.BORO_MUNI,EELD.EVENT_NAME,EELD.OPERATOR_AD_ID, ?,? FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD "
						+ "WHERE EXISTS (SELECT EELD2.FK_FINALIZED_EVENT_ID, EELD2.BORO_MUNI,EELD2.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD2 "
						+ "WHERE EELD.BORO_MUNI = EELD2.BORO_MUNI AND EELD.EVENT_NAME = EELD2.EVENT_NAME AND EELD2.BORO_MUNI = ? AND EELD2.EVENT_NAME = ? AND EVENT_TYPE = 'D' AND EELD2.EVENT_TYPE = EELD.EVENT_TYPE) ",
				(PreparedStatementCallback<Boolean>) ps -> {
					ps.setString(1, "Test");
					ps.setLong(2, (long) 10);
					ps.setLong(3, (long) 2);
					ps.setString(4, "B");
					ps.setString(5, "Test");
					ps.execute();
					return true;
				})).thenReturn(true);

		Mockito.when(oracleJdbcTemplate.execute(
				"INSERT INTO LS_FINALIZE_SUB_EVENT_LIST_DET (FINALIZED_EVENT_ID, SUB_EVENT_TIME, SUB_EVENT_NAME, BORO_MUNI,EVENT_NAME,OPERATOR_AD_ID, COUNT_OF_METER, SUB_EVENT_SUFFIX) "
						+ "SELECT EELD.FK_FINALIZED_EVENT_ID,EELD.EXECUTE_TIME,?,EELD.BORO_MUNI,EELD.EVENT_NAME,EELD.OPERATOR_AD_ID, ?,? FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD "
						+ "WHERE EXISTS (SELECT EELD2.FK_FINALIZED_EVENT_ID, EELD2.BORO_MUNI,EELD2.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD2 "
						+ "WHERE EELD.BORO_MUNI = EELD2.BORO_MUNI AND EELD.EVENT_NAME = EELD2.EVENT_NAME AND EELD2.BORO_MUNI = ? AND EELD2.EVENT_NAME = ? AND EVENT_TYPE = 'D' AND EELD2.EVENT_TYPE = EELD.EVENT_TYPE) ",
				(PreparedStatementCallback<Boolean>) ps -> {
					ps.setString(1, "Test");
					ps.setLong(2, (long) 10);
					ps.setLong(3, (long) 2);
					ps.setString(4, "B");
					ps.setString(5, "Test");
					ps.execute();
					return true;
				})).thenReturn(true);

		String SELECT_DET_SQL = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_SUB_EVENT_LIST_DET WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Mockito.when(oracleJdbcTemplate.queryForObject(SELECT_DET_SQL,
				new Object[] { subEvent.getBorough(), subEvent.getEvent() }, Integer.class)).thenReturn(-1);

		mfrm = jdbcMeterEventConnectRepo.finalizeSubEventMeter(subEvent);
		Assert.assertNotNull(mfrm);
	}

	@Test
	public void verifySubEventNameIfExist() {
		String borough = "B";
		String event = "Test";
		String subEventName = "Test";
		String query = "select count(FINALIZED_EVENT_ID) from LS_FINALIZE_SUB_EVENT_LIST_DET where boro_muni = ? and event_name = ? and sub_event_name = ?";
		Mockito.when(
				oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event, subEventName }, Long.class))
				.thenReturn((long) 1);
		Boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "verifySubEventNameIfExist", "B",
				"Test", "Test");
		Assert.assertEquals(res, true);
	}

	@Test
	public void verifySubEventNameIfExistTest() {
		String borough = "B";
		String event = "Test";
		String subEventName = "Test";
		String query = "select count(FINALIZED_EVENT_ID) from LS_FINALIZE_SUB_EVENT_LIST_DET where boro_muni = ? and event_name = ? and sub_event_name = ?";
		Mockito.when(
				oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event, subEventName }, Long.class))
				.thenReturn((long) 0);
		Boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "verifySubEventNameIfExist", "B",
				"Test", "Test");
		Assert.assertEquals(res, false);
	}

	/*
	 * @Test public void getKVAForSubevent() { String borough = "B"; String
	 * eventName = "Test"; String subEventName = "Test"; String query =
	 * "SELECT sum(mel.demand) FROM ls_meter_event_load mel inner join LS_CREATE_SUB_EVENT_LIST  fsel on fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name and fsel.fk_meter_event_load_id = mel.meter_event_load_id and mel.boro_muni =? and mel.event_name=?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new
	 * Object[]{borough, eventName},Integer.class)).thenReturn(1); int count =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getKVAForSubevent", "B", "Test", "Test"); Assert.assertNotNull(count); }
	 */

	@Test
	public void getKVAForFinalSubevent() {
		String borough = "B";
		String eventName = "Test";
		String subEventName = "Test";
		String query = "SELECT sum(mel.demand) FROM ls_meter_event_load mel inner join LS_FINALIZE_SUB_EVENT_LIST  fsel on fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name and fsel.fk_meter_event_load_id = mel.meter_event_load_id and mel.boro_muni =? and mel.event_name=? and fsel.sub_event_name=?";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName, subEventName },
				String.class)).thenReturn("Test");
		String response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getKVAForFinalSubevent", "B",
				"Test", "Test");
		Assert.assertNotNull(response);
	}

	@Test(expected = NullPointerException.class)
	public void getTotalFinalizeRecordInEvent() {
		String borough = "B";
		String eventName = "Test";
		String query = "SELECT count (fsel.fk_meter_event_load_id)FROM ls_finalize_sub_event_list fsel LEFT JOIN ls_execute_event_list_connect eelc ON eelc.fk_meter_event_load_id = fsel.fk_meter_event_load_id AND fsel.event_name = eelc.event_name WHERE fsel.boro_muni = ? AND fsel.event_name = ? AND eelc.fk_meter_event_load_id IS NULL";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Long.class))
				.thenReturn((long) 1);
		long count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getTotalFinalizeRecordInEvent", "B",
				"Test");
		Assert.assertNotNull(count);
	}

	/*
	 * @Test public void getKVAForConnectedMeters() { String borough = "B";
	 * String eventName = "SheepsheadBaySampleData7.27.20-1300"; String query =
	 * "SELECT SUM(mel.demand) FROM ls_meter_event_load mel INNER JOIN meter_status_vw msv ON msv.meter_number = mel.meter_number AND msv.boro_muni = mel.boro_muni AND msv.event_name = mel.event_name WHERE ( ( msv.meter_status = 'RMT_PROV_RES_STAT_CONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C' ) ) AND msv.boro_muni = ? AND msv.event_name = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, eventName }, Double.class)).thenReturn((double) 1); double count
	 * = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getKVAForConnectedMeters", "B","SheepsheadBaySampleData7.27.20-1300");
	 * //Assert.assertNull(count); }
	 */
	/*
	 * @Test public void getKVAForSubeventTest() { String borough = "B"; String
	 * eventName = "Test"; String query =
	 * "select SUM (mel.demand) from ls_meter_event_load mel inner join meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where ( (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C') OR (req_status IN ('N','I')) OR (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status <> 'GMI_RSM_SUCCESS' AND req_status = 'C')) AND msv.boro_muni=? and msv.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND msv.boro_muni = esel.boro_muni AND msv.event_name = esel.event_name)"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, eventName }, Integer.class)) .thenReturn(1); int count =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getKVAForSubevent", "B", "Test"); Assert.assertNotNull(count); }
	 */
	/*
	 * @Test public void getKVAForSubeventSelectedMeters() { String borough =
	 * "B"; String eventName = "Test"; String meters = "Test"; String query =
	 * "select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("
	 * + meters + ")"; Mockito.when(oracleJdbcTemplate.queryForObject(query, new
	 * Object[] { borough, eventName }, Integer.class)) .thenReturn(1); int
	 * count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getKVAForSubeventSelectedMeters", "B", "Test", "Test");
	 * Assert.assertNotNull(count); }
	 */

	@Test
	public void getKVAForConnectedSelectedMeters() {
		String borough = "B";
		String eventName = "Test";
		String meters = "Test";
		String query = "select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("
				+ meters + ")";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, String.class))
				.thenReturn("test");
		String response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
				"getKVAForConnectedSelectedMeters", "B", "Test", "Test");
		Assert.assertNotNull(response);
	}

	/*
	 * @Test public void getKVAOfExcludeMeters() { String borough = "B"; String
	 * eventName = "Test"; String meters = "Test"; String query =
	 * "select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number NOT IN ("
	 * + meters + ")"; Mockito.when(oracleJdbcTemplate.queryForObject(query, new
	 * Object[] { borough, eventName }, Integer.class)) .thenReturn(1); int
	 * response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getKVAOfExcludeMeters", "B", "Test", "Test");
	 * Assert.assertNotNull(response); }
	 */

	@Test
	public void searchMeterConnected() {
		MeterConnectResponseMapper mcrm = new MeterConnectResponseMapper();
		MeterSearch meterSearch = new MeterSearch();
		mcrm = jdbcMeterEventConnectRepo.searchMeterConnected(meterSearch);
		Assert.assertEquals(mcrm.getBorough(), null);
	}

	@Test
	public void getSubEventSuffix() {
		String borough = "B";
		String eventName = "Test";
		// String query ="select SUM(mel.demand) from ls_meter_event_load mel
		// WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number
		// NOT IN ("+meters+")";
		// Mockito.when(oracleJdbcTemplate.queryForObject(query,new
		// Object[]{borough, eventName}, Integer.class)).thenReturn(1);
		ResponseEntity<Long> response = jdbcMeterEventConnectRepo.getSubEventSuffix(borough, eventName);
		Assert.assertNotNull(response);
	}

	@Test
	public void getSubEventSuffixTest() {
		String borough = null;
		String eventName = null;
		ResponseEntity<Long> response = jdbcMeterEventConnectRepo.getSubEventSuffix(borough, eventName);
		Assert.assertNotNull(response);
	}

	/*
	 * @Test public void getTotalCountForConnect() { String borough = "B";
	 * String event = "Test"; String query =
	 * "select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where ( (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C') OR (req_status IN ('N','I')) OR (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status <> 'GMI_RSM_SUCCESS' AND req_status = 'C')) AND msv.boro_muni=? and msv.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND msv.boro_muni = esel.boro_muni AND msv.event_name = esel.event_name)"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, event }, Long.class)) .thenReturn((long) 1); Long response =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getTotalCountForConnect", "B", "Test"); Assert.assertNotNull(response);
	 * }
	 */
	/*
	 * @Test public void getTotalMeterCountForConnect() { String borough = "B";
	 * String event = "Test"; String query =
	 * "select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where ( (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C') OR (req_status IN ('N','I')) OR (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status <> 'GMI_RSM_SUCCESS' AND req_status = 'C')) AND msv.boro_muni=? and msv.event_name = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query,new
	 * Object[]{borough, event}, Long.class)) .thenReturn((long) 1); Long
	 * response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getTotalMeterCountForConnect", "B", "Test");
	 * Assert.assertNotNull(response); }
	 */
	@Test
	public void getTotalCountForConnected() {
		String borough = "B";
		String event = "Test";
		String query = "SELECT count(mel.meter_event_load_id) FROM ls_meter_event_load mel INNER JOIN meter_status_vw msv ON msv.meter_number = mel.meter_number AND msv.boro_muni = mel.boro_muni AND msv.event_name = mel.event_name WHERE ( ( msv.meter_status = 'RMT_PROV_RES_STAT_CONNECTED'AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C' )) AND msv.boro_muni = ? AND msv.event_name = ?";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event }, Long.class))
				.thenReturn((long) 1);
		Long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getTotalCountForConnected", "B",
				"Test");
		// Assert.assertNotNull(response);
	}

	/*
	 * @Test public void getTotalCountAfterExclude() { String borough = "B";
	 * String event = "Test"; String meters = "Test"; String query =
	 * "select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where ( (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C') OR (req_status IN ('N','I')) OR (msv.meter_status = 'RMT_PROV_RES_STAT_DISCONNECTED' AND msv.prv_cmd_status <> 'GMI_RSM_SUCCESS' AND req_status = 'C')) AND msv.boro_muni=? and msv.event_name = ?  AND mel.METER_EVENT_LOAD_ID NOT IN ("
	 * + meters +
	 * ")  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND msv.boro_muni = esel.boro_muni AND msv.event_name = esel.event_name)"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, event }, Long.class)) .thenReturn((long) 1); Long response =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getTotalCountAfterExclude", "B", "Test", "Test");
	 * Assert.assertNotNull(response); }
	 */

	@Test
	public void getTotalCountForFinalSubEvent() {
		String borough = "B";
		String event = "Test";
		String subEvent = "Test";
		String query = "SELECT COUNT(fk_meter_event_load_id) FROM ls_finalize_sub_event_list WHERE boro_muni = ? AND event_name= ? AND sub_event_name = ? ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event, subEvent }, Long.class))
				.thenReturn((long) 1);
		Long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getTotalCountForFinalSubEvent",
				"B", "Test", "Test");
		Assert.assertNotNull(response);
	}

	@Test
	public void getSubEventMeters() {
		MeterConnectResponseMapper mc = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mfrm = new ResponseEntity<MeterConnectResponseMapper>(mc,
				HttpStatus.OK);
		mfrm = jdbcMeterEventConnectRepo.getSubEventMeters("Test", "Test", "Test", 1, 10);
		Assert.assertNotNull(mfrm);
	}

	@Test
	public void getSubEventMeters2() {
		MeterConnectResponseMapper mc = new MeterConnectResponseMapper();
		SubEvent subEvent = new SubEvent();
		subEvent.setExclude(false);
		subEvent.setListOfMeters(null);
		mc = jdbcMeterEventConnectRepo.getSubEventMeters(subEvent);
		Assert.assertNotNull(mc);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName1() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "structureName";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getConnectedMeterFieldValuesByBoroughAndEventName1() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "req_status";
		fieldValueList = jdbcMeterEventConnectRepo.getConnectedMetersFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}
	
	@Test
	public void getConnectedMeterFieldValuesByBoroughAndEventName2() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "sub_event_name";
		fieldValueList = jdbcMeterEventConnectRepo.getConnectedMetersFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}
	
	@Test
	public void getFieldValuesByBoroughAndEventName2() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "meterEventLoadId";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName3() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "borough";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName4() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "eventName";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName5() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "demand";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName6() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "feeder";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName7() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "buildingNumber";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName8() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "serviceAddress";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName9() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "customerZipCode";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName10() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "meterNumber";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName11() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "accountNumber";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName12() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "network";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName13() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "eventStatus";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName14() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "vcapInsertTime";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	@Test
	public void getFieldValuesByBoroughAndEventName15() {
		List<String> fieldValueList = new ArrayList<>();
		String borough = "B";
		String eventName = "Test";
		String fieldName = "transformer";
		fieldValueList = jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertNotNull(fieldValueList);
	}

	/*
	 * @Test(expected = IllegalArgumentException.class) public void
	 * getFieldValuesByBoroughAndEventName16() { List<String> fieldValueList =
	 * new ArrayList<>(); String borough = "B"; String eventName = "Test";
	 * String fieldName = "VCAP_INSERT_TIME"; fieldValueList =
	 * jdbcMeterEventConnectRepo.getFieldValuesByBoroughAndEventName(borough,
	 * eventName, fieldName); Assert.assertNotNull(fieldValueList); }
	 */

	@Test
	public void isEventLocked() {
		String borough = "B";
		String eventName = "Test";
		String adid = "budidhak";
		Integer CountOfOperator = 1;
		String lockOperatorADID = "Test";
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Mockito.when((Integer) oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName },
				Integer.class)).thenReturn(CountOfOperator);
		Mockito.when(
				oracleJdbcTemplate.queryForObject(operatorADIDQuery, new Object[] { "Test", "Test" }, String.class))
				.thenReturn(lockOperatorADID);
		MeterLockedStatusResponseMapper mvrp = jdbcMeterEventConnectRepo.isEventLocked(borough, eventName, adid);
		Assert.assertNotNull(mvrp);
	}

	@Test
	public void getSubEventMeterLists() {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("SheepsheadBaySampleData7.27.20-1300");
		List<String> listOfMeters = new ArrayList<>();
		subEvent.setListOfMeters(listOfMeters);
		Boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getSubEventMeterLists", subEvent);
		Assert.assertEquals(res, true);
	}

	@Test
	public void getSubEventMeterListsSelectAll() {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("SheepsheadBaySampleData7.27.20-1300");
		List<String> listOfMeters = new ArrayList<>();
		subEvent.setListOfMeters(listOfMeters);
		Boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getSubEventMeterListsSelectAll",
				subEvent);
		Assert.assertEquals(res, false);
	}

	@Test
	public void getSubEventMeterListsAfterExclude() {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		List<String> listOfMeters = new ArrayList<>();
		subEvent.setListOfMeters(listOfMeters);
		subEvent.setEvent("SheepsheadBaySampleData7.27.20-1300");
		ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getSubEventMeterListsAfterExclude", subEvent);
	}

	/*
	 * @Test public void getAllSubEventMeterLists() { List<MeterEventLoad>
	 * meterEventLoadList = new ArrayList<MeterEventLoad>(); SubEvent subEvent =
	 * new SubEvent(); subEvent.setBorough("B");
	 * subEvent.setEvent("SheepsheadBaySampleData7.27.20-1300"); List<String>
	 * listOfMeters = new ArrayList<>(); subEvent.setListOfMeters(listOfMeters);
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getAllSubEventMeterLists", subEvent); }
	 */

	@Test
	public void convertMeterStatus() {
		List<MeterEventLoad> meterEventLoadList = new ArrayList<MeterEventLoad>();
		List<MeterEventLoad> response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
				"convertMeterStatus", meterEventLoadList);
		Assert.assertNotNull(response);
	}

	/*
	 * @Test public void totalCountForSelectAll() { String borough = "B"; String
	 * event = "Test"; String query =
	 * "select count(*) from LS_EXECUTE_EVENT_LIST where boro_muni = ? and event_name = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, event }, Long.class)) .thenReturn((long) 1); long res =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "totalCountForSelectAll", "B", "Test"); Assert.assertNotNull(res); }
	 */

	/*
	 * @Test public void checkEventExecuted() { String borough = "B"; String
	 * event = "Test"; String query =
	 * "select count(fk_finalized_event_id) from LS_EXECUTE_EVENT_LIST_DETAILS where boro_muni = ? and event_name = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, event }, Long.class)) .thenReturn((long) 1); Boolean res =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "checkEventExecuted", "B", "Test"); Assert.assertEquals(res, true); }
	 */

	/*
	 * @Test public void checkEventExecutedTest() { String borough = "B"; String
	 * event = "Test"; String query =
	 * "select count(fk_finalized_event_id) from LS_EXECUTE_EVENT_LIST_DETAILS where boro_muni = ? and event_name = ?"
	 * ; Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] {
	 * borough, event }, Long.class)) .thenReturn((long) 0); Boolean res =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "checkEventExecuted", "B", "Test"); Assert.assertEquals(res, false); }
	 */

	/*
	 * @Test(expected = ArrayIndexOutOfBoundsException.class) public void
	 * buildFilterQuery() { String borough = "B"; String eventName = "Test";
	 * String meters = "Test"; String query =
	 * "select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("
	 * + meters + ")"; Mockito.when(oracleJdbcTemplate.queryForObject(query, new
	 * Object[] { borough, eventName }, String.class)) .thenReturn("test");
	 * String[] meterArry = new String[2]; String response =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "buildFilterQuery", meterArry, 1, 10, true, true);
	 * Assert.assertNotNull(response); }
	 */
	
	@Test
	public void buildFilterQuery() {
		
		 Map<String,String> filterListMap=new HashMap<>();
		 filterListMap.put("Test", "Test,Test");
		 String queryPrefix="Test";
		
		String response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "buildFilterQuery", filterListMap,queryPrefix);
		Assert.assertNotNull(response);
	}
	
	
	@Test
	public void buildSortQuery() {
		
		 Map<String,String> sortListMap=new HashMap<>();
		 sortListMap.put("Test", "Test,Test");
		 String queryPrefix="Test";
		
		String response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "buildSortQuery", sortListMap,queryPrefix);
		Assert.assertNotNull(response);
	}

	/*
	 * @Test public void buildFilterQuery3() { String borough = "B"; String
	 * eventName = "Test"; String meters = "Test"; String filterList =
	 * "serviceAddress:test-xyz, eventName:test-abc"; String query =
	 * "select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("
	 * + meters + ")"; Mockito.when(oracleJdbcTemplate.queryForObject(query, new
	 * Object[] { borough, eventName }, String.class)) .thenReturn("test");
	 * String[] meterArry = new String[2];
	 * 
	 * String response =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "buildFilterQuery", filterList); Assert.assertNotNull(response); }
	 */

	/*
	 * @Test(expected = ArrayIndexOutOfBoundsException.class) public void
	 * buildExcludeFilterQuery() {
	 * 
	 * String borough = "B"; String eventName = "Test"; String meters ="Test";
	 * String query
	 * ="select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("
	 * +meters+")"; Mockito.when(oracleJdbcTemplate.queryForObject(query,new
	 * Object[]{borough, eventName}, String.class)).thenReturn("test");
	 * 
	 * String[] meterArry = new String[0]; String response =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "buildExcludeFilterQuery", meterArry, 1, 10, true);
	 * Assert.assertNotNull(response); }
	 */

	@Test
	public void getMeterEventLoadIds() {
		List<MeterEventLoadIdAndDemand> mvl = new ArrayList<MeterEventLoadIdAndDemand>();
		mvl = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getMeterEventLoadIds", "B", "Test", "");
		Assert.assertNotNull(mvl);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void checkAndUpdateIfEventUnlocked() {
		MeterConnectResponseMapper mcrp = new MeterConnectResponseMapper();
		String borough = mcrp.getBorough();
		String eventName = mcrp.getEventName();
		Integer CountOfOperator = 1;
		String lockOperatorADID = "Test";
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";

		Mockito.when((Integer) oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName },
				Integer.class)).thenReturn(2);
		Mockito.when(
				oracleJdbcTemplate.queryForObject(operatorADIDQuery, new Object[] { borough, eventName }, String.class))
				.thenReturn("Test");

		MeterConnectResponseMapper mvrp = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
				"checkAndUpdateIfEventUnlocked", "Test1", mcrp);
		Assert.assertNotNull(mvrp);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void checkAndUpdateIfEventUnlocked2() {
		MeterConnectResponseMapper mcrp = new MeterConnectResponseMapper();
		String borough = mcrp.getBorough();
		String eventName = mcrp.getEventName();
		Integer CountOfOperator = 1;
		String lockOperatorADID = "Test";
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";

		Mockito.when((Integer) oracleJdbcTemplate.queryForObject(totalCountQuery, new Object[] { borough, eventName },
				Integer.class)).thenReturn(2);
		Mockito.when(
				oracleJdbcTemplate.queryForObject(operatorADIDQuery, new Object[] { borough, eventName }, String.class))
				.thenReturn("Test");

		MeterConnectResponseMapper mvrp = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
				"checkAndUpdateIfEventUnlocked", "Test", mcrp);
		Assert.assertNotNull(mvrp);
	}

	@Test
	public void getValidTotalRecord() {
		String borough = "B";
		String eventName = "Test";
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Integer.class))
				.thenReturn(1);
		int count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getValidTotalRecord", "B", "Test");
		Assert.assertNotNull(count);
	}

	@Test
	public void getTotalKva() {
		String borough = "B";
		String eventName = "Test";
		String filterList = "serviceAddress:test-xyz, eventName:test-abc";
		//String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) "

		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name inner join ls_validate_event_list lve on lve.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and lve.boro_muni=mel.boro_muni and lve.event_name=mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) "
				+ filterList;
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, String.class))
				.thenReturn("Test");
		String response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getTotalKva", "B", "Test",
				filterList);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void getCountOfMeters() {
		String borough = "B";
		String eventName = "Test";
		String filterList = "Test";
		String countQuery = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name inner join ls_validate_event_list lve on lve.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and lve.boro_muni=mel.boro_muni and lve.event_name=mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) " + filterList;

		Mockito.when((Integer)oracleJdbcTemplate.queryForObject(countQuery,  new Object[]{borough, eventName}, Integer.class))
				.thenReturn(1);
		int count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getCountOfMeters", "B", "Test", "Test");
		Assert.assertNotNull(count);
	}
	
	@Test(expected = NullPointerException.class)
	public void createSubEventMeters() {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("Test");
		subEvent.setEvent("Test");
		subEvent.setExclude(true);
		subEvent.setIsCreateSubEvent(true);
		
		int count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "createSubEventMeters", subEvent );
		Assert.assertNotNull(count);
	}

	/*
	 * @Test public void getCountOfMeters() { String borough = "B"; String
	 * eventName = "ParkSlope.11.11/09/20-11:17:02.AUTO"; String filterList =
	 * ""; String countQuery =
	 * "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) "
	 * + filterList;
	 * Mockito.when((Integer)oracleJdbcTemplate.queryForObject(countQuery, new
	 * Object[]{borough, eventName}, Integer.class)).thenReturn(null); int count
	 * = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getCountOfMeters",
	 * "B","ParkSlope.11.11/09/20-11:17:02.AUTO",filterList);
	 * //Assert.assertNotNull(count); }
	 */
	/*
	 * @Test public void getTotalConnectedMeters() { String borough = "B";
	 * String eventName = "Test"; String query =
	 * "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name where((msv.meter_status = 'RMT_PROV_RES_STAT_CONNECTED' AND msv.prv_cmd_status = 'GMI_RSM_SUCCESS' AND req_status = 'C' )) AND msv.boro_muni=? and msv.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND msv.boro_muni = esel.boro_muni AND msv.event_name = esel.event_name)"
	 * ; Mockito.when((Integer)oracleJdbcTemplate.queryForObject(query, new
	 * Object[]{borough, eventName}, Integer.class)).thenReturn(1); int count =
	 * ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo,
	 * "getTotalConnectedMeters", "B","Test"); Assert.assertNotNull(count); }
	 */

	@Test
	public void getMeterCountExcludeFinalized() {
		String borough = "B";
		String event = "Test";
		String query = "select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? AND eel.sub_event_name IS NULL AND eel.FK_METER_EVENT_LOAD_ID NOT IN (SELECT EEL2.FK_METER_EVENT_LOAD_ID FROM LS_EXECUTE_EVENT_LIST EEL2 where EEL2.boro_muni = ? and EEL2.event_name = ? AND EEL2.sub_event_name IS NOT NULL) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name)";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event }, Long.class))
				.thenReturn((long) 1);
		Long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getMeterCountExcludeFinalized",
				"B", "Test");
		//Assert.assertNotNull(response);
	}

	@Test
	public void getTotalMeterCount() {
		String borough = "B";
		String event = "Test";
		String query = "select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? ";
	
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event }, Long.class))
				.thenReturn((long) 1);
		Long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "getTotalMeterCount", "B", "Test");
		Assert.assertNotNull(response);
	}

	@Test
	public void meterCountSubEventBeforeFinalized() {
		String borough = "B";
		String event = "Test";
		String query = "SELECT COUNT(fk_meter_event_load_id) FROM ls_connect_event_list WHERE boro_muni = ? AND event_name= ? ";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event }, Long.class))
				.thenReturn((long) 1);
		Long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "meterCountSubEventBeforeFinalized",
				"B", "Test");
		Assert.assertNotNull(response);
	}

	@Test
	public void meterSubeventKVABeforeFinalized() {
		String borough = "B";
		String eventName = "Test";
		String query = "SELECT sum(mel.demand) FROM ls_meter_event_load mel inner join LS_CONNECT_EVENT_LIST  fsel on fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name and fsel.fk_meter_event_load_id = mel.meter_event_load_id and mel.boro_muni =? and mel.event_name=?";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, eventName }, Double.class))
				.thenReturn((double) 1);
		double count = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "meterSubeventKVABeforeFinalized",
				"B", "Test");
		Assert.assertNotNull(count);
	}

	@Test
	public void unlockEvents() {
		jdbcMeterEventConnectRepo.unlockEvents("BUDIDHAK");
	}

	@Test
	public void finalizeSubEventMeter3() {
		String borough = "Test";
		String eventName = "Test";
		String subEventName = "Test";
		int eventId = 1;
		boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "finalizeSubEventMeter", borough,
				eventName, subEventName, eventId);
		Assert.assertEquals(res, true);
	}

	/*@Test
	public void finalizeSubEventMeterDetails()throws MeterFinalizeException  {
		String borough = "Test";		
		String eventName = "Test";
		String subEventName = "Test";
		long totalCount = 1;
		long suffix = 1;
		String adid = "Test";		
		boolean res = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "finalizeSubEventMeterDetails",
				borough, eventName, subEventName, totalCount, suffix, adid);
		Assert.assertEquals(res, true);
	}*/

	@Test
	public void finalizeSubEventMeterCount() {
		String borough = "B";
		String event = "Test";
		String query = "select count(*) from LS_CONNECT_EVENT_LIST where boro_muni = ? and event_name = ?";
		Mockito.when(oracleJdbcTemplate.queryForObject(query, new Object[] { borough, event }, Long.class))
				.thenReturn((long) 1);
		long response = ReflectionTestUtils.invokeMethod(jdbcMeterEventConnectRepo, "finalizeSubEventMeterCount", "B",
				"Test");
		Assert.assertNotNull(response);
	}
	
}
