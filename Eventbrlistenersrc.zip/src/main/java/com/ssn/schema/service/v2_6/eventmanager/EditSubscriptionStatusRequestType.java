
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditSubscriptionStatusRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditSubscriptionStatusRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EventID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="SubscriptionStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditSubscriptionStatusRequestType", propOrder = {
    "eventID",
    "subscriptionStatus"
})
public class EditSubscriptionStatusRequestType {

    @XmlElement(name = "EventID")
    protected long eventID;
    @XmlElement(name = "SubscriptionStatus")
    protected boolean subscriptionStatus;

    /**
     * Gets the value of the eventID property.
     * 
     */
    public long getEventID() {
        return eventID;
    }

    /**
     * Sets the value of the eventID property.
     * 
     */
    public void setEventID(long value) {
        this.eventID = value;
    }

    /**
     * Gets the value of the subscriptionStatus property.
     * 
     */
    public boolean isSubscriptionStatus() {
        return subscriptionStatus;
    }

    /**
     * Sets the value of the subscriptionStatus property.
     * 
     */
    public void setSubscriptionStatus(boolean value) {
        this.subscriptionStatus = value;
    }

}
