
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClearByEventSearchType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClearByEventSearchType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EventSearchKey" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="EventID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClearByEventSearchType", propOrder = {
    "eventSearchKey",
    "eventID"
})
public class ClearByEventSearchType {

    @XmlElement(name = "EventSearchKey")
    protected long eventSearchKey;
    @XmlElement(name = "EventID")
    protected int eventID;

    /**
     * Gets the value of the eventSearchKey property.
     * 
     */
    public long getEventSearchKey() {
        return eventSearchKey;
    }

    /**
     * Sets the value of the eventSearchKey property.
     * 
     */
    public void setEventSearchKey(long value) {
        this.eventSearchKey = value;
    }

    /**
     * Gets the value of the eventID property.
     * 
     */
    public int getEventID() {
        return eventID;
    }

    /**
     * Sets the value of the eventID property.
     * 
     */
    public void setEventID(int value) {
        this.eventID = value;
    }

}
