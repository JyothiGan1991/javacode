package com.coned.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;*/
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.coned.exception.ResourceMissingException;
import com.coned.jpa.controller.FinalizeEventListDetailsController;
import com.coned.model.ExecuteEventListDetails;
import com.coned.model.FinalizeEventListDetails;
import com.coned.model.RejectEventListDetails;
import com.coned.util.AOCCWebUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Component
@PropertySource("classpath:queries.properties")
//@CacheConfig(cacheNames={"allevents"})
public class BaseService {
	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";
	private static String FINALIZE = "finalize";
	private static String EXECUTE = "execute";
	private static String REJECT = "reject";
	private static String OPERATOR = "Operator";
	
	@Autowired
	private Environment env;
	private static final Logger logger = LoggerFactory.getLogger(FinalizeEventListDetailsController.class);
	@PersistenceContext
	private EntityManager em;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	BaseService selfFinCntr;
	
	@Autowired
	ExecuteEventUtil eutil;

	@Autowired
	AOCCWebUtil webutil;
	
	public boolean isUserAuthorized(String userName, String apiKey, String ipaddress, int loginStatus, int apiStatus) {
		boolean isUserAuthorized = false;
		try {
			
			Properties props = System.getProperties() ;
			final Set<String> keys = props.stringPropertyNames();
		
			String qstr = env.getProperty("aocc.login.isUserAuthorized");
			qstr 	= "SELECT count(*) FROM ami_load_shedding.ls_aocc_user_login "
					+ "WHERE UPPER(username)=UPPER('"+userName+"') AND token='"+apiKey+"' "
					+ "AND ipaddress='"+ipaddress+"' AND login_status="+loginStatus+" AND token_status="+apiStatus;
			logger.debug("isUserAuthorized - query "+qstr);
			int count = ((Number)em.createNativeQuery(qstr).getSingleResult()).intValue();
			logger.debug(em.createNativeQuery(qstr).getResultList().get(0)+" Result - count? "+count);
			if(count>0)
				isUserAuthorized = true;
		} catch (Exception e) {
			logger.error("** Exception ->isUserAuthorized: "+e);
		}
		return isUserAuthorized;
	}
		
	public List getUserDetails(String username) {
		logger.debug("--- START getUserDetails() ---");
		List<Object[]> list = new ArrayList<Object[]>();
		try {
			String qstr = env.getProperty("aocc.login.getUserDetails");
			logger.debug("getUserDetails - query "+qstr);
			Query q = em.createNativeQuery(qstr);
			q.setParameter("userName", username);
			/*qstr 	= "SELECT u.status, r.name FROM ami_load_shedding.ls_aocc_role r "
					+ "INNER JOIN ami_load_shedding.ls_aocc_user u ON u.role_id = r.id "
					+ "WHERE UPPER(u.username) = UPPER('"+username+"')";*/
			
			list = q.getResultList();
		} catch (Exception e) {
			logger.error("** Exception ->getUserDetails: "+e);
		}
		logger.debug("--- END getUserDetails() ---");
		return list;
	}
	
	@Transactional
	public boolean saveUserLogin(String userName, String apiKey, String action, String actionTime) {
		try {
			logger.debug(" --- START saveUserLogin() --- ");
			int tokenStatus = 0;
			int loginStatus = 0;
			String ipaddress = webutil.getClientIp();
			String qstr = "";
			Query q = null;
//			logger.debug("query? "+q.toString());
			if(action.equalsIgnoreCase("login")){
				tokenStatus = 13;
				loginStatus = 10;
				/*qstr 	= "Insert into ami_load_shedding.ls_aocc_user_login (USERNAME,TOKEN,IPADDRESS, LOGIN_STATUS,TOKEN_STATUS,LOGIN_TIME) "
						+ "values ('"+ userName +"','"+ apiKey +"','"+ ipaddress +"',"+ loginStatus +","+ tokenStatus +",to_date('"+ actionTime +"','MM/DD/YYYY HH24:MI:SS'))";*/
				qstr = env.getProperty("aocc.login.createUserLogin");
				logger.debug(" --qstr? "+qstr);
				q = em.createNativeQuery(qstr);
				q.setParameter("userName", userName);
				q.setParameter("apiKey", apiKey);
				q.setParameter("ipaddress", ipaddress);
				q.setParameter("loginStatus", loginStatus);
				q.setParameter("tokenStatus", tokenStatus);
				q.setParameter("actionTime", actionTime);
			} else if (action.equalsIgnoreCase("logout")){
				tokenStatus = 12;
				loginStatus = 11;
				/*qstr 	= "UPDATE ami_load_shedding.ls_aocc_user_login "
						+ "SET logout_time=to_date('"+ actionTime +"','MM/DD/YYYY HH24:MI:SS'),"
						+ "token_status="+tokenStatus+","
						+ "login_status="+loginStatus+ " "
						+ "WHERE UPPER(username)=UPPER('"+ userName +"') AND token='"+ apiKey +"' "
						+ "AND ipaddress='"+ ipaddress +"'";*/
				qstr = env.getProperty("aocc.login.updateUserLogin");
				logger.debug(" --qstr? "+qstr);
				q = em.createNativeQuery(qstr);
				q.setParameter("actionTime", actionTime);
				q.setParameter("loginStatus", loginStatus);
				q.setParameter("tokenStatus", tokenStatus);				
				q.setParameter("userName", userName);
				q.setParameter("apiKey", apiKey);
				q.setParameter("ipaddress", ipaddress);
				
			}
			logger.debug("saveUserLogin - query "+qstr);
			int res = q.executeUpdate();//eutil.executeQuery(qstr);
			logger.debug("saveUserLogin - res "+res);
			if(res != 0) {
				return true;
			}
			logger.debug(" --- END saveUserLogin() --- ");
		} catch (Exception e) {
			logger.error("** Exception ->getUserDetails: "+e);
		}
		return false;
	}
	
	Optional<FinalizeEventListDetails> findFinById(Long eventid) {
		Optional<FinalizeEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT finalized_event_id, count_of_meters, finalize_time, boro_muni, event_name FROM "
					+ "ami_load_shedding.ls_finalize_event_list_details WHERE finalized_event_id=" + eventid;
			logger.debug("findFinById " + qstr);
			FinalizeEventListDetails event = (FinalizeEventListDetails) em
					.createNativeQuery(qstr, FinalizeEventListDetails.class).getSingleResult();

			/*
			 * Query q = em.createNamedQuery("aocc.disconnect.findEventById");
			 * q.setParameter(1, eventid); FinalizeEventListDetails event =
			 * (FinalizeEventListDetails)q.getSingleResult();
			 */
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findFinById() " + e);
		}
		return opt;
	}

	Optional<RejectEventListDetails> findRejById(Long eventid) {
		Optional<RejectEventListDetails> opt = Optional.empty();
		try {
			String qstr = "SELECT fk_finalized_event_id,reject_time,boro_muni,event_name,operator_ad_id FROM "
					+ "ami_load_shedding.ls_reject_event_details WHERE fk_finalized_event_id=" + eventid;
			logger.debug("findRejById " + qstr);
			RejectEventListDetails event = (RejectEventListDetails) em
					.createNativeQuery(qstr, RejectEventListDetails.class).getSingleResult();
			opt = Optional.ofNullable(event);
		} catch (Exception e) {
			logger.error("Exception -> findRejById() " + e);
		}
		return opt;
	}

	public Map<String, Object> findEvent(Long eventid) {
		long time = System.currentTimeMillis();
		Optional<FinalizeEventListDetails> optFin = findFinById(eventid);
		Optional<ExecuteEventListDetails> optExe = eutil.findExeById(eventid);
		Optional<RejectEventListDetails> optRej = findRejById(eventid);
		logger.debug("{}: {} ms ", "TimeTrack-->  1-- findEvent(): ", System.currentTimeMillis() - time);
		logger.debug("Found in Finalize_Event? ------- " + "Eventid? " + eventid + optFin.isPresent());
		logger.debug("Found in Execute_Event?------- " + optExe.isPresent());
		logger.debug("Found in Reject_Event?------- " + optRej.isPresent());

		boolean foundEvnt = false;
		Map eventDetails = new HashMap();
		if (optExe.isPresent()) {
			foundEvnt = true;
			ExecuteEventListDetails exeEventDetails = optExe.get();
			eventDetails.put("id", exeEventDetails.getId());
			eventDetails.put("eventName", exeEventDetails.getEventname());
			eventDetails.put("eventDateTime", exeEventDetails.getExecuteDateTime());
			eventDetails.put("operator", exeEventDetails.getOperatorAdId());
			eventDetails.put("status", EXECUTE);
		} else if (optRej.isPresent()) {
			foundEvnt = true;
			RejectEventListDetails rejEventDetails = optRej.get();
			eventDetails.put("id", rejEventDetails.getId());
			eventDetails.put("eventName", rejEventDetails.getEventname());
			eventDetails.put("eventDateTime", rejEventDetails.getRejectTime());
			eventDetails.put("operator", rejEventDetails.getOperatorAdId());
			eventDetails.put("status", REJECT);
		} else if (optFin.isPresent()) {
			foundEvnt = true;
			FinalizeEventListDetails finEventDetails = optFin.get();
			eventDetails.put("id", finEventDetails.getId());
			eventDetails.put("eventName", finEventDetails.getEventName());
			eventDetails.put("eventDateTime", finEventDetails.getFinalizationDateTime());
			eventDetails.put("numberOfFinalizedMeters", finEventDetails.getNumberOfFinalizedMeters());
			eventDetails.put("status", FINALIZE);
		}
		/*
		 * if (!foundEvnt) throw new ResourceMissingException("Event not found :: " +
		 * eventid);
		 */
		time = System.currentTimeMillis() - time;
		logger.debug("{}: {} ms ", "TimeTrack-->  End--- findEvent() ", time);
		return eventDetails;
	}

	public Map<String, Object> disconnectEventQ(@RequestBody Map<String, Object> payload)
			throws ResourceMissingException {
		logger.debug("---------------------- START - disconnectEvent ------------------------");
		Long eventid = Long.valueOf((Integer) payload.get("id"));
		logger.debug(" --- eventid? " + eventid);
		Map<String, Object> statusMap = findEvent(eventid);
		Map<String, Object> response = new HashMap<>();
		logger.debug(" --- status? " + statusMap.get("status") + " action? " + payload.get("action"));
		if (statusMap.isEmpty()) {
			response.put("result", FAILED);
			response.put("status", "other");
			throw new ResourceMissingException("Event Not Fount!!");
		} else if (statusMap.get("status").equals(EXECUTE)) {
			response.put("result", FAILED);
			response.put("status", EXECUTE);
		} else if (statusMap.get("status").equals(REJECT)) {
			response.put("result", FAILED);
			response.put("status", REJECT);
		} else if (statusMap.get("status").equals(FINALIZE)) {
			response.put("result", FAILED);
			response.put("status", OTHER);

			String action = (String) payload.get("action");
			String op_adid = (String) payload.get("userId");
			String qstr = "";
			Query q = null;
			int res = 0;
			boolean deleteFinRec = false;
			if (action.equalsIgnoreCase(REJECT)) {
				qstr = "INSERT INTO ami_load_shedding.ls_reject_event_details "
						+ "(fk_finalized_event_id, event_name, boro_muni, reject_time, OPERATOR_AD_ID)  "
						+ "SELECT finalized_event_id, event_name, boro_muni," + "current_timestamp, '" + op_adid + "' "
						+ " FROM ami_load_shedding.ls_finalize_event_list_details " + "WHERE finalized_event_id IN ("
						+ eventid + ")";
				res = eutil.executeQuery(qstr);
				logger.debug("---INSERT INFO ls_execute_event_list_details -> Result: " + res);

				qstr = "INSERT INTO ami_load_shedding.ls_reject_event_list "
						+ "(fk_meter_event_load_id, event_name, boro_muni, reject_time, OPERATOR_AD_ID) "
						+ "SELECT l.fk_meter_event_load_id, l.event_name, l.boro_muni, " + "current_timestamp, '" + op_adid + "' "
						+ "FROM ami_load_shedding.ls_finalize_event_list l "
						+ "INNER JOIN ami_load_shedding.ls_finalize_event_list_details d "
						+ "ON d.event_name = l.event_name " + "AND d.boro_muni  = l.boro_muni "
						+ "WHERE d.finalized_event_id IN (" + eventid + ")";
//				q = (Query) em.createNativeQuery();
				res = eutil.executeQuery(qstr);
				deleteFinRec = true;
				logger.debug("---INSERT INFO ls_execute_event_list -> Result: " + res);
			} else if (action.equalsIgnoreCase(EXECUTE)) {
				if (selfFinCntr.saveExeAction(payload))
					deleteFinRec = eutil.callRemoteJob(eventid, "D", null);
			}
			if (deleteFinRec) {
				/*qstr = "DELETE FROM ami_load_shedding.ls_finalize_event_list " + "WHERE EVENT_NAME = ("
						+ "SELECT EVENT_NAME FROM ami_load_shedding.ls_finalize_event_list_details "
						+ "WHERE finalized_event_id IN (" + eventid + ")) " + "AND BORO_MUNI = ("
						+ "SELECT BORO_MUNI FROM ami_load_shedding.ls_finalize_event_list_details "
						+ "WHERE finalized_event_id IN (" + eventid + "))";*/
				qstr = "DELETE FROM ami_load_shedding.ls_finalize_event_list " + "WHERE fk_finalized_event_id=" + eventid;				
				res = eutil.executeQuery(qstr);
				logger.debug("---DELETE FROM ls_finalize_event_list -> Result: " + res);

				qstr = "DELETE FROM ami_load_shedding.ls_finalize_event_list_details " + "WHERE finalized_event_id IN ("
						+ eventid + ")";
				res = eutil.executeQuery(qstr);
				logger.debug("---DELETE FROM ls_finalize_event_list_details -> Result: " + res);

				response.put("result", SUCCESS);
				response.put("status", "");
			}
			logger.debug("---------------------- END - disconnectEvent ------------------------");
		} // end of else

		return response;
	}

	public ResponseEntity<Map<String, Object>> getFinalizedEventListDetailsById(
			@PathVariable(value = "id") Long eventid) throws ResourceMissingException {
		long time = System.currentTimeMillis();
		Map eventDetails = findEvent(eventid);
		if (eventDetails.isEmpty())
			throw new ResourceMissingException("Event not found :: " + eventid);
		time = System.currentTimeMillis() - time;
		logger.debug("{}: {} ms ", "TimeTrack-->  Total: /disconnect/events/{id}", time);
		return ResponseEntity.ok().body(eventDetails);
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public boolean saveExeAction(Map<String, Object> payload) throws ResourceMissingException {
		boolean success = false;
		try {
			logger.debug(
					"---------------------- START - FinalizeEventListDetailsController - saveExeAction ------------------------");
			Long eventid = Long.valueOf((Integer) payload.get("id"));
			logger.debug(" --- eventid? " + eventid);
			Map<String, Object> statusMap = findEvent(eventid);
			logger.debug(" --- status? " + statusMap.get("status") + " action? " + payload.get("action"));

			/********************************************************************************************/
			String action = (String) payload.get("action");
			String op_adid = (String) payload.get("userId");
			String qstr = "";
			Query q = null;
			int res = 0;
			qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list_details "
					+ "(fk_finalized_event_id, event_name, boro_muni, execute_time, EVENT_TYPE, OPERATOR_AD_ID)  "
					+ "SELECT finalized_event_id, event_name, boro_muni," + "current_timestamp, 'D','" + op_adid + "' "
					+ " FROM ami_load_shedding.ls_finalize_event_list_details " + "WHERE finalized_event_id IN ("
					+ eventid + ")";
			res = eutil.executeQuery(qstr);
			logger.debug("---INSERT INFO ls_execute_event_list_details -> Result: " + res);

			qstr = "INSERT INTO ami_load_shedding.ls_execute_event_list "
					+ "(fk_meter_event_load_id, event_name, boro_muni, meter_number) "
					+ "SELECT l.fk_meter_event_load_id, l.event_name, l.boro_muni, m.meter_number "
					+ "FROM ami_load_shedding.ls_finalize_event_list l "
					+ "INNER JOIN ami_load_shedding.ls_finalize_event_list_details d "
					+ "ON d.event_name = l.event_name " + "AND d.boro_muni  = l.boro_muni "
					+ "INNER JOIN ami_load_shedding.ls_meter_event_load m "
					+ "ON m.meter_event_load_id = l.fk_meter_event_load_id " + "WHERE d.finalized_event_id IN ("
					+ eventid + ")";
			res = eutil.executeQuery(qstr);
			logger.debug("***---INSERT INFO ls_execute_event_list -> Result: " + res);
			/*******************
			 * Start temporarily write into METER_STATUS_VW
			 ***********************
			qstr = "INSERT INTO ami_load_shedding.meter_status_vw "
					+ "(event_name, boro_muni, meter_number, prv_cmd_status, meter_status, req_status) "
					+ "SELECT l.event_name, l.boro_muni, m.meter_number, 'GMI_RSM_SUCCESS',	'RMT_PROV_RES_STAT_DISCONNECTED', 'I' "
					+ "FROM ami_load_shedding.ls_finalize_event_list l "
					+ "INNER JOIN ami_load_shedding.ls_finalize_event_list_details d "
					+ "ON d.event_name = l.event_name " + "AND d.boro_muni  = l.boro_muni "
					+ "INNER JOIN ami_load_shedding.ls_meter_event_load m "
					+ "ON m.meter_event_load_id = l.fk_meter_event_load_id " + "WHERE d.finalized_event_id IN ("
					+ eventid + ")";
			res = eutil.executeQuery(qstr);
			logger.debug("---INSERT INFO meter_status_vw -> Result: " + res);
			******************
			 * End temporarily write into METER_STATUS_VW
			 ************************/
			logger.debug("---INSERT INFO ls_execute_event_list -> Result: " + res);
			logger.debug("---------------------- END - saveExeAction ------------------------");
			success = true;
		} catch (Exception e) {
			logger.error("** Exception -> saveExeAction: "+e);
		}
		return success;
	}
}
