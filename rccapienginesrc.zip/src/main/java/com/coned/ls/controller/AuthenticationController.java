package com.coned.ls.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.AuthorizationService;

/**
 * Rest Controller to implement login and logout API.
 *
 */
@RestController
@RequestMapping("operator")
public class AuthenticationController extends BaseController{

	private static final Logger LOGGER = LogManager.getLogger(AuthenticationController.class);
	
	@Autowired
	private AuthorizationService authenticationService; 

	/*
	 * Method to check user is authorized to access RCC API's.
	 * 
	 * @RequestParam adid String
	 * @RequestParam role String
	 * 
     * @return 			  OperatorDetail 
	 */	
	@GetMapping("/auth")
	public OperatorDetail isOperatorAuthorized(@RequestParam(name = "adid") String adid, @RequestParam(name = "role") String role) throws OperatorAuthorizationException{
		LOGGER.info(String.format("Request for authorization of operator %s with role %s",adid, role));
		
		OperatorDetail operatorDetail = new OperatorDetail(true, "SUCCESS");
		if(! (isEmptyOrNull(adid)) || (isEmptyOrNull(role)) ){
			if(authenticationService.isOperatorAuthorized(adid, role)){
				return operatorDetail;
			}else{
				operatorDetail.setAuthenticate(false);
				operatorDetail.setMessage("ACCESS_DENIED");
			}
		}throw new OperatorAuthorizationException();
	}
	
	/*
	 * Method to store login details in the database.
	 * 
	 * @RequestBody operatorLoginDetail OperatorLoginDetail
	 * 
     * @return 							OperatorLoginDetail 
	 */	
	@PostMapping("/auth/persistApi/")
	public OperatorLoginDetail persistApi(@RequestBody OperatorLoginDetail operatorLoginDetail) throws OperatorAuthorizationException{
		LOGGER.info(String.format("Request for persist API key into database"));
		
		try{
			if(null!=operatorLoginDetail){
				LOGGER.info(String.format("Request for persist API key into database %s",operatorLoginDetail.toString()));
				
				operatorLoginDetail = authenticationService.persistApi(operatorLoginDetail);
			}
		}catch(OperatorAuthorizationException ex){
			LOGGER.error(ex.getMessage(), ex);
			
			throw new OperatorAuthorizationException(ex.getMessage(),ex);
		}
		
		return operatorLoginDetail;
	}
	
	/*
	 * Method to read login details of the user.
	 * 
	 * @RequestBody operatorLoginDetail OperatorLoginDetail
	 * 
     * @return 							OperatorLoginDetail 
	 */	
	@PostMapping("/principal/")
	public OperatorLoginDetail getOperatorLoginDetail(@RequestBody OperatorLoginDetail operatorLoginDetail) throws OperatorAuthorizationException{
		LOGGER.info(String.format("Request to get the operator login detail from database"));
		
		String adid = operatorLoginDetail.getAdid();
		String role = operatorLoginDetail.getRole();
		
		LOGGER.info(String.format("Request to get the operator login detail from database %s with role %s",adid, role));
		
		if(! (isEmptyOrNull(adid)) || (isEmptyOrNull(role)) ){
			operatorLoginDetail = authenticationService.getOperatorLoginDetail(adid, role);
			return operatorLoginDetail;
		}throw new OperatorAuthorizationException("OPERATOR_DETAIL_NOT_FOUND");
	}
	
	/*
	 * Method to check user is authorized to access RCC API's.
	 * 
	 * @RequestBody operatorLoginDetail OperatorLoginDetail
	 * 
     * @return 							OperatorLoginDetail 
	 */	
	@PostMapping("/principal/permission/")
	public OperatorDetail isAPIEndpointAuthorizeed(@RequestBody OperatorLoginDetail operatorLoginDetail) throws OperatorAuthorizationException{
		String adid = operatorLoginDetail.getAdid(); 
		String apiKey = operatorLoginDetail.getApiKey();
		int apiKeyStatus = operatorLoginDetail.getApiKeyStatus(); 
		int loginStatus = operatorLoginDetail.getLoginStatus();	
		
		OperatorDetail operatorDetail = new OperatorDetail( );
		
		LOGGER.info(String.format("Request to get the operator login detail from database"));
		LOGGER.info(String.format("Request to get the operator login detail from database %s with role %s",adid, apiKeyStatus, loginStatus));

		try{
			if( !(isEmptyOrNull(adid)) && !(isEmptyOrNull(apiKey)) ){
				if(authenticationService.isAPIEndpointAuthorizeed(adid,apiKey,13,10) == true){
					operatorDetail.setAuthenticate(true);
					operatorDetail.setMessage("SUCCESS");
					return operatorDetail;
				}else{
					operatorDetail.setAuthenticate(false);
					operatorDetail.setMessage("ACCESS_DENIED");
					
					return operatorDetail;
				}
			}
		}catch(OperatorAuthorizationException exp){
			throw new OperatorAuthorizationException("ACCESS_DENIED", HttpStatus.UNAUTHORIZED);
		}
		
		return operatorDetail;
	}
}
