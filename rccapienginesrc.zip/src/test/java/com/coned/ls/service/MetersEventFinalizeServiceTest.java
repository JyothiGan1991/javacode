package com.coned.ls.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.repository.MetersEventFinalizeRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={MetersEventFinalizeService.class})
@AutoConfigureMockMvc

public class MetersEventFinalizeServiceTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	@Mock
    private MetersEventFinalizeRepository metersEventFinalizeRepository;

	@InjectMocks
    private MetersEventFinalizeService  metersEventFinalizeService = new MetersEventFinalizeServiceImpl();
    
	MeterFinalizeResponseMapper meterFinalizeResponseMapper;
	
	private MockMvc mockMvc;
	//String expectedTestResult =  "{\"countOfMeters\":10,\"finalizeTime\":null,\"operatorAdId\":\"AN20025372\",\"borough\":\"B\",\"eventName\":\"SheepsheadBaySampleData7.27.20-1300\",\"message\":\"Success\",\"valid\":true}";
	
	@Before
    public void init() {
        MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }
	
	@Test
	public void finalizeMeterEvent(){
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300","Success",true);
		meterFinalizeResponseMapper = new MeterFinalizeResponseMapper("Success",true);
		ResponseEntity<MeterFinalizeResponseMapper> response = new ResponseEntity<MeterFinalizeResponseMapper>(meterFinalizeResponseMapper, HttpStatus.OK);
		try {
			String adid = "XYZ";
			Mockito.when(metersEventFinalizeRepository.finalizeMeterEvent(meterEventFinalize,adid)).thenReturn(meterFinalizeResponseMapper);
			ResponseEntity<MeterFinalizeResponseMapper> result = metersEventFinalizeService.finalizeMeterEvent(meterEventFinalize, adid);
			Assert.assertEquals(response.getBody().getMessage(), result.getBody().getMessage());
		} catch (MeterFinalizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		@Test
		public void finalizeMeterEvent2(){
			MeterEventFinalize meterEventFinalize = new MeterEventFinalize(10, null, "AN20025372", "B", "SheepsheadBaySampleData7.27.20-1300","Success",true);
			meterFinalizeResponseMapper = new MeterFinalizeResponseMapper("Success",false);
			ResponseEntity<MeterFinalizeResponseMapper> response = new ResponseEntity<MeterFinalizeResponseMapper>(meterFinalizeResponseMapper, HttpStatus.OK);
			try {
				String adid = "XYZ";
				Mockito.when(metersEventFinalizeRepository.finalizeMeterEvent(meterEventFinalize,adid)).thenReturn(meterFinalizeResponseMapper);
				ResponseEntity<MeterFinalizeResponseMapper> result = metersEventFinalizeService.finalizeMeterEvent(meterEventFinalize, adid);
				Assert.assertEquals(response.getBody().getMessage(), result.getBody().getMessage());
			} catch (MeterFinalizeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}