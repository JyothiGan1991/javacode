
package jobmanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CronJobTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CronJobTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_SEARCH_CACHE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_EXPORT_DATA"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_JOB_UPDATE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SEC_LOG_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_TASK_STATS_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_POP_DAILY_RSR_SUM"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_GAP_FILL"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_RECOVERY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_NETWORK_STATUS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_METER_SEC_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ARCHIVE_JOBS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_BILL_CYCLE_SUMMARY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_UNFILL_GAP_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_NET_BACKBONE_HST"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_RECOVERY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CMD_QUEUE_RETRY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RSND_FAIL_NP_RES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ITVL_SUCCESS_PROC"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_HEALTH_FLAG_EVENT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_DAY_START_PROC"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_NEW_ROUTES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_INS_ROUTES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_ROUTES_LAST"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SCHED_SUM_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_EVENT_LOG_GAP_FILL"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SET_UNREACHABLE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RESET_UNREACHABLE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ALARM_COUNTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_UNSCHED_METER_CNT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_TABLE_3_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ERR_HIST_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CARDINALITY_STATS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ALL_OUTAGES_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INFER_OUTAGES_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_LATENCY_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_DEV_STATE_SNAPSHOT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_READ_SUCCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RESOLVE_EVENTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DEVICE_CACHE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ADD_PARTITIONS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REMOVE_PARTITIONS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_NETSTATUS_COUNTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RMT_PROV_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DB"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_IMU_PREPROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_SEGMENT_DB"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "CronJobTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum CronJobTypeEnumeration {

    JOB_OP_CRON_CLEAR_SEARCH_CACHE("JOB_OP_CRON_CLEAR_SEARCH_CACHE"),
    JOB_OP_CRON_CLEAR_EXPORT_DATA("JOB_OP_CRON_CLEAR_EXPORT_DATA"),
    JOB_OP_CRON_JOB_UPDATE("JOB_OP_CRON_JOB_UPDATE"),
    JOB_OP_CRON_INTERVAL_PROCESS("JOB_OP_CRON_INTERVAL_PROCESS"),
    JOB_OP_CRON_REGISTER_PROCESS("JOB_OP_CRON_REGISTER_PROCESS"),
    JOB_OP_CRON_SEC_LOG_PROCESS("JOB_OP_CRON_SEC_LOG_PROCESS"),
    JOB_OP_CRON_TASK_STATS_PROCESS("JOB_OP_CRON_TASK_STATS_PROCESS"),
    JOB_OP_CRON_POP_DAILY_RSR_SUM("JOB_OP_CRON_POP_DAILY_RSR_SUM"),
    JOB_OP_CRON_INTERVAL_GAP_FILL("JOB_OP_CRON_INTERVAL_GAP_FILL"),
    JOB_OP_CRON_INTERVAL_RECOVERY("JOB_OP_CRON_INTERVAL_RECOVERY"),
    JOB_OP_CRON_GEN_NETWORK_STATUS("JOB_OP_CRON_GEN_NETWORK_STATUS"),
    JOB_OP_CRON_GEN_METER_SEC_RPT("JOB_OP_CRON_GEN_METER_SEC_RPT"),
    JOB_OP_CRON_ARCHIVE_JOBS("JOB_OP_CRON_ARCHIVE_JOBS"),
    JOB_OP_CRON_BILL_CYCLE_SUMMARY("JOB_OP_CRON_BILL_CYCLE_SUMMARY"),
    JOB_OP_CRON_UNFILL_GAP_PROCESS("JOB_OP_CRON_UNFILL_GAP_PROCESS"),
    JOB_OP_CRON_NET_BACKBONE_HST("JOB_OP_CRON_NET_BACKBONE_HST"),
    JOB_OP_CRON_REGISTER_RECOVERY("JOB_OP_CRON_REGISTER_RECOVERY"),
    JOB_OP_CRON_CMD_QUEUE_RETRY("JOB_OP_CRON_CMD_QUEUE_RETRY"),
    JOB_OP_CRON_RSND_FAIL_NP_RES("JOB_OP_CRON_RSND_FAIL_NP_RES"),
    JOB_OP_CRON_ITVL_SUCCESS_PROC("JOB_OP_CRON_ITVL_SUCCESS_PROC"),
    JOB_OP_CRON_HEALTH_FLAG_EVENT("JOB_OP_CRON_HEALTH_FLAG_EVENT"),
    JOB_OP_CRON_DAY_START_PROC("JOB_OP_CRON_DAY_START_PROC"),
    JOB_OP_CRON_SYNC_NEW_ROUTES("JOB_OP_CRON_SYNC_NEW_ROUTES"),
    JOB_OP_CRON_SYNC_INS_ROUTES("JOB_OP_CRON_SYNC_INS_ROUTES"),
    JOB_OP_CRON_SYNC_ROUTES_LAST("JOB_OP_CRON_SYNC_ROUTES_LAST"),
    JOB_OP_CRON_SCHED_SUM_PROCESS("JOB_OP_CRON_SCHED_SUM_PROCESS"),
    JOB_OP_CRON_EVENT_LOG_GAP_FILL("JOB_OP_CRON_EVENT_LOG_GAP_FILL"),
    JOB_OP_CRON_SET_UNREACHABLE("JOB_OP_CRON_SET_UNREACHABLE"),
    JOB_OP_CRON_RESET_UNREACHABLE("JOB_OP_CRON_RESET_UNREACHABLE"),
    JOB_OP_CRON_ALARM_COUNTS("JOB_OP_CRON_ALARM_COUNTS"),
    JOB_OP_CRON_UNSCHED_METER_CNT("JOB_OP_CRON_UNSCHED_METER_CNT"),
    JOB_OP_CRON_TABLE_3_PROCESS("JOB_OP_CRON_TABLE_3_PROCESS"),
    JOB_OP_CRON_ERR_HIST_PROCESS("JOB_OP_CRON_ERR_HIST_PROCESS"),
    JOB_OP_CRON_CARDINALITY_STATS("JOB_OP_CRON_CARDINALITY_STATS"),
    JOB_OP_CRON_ALL_OUTAGES_RPT("JOB_OP_CRON_ALL_OUTAGES_RPT"),
    JOB_OP_CRON_INFER_OUTAGES_RPT("JOB_OP_CRON_INFER_OUTAGES_RPT"),
    JOB_OP_CRON_GEN_LATENCY_RPT("JOB_OP_CRON_GEN_LATENCY_RPT"),
    JOB_OP_CRON_DEV_STATE_SNAPSHOT("JOB_OP_CRON_DEV_STATE_SNAPSHOT"),
    JOB_OP_CRON_GEN_READ_SUCCESS("JOB_OP_CRON_GEN_READ_SUCCESS"),
    JOB_OP_CRON_RESOLVE_EVENTS("JOB_OP_CRON_RESOLVE_EVENTS"),
    JOB_OP_CRON_SYNC_DEVICE_CACHE("JOB_OP_CRON_SYNC_DEVICE_CACHE"),
    JOB_OP_CRON_ADD_PARTITIONS("JOB_OP_CRON_ADD_PARTITIONS"),
    JOB_OP_CRON_REMOVE_PARTITIONS("JOB_OP_CRON_REMOVE_PARTITIONS"),
    JOB_OP_CRON_NETSTATUS_COUNTS("JOB_OP_CRON_NETSTATUS_COUNTS"),
    JOB_OP_CRON_RMT_PROV_PROCESS("JOB_OP_CRON_RMT_PROV_PROCESS"),
    JOB_OP_CRON_SYNC_DB("JOB_OP_CRON_SYNC_DB"),
    JOB_OP_CRON_IMU_PREPROCESS("JOB_OP_CRON_IMU_PREPROCESS"),
    JOB_OP_CRON_SYNC_SEGMENT_DB("JOB_OP_CRON_SYNC_SEGMENT_DB"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    CronJobTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CronJobTypeEnumeration fromValue(String v) {
        for (CronJobTypeEnumeration c: CronJobTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
