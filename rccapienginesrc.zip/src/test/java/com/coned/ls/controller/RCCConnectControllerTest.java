
package com.coned.ls.controller;

import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.FilterAttribute;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFilterResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
//import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.service.MeterEventConnectService;
import com.coned.ls.service.MeterFilterService;
import com.coned.ls.service.OpenEventService;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = RCCConnectController.class)
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class,
		DataSourceTransactionManagerAutoConfiguration.class })
@WebMvcTest(RCCConnectController.class)
public class RCCConnectControllerTest {

	@Autowired
	private WebApplicationContext wac;

	private MockMvc mockMvc;

	// @InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	@InjectMocks
	RCCConnectController rccConnectController;

	@MockBean
	OpenEventService openEventService;

	@MockBean
	MeterEventConnectService meterEventConnectService;
	@MockBean
	MeterFilterService meterFilterService;

	List<MeterEventLoad> meterEventLoads = new ArrayList<>();

	@Test
	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		rccConnectController = new RCCConnectController();
		System.out.println("@Before annotation method is being called ....");

		ReflectionTestUtils.setField(rccConnectController, "openEventService", openEventService);
		ReflectionTestUtils.setField(rccConnectController, "meterEventConnectService", meterEventConnectService);
		ReflectionTestUtils.setField(rccConnectController, "meterFilterService", meterFilterService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

	@Test
	public void getBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "boro";
		Mockito.when(openEventService.getExecuteBorough()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getExecuteBorough()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}
	
	@Test
	public void getEventName() throws Exception {
		
		List<String> expectedEventNameList = new ArrayList<String>();

		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "event_name";
		Mockito.when(openEventService.getExecuteEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getExecuteEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}
	
	

	@Test
	public void getEventNameByBorough() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "boro";
		Mockito.when(openEventService.getExecuteEventByBorough(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getEventNameByBorough(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());

	}

	@Test
	public void getValidMetersForConnect() throws Exception {

		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();

		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoad);

		mapper.setMeterEventLoads(meterEventLoads);

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);

		mapper.setPageNumber(20);
		mapper.setPageSize(1);
		mapper.setTotalRecord(2);
		mapper.setRecordOffsetRange("abcd");
		//mapper.setInsertTime(date);
		mapper.setBorough("M");
		mapper.setEventName("QRST");
		mapper.setNetwork("GHIJ");
		mapper.setRemainingRow(3);
		mapper.setValidResponse(true);
		mapper.setMessage("abcdef");
		ResponseEntity<MeterConnectResponseMapper> result = new ResponseEntity<MeterConnectResponseMapper>(mapper,
				new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 50;
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);

		Mockito.when(meterEventConnectService.getValidMetersForConnect(meterOpenEvent)).thenReturn(result);
		ResponseEntity<MeterConnectResponseMapper> actual = rccConnectController.getValidMetersForConnect(request,meterOpenEvent);
		Assert.assertEquals( result.getStatusCode(),actual.getStatusCode());

	}
	
	@Test(expected=IllegalArgumentException.class)
	public void getInvalidValidateMeterForConnect() throws Exception {
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		mapper.setPageNumber(20);
		mapper.setPageSize(1);
		mapper.setTotalRecord(2);
		mapper.setRecordOffsetRange("abcd");
		mapper.setBorough("M");
		mapper.setEventName("QRST");
		mapper.setNetwork("GHIJ");
		mapper.setValidResponse(true);
		mapper.setMessage("abcdef");
		
		String borough = null;
		String eventName = null;
		int startRowIndex = 0;
		int batchSize = 0;
		String filterList = null;
		String sortList = null;
		String adid = null;
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "");
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		ResponseEntity<MeterConnectResponseMapper> result = new ResponseEntity<MeterConnectResponseMapper>(mapper,new HttpHeaders(), HttpStatus.OK);
		Mockito.when(meterEventConnectService.getValidMetersForConnect(meterOpenEvent)).thenReturn(result);
		ResponseEntity<MeterConnectResponseMapper> actual = rccConnectController.getValidMetersForConnect(request,meterOpenEvent);
		Assert.assertEquals(result.getBody().getBorough(), actual.getBody().getBorough());
	}
	
	@Test
	public void getFieldValuesByBoroughAndEventNameTest() throws Exception {
		List<String> expectedEventNameList = new ArrayList<String>();
		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String fieldName = "fieldName";
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(meterEventConnectService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());
	}
	
	@Test
	public void getConnectedMeters() throws MeterEventConnectException {
		MeterConnectResponseMapper merp = new MeterConnectResponseMapper();
		merp.setBorough("B");
		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(merp,
				HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough("B");
		meterOpenEvent.setEventName("Ridgewood.09.10/11/20-09:27:18.AUTO");
		meterOpenEvent.setStartRowIndex(10);
		meterOpenEvent.setBatchSize(50);
		
		Mockito.when(meterEventConnectService.getConnectedMeters(meterOpenEvent))
				.thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> result = rccConnectController.getConnectedMeters(meterOpenEvent);
		Assert.assertEquals(mockData.getBody().getBorough(), result.getBody().getBorough());
	}

	@Test(expected=AssertionError.class)
	public void getInvalidConnectdMetersTest() throws MeterEventConnectException {
		MeterConnectResponseMapper merp = new MeterConnectResponseMapper();
		merp.setBorough("B");
		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(merp,HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough(null);
		meterOpenEvent.setEventName(null);
		meterOpenEvent.setStartRowIndex(0);
		meterOpenEvent.setBatchSize(0);
		
		Mockito.when(meterEventConnectService.getConnectedMeters(meterOpenEvent)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> result = rccConnectController.getConnectedMeters(meterOpenEvent);
		Assert.assertEquals(mockData.getBody().getBorough(), result.getBody().getBorough());
	}
	@Test
	public void finalizeSubEventMeter() throws Exception {
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		SubEvent subEvent = new SubEvent();
		merp.setMessage("SUCCESS");
		subEvent.setBorough("B");
		subEvent.setEvent("Ridgewood.09.10/11/20-09:27:18.AUTO");
		subEvent.setSubEventName("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<MeterFinalizeResponseMapper> mockData = new ResponseEntity<MeterFinalizeResponseMapper>(merp,
				HttpStatus.OK);
		Mockito.when(meterEventConnectService.finalizeSubEventMeter(subEvent)).thenReturn(mockData);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterFinalizeResponseMapper> result = rccConnectController.finalizeSubEventMeter(request,subEvent);
		Assert.assertEquals(mockData.getBody().getMessage(), result.getBody().getMessage());
	}
	
	@Test(expected=AssertionError.class)
	public void InvalidfinalizeSubEventMeter() throws Exception {
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		SubEvent subEvent = new SubEvent();
		merp.setMessage("");
		subEvent.setBorough(null);
		subEvent.setEvent(null);
		subEvent.setSubEventName(null);
		ResponseEntity<MeterFinalizeResponseMapper> mockData = new ResponseEntity<MeterFinalizeResponseMapper>(merp,HttpStatus.OK);
		Mockito.when(meterEventConnectService.finalizeSubEventMeter(subEvent)).thenReturn(mockData);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterFinalizeResponseMapper> result = rccConnectController.finalizeSubEventMeter(request,subEvent);
		Assert.assertEquals(mockData.getBody(), result.getBody());
	}
	
	@Test
	public void getSubEventSuffix() throws Exception {

		String borough = "B";
		String eventName = "Flatbush.23.11/08/20-23:24:06.KUMARM";
		String items = "Suffix";

		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(meterEventConnectService.getSubEventSuffix(borough, eventName)).thenReturn(mockData);
		ResponseEntity<Long> response = rccConnectController.getSubEventSuffix(borough, eventName, items);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());

	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidSubEventSuffix() throws Exception {
		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(meterEventConnectService.getSubEventSuffix(null,null)).thenReturn(mockData);
		ResponseEntity<Long> response = rccConnectController.getSubEventSuffix(null,null,null);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	@Test
	public void initMeterFilter() throws Exception {
		List<FilterAttribute> listOfFilterAttributes = new ArrayList<FilterAttribute>();
		FilterAttribute fa = new FilterAttribute();
		fa.setFilterAttribute("test");
		fa.setSuccess(true);
		listOfFilterAttributes.add(fa);
		MeterFilterResponseMapper mockData = new MeterFilterResponseMapper();
		mockData.setFilterAttributes(listOfFilterAttributes);
		mockData.setValidResponse(true);
		Mockito.when(meterFilterService.initMeterFilter(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(listOfFilterAttributes);	
		MeterFilterResponseMapper response =rccConnectController.initMeterFilter(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),Mockito.anyInt());
		Assert.assertEquals(mockData.isValidResponse(), response.isValidResponse());
		 
	}
	@Test
	public void getSubBoroughAndEventName() throws Exception {

		String fields = "sub_event_name";

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedEventNameList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEvent()).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());

	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidSubBoroughAndEventName() throws Exception {
		String fields = "test";
		List<String> expectedEventNameList = new ArrayList<String>();
		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedEventNameList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeBorough()).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	@Test
	public void getSubBoroughAndEventNameTest() throws Exception {
		String fields = "sub_boro";
		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("M");
		expectedEventNameList.add("Q");
		expectedEventNameList.add("X");
		expectedEventNameList.add("B");
		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedEventNameList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeBorough()).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}
	@Test
	public void getSubEventNameBySubBorough() throws Exception {

		String borough = "M";

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEventByBorough(borough)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());

	}
	
	@Test
	public void getSubEventNameBySubBoroughTest() throws Exception {

		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough,eventName);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());

	}
	
	@Test
	public void getInvalidSubEventNameBySubBoroughTest() throws Exception {
	   String borough = null;
	   String eventName = null;
		List<String> expectedEventNameList = new ArrayList<String>();
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough, eventName);
		Assert.assertEquals(result.getBody(), response.getBody());
	}
	
	
	@Test
	public void searchMeter() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("Flatbush.23.11/08/20-23:24:06");
		meterSearch.setMeters("009445720");
		meterSearch.setSubEvent("Zone00323");
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();

		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(mapper,
				HttpStatus.OK);
		Mockito.when(meterEventConnectService.searchMeters(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.searchMeter(meterSearch);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=AssertionError.class)
	public void InvalidsearchMeter() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		meterSearch.setMeters(null);
		meterSearch.setSubEvent(null);
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectService.searchMeters(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.searchMeter(meterSearch);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}

    @Test
	public void getSubEventMeters() throws Exception {

		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String subEventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 500;

		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockdata = new ResponseEntity<MeterConnectResponseMapper>(mapper,
				HttpStatus.OK);
		Mockito.when(meterEventConnectService.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize))
				.thenReturn(mockdata);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.getSubEventMeters(borough, eventName,
				subEventName, startRowIndex, batchSize);
		Assert.assertEquals(mockdata.getStatusCode(), response.getStatusCode());

	}
    @Test //(expected=AssertionError.class)
	public void getInvalidSubEventMetersTest() throws Exception {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough(null);
		subEvent.setEvent(null);
		subEvent.setMeters(null);
		subEvent.setSubEventName(null);
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockdata = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectService.getSubEventMeters(subEvent)).thenReturn(mockdata);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.getSubEventMeters(subEvent);
		Assert.assertEquals(mockdata.getBody().getBorough(), response.getBody().getBorough());
	}
    
    
    @Test
	public void searchMeterConnected() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("Flatbush.23.11/08/20-23:24:06");
		meterSearch.setMeters("009445720");
		meterSearch.setSubEvent("Zone00323");
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
        ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectService.searchMeterConnected(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.searchMeterConnected(meterSearch);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=AssertionError.class)
	public void InvalidsearchMeterConnected() throws Exception {
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		meterSearch.setMeters(null);
		meterSearch.setSubEvent(null);
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectService.searchMeterConnected(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.searchMeterConnected(meterSearch);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}
	
	@Test
	public void getSubEventMetersTest() throws Exception {

		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Flatbush.23.11/08/20-23:24:06");
		subEvent.setMeters("009445720");
		subEvent.setSubEventName("Zone00323");
		MeterConnectResponseMapper mapper = new MeterConnectResponseMapper();
		ResponseEntity<MeterConnectResponseMapper> mockData = new ResponseEntity<MeterConnectResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventConnectService.getSubEventMeters(subEvent)).thenReturn(mockData);
		ResponseEntity<MeterConnectResponseMapper> response = rccConnectController.getSubEventMeters(subEvent);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	@Test
    public void isEventLocked(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
		Mockito.when(meterEventConnectService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = meterEventConnectService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK");
		Assert.assertEquals(mlsp.getMessage(),response.getMessage());
	}
	@Test
    public void isEventLockedTest(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
    	MockHttpServletRequest request = new MockHttpServletRequest();
    	request.addHeader("adid", "BUDIDHAK");
		Mockito.when(meterEventConnectService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = rccConnectController.isEventLocked(request,"B","SheepsheadBaySampleData7.27.20-1300");
		Assert.assertEquals(mlsp,response);
}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventConnectService).unlockEvents(adid);
		rccConnectController.unlockEvents(request);
	}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents2(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "");
		String adid = "";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventConnectService).unlockEvents(adid);
		rccConnectController.unlockEvents(request);
	}


}