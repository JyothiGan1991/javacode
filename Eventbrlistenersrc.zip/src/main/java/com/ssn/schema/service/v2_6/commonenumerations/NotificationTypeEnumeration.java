
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NotificationTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="NotificationTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="JOB_OP_BRDG_NTFCTN_LINK_STATE"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "NotificationTypeEnumeration")
@XmlEnum
public enum NotificationTypeEnumeration {

    JOB_OP_BRDG_NTFCTN_LINK_STATE("JOB_OP_BRDG_NTFCTN_LINK_STATE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    NotificationTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NotificationTypeEnumeration fromValue(String v) {
        for (NotificationTypeEnumeration c: NotificationTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
