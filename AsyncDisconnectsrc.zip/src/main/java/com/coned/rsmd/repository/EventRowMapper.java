package com.coned.rsmd.repository;

import com.coned.rsmd.domain.Meter;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class EventRowMapper implements RowMapper<Meter> {
	public Meter mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Meter(rs.getBigDecimal(1), rs.getBigDecimal(2), rs.getString(3), rs.getString(4), rs.getString(5));
	}
}