
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusFlagTypeWithDesc complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusFlagTypeWithDesc"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StatusFlagName" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}IntervalStatusType"/&gt;
 *         &lt;element name="StatusFlagDesc" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusFlagTypeWithDesc", propOrder = {
    "statusFlagName",
    "statusFlagDesc"
})
public class StatusFlagTypeWithDesc {

    @XmlElement(name = "StatusFlagName", required = true)
    @XmlSchemaType(name = "string")
    protected IntervalStatusType statusFlagName;
    @XmlElement(name = "StatusFlagDesc", required = true)
    protected String statusFlagDesc;

    /**
     * Gets the value of the statusFlagName property.
     * 
     * @return
     *     possible object is
     *     {@link IntervalStatusType }
     *     
     */
    public IntervalStatusType getStatusFlagName() {
        return statusFlagName;
    }

    /**
     * Sets the value of the statusFlagName property.
     * 
     * @param value
     *     allowed object is
     *     {@link IntervalStatusType }
     *     
     */
    public void setStatusFlagName(IntervalStatusType value) {
        this.statusFlagName = value;
    }

    /**
     * Gets the value of the statusFlagDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusFlagDesc() {
        return statusFlagDesc;
    }

    /**
     * Sets the value of the statusFlagDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusFlagDesc(String value) {
        this.statusFlagDesc = value;
    }

}
