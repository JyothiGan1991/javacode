
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocationSortColumnName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LocationSortColumnName"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="LocationID"/&gt;
 *     &lt;enumeration value="UtilPremiseID"/&gt;
 *     &lt;enumeration value="LocationType"/&gt;
 *     &lt;enumeration value="Address"/&gt;
 *     &lt;enumeration value="City"/&gt;
 *     &lt;enumeration value="PostalCode"/&gt;
 *     &lt;enumeration value="Latitude"/&gt;
 *     &lt;enumeration value="Longitude"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "LocationSortColumnName")
@XmlEnum
public enum LocationSortColumnName {

    @XmlEnumValue("LocationID")
    LOCATION_ID("LocationID"),
    @XmlEnumValue("UtilPremiseID")
    UTIL_PREMISE_ID("UtilPremiseID"),
    @XmlEnumValue("LocationType")
    LOCATION_TYPE("LocationType"),
    @XmlEnumValue("Address")
    ADDRESS("Address"),
    @XmlEnumValue("City")
    CITY("City"),
    @XmlEnumValue("PostalCode")
    POSTAL_CODE("PostalCode"),
    @XmlEnumValue("Latitude")
    LATITUDE("Latitude"),
    @XmlEnumValue("Longitude")
    LONGITUDE("Longitude");
    private final String value;

    LocationSortColumnName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LocationSortColumnName fromValue(String v) {
        for (LocationSortColumnName c: LocationSortColumnName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
