
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TimeZoneTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TimeZoneTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TZ_CANADA_NEWFOUNDLAND"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MARTINIQUE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CAYMAN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_NEW_YORK"/&gt;
 *     &lt;enumeration value="TZ_CANADA_SASKATCHEWAN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CHICAGO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PHOENIX"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DENVER"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_LOS_ANGELES"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ANCHORAGE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_HONOLULU"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ADAK"/&gt;
 *     &lt;enumeration value="TZ_GMT"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_JOHANNESBURG"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_VICTORIA"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_QUEENSLAND"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_ACT"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_ADELAIDE"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_BRISBANE"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_BROKEN_HILL"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_CANBERRA"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_DARWIN"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_HOBART"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_LHI"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_LINDEMAN"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_LORD_HOWE"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_MELBOURNE"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_NORTH"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_NSW"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_PERTH"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_SOUTH"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_SYDNEY"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_TASMANIA"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_WEST"/&gt;
 *     &lt;enumeration value="TZ_AUSTRALIA_YANCOWINNA"/&gt;
 *     &lt;enumeration value="TZ_BRAZIL_ACRE"/&gt;
 *     &lt;enumeration value="TZ_BRAZIL_DENORONHA"/&gt;
 *     &lt;enumeration value="TZ_BRAZIL_EAST"/&gt;
 *     &lt;enumeration value="TZ_BRAZIL_WEST"/&gt;
 *     &lt;enumeration value="TZ_PORTUGAL"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_1"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_2"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_3"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_4"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_5"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_6"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_7"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_8"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_9"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_10"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_11"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_12"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_13"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_MINUS_14"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_1"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_2"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_3"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_4"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_5"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_6"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_7"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_8"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_9"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_10"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_11"/&gt;
 *     &lt;enumeration value="TZ_ETC_GMT_PLUS_12"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ABIDJAN"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ACCRA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ADDIS_ABABA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ALGIERS"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ASMARA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_ASMERA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BAMAKO"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BANGUI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BANJUL"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BISSAU"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BLANTYRE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BRAZZAVILLE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_BUJUMBURA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_CAIRO"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_CASABLANCA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_CEUTA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_CONAKRY"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_DAKAR"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_DAR_ES_SALAAM"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_DJIBOUTI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_DOUALA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_EL_AAIUN"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_FREETOWN"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_GABORONE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_HARARE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_KAMPALA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_KHARTOUM"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_KIGALI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_KINSHASA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LAGOS"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LIBREVILLE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LOME"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LUANDA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LUBUMBASHI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_LUSAKA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MALABO"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MAPUTO"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MASERU"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MBABANE"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MOGADISHU"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_MONROVIA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_NAIROBI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_NDJAMENA"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_NIAMEY"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_NOUAKCHOTT"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_OUAGADOUGOU"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_PORTO_NOVO"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_SAO_TOME"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_TIMBUKTU"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_TRIPOLI"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_TUNIS"/&gt;
 *     &lt;enumeration value="TZ_AFRICA_WINDHOEK"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ANGUILLA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ANTIGUA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARAGUAINA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_BUENOSAIRES"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_CATAMARCA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_COMODRIVADAVIA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_CORDOBA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_JUJUY"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_LA_RIOJA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_MENDOZA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_RIO_GALLEGOS"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_SALTA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_SAN_JUAN"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_SAN_LUIS"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_TUCUMAN"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_ARGNT_USHUAIA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ARUBA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ASUNCION"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ATIKOKAN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ATKA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BAHIA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BARBADOS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BELEM"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BELIZE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BLANC_SABLON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BOA_VISTA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BOGOTA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BOISE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_BUENOS_AIRES"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CAMBRIDGE_BAY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CAMPO_GRANDE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CANCUN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CARACAS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CATAMARCA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CAYENNE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CHIHUAHUA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CORAL_HARBOUR"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CORDOBA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_COSTA_RICA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CUIABA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_CURACAO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DANMARKSHAVN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DAWSON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DAWSON_CREEK"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DETROIT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_DOMINICA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_EDMONTON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_EIRUNEPE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_EL_SALVADOR"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ENSENADA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_FORT_WAYNE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_FORTALEZA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GLACE_BAY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GODTHAB"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GOOSE_BAY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GRAND_TURK"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GRENADA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GUADELOUPE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GUATEMALA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GUAYAQUIL"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_GUYANA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_HALIFAX"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_HAVANA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_HERMOSILLO"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDIANA_INDIANAPOLIS"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_KNOX"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_MARENGO"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_PETERSBURG"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_TELL_CITY"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_VEVAY"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_VINCENNES"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNA_WINAMAC"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_INDNAPOLIS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_INUVIK"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_IQALUIT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_JAMAICA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_JUJUY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_JUNEAU"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_KENTUCKY_LOUISVILLE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_KENTUCKY_MONTICELLO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_KNOX_IN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_LA_PAZ"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_LIMA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_LOUISVILLE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MACEIO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MANAGUA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MANAUS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MARIGOT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MATAMOROS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MAZATLAN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MENDOZA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MENOMINEE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MERIDA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MEXICO_CITY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MIQUELON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MONCTON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MONTERREY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MONTEVIDEO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MONTREAL"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_MONTSERRAT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_NASSAU"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_NIPIGON"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_NOME"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_NORONHA"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_NTH_DKOTA_CENTER"/&gt;
 *     &lt;enumeration value="TZ_AMRICA_NTH_DKOTA_NEW_SALEM"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_OJINAGA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PANAMA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PANGNIRTUNG"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PARAMARIBO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PORT_AU_PRINCE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PORT_OF_SPAIN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PORTO_ACRE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PORTO_VELHO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_PUERTO_RICO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_RAINY_RIVER"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_RANKIN_INLET"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_RECIFE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_REGINA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_RESOLUTE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_RIO_BRANCO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ROSARIO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SANTA_ISABEL"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SANTIAGO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SANTO_DOMINGO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SAO_PAULO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SCORESBYSUND"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SHIPROCK"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_BARTHELEMY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_JOHNS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_KITTS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_LUCIA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_THOMAS"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_ST_VINCENT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_SWIFT_CURRENT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_TEGUCIGALPA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_THULE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_THUNDER_BAY"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_TIJUANA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_TORONTO"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_TORTOLA"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_VANCOUVER"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_VIRGIN"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_WHITEHORSE"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_WINNIPEG"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_YAKUTAT"/&gt;
 *     &lt;enumeration value="TZ_AMERICA_YELLOWKNIFE"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_CASEY"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_DAVIS"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_DUMONTDURVILLE"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_MAWSON"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_MCMURDO"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_PALMER"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_SOUTH_POLE"/&gt;
 *     &lt;enumeration value="TZ_ANTARCTICA_SYOWA"/&gt;
 *     &lt;enumeration value="TZ_ARCTIC_LONGYEARBYEN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ADEN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ALMATY"/&gt;
 *     &lt;enumeration value="TZ_ASIA_AMMAN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ANADYR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_AQTAU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_AQTOBE"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ASHGABAT"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ASHKHABAD"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BAGHDAD"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BAHRAIN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BAKU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BANGKOK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BEIRUT"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BISHKEK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_BRUNEI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_CALCUTTA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_CHOIBALSAN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_CHONGQING"/&gt;
 *     &lt;enumeration value="TZ_ASIA_CHUNGKING"/&gt;
 *     &lt;enumeration value="TZ_ASIA_COLOMBO"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DACCA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DAMASCUS"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DHAKA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DILI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DUBAI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_DUSHANBE"/&gt;
 *     &lt;enumeration value="TZ_ASIA_GAZA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_HARBIN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_HO_CHI_MINH"/&gt;
 *     &lt;enumeration value="TZ_ASIA_HONG_KONG"/&gt;
 *     &lt;enumeration value="TZ_ASIA_HOVD"/&gt;
 *     &lt;enumeration value="TZ_ASIA_IRKUTSK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ISTANBUL"/&gt;
 *     &lt;enumeration value="TZ_ASIA_JAKARTA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_JAYAPURA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_JERUSALEM"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KABUL"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KAMCHATKA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KARACHI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KASHGAR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KATHMANDU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KATMANDU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KOLKATA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KRASNOYARSK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KUALA_LUMPUR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KUCHING"/&gt;
 *     &lt;enumeration value="TZ_ASIA_KUWAIT"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MACAO"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MACAU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MAGADAN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MAKASSAR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MANILA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_MUSCAT"/&gt;
 *     &lt;enumeration value="TZ_ASIA_NICOSIA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_NOVOSIBIRSK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_OMSK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ORAL"/&gt;
 *     &lt;enumeration value="TZ_ASIA_PHNOM_PENH"/&gt;
 *     &lt;enumeration value="TZ_ASIA_PONTIANAK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_PYONGYANG"/&gt;
 *     &lt;enumeration value="TZ_ASIA_QATAR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_QYZYLORDA"/&gt;
 *     &lt;enumeration value="TZ_ASIA_RANGOON"/&gt;
 *     &lt;enumeration value="TZ_ASIA_RIYADH"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SAIGON"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SAKHALIN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SAMARKAND"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SEOUL"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SHANGHAI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_SINGAPORE"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TAIPEI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TASHKENT"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TBILISI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TEHRAN"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TEL_AVIV"/&gt;
 *     &lt;enumeration value="TZ_ASIA_THIMBU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_THIMPHU"/&gt;
 *     &lt;enumeration value="TZ_ASIA_TOKYO"/&gt;
 *     &lt;enumeration value="TZ_ASIA_UJUNG_PANDANG"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ULAANBAATAR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_ULAN_BATOR"/&gt;
 *     &lt;enumeration value="TZ_ASIA_URUMQI"/&gt;
 *     &lt;enumeration value="TZ_ASIA_VIENTIANE"/&gt;
 *     &lt;enumeration value="TZ_ASIA_VLADIVOSTOK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_YAKUTSK"/&gt;
 *     &lt;enumeration value="TZ_ASIA_YEKATERINBURG"/&gt;
 *     &lt;enumeration value="TZ_ASIA_YEREVAN"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_AZORES"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_BERMUDA"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_CANARY"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_CAPE_VERDE"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_FAEROE"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_FAROE"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_JAN_MAYEN"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_MADEIRA"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_REYKJAVIK"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_SOUTH_GEORGIA"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_ST_HELENA"/&gt;
 *     &lt;enumeration value="TZ_ATLANTIC_STANLEY"/&gt;
 *     &lt;enumeration value="TZ_CET"/&gt;
 *     &lt;enumeration value="TZ_CST"/&gt;
 *     &lt;enumeration value="TZ_CST6CDT"/&gt;
 *     &lt;enumeration value="TZ_CANADA_ATLANTIC"/&gt;
 *     &lt;enumeration value="TZ_CANADA_CENTRAL"/&gt;
 *     &lt;enumeration value="TZ_CANADA_EAST_SASKATCHEWAN"/&gt;
 *     &lt;enumeration value="TZ_CANADA_EASTERN"/&gt;
 *     &lt;enumeration value="TZ_CANADA_MOUNTAIN"/&gt;
 *     &lt;enumeration value="TZ_CANADA_PACIFIC"/&gt;
 *     &lt;enumeration value="TZ_CANADA_YUKON"/&gt;
 *     &lt;enumeration value="TZ_CHILE_CONTINENTAL"/&gt;
 *     &lt;enumeration value="TZ_CHILE_EASTERISLAND"/&gt;
 *     &lt;enumeration value="TZ_CUBA"/&gt;
 *     &lt;enumeration value="TZ_EET"/&gt;
 *     &lt;enumeration value="TZ_EST"/&gt;
 *     &lt;enumeration value="TZ_EST5EDT"/&gt;
 *     &lt;enumeration value="TZ_EGYPT"/&gt;
 *     &lt;enumeration value="TZ_EIRE"/&gt;
 *     &lt;enumeration value="TZ_ETC_GREENWICH"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_AMSTERDAM"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ANDORRA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ATHENS"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BELFAST"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BELGRADE"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BERLIN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BRATISLAVA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BRUSSELS"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BUCHAREST"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_BUDAPEST"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_CHISINAU"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_COPENHAGEN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_DUBLIN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_GIBRALTAR"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_GUERNSEY"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_HELSINKI"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ISLE_OF_MAN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ISTANBUL"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_JERSEY"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_KALININGRAD"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_KIEV"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_LISBON"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_LJUBLJANA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_LONDON"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_LUXEMBOURG"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MADRID"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MALTA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MARIEHAMN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MINSK"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MONACO"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_MOSCOW"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_NICOSIA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_OSLO"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_PARIS"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_PODGORICA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_PRAGUE"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_RIGA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ROME"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SAMARA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SAN_MARINO"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SARAJEVO"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SIMFEROPOL"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SKOPJE"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_SOFIA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_STOCKHOLM"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_TALLINN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_TIRANE"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_TIRASPOL"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_UZHGOROD"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_VADUZ"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_VATICAN"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_VIENNA"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_VILNIUS"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_VOLGOGRAD"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_WARSAW"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ZAGREB"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ZAPOROZHYE"/&gt;
 *     &lt;enumeration value="TZ_EUROPE_ZURICH"/&gt;
 *     &lt;enumeration value="TZ_GB"/&gt;
 *     &lt;enumeration value="TZ_GB_EIRE"/&gt;
 *     &lt;enumeration value="TZ_GMT0"/&gt;
 *     &lt;enumeration value="TZ_GREENWICH"/&gt;
 *     &lt;enumeration value="TZ_HST"/&gt;
 *     &lt;enumeration value="TZ_HONGKONG"/&gt;
 *     &lt;enumeration value="TZ_ICELAND"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_ANTANANARIVO"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_CHAGOS"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_CHRISTMAS"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_COCOS"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_COMORO"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_KERGUELEN"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_MAHE"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_MALDIVES"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_MAURITIUS"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_MAYOTTE"/&gt;
 *     &lt;enumeration value="TZ_INDIAN_REUNION"/&gt;
 *     &lt;enumeration value="TZ_IRAN"/&gt;
 *     &lt;enumeration value="TZ_ISRAEL"/&gt;
 *     &lt;enumeration value="TZ_JAMAICA"/&gt;
 *     &lt;enumeration value="TZ_JAPAN"/&gt;
 *     &lt;enumeration value="TZ_KWAJALEIN"/&gt;
 *     &lt;enumeration value="TZ_LIBYA"/&gt;
 *     &lt;enumeration value="TZ_MET"/&gt;
 *     &lt;enumeration value="TZ_MST"/&gt;
 *     &lt;enumeration value="TZ_MST7MDT"/&gt;
 *     &lt;enumeration value="TZ_MEXICO_BAJANORTE"/&gt;
 *     &lt;enumeration value="TZ_MEXICO_BAJASUR"/&gt;
 *     &lt;enumeration value="TZ_MEXICO_GENERAL"/&gt;
 *     &lt;enumeration value="TZ_NZ"/&gt;
 *     &lt;enumeration value="TZ_NZ_CHAT"/&gt;
 *     &lt;enumeration value="TZ_NAVAJO"/&gt;
 *     &lt;enumeration value="TZ_PRC"/&gt;
 *     &lt;enumeration value="TZ_PST"/&gt;
 *     &lt;enumeration value="TZ_PST8PDT"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_APIA"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_AUCKLAND"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_CHATHAM"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_EASTER"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_EFATE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_ENDERBURY"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_FAKAOFO"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_FIJI"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_FUNAFUTI"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_GALAPAGOS"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_GAMBIER"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_GUADALCANAL"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_GUAM"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_JOHNSTON"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_KIRITIMATI"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_KOSRAE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_KWAJALEIN"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_MAJURO"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_MARQUESAS"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_MIDWAY"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_NAURU"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_NIUE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_NORFOLK"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_NOUMEA"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_PAGO_PAGO"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_PALAU"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_PITCAIRN"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_PONAPE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_PORT_MORESBY"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_RAROTONGA"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_SAIPAN"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_SAMOA"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_TAHITI"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_TARAWA"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_TONGATAPU"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_TRUK"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_WAKE"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_WALLIS"/&gt;
 *     &lt;enumeration value="TZ_PACIFIC_YAP"/&gt;
 *     &lt;enumeration value="TZ_POLAND"/&gt;
 *     &lt;enumeration value="TZ_ROK"/&gt;
 *     &lt;enumeration value="TZ_SINGAPORE"/&gt;
 *     &lt;enumeration value="TZ_TURKEY"/&gt;
 *     &lt;enumeration value="TZ_US_ALASKA"/&gt;
 *     &lt;enumeration value="TZ_US_ALEUTIAN"/&gt;
 *     &lt;enumeration value="TZ_US_ARIZONA"/&gt;
 *     &lt;enumeration value="TZ_US_CENTRAL"/&gt;
 *     &lt;enumeration value="TZ_US_EAST_INDIANA"/&gt;
 *     &lt;enumeration value="TZ_US_EASTERN"/&gt;
 *     &lt;enumeration value="TZ_US_HAWAII"/&gt;
 *     &lt;enumeration value="TZ_US_INDIANA_STARKE"/&gt;
 *     &lt;enumeration value="TZ_US_MICHIGAN"/&gt;
 *     &lt;enumeration value="TZ_US_MOUNTAIN"/&gt;
 *     &lt;enumeration value="TZ_US_PACIFIC"/&gt;
 *     &lt;enumeration value="TZ_US_PACIFIC_NEW"/&gt;
 *     &lt;enumeration value="TZ_US_SAMOA"/&gt;
 *     &lt;enumeration value="TZ_UTC"/&gt;
 *     &lt;enumeration value="TZ_W_SU"/&gt;
 *     &lt;enumeration value="TZ_WET"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TimeZoneTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum TimeZoneTypeEnum {

    TZ_CANADA_NEWFOUNDLAND("TZ_CANADA_NEWFOUNDLAND"),
    TZ_AMERICA_MARTINIQUE("TZ_AMERICA_MARTINIQUE"),
    TZ_AMERICA_CAYMAN("TZ_AMERICA_CAYMAN"),
    TZ_AMERICA_NEW_YORK("TZ_AMERICA_NEW_YORK"),
    TZ_CANADA_SASKATCHEWAN("TZ_CANADA_SASKATCHEWAN"),
    TZ_AMERICA_CHICAGO("TZ_AMERICA_CHICAGO"),
    TZ_AMERICA_PHOENIX("TZ_AMERICA_PHOENIX"),
    TZ_AMERICA_DENVER("TZ_AMERICA_DENVER"),
    TZ_AMERICA_LOS_ANGELES("TZ_AMERICA_LOS_ANGELES"),
    TZ_AMERICA_ANCHORAGE("TZ_AMERICA_ANCHORAGE"),
    TZ_PACIFIC_HONOLULU("TZ_PACIFIC_HONOLULU"),
    TZ_AMERICA_ADAK("TZ_AMERICA_ADAK"),
    TZ_GMT("TZ_GMT"),
    TZ_AFRICA_JOHANNESBURG("TZ_AFRICA_JOHANNESBURG"),
    TZ_AUSTRALIA_VICTORIA("TZ_AUSTRALIA_VICTORIA"),
    TZ_AUSTRALIA_QUEENSLAND("TZ_AUSTRALIA_QUEENSLAND"),
    TZ_AUSTRALIA_ACT("TZ_AUSTRALIA_ACT"),
    TZ_AUSTRALIA_ADELAIDE("TZ_AUSTRALIA_ADELAIDE"),
    TZ_AUSTRALIA_BRISBANE("TZ_AUSTRALIA_BRISBANE"),
    TZ_AUSTRALIA_BROKEN_HILL("TZ_AUSTRALIA_BROKEN_HILL"),
    TZ_AUSTRALIA_CANBERRA("TZ_AUSTRALIA_CANBERRA"),
    TZ_AUSTRALIA_DARWIN("TZ_AUSTRALIA_DARWIN"),
    TZ_AUSTRALIA_HOBART("TZ_AUSTRALIA_HOBART"),
    TZ_AUSTRALIA_LHI("TZ_AUSTRALIA_LHI"),
    TZ_AUSTRALIA_LINDEMAN("TZ_AUSTRALIA_LINDEMAN"),
    TZ_AUSTRALIA_LORD_HOWE("TZ_AUSTRALIA_LORD_HOWE"),
    TZ_AUSTRALIA_MELBOURNE("TZ_AUSTRALIA_MELBOURNE"),
    TZ_AUSTRALIA_NORTH("TZ_AUSTRALIA_NORTH"),
    TZ_AUSTRALIA_NSW("TZ_AUSTRALIA_NSW"),
    TZ_AUSTRALIA_PERTH("TZ_AUSTRALIA_PERTH"),
    TZ_AUSTRALIA_SOUTH("TZ_AUSTRALIA_SOUTH"),
    TZ_AUSTRALIA_SYDNEY("TZ_AUSTRALIA_SYDNEY"),
    TZ_AUSTRALIA_TASMANIA("TZ_AUSTRALIA_TASMANIA"),
    TZ_AUSTRALIA_WEST("TZ_AUSTRALIA_WEST"),
    TZ_AUSTRALIA_YANCOWINNA("TZ_AUSTRALIA_YANCOWINNA"),
    TZ_BRAZIL_ACRE("TZ_BRAZIL_ACRE"),
    TZ_BRAZIL_DENORONHA("TZ_BRAZIL_DENORONHA"),
    TZ_BRAZIL_EAST("TZ_BRAZIL_EAST"),
    TZ_BRAZIL_WEST("TZ_BRAZIL_WEST"),
    TZ_PORTUGAL("TZ_PORTUGAL"),
    TZ_ETC_GMT_MINUS_1("TZ_ETC_GMT_MINUS_1"),
    TZ_ETC_GMT_MINUS_2("TZ_ETC_GMT_MINUS_2"),
    TZ_ETC_GMT_MINUS_3("TZ_ETC_GMT_MINUS_3"),
    TZ_ETC_GMT_MINUS_4("TZ_ETC_GMT_MINUS_4"),
    TZ_ETC_GMT_MINUS_5("TZ_ETC_GMT_MINUS_5"),
    TZ_ETC_GMT_MINUS_6("TZ_ETC_GMT_MINUS_6"),
    TZ_ETC_GMT_MINUS_7("TZ_ETC_GMT_MINUS_7"),
    TZ_ETC_GMT_MINUS_8("TZ_ETC_GMT_MINUS_8"),
    TZ_ETC_GMT_MINUS_9("TZ_ETC_GMT_MINUS_9"),
    TZ_ETC_GMT_MINUS_10("TZ_ETC_GMT_MINUS_10"),
    TZ_ETC_GMT_MINUS_11("TZ_ETC_GMT_MINUS_11"),
    TZ_ETC_GMT_MINUS_12("TZ_ETC_GMT_MINUS_12"),
    TZ_ETC_GMT_MINUS_13("TZ_ETC_GMT_MINUS_13"),
    TZ_ETC_GMT_MINUS_14("TZ_ETC_GMT_MINUS_14"),
    TZ_ETC_GMT_PLUS_1("TZ_ETC_GMT_PLUS_1"),
    TZ_ETC_GMT_PLUS_2("TZ_ETC_GMT_PLUS_2"),
    TZ_ETC_GMT_PLUS_3("TZ_ETC_GMT_PLUS_3"),
    TZ_ETC_GMT_PLUS_4("TZ_ETC_GMT_PLUS_4"),
    TZ_ETC_GMT_PLUS_5("TZ_ETC_GMT_PLUS_5"),
    TZ_ETC_GMT_PLUS_6("TZ_ETC_GMT_PLUS_6"),
    TZ_ETC_GMT_PLUS_7("TZ_ETC_GMT_PLUS_7"),
    TZ_ETC_GMT_PLUS_8("TZ_ETC_GMT_PLUS_8"),
    TZ_ETC_GMT_PLUS_9("TZ_ETC_GMT_PLUS_9"),
    TZ_ETC_GMT_PLUS_10("TZ_ETC_GMT_PLUS_10"),
    TZ_ETC_GMT_PLUS_11("TZ_ETC_GMT_PLUS_11"),
    TZ_ETC_GMT_PLUS_12("TZ_ETC_GMT_PLUS_12"),
    TZ_AFRICA_ABIDJAN("TZ_AFRICA_ABIDJAN"),
    TZ_AFRICA_ACCRA("TZ_AFRICA_ACCRA"),
    TZ_AFRICA_ADDIS_ABABA("TZ_AFRICA_ADDIS_ABABA"),
    TZ_AFRICA_ALGIERS("TZ_AFRICA_ALGIERS"),
    TZ_AFRICA_ASMARA("TZ_AFRICA_ASMARA"),
    TZ_AFRICA_ASMERA("TZ_AFRICA_ASMERA"),
    TZ_AFRICA_BAMAKO("TZ_AFRICA_BAMAKO"),
    TZ_AFRICA_BANGUI("TZ_AFRICA_BANGUI"),
    TZ_AFRICA_BANJUL("TZ_AFRICA_BANJUL"),
    TZ_AFRICA_BISSAU("TZ_AFRICA_BISSAU"),
    TZ_AFRICA_BLANTYRE("TZ_AFRICA_BLANTYRE"),
    TZ_AFRICA_BRAZZAVILLE("TZ_AFRICA_BRAZZAVILLE"),
    TZ_AFRICA_BUJUMBURA("TZ_AFRICA_BUJUMBURA"),
    TZ_AFRICA_CAIRO("TZ_AFRICA_CAIRO"),
    TZ_AFRICA_CASABLANCA("TZ_AFRICA_CASABLANCA"),
    TZ_AFRICA_CEUTA("TZ_AFRICA_CEUTA"),
    TZ_AFRICA_CONAKRY("TZ_AFRICA_CONAKRY"),
    TZ_AFRICA_DAKAR("TZ_AFRICA_DAKAR"),
    TZ_AFRICA_DAR_ES_SALAAM("TZ_AFRICA_DAR_ES_SALAAM"),
    TZ_AFRICA_DJIBOUTI("TZ_AFRICA_DJIBOUTI"),
    TZ_AFRICA_DOUALA("TZ_AFRICA_DOUALA"),
    TZ_AFRICA_EL_AAIUN("TZ_AFRICA_EL_AAIUN"),
    TZ_AFRICA_FREETOWN("TZ_AFRICA_FREETOWN"),
    TZ_AFRICA_GABORONE("TZ_AFRICA_GABORONE"),
    TZ_AFRICA_HARARE("TZ_AFRICA_HARARE"),
    TZ_AFRICA_KAMPALA("TZ_AFRICA_KAMPALA"),
    TZ_AFRICA_KHARTOUM("TZ_AFRICA_KHARTOUM"),
    TZ_AFRICA_KIGALI("TZ_AFRICA_KIGALI"),
    TZ_AFRICA_KINSHASA("TZ_AFRICA_KINSHASA"),
    TZ_AFRICA_LAGOS("TZ_AFRICA_LAGOS"),
    TZ_AFRICA_LIBREVILLE("TZ_AFRICA_LIBREVILLE"),
    TZ_AFRICA_LOME("TZ_AFRICA_LOME"),
    TZ_AFRICA_LUANDA("TZ_AFRICA_LUANDA"),
    TZ_AFRICA_LUBUMBASHI("TZ_AFRICA_LUBUMBASHI"),
    TZ_AFRICA_LUSAKA("TZ_AFRICA_LUSAKA"),
    TZ_AFRICA_MALABO("TZ_AFRICA_MALABO"),
    TZ_AFRICA_MAPUTO("TZ_AFRICA_MAPUTO"),
    TZ_AFRICA_MASERU("TZ_AFRICA_MASERU"),
    TZ_AFRICA_MBABANE("TZ_AFRICA_MBABANE"),
    TZ_AFRICA_MOGADISHU("TZ_AFRICA_MOGADISHU"),
    TZ_AFRICA_MONROVIA("TZ_AFRICA_MONROVIA"),
    TZ_AFRICA_NAIROBI("TZ_AFRICA_NAIROBI"),
    TZ_AFRICA_NDJAMENA("TZ_AFRICA_NDJAMENA"),
    TZ_AFRICA_NIAMEY("TZ_AFRICA_NIAMEY"),
    TZ_AFRICA_NOUAKCHOTT("TZ_AFRICA_NOUAKCHOTT"),
    TZ_AFRICA_OUAGADOUGOU("TZ_AFRICA_OUAGADOUGOU"),
    TZ_AFRICA_PORTO_NOVO("TZ_AFRICA_PORTO_NOVO"),
    TZ_AFRICA_SAO_TOME("TZ_AFRICA_SAO_TOME"),
    TZ_AFRICA_TIMBUKTU("TZ_AFRICA_TIMBUKTU"),
    TZ_AFRICA_TRIPOLI("TZ_AFRICA_TRIPOLI"),
    TZ_AFRICA_TUNIS("TZ_AFRICA_TUNIS"),
    TZ_AFRICA_WINDHOEK("TZ_AFRICA_WINDHOEK"),
    TZ_AMRICA_ANGUILLA("TZ_AMRICA_ANGUILLA"),
    TZ_AMRICA_ANTIGUA("TZ_AMRICA_ANTIGUA"),
    TZ_AMRICA_ARAGUAINA("TZ_AMRICA_ARAGUAINA"),
    TZ_AMRICA_ARGNT_BUENOSAIRES("TZ_AMRICA_ARGNT_BUENOSAIRES"),
    TZ_AMRICA_ARGNT_CATAMARCA("TZ_AMRICA_ARGNT_CATAMARCA"),
    TZ_AMRICA_ARGNT_COMODRIVADAVIA("TZ_AMRICA_ARGNT_COMODRIVADAVIA"),
    TZ_AMRICA_ARGNT_CORDOBA("TZ_AMRICA_ARGNT_CORDOBA"),
    TZ_AMRICA_ARGNT_JUJUY("TZ_AMRICA_ARGNT_JUJUY"),
    TZ_AMRICA_ARGNT_LA_RIOJA("TZ_AMRICA_ARGNT_LA_RIOJA"),
    TZ_AMRICA_ARGNT_MENDOZA("TZ_AMRICA_ARGNT_MENDOZA"),
    TZ_AMRICA_ARGNT_RIO_GALLEGOS("TZ_AMRICA_ARGNT_RIO_GALLEGOS"),
    TZ_AMRICA_ARGNT_SALTA("TZ_AMRICA_ARGNT_SALTA"),
    TZ_AMRICA_ARGNT_SAN_JUAN("TZ_AMRICA_ARGNT_SAN_JUAN"),
    TZ_AMRICA_ARGNT_SAN_LUIS("TZ_AMRICA_ARGNT_SAN_LUIS"),
    TZ_AMRICA_ARGNT_TUCUMAN("TZ_AMRICA_ARGNT_TUCUMAN"),
    TZ_AMRICA_ARGNT_USHUAIA("TZ_AMRICA_ARGNT_USHUAIA"),
    TZ_AMERICA_ARUBA("TZ_AMERICA_ARUBA"),
    TZ_AMERICA_ASUNCION("TZ_AMERICA_ASUNCION"),
    TZ_AMERICA_ATIKOKAN("TZ_AMERICA_ATIKOKAN"),
    TZ_AMERICA_ATKA("TZ_AMERICA_ATKA"),
    TZ_AMERICA_BAHIA("TZ_AMERICA_BAHIA"),
    TZ_AMERICA_BARBADOS("TZ_AMERICA_BARBADOS"),
    TZ_AMERICA_BELEM("TZ_AMERICA_BELEM"),
    TZ_AMERICA_BELIZE("TZ_AMERICA_BELIZE"),
    TZ_AMERICA_BLANC_SABLON("TZ_AMERICA_BLANC_SABLON"),
    TZ_AMERICA_BOA_VISTA("TZ_AMERICA_BOA_VISTA"),
    TZ_AMERICA_BOGOTA("TZ_AMERICA_BOGOTA"),
    TZ_AMERICA_BOISE("TZ_AMERICA_BOISE"),
    TZ_AMERICA_BUENOS_AIRES("TZ_AMERICA_BUENOS_AIRES"),
    TZ_AMERICA_CAMBRIDGE_BAY("TZ_AMERICA_CAMBRIDGE_BAY"),
    TZ_AMERICA_CAMPO_GRANDE("TZ_AMERICA_CAMPO_GRANDE"),
    TZ_AMERICA_CANCUN("TZ_AMERICA_CANCUN"),
    TZ_AMERICA_CARACAS("TZ_AMERICA_CARACAS"),
    TZ_AMERICA_CATAMARCA("TZ_AMERICA_CATAMARCA"),
    TZ_AMERICA_CAYENNE("TZ_AMERICA_CAYENNE"),
    TZ_AMERICA_CHIHUAHUA("TZ_AMERICA_CHIHUAHUA"),
    TZ_AMERICA_CORAL_HARBOUR("TZ_AMERICA_CORAL_HARBOUR"),
    TZ_AMERICA_CORDOBA("TZ_AMERICA_CORDOBA"),
    TZ_AMERICA_COSTA_RICA("TZ_AMERICA_COSTA_RICA"),
    TZ_AMERICA_CUIABA("TZ_AMERICA_CUIABA"),
    TZ_AMERICA_CURACAO("TZ_AMERICA_CURACAO"),
    TZ_AMERICA_DANMARKSHAVN("TZ_AMERICA_DANMARKSHAVN"),
    TZ_AMERICA_DAWSON("TZ_AMERICA_DAWSON"),
    TZ_AMERICA_DAWSON_CREEK("TZ_AMERICA_DAWSON_CREEK"),
    TZ_AMERICA_DETROIT("TZ_AMERICA_DETROIT"),
    TZ_AMERICA_DOMINICA("TZ_AMERICA_DOMINICA"),
    TZ_AMERICA_EDMONTON("TZ_AMERICA_EDMONTON"),
    TZ_AMERICA_EIRUNEPE("TZ_AMERICA_EIRUNEPE"),
    TZ_AMERICA_EL_SALVADOR("TZ_AMERICA_EL_SALVADOR"),
    TZ_AMERICA_ENSENADA("TZ_AMERICA_ENSENADA"),
    TZ_AMERICA_FORT_WAYNE("TZ_AMERICA_FORT_WAYNE"),
    TZ_AMERICA_FORTALEZA("TZ_AMERICA_FORTALEZA"),
    TZ_AMERICA_GLACE_BAY("TZ_AMERICA_GLACE_BAY"),
    TZ_AMERICA_GODTHAB("TZ_AMERICA_GODTHAB"),
    TZ_AMERICA_GOOSE_BAY("TZ_AMERICA_GOOSE_BAY"),
    TZ_AMERICA_GRAND_TURK("TZ_AMERICA_GRAND_TURK"),
    TZ_AMERICA_GRENADA("TZ_AMERICA_GRENADA"),
    TZ_AMERICA_GUADELOUPE("TZ_AMERICA_GUADELOUPE"),
    TZ_AMERICA_GUATEMALA("TZ_AMERICA_GUATEMALA"),
    TZ_AMERICA_GUAYAQUIL("TZ_AMERICA_GUAYAQUIL"),
    TZ_AMERICA_GUYANA("TZ_AMERICA_GUYANA"),
    TZ_AMERICA_HALIFAX("TZ_AMERICA_HALIFAX"),
    TZ_AMERICA_HAVANA("TZ_AMERICA_HAVANA"),
    TZ_AMERICA_HERMOSILLO("TZ_AMERICA_HERMOSILLO"),
    TZ_AMRICA_INDIANA_INDIANAPOLIS("TZ_AMRICA_INDIANA_INDIANAPOLIS"),
    TZ_AMRICA_INDNA_KNOX("TZ_AMRICA_INDNA_KNOX"),
    TZ_AMRICA_INDNA_MARENGO("TZ_AMRICA_INDNA_MARENGO"),
    TZ_AMRICA_INDNA_PETERSBURG("TZ_AMRICA_INDNA_PETERSBURG"),
    TZ_AMRICA_INDNA_TELL_CITY("TZ_AMRICA_INDNA_TELL_CITY"),
    TZ_AMRICA_INDNA_VEVAY("TZ_AMRICA_INDNA_VEVAY"),
    TZ_AMRICA_INDNA_VINCENNES("TZ_AMRICA_INDNA_VINCENNES"),
    TZ_AMRICA_INDNA_WINAMAC("TZ_AMRICA_INDNA_WINAMAC"),
    TZ_AMRICA_INDNAPOLIS("TZ_AMRICA_INDNAPOLIS"),
    TZ_AMERICA_INUVIK("TZ_AMERICA_INUVIK"),
    TZ_AMERICA_IQALUIT("TZ_AMERICA_IQALUIT"),
    TZ_AMERICA_JAMAICA("TZ_AMERICA_JAMAICA"),
    TZ_AMERICA_JUJUY("TZ_AMERICA_JUJUY"),
    TZ_AMERICA_JUNEAU("TZ_AMERICA_JUNEAU"),
    TZ_AMERICA_KENTUCKY_LOUISVILLE("TZ_AMERICA_KENTUCKY_LOUISVILLE"),
    TZ_AMERICA_KENTUCKY_MONTICELLO("TZ_AMERICA_KENTUCKY_MONTICELLO"),
    TZ_AMERICA_KNOX_IN("TZ_AMERICA_KNOX_IN"),
    TZ_AMERICA_LA_PAZ("TZ_AMERICA_LA_PAZ"),
    TZ_AMERICA_LIMA("TZ_AMERICA_LIMA"),
    TZ_AMERICA_LOUISVILLE("TZ_AMERICA_LOUISVILLE"),
    TZ_AMERICA_MACEIO("TZ_AMERICA_MACEIO"),
    TZ_AMERICA_MANAGUA("TZ_AMERICA_MANAGUA"),
    TZ_AMERICA_MANAUS("TZ_AMERICA_MANAUS"),
    TZ_AMERICA_MARIGOT("TZ_AMERICA_MARIGOT"),
    TZ_AMERICA_MATAMOROS("TZ_AMERICA_MATAMOROS"),
    TZ_AMERICA_MAZATLAN("TZ_AMERICA_MAZATLAN"),
    TZ_AMERICA_MENDOZA("TZ_AMERICA_MENDOZA"),
    TZ_AMERICA_MENOMINEE("TZ_AMERICA_MENOMINEE"),
    TZ_AMERICA_MERIDA("TZ_AMERICA_MERIDA"),
    TZ_AMERICA_MEXICO_CITY("TZ_AMERICA_MEXICO_CITY"),
    TZ_AMERICA_MIQUELON("TZ_AMERICA_MIQUELON"),
    TZ_AMERICA_MONCTON("TZ_AMERICA_MONCTON"),
    TZ_AMERICA_MONTERREY("TZ_AMERICA_MONTERREY"),
    TZ_AMERICA_MONTEVIDEO("TZ_AMERICA_MONTEVIDEO"),
    TZ_AMERICA_MONTREAL("TZ_AMERICA_MONTREAL"),
    TZ_AMERICA_MONTSERRAT("TZ_AMERICA_MONTSERRAT"),
    TZ_AMERICA_NASSAU("TZ_AMERICA_NASSAU"),
    TZ_AMERICA_NIPIGON("TZ_AMERICA_NIPIGON"),
    TZ_AMERICA_NOME("TZ_AMERICA_NOME"),
    TZ_AMERICA_NORONHA("TZ_AMERICA_NORONHA"),
    TZ_AMRICA_NTH_DKOTA_CENTER("TZ_AMRICA_NTH_DKOTA_CENTER"),
    TZ_AMRICA_NTH_DKOTA_NEW_SALEM("TZ_AMRICA_NTH_DKOTA_NEW_SALEM"),
    TZ_AMERICA_OJINAGA("TZ_AMERICA_OJINAGA"),
    TZ_AMERICA_PANAMA("TZ_AMERICA_PANAMA"),
    TZ_AMERICA_PANGNIRTUNG("TZ_AMERICA_PANGNIRTUNG"),
    TZ_AMERICA_PARAMARIBO("TZ_AMERICA_PARAMARIBO"),
    TZ_AMERICA_PORT_AU_PRINCE("TZ_AMERICA_PORT_AU_PRINCE"),
    TZ_AMERICA_PORT_OF_SPAIN("TZ_AMERICA_PORT_OF_SPAIN"),
    TZ_AMERICA_PORTO_ACRE("TZ_AMERICA_PORTO_ACRE"),
    TZ_AMERICA_PORTO_VELHO("TZ_AMERICA_PORTO_VELHO"),
    TZ_AMERICA_PUERTO_RICO("TZ_AMERICA_PUERTO_RICO"),
    TZ_AMERICA_RAINY_RIVER("TZ_AMERICA_RAINY_RIVER"),
    TZ_AMERICA_RANKIN_INLET("TZ_AMERICA_RANKIN_INLET"),
    TZ_AMERICA_RECIFE("TZ_AMERICA_RECIFE"),
    TZ_AMERICA_REGINA("TZ_AMERICA_REGINA"),
    TZ_AMERICA_RESOLUTE("TZ_AMERICA_RESOLUTE"),
    TZ_AMERICA_RIO_BRANCO("TZ_AMERICA_RIO_BRANCO"),
    TZ_AMERICA_ROSARIO("TZ_AMERICA_ROSARIO"),
    TZ_AMERICA_SANTA_ISABEL("TZ_AMERICA_SANTA_ISABEL"),
    TZ_AMERICA_SANTIAGO("TZ_AMERICA_SANTIAGO"),
    TZ_AMERICA_SANTO_DOMINGO("TZ_AMERICA_SANTO_DOMINGO"),
    TZ_AMERICA_SAO_PAULO("TZ_AMERICA_SAO_PAULO"),
    TZ_AMERICA_SCORESBYSUND("TZ_AMERICA_SCORESBYSUND"),
    TZ_AMERICA_SHIPROCK("TZ_AMERICA_SHIPROCK"),
    TZ_AMERICA_ST_BARTHELEMY("TZ_AMERICA_ST_BARTHELEMY"),
    TZ_AMERICA_ST_JOHNS("TZ_AMERICA_ST_JOHNS"),
    TZ_AMERICA_ST_KITTS("TZ_AMERICA_ST_KITTS"),
    TZ_AMERICA_ST_LUCIA("TZ_AMERICA_ST_LUCIA"),
    TZ_AMERICA_ST_THOMAS("TZ_AMERICA_ST_THOMAS"),
    TZ_AMERICA_ST_VINCENT("TZ_AMERICA_ST_VINCENT"),
    TZ_AMERICA_SWIFT_CURRENT("TZ_AMERICA_SWIFT_CURRENT"),
    TZ_AMERICA_TEGUCIGALPA("TZ_AMERICA_TEGUCIGALPA"),
    TZ_AMERICA_THULE("TZ_AMERICA_THULE"),
    TZ_AMERICA_THUNDER_BAY("TZ_AMERICA_THUNDER_BAY"),
    TZ_AMERICA_TIJUANA("TZ_AMERICA_TIJUANA"),
    TZ_AMERICA_TORONTO("TZ_AMERICA_TORONTO"),
    TZ_AMERICA_TORTOLA("TZ_AMERICA_TORTOLA"),
    TZ_AMERICA_VANCOUVER("TZ_AMERICA_VANCOUVER"),
    TZ_AMERICA_VIRGIN("TZ_AMERICA_VIRGIN"),
    TZ_AMERICA_WHITEHORSE("TZ_AMERICA_WHITEHORSE"),
    TZ_AMERICA_WINNIPEG("TZ_AMERICA_WINNIPEG"),
    TZ_AMERICA_YAKUTAT("TZ_AMERICA_YAKUTAT"),
    TZ_AMERICA_YELLOWKNIFE("TZ_AMERICA_YELLOWKNIFE"),
    TZ_ANTARCTICA_CASEY("TZ_ANTARCTICA_CASEY"),
    TZ_ANTARCTICA_DAVIS("TZ_ANTARCTICA_DAVIS"),
    TZ_ANTARCTICA_DUMONTDURVILLE("TZ_ANTARCTICA_DUMONTDURVILLE"),
    TZ_ANTARCTICA_MAWSON("TZ_ANTARCTICA_MAWSON"),
    TZ_ANTARCTICA_MCMURDO("TZ_ANTARCTICA_MCMURDO"),
    TZ_ANTARCTICA_PALMER("TZ_ANTARCTICA_PALMER"),
    TZ_ANTARCTICA_SOUTH_POLE("TZ_ANTARCTICA_SOUTH_POLE"),
    TZ_ANTARCTICA_SYOWA("TZ_ANTARCTICA_SYOWA"),
    TZ_ARCTIC_LONGYEARBYEN("TZ_ARCTIC_LONGYEARBYEN"),
    TZ_ASIA_ADEN("TZ_ASIA_ADEN"),
    TZ_ASIA_ALMATY("TZ_ASIA_ALMATY"),
    TZ_ASIA_AMMAN("TZ_ASIA_AMMAN"),
    TZ_ASIA_ANADYR("TZ_ASIA_ANADYR"),
    TZ_ASIA_AQTAU("TZ_ASIA_AQTAU"),
    TZ_ASIA_AQTOBE("TZ_ASIA_AQTOBE"),
    TZ_ASIA_ASHGABAT("TZ_ASIA_ASHGABAT"),
    TZ_ASIA_ASHKHABAD("TZ_ASIA_ASHKHABAD"),
    TZ_ASIA_BAGHDAD("TZ_ASIA_BAGHDAD"),
    TZ_ASIA_BAHRAIN("TZ_ASIA_BAHRAIN"),
    TZ_ASIA_BAKU("TZ_ASIA_BAKU"),
    TZ_ASIA_BANGKOK("TZ_ASIA_BANGKOK"),
    TZ_ASIA_BEIRUT("TZ_ASIA_BEIRUT"),
    TZ_ASIA_BISHKEK("TZ_ASIA_BISHKEK"),
    TZ_ASIA_BRUNEI("TZ_ASIA_BRUNEI"),
    TZ_ASIA_CALCUTTA("TZ_ASIA_CALCUTTA"),
    TZ_ASIA_CHOIBALSAN("TZ_ASIA_CHOIBALSAN"),
    TZ_ASIA_CHONGQING("TZ_ASIA_CHONGQING"),
    TZ_ASIA_CHUNGKING("TZ_ASIA_CHUNGKING"),
    TZ_ASIA_COLOMBO("TZ_ASIA_COLOMBO"),
    TZ_ASIA_DACCA("TZ_ASIA_DACCA"),
    TZ_ASIA_DAMASCUS("TZ_ASIA_DAMASCUS"),
    TZ_ASIA_DHAKA("TZ_ASIA_DHAKA"),
    TZ_ASIA_DILI("TZ_ASIA_DILI"),
    TZ_ASIA_DUBAI("TZ_ASIA_DUBAI"),
    TZ_ASIA_DUSHANBE("TZ_ASIA_DUSHANBE"),
    TZ_ASIA_GAZA("TZ_ASIA_GAZA"),
    TZ_ASIA_HARBIN("TZ_ASIA_HARBIN"),
    TZ_ASIA_HO_CHI_MINH("TZ_ASIA_HO_CHI_MINH"),
    TZ_ASIA_HONG_KONG("TZ_ASIA_HONG_KONG"),
    TZ_ASIA_HOVD("TZ_ASIA_HOVD"),
    TZ_ASIA_IRKUTSK("TZ_ASIA_IRKUTSK"),
    TZ_ASIA_ISTANBUL("TZ_ASIA_ISTANBUL"),
    TZ_ASIA_JAKARTA("TZ_ASIA_JAKARTA"),
    TZ_ASIA_JAYAPURA("TZ_ASIA_JAYAPURA"),
    TZ_ASIA_JERUSALEM("TZ_ASIA_JERUSALEM"),
    TZ_ASIA_KABUL("TZ_ASIA_KABUL"),
    TZ_ASIA_KAMCHATKA("TZ_ASIA_KAMCHATKA"),
    TZ_ASIA_KARACHI("TZ_ASIA_KARACHI"),
    TZ_ASIA_KASHGAR("TZ_ASIA_KASHGAR"),
    TZ_ASIA_KATHMANDU("TZ_ASIA_KATHMANDU"),
    TZ_ASIA_KATMANDU("TZ_ASIA_KATMANDU"),
    TZ_ASIA_KOLKATA("TZ_ASIA_KOLKATA"),
    TZ_ASIA_KRASNOYARSK("TZ_ASIA_KRASNOYARSK"),
    TZ_ASIA_KUALA_LUMPUR("TZ_ASIA_KUALA_LUMPUR"),
    TZ_ASIA_KUCHING("TZ_ASIA_KUCHING"),
    TZ_ASIA_KUWAIT("TZ_ASIA_KUWAIT"),
    TZ_ASIA_MACAO("TZ_ASIA_MACAO"),
    TZ_ASIA_MACAU("TZ_ASIA_MACAU"),
    TZ_ASIA_MAGADAN("TZ_ASIA_MAGADAN"),
    TZ_ASIA_MAKASSAR("TZ_ASIA_MAKASSAR"),
    TZ_ASIA_MANILA("TZ_ASIA_MANILA"),
    TZ_ASIA_MUSCAT("TZ_ASIA_MUSCAT"),
    TZ_ASIA_NICOSIA("TZ_ASIA_NICOSIA"),
    TZ_ASIA_NOVOSIBIRSK("TZ_ASIA_NOVOSIBIRSK"),
    TZ_ASIA_OMSK("TZ_ASIA_OMSK"),
    TZ_ASIA_ORAL("TZ_ASIA_ORAL"),
    TZ_ASIA_PHNOM_PENH("TZ_ASIA_PHNOM_PENH"),
    TZ_ASIA_PONTIANAK("TZ_ASIA_PONTIANAK"),
    TZ_ASIA_PYONGYANG("TZ_ASIA_PYONGYANG"),
    TZ_ASIA_QATAR("TZ_ASIA_QATAR"),
    TZ_ASIA_QYZYLORDA("TZ_ASIA_QYZYLORDA"),
    TZ_ASIA_RANGOON("TZ_ASIA_RANGOON"),
    TZ_ASIA_RIYADH("TZ_ASIA_RIYADH"),
    TZ_ASIA_SAIGON("TZ_ASIA_SAIGON"),
    TZ_ASIA_SAKHALIN("TZ_ASIA_SAKHALIN"),
    TZ_ASIA_SAMARKAND("TZ_ASIA_SAMARKAND"),
    TZ_ASIA_SEOUL("TZ_ASIA_SEOUL"),
    TZ_ASIA_SHANGHAI("TZ_ASIA_SHANGHAI"),
    TZ_ASIA_SINGAPORE("TZ_ASIA_SINGAPORE"),
    TZ_ASIA_TAIPEI("TZ_ASIA_TAIPEI"),
    TZ_ASIA_TASHKENT("TZ_ASIA_TASHKENT"),
    TZ_ASIA_TBILISI("TZ_ASIA_TBILISI"),
    TZ_ASIA_TEHRAN("TZ_ASIA_TEHRAN"),
    TZ_ASIA_TEL_AVIV("TZ_ASIA_TEL_AVIV"),
    TZ_ASIA_THIMBU("TZ_ASIA_THIMBU"),
    TZ_ASIA_THIMPHU("TZ_ASIA_THIMPHU"),
    TZ_ASIA_TOKYO("TZ_ASIA_TOKYO"),
    TZ_ASIA_UJUNG_PANDANG("TZ_ASIA_UJUNG_PANDANG"),
    TZ_ASIA_ULAANBAATAR("TZ_ASIA_ULAANBAATAR"),
    TZ_ASIA_ULAN_BATOR("TZ_ASIA_ULAN_BATOR"),
    TZ_ASIA_URUMQI("TZ_ASIA_URUMQI"),
    TZ_ASIA_VIENTIANE("TZ_ASIA_VIENTIANE"),
    TZ_ASIA_VLADIVOSTOK("TZ_ASIA_VLADIVOSTOK"),
    TZ_ASIA_YAKUTSK("TZ_ASIA_YAKUTSK"),
    TZ_ASIA_YEKATERINBURG("TZ_ASIA_YEKATERINBURG"),
    TZ_ASIA_YEREVAN("TZ_ASIA_YEREVAN"),
    TZ_ATLANTIC_AZORES("TZ_ATLANTIC_AZORES"),
    TZ_ATLANTIC_BERMUDA("TZ_ATLANTIC_BERMUDA"),
    TZ_ATLANTIC_CANARY("TZ_ATLANTIC_CANARY"),
    TZ_ATLANTIC_CAPE_VERDE("TZ_ATLANTIC_CAPE_VERDE"),
    TZ_ATLANTIC_FAEROE("TZ_ATLANTIC_FAEROE"),
    TZ_ATLANTIC_FAROE("TZ_ATLANTIC_FAROE"),
    TZ_ATLANTIC_JAN_MAYEN("TZ_ATLANTIC_JAN_MAYEN"),
    TZ_ATLANTIC_MADEIRA("TZ_ATLANTIC_MADEIRA"),
    TZ_ATLANTIC_REYKJAVIK("TZ_ATLANTIC_REYKJAVIK"),
    TZ_ATLANTIC_SOUTH_GEORGIA("TZ_ATLANTIC_SOUTH_GEORGIA"),
    TZ_ATLANTIC_ST_HELENA("TZ_ATLANTIC_ST_HELENA"),
    TZ_ATLANTIC_STANLEY("TZ_ATLANTIC_STANLEY"),
    TZ_CET("TZ_CET"),
    TZ_CST("TZ_CST"),
    @XmlEnumValue("TZ_CST6CDT")
    TZ_CST_6_CDT("TZ_CST6CDT"),
    TZ_CANADA_ATLANTIC("TZ_CANADA_ATLANTIC"),
    TZ_CANADA_CENTRAL("TZ_CANADA_CENTRAL"),
    TZ_CANADA_EAST_SASKATCHEWAN("TZ_CANADA_EAST_SASKATCHEWAN"),
    TZ_CANADA_EASTERN("TZ_CANADA_EASTERN"),
    TZ_CANADA_MOUNTAIN("TZ_CANADA_MOUNTAIN"),
    TZ_CANADA_PACIFIC("TZ_CANADA_PACIFIC"),
    TZ_CANADA_YUKON("TZ_CANADA_YUKON"),
    TZ_CHILE_CONTINENTAL("TZ_CHILE_CONTINENTAL"),
    TZ_CHILE_EASTERISLAND("TZ_CHILE_EASTERISLAND"),
    TZ_CUBA("TZ_CUBA"),
    TZ_EET("TZ_EET"),
    TZ_EST("TZ_EST"),
    @XmlEnumValue("TZ_EST5EDT")
    TZ_EST_5_EDT("TZ_EST5EDT"),
    TZ_EGYPT("TZ_EGYPT"),
    TZ_EIRE("TZ_EIRE"),
    TZ_ETC_GREENWICH("TZ_ETC_GREENWICH"),
    TZ_EUROPE_AMSTERDAM("TZ_EUROPE_AMSTERDAM"),
    TZ_EUROPE_ANDORRA("TZ_EUROPE_ANDORRA"),
    TZ_EUROPE_ATHENS("TZ_EUROPE_ATHENS"),
    TZ_EUROPE_BELFAST("TZ_EUROPE_BELFAST"),
    TZ_EUROPE_BELGRADE("TZ_EUROPE_BELGRADE"),
    TZ_EUROPE_BERLIN("TZ_EUROPE_BERLIN"),
    TZ_EUROPE_BRATISLAVA("TZ_EUROPE_BRATISLAVA"),
    TZ_EUROPE_BRUSSELS("TZ_EUROPE_BRUSSELS"),
    TZ_EUROPE_BUCHAREST("TZ_EUROPE_BUCHAREST"),
    TZ_EUROPE_BUDAPEST("TZ_EUROPE_BUDAPEST"),
    TZ_EUROPE_CHISINAU("TZ_EUROPE_CHISINAU"),
    TZ_EUROPE_COPENHAGEN("TZ_EUROPE_COPENHAGEN"),
    TZ_EUROPE_DUBLIN("TZ_EUROPE_DUBLIN"),
    TZ_EUROPE_GIBRALTAR("TZ_EUROPE_GIBRALTAR"),
    TZ_EUROPE_GUERNSEY("TZ_EUROPE_GUERNSEY"),
    TZ_EUROPE_HELSINKI("TZ_EUROPE_HELSINKI"),
    TZ_EUROPE_ISLE_OF_MAN("TZ_EUROPE_ISLE_OF_MAN"),
    TZ_EUROPE_ISTANBUL("TZ_EUROPE_ISTANBUL"),
    TZ_EUROPE_JERSEY("TZ_EUROPE_JERSEY"),
    TZ_EUROPE_KALININGRAD("TZ_EUROPE_KALININGRAD"),
    TZ_EUROPE_KIEV("TZ_EUROPE_KIEV"),
    TZ_EUROPE_LISBON("TZ_EUROPE_LISBON"),
    TZ_EUROPE_LJUBLJANA("TZ_EUROPE_LJUBLJANA"),
    TZ_EUROPE_LONDON("TZ_EUROPE_LONDON"),
    TZ_EUROPE_LUXEMBOURG("TZ_EUROPE_LUXEMBOURG"),
    TZ_EUROPE_MADRID("TZ_EUROPE_MADRID"),
    TZ_EUROPE_MALTA("TZ_EUROPE_MALTA"),
    TZ_EUROPE_MARIEHAMN("TZ_EUROPE_MARIEHAMN"),
    TZ_EUROPE_MINSK("TZ_EUROPE_MINSK"),
    TZ_EUROPE_MONACO("TZ_EUROPE_MONACO"),
    TZ_EUROPE_MOSCOW("TZ_EUROPE_MOSCOW"),
    TZ_EUROPE_NICOSIA("TZ_EUROPE_NICOSIA"),
    TZ_EUROPE_OSLO("TZ_EUROPE_OSLO"),
    TZ_EUROPE_PARIS("TZ_EUROPE_PARIS"),
    TZ_EUROPE_PODGORICA("TZ_EUROPE_PODGORICA"),
    TZ_EUROPE_PRAGUE("TZ_EUROPE_PRAGUE"),
    TZ_EUROPE_RIGA("TZ_EUROPE_RIGA"),
    TZ_EUROPE_ROME("TZ_EUROPE_ROME"),
    TZ_EUROPE_SAMARA("TZ_EUROPE_SAMARA"),
    TZ_EUROPE_SAN_MARINO("TZ_EUROPE_SAN_MARINO"),
    TZ_EUROPE_SARAJEVO("TZ_EUROPE_SARAJEVO"),
    TZ_EUROPE_SIMFEROPOL("TZ_EUROPE_SIMFEROPOL"),
    TZ_EUROPE_SKOPJE("TZ_EUROPE_SKOPJE"),
    TZ_EUROPE_SOFIA("TZ_EUROPE_SOFIA"),
    TZ_EUROPE_STOCKHOLM("TZ_EUROPE_STOCKHOLM"),
    TZ_EUROPE_TALLINN("TZ_EUROPE_TALLINN"),
    TZ_EUROPE_TIRANE("TZ_EUROPE_TIRANE"),
    TZ_EUROPE_TIRASPOL("TZ_EUROPE_TIRASPOL"),
    TZ_EUROPE_UZHGOROD("TZ_EUROPE_UZHGOROD"),
    TZ_EUROPE_VADUZ("TZ_EUROPE_VADUZ"),
    TZ_EUROPE_VATICAN("TZ_EUROPE_VATICAN"),
    TZ_EUROPE_VIENNA("TZ_EUROPE_VIENNA"),
    TZ_EUROPE_VILNIUS("TZ_EUROPE_VILNIUS"),
    TZ_EUROPE_VOLGOGRAD("TZ_EUROPE_VOLGOGRAD"),
    TZ_EUROPE_WARSAW("TZ_EUROPE_WARSAW"),
    TZ_EUROPE_ZAGREB("TZ_EUROPE_ZAGREB"),
    TZ_EUROPE_ZAPOROZHYE("TZ_EUROPE_ZAPOROZHYE"),
    TZ_EUROPE_ZURICH("TZ_EUROPE_ZURICH"),
    TZ_GB("TZ_GB"),
    TZ_GB_EIRE("TZ_GB_EIRE"),
    @XmlEnumValue("TZ_GMT0")
    TZ_GMT_0("TZ_GMT0"),
    TZ_GREENWICH("TZ_GREENWICH"),
    TZ_HST("TZ_HST"),
    TZ_HONGKONG("TZ_HONGKONG"),
    TZ_ICELAND("TZ_ICELAND"),
    TZ_INDIAN_ANTANANARIVO("TZ_INDIAN_ANTANANARIVO"),
    TZ_INDIAN_CHAGOS("TZ_INDIAN_CHAGOS"),
    TZ_INDIAN_CHRISTMAS("TZ_INDIAN_CHRISTMAS"),
    TZ_INDIAN_COCOS("TZ_INDIAN_COCOS"),
    TZ_INDIAN_COMORO("TZ_INDIAN_COMORO"),
    TZ_INDIAN_KERGUELEN("TZ_INDIAN_KERGUELEN"),
    TZ_INDIAN_MAHE("TZ_INDIAN_MAHE"),
    TZ_INDIAN_MALDIVES("TZ_INDIAN_MALDIVES"),
    TZ_INDIAN_MAURITIUS("TZ_INDIAN_MAURITIUS"),
    TZ_INDIAN_MAYOTTE("TZ_INDIAN_MAYOTTE"),
    TZ_INDIAN_REUNION("TZ_INDIAN_REUNION"),
    TZ_IRAN("TZ_IRAN"),
    TZ_ISRAEL("TZ_ISRAEL"),
    TZ_JAMAICA("TZ_JAMAICA"),
    TZ_JAPAN("TZ_JAPAN"),
    TZ_KWAJALEIN("TZ_KWAJALEIN"),
    TZ_LIBYA("TZ_LIBYA"),
    TZ_MET("TZ_MET"),
    TZ_MST("TZ_MST"),
    @XmlEnumValue("TZ_MST7MDT")
    TZ_MST_7_MDT("TZ_MST7MDT"),
    TZ_MEXICO_BAJANORTE("TZ_MEXICO_BAJANORTE"),
    TZ_MEXICO_BAJASUR("TZ_MEXICO_BAJASUR"),
    TZ_MEXICO_GENERAL("TZ_MEXICO_GENERAL"),
    TZ_NZ("TZ_NZ"),
    TZ_NZ_CHAT("TZ_NZ_CHAT"),
    TZ_NAVAJO("TZ_NAVAJO"),
    TZ_PRC("TZ_PRC"),
    TZ_PST("TZ_PST"),
    @XmlEnumValue("TZ_PST8PDT")
    TZ_PST_8_PDT("TZ_PST8PDT"),
    TZ_PACIFIC_APIA("TZ_PACIFIC_APIA"),
    TZ_PACIFIC_AUCKLAND("TZ_PACIFIC_AUCKLAND"),
    TZ_PACIFIC_CHATHAM("TZ_PACIFIC_CHATHAM"),
    TZ_PACIFIC_EASTER("TZ_PACIFIC_EASTER"),
    TZ_PACIFIC_EFATE("TZ_PACIFIC_EFATE"),
    TZ_PACIFIC_ENDERBURY("TZ_PACIFIC_ENDERBURY"),
    TZ_PACIFIC_FAKAOFO("TZ_PACIFIC_FAKAOFO"),
    TZ_PACIFIC_FIJI("TZ_PACIFIC_FIJI"),
    TZ_PACIFIC_FUNAFUTI("TZ_PACIFIC_FUNAFUTI"),
    TZ_PACIFIC_GALAPAGOS("TZ_PACIFIC_GALAPAGOS"),
    TZ_PACIFIC_GAMBIER("TZ_PACIFIC_GAMBIER"),
    TZ_PACIFIC_GUADALCANAL("TZ_PACIFIC_GUADALCANAL"),
    TZ_PACIFIC_GUAM("TZ_PACIFIC_GUAM"),
    TZ_PACIFIC_JOHNSTON("TZ_PACIFIC_JOHNSTON"),
    TZ_PACIFIC_KIRITIMATI("TZ_PACIFIC_KIRITIMATI"),
    TZ_PACIFIC_KOSRAE("TZ_PACIFIC_KOSRAE"),
    TZ_PACIFIC_KWAJALEIN("TZ_PACIFIC_KWAJALEIN"),
    TZ_PACIFIC_MAJURO("TZ_PACIFIC_MAJURO"),
    TZ_PACIFIC_MARQUESAS("TZ_PACIFIC_MARQUESAS"),
    TZ_PACIFIC_MIDWAY("TZ_PACIFIC_MIDWAY"),
    TZ_PACIFIC_NAURU("TZ_PACIFIC_NAURU"),
    TZ_PACIFIC_NIUE("TZ_PACIFIC_NIUE"),
    TZ_PACIFIC_NORFOLK("TZ_PACIFIC_NORFOLK"),
    TZ_PACIFIC_NOUMEA("TZ_PACIFIC_NOUMEA"),
    TZ_PACIFIC_PAGO_PAGO("TZ_PACIFIC_PAGO_PAGO"),
    TZ_PACIFIC_PALAU("TZ_PACIFIC_PALAU"),
    TZ_PACIFIC_PITCAIRN("TZ_PACIFIC_PITCAIRN"),
    TZ_PACIFIC_PONAPE("TZ_PACIFIC_PONAPE"),
    TZ_PACIFIC_PORT_MORESBY("TZ_PACIFIC_PORT_MORESBY"),
    TZ_PACIFIC_RAROTONGA("TZ_PACIFIC_RAROTONGA"),
    TZ_PACIFIC_SAIPAN("TZ_PACIFIC_SAIPAN"),
    TZ_PACIFIC_SAMOA("TZ_PACIFIC_SAMOA"),
    TZ_PACIFIC_TAHITI("TZ_PACIFIC_TAHITI"),
    TZ_PACIFIC_TARAWA("TZ_PACIFIC_TARAWA"),
    TZ_PACIFIC_TONGATAPU("TZ_PACIFIC_TONGATAPU"),
    TZ_PACIFIC_TRUK("TZ_PACIFIC_TRUK"),
    TZ_PACIFIC_WAKE("TZ_PACIFIC_WAKE"),
    TZ_PACIFIC_WALLIS("TZ_PACIFIC_WALLIS"),
    TZ_PACIFIC_YAP("TZ_PACIFIC_YAP"),
    TZ_POLAND("TZ_POLAND"),
    TZ_ROK("TZ_ROK"),
    TZ_SINGAPORE("TZ_SINGAPORE"),
    TZ_TURKEY("TZ_TURKEY"),
    TZ_US_ALASKA("TZ_US_ALASKA"),
    TZ_US_ALEUTIAN("TZ_US_ALEUTIAN"),
    TZ_US_ARIZONA("TZ_US_ARIZONA"),
    TZ_US_CENTRAL("TZ_US_CENTRAL"),
    TZ_US_EAST_INDIANA("TZ_US_EAST_INDIANA"),
    TZ_US_EASTERN("TZ_US_EASTERN"),
    TZ_US_HAWAII("TZ_US_HAWAII"),
    TZ_US_INDIANA_STARKE("TZ_US_INDIANA_STARKE"),
    TZ_US_MICHIGAN("TZ_US_MICHIGAN"),
    TZ_US_MOUNTAIN("TZ_US_MOUNTAIN"),
    TZ_US_PACIFIC("TZ_US_PACIFIC"),
    TZ_US_PACIFIC_NEW("TZ_US_PACIFIC_NEW"),
    TZ_US_SAMOA("TZ_US_SAMOA"),
    TZ_UTC("TZ_UTC"),
    TZ_W_SU("TZ_W_SU"),
    TZ_WET("TZ_WET"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    TimeZoneTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TimeZoneTypeEnum fromValue(String v) {
        for (TimeZoneTypeEnum c: TimeZoneTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
