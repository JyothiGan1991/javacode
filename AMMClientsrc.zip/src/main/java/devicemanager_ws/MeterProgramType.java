
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterProgramType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterProgramType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MeterProgramID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="MeterProgramName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterProgramNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProgramSeal" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterProgramType", propOrder = {
    "meterProgramID",
    "meterProgramName",
    "meterProgramNotes",
    "programSeal"
})
public class MeterProgramType {

    @XmlElement(name = "MeterProgramID")
    protected long meterProgramID;
    @XmlElement(name = "MeterProgramName")
    protected String meterProgramName;
    @XmlElement(name = "MeterProgramNotes")
    protected String meterProgramNotes;
    @XmlElement(name = "ProgramSeal", required = true)
    protected String programSeal;

    /**
     * Gets the value of the meterProgramID property.
     * 
     */
    public long getMeterProgramID() {
        return meterProgramID;
    }

    /**
     * Sets the value of the meterProgramID property.
     * 
     */
    public void setMeterProgramID(long value) {
        this.meterProgramID = value;
    }

    /**
     * Gets the value of the meterProgramName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterProgramName() {
        return meterProgramName;
    }

    /**
     * Sets the value of the meterProgramName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterProgramName(String value) {
        this.meterProgramName = value;
    }

    /**
     * Gets the value of the meterProgramNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterProgramNotes() {
        return meterProgramNotes;
    }

    /**
     * Sets the value of the meterProgramNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterProgramNotes(String value) {
        this.meterProgramNotes = value;
    }

    /**
     * Gets the value of the programSeal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramSeal() {
        return programSeal;
    }

    /**
     * Sets the value of the programSeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramSeal(String value) {
        this.programSeal = value;
    }

}
