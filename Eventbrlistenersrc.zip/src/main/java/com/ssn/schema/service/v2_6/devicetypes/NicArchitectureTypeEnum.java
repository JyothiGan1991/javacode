
package com.ssn.schema.service.v2_6.devicetypes;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NicArchitectureTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="NicArchitectureTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NIC_HW_ARCH_UNKNOWN"/>
 *     &lt;enumeration value="NIC_HW_ARCH_ARM"/>
 *     &lt;enumeration value="NIC_HW_ARCH_AKIO"/>
 *     &lt;enumeration value="NIC_HW_ARCH_RNI"/>
 *     &lt;enumeration value="NIC_HW_ARCH_MILLI"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "NicArchitectureTypeEnum")
@XmlEnum
public enum NicArchitectureTypeEnum {

    NIC_HW_ARCH_UNKNOWN("NIC_HW_ARCH_UNKNOWN"),
    NIC_HW_ARCH_ARM("NIC_HW_ARCH_ARM"),
    NIC_HW_ARCH_AKIO("NIC_HW_ARCH_AKIO"),
    NIC_HW_ARCH_RNI("NIC_HW_ARCH_RNI"),
    NIC_HW_ARCH_MILLI("NIC_HW_ARCH_MILLI"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    NicArchitectureTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NicArchitectureTypeEnum fromValue(String v) {
        for (NicArchitectureTypeEnum c: NicArchitectureTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
