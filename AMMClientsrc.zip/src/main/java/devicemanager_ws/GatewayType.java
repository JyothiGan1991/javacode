
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GatewayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GatewayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RootPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocalSecret" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RemoteSecret" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ChapUsername" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocalChapPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RemoteChapPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IPV6Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetworkMask" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkMaskType"/&gt;
 *         &lt;element name="UiqIPAddress" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="UiqIPPort" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="UiqPhoneNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqPhoneNumSec" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayIPPort" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="GatewayIPAddress" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="GatewayIPV6WANAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayPhoneNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANHardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANSoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsSocketAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GatewayType", propOrder = {
    "rootPassword",
    "localSecret",
    "remoteSecret",
    "chapUsername",
    "localChapPassword",
    "remoteChapPassword",
    "ipv6Address",
    "networkMask",
    "uiqIPAddress",
    "uiqIPPort",
    "uiqPhoneNum",
    "uiqPhoneNumSec",
    "gatewayIPPort",
    "gatewayIPAddress",
    "gatewayIPV6WANAddress",
    "gatewayPhoneNum",
    "wanHardwareConfig",
    "wanSoftwareConfig",
    "isSocketAP"
})
@XmlSeeAlso({
    GetGatewayType.class
})
public class GatewayType {

    @XmlElement(name = "RootPassword")
    protected String rootPassword;
    @XmlElement(name = "LocalSecret")
    protected String localSecret;
    @XmlElement(name = "RemoteSecret")
    protected String remoteSecret;
    @XmlElement(name = "ChapUsername")
    protected String chapUsername;
    @XmlElement(name = "LocalChapPassword")
    protected String localChapPassword;
    @XmlElement(name = "RemoteChapPassword")
    protected String remoteChapPassword;
    @XmlElement(name = "IPV6Address")
    protected String ipv6Address;
    @XmlElement(name = "NetworkMask")
    protected int networkMask;
    @XmlElement(name = "UiqIPAddress", required = true)
    protected String uiqIPAddress;
    @XmlElement(name = "UiqIPPort")
    protected int uiqIPPort;
    @XmlElement(name = "UiqPhoneNum")
    protected String uiqPhoneNum;
    @XmlElement(name = "UiqPhoneNumSec")
    protected String uiqPhoneNumSec;
    @XmlElement(name = "GatewayIPPort")
    protected int gatewayIPPort;
    @XmlElement(name = "GatewayIPAddress", required = true)
    protected String gatewayIPAddress;
    @XmlElement(name = "GatewayIPV6WANAddress")
    protected String gatewayIPV6WANAddress;
    @XmlElement(name = "GatewayPhoneNum")
    protected String gatewayPhoneNum;
    @XmlElement(name = "WANHardwareConfig")
    protected String wanHardwareConfig;
    @XmlElement(name = "WANSoftwareConfig")
    protected String wanSoftwareConfig;
    @XmlElement(name = "IsSocketAP", defaultValue = "false")
    protected Boolean isSocketAP;

    /**
     * Gets the value of the rootPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRootPassword() {
        return rootPassword;
    }

    /**
     * Sets the value of the rootPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRootPassword(String value) {
        this.rootPassword = value;
    }

    /**
     * Gets the value of the localSecret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalSecret() {
        return localSecret;
    }

    /**
     * Sets the value of the localSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalSecret(String value) {
        this.localSecret = value;
    }

    /**
     * Gets the value of the remoteSecret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteSecret() {
        return remoteSecret;
    }

    /**
     * Sets the value of the remoteSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteSecret(String value) {
        this.remoteSecret = value;
    }

    /**
     * Gets the value of the chapUsername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChapUsername() {
        return chapUsername;
    }

    /**
     * Sets the value of the chapUsername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChapUsername(String value) {
        this.chapUsername = value;
    }

    /**
     * Gets the value of the localChapPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalChapPassword() {
        return localChapPassword;
    }

    /**
     * Sets the value of the localChapPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalChapPassword(String value) {
        this.localChapPassword = value;
    }

    /**
     * Gets the value of the remoteChapPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoteChapPassword() {
        return remoteChapPassword;
    }

    /**
     * Sets the value of the remoteChapPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoteChapPassword(String value) {
        this.remoteChapPassword = value;
    }

    /**
     * Gets the value of the ipv6Address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPV6Address() {
        return ipv6Address;
    }

    /**
     * Sets the value of the ipv6Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPV6Address(String value) {
        this.ipv6Address = value;
    }

    /**
     * Gets the value of the networkMask property.
     * 
     */
    public int getNetworkMask() {
        return networkMask;
    }

    /**
     * Sets the value of the networkMask property.
     * 
     */
    public void setNetworkMask(int value) {
        this.networkMask = value;
    }

    /**
     * Gets the value of the uiqIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqIPAddress() {
        return uiqIPAddress;
    }

    /**
     * Sets the value of the uiqIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqIPAddress(String value) {
        this.uiqIPAddress = value;
    }

    /**
     * Gets the value of the uiqIPPort property.
     * 
     */
    public int getUiqIPPort() {
        return uiqIPPort;
    }

    /**
     * Sets the value of the uiqIPPort property.
     * 
     */
    public void setUiqIPPort(int value) {
        this.uiqIPPort = value;
    }

    /**
     * Gets the value of the uiqPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqPhoneNum() {
        return uiqPhoneNum;
    }

    /**
     * Sets the value of the uiqPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqPhoneNum(String value) {
        this.uiqPhoneNum = value;
    }

    /**
     * Gets the value of the uiqPhoneNumSec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiqPhoneNumSec() {
        return uiqPhoneNumSec;
    }

    /**
     * Sets the value of the uiqPhoneNumSec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiqPhoneNumSec(String value) {
        this.uiqPhoneNumSec = value;
    }

    /**
     * Gets the value of the gatewayIPPort property.
     * 
     */
    public int getGatewayIPPort() {
        return gatewayIPPort;
    }

    /**
     * Sets the value of the gatewayIPPort property.
     * 
     */
    public void setGatewayIPPort(int value) {
        this.gatewayIPPort = value;
    }

    /**
     * Gets the value of the gatewayIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPAddress() {
        return gatewayIPAddress;
    }

    /**
     * Sets the value of the gatewayIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPAddress(String value) {
        this.gatewayIPAddress = value;
    }

    /**
     * Gets the value of the gatewayIPV6WANAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayIPV6WANAddress() {
        return gatewayIPV6WANAddress;
    }

    /**
     * Sets the value of the gatewayIPV6WANAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayIPV6WANAddress(String value) {
        this.gatewayIPV6WANAddress = value;
    }

    /**
     * Gets the value of the gatewayPhoneNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayPhoneNum() {
        return gatewayPhoneNum;
    }

    /**
     * Sets the value of the gatewayPhoneNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayPhoneNum(String value) {
        this.gatewayPhoneNum = value;
    }

    /**
     * Gets the value of the wanHardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANHardwareConfig() {
        return wanHardwareConfig;
    }

    /**
     * Sets the value of the wanHardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANHardwareConfig(String value) {
        this.wanHardwareConfig = value;
    }

    /**
     * Gets the value of the wanSoftwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANSoftwareConfig() {
        return wanSoftwareConfig;
    }

    /**
     * Sets the value of the wanSoftwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANSoftwareConfig(String value) {
        this.wanSoftwareConfig = value;
    }

    /**
     * Gets the value of the isSocketAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSocketAP() {
        return isSocketAP;
    }

    /**
     * Sets the value of the isSocketAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSocketAP(Boolean value) {
        this.isSocketAP = value;
    }

}
