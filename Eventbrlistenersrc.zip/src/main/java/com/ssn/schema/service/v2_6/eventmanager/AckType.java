
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.commonenumerations.AckTypeEnum;
import com.ssn.schema.service.v2_6.commonenumerations.OperatorEnumeration;


/**
 * <p>Java class for AckType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AckType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}AckTypeEnum"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operator" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}OperatorEnumeration" default="SQL_EQUAL_TO" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AckType", propOrder = {
    "name"
})
public class AckType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected AckTypeEnum name;
    @XmlAttribute(name = "Operator")
    protected OperatorEnumeration operator;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link AckTypeEnum }
     *     
     */
    public AckTypeEnum getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link AckTypeEnum }
     *     
     */
    public void setName(AckTypeEnum value) {
        this.name = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link OperatorEnumeration }
     *     
     */
    public OperatorEnumeration getOperator() {
        if (operator == null) {
            return OperatorEnumeration.SQL_EQUAL_TO;
        } else {
            return operator;
        }
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperatorEnumeration }
     *     
     */
    public void setOperator(OperatorEnumeration value) {
        this.operator = value;
    }

}
