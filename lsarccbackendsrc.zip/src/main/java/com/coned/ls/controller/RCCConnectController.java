package com.coned.ls.controller;

import java.util.ArrayList;
import java.util.List;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

import com.coned.ls.service.MeterEventService;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.utility.DateUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Controller to implement Rest Api's for RCC Connect.
 * 
 */
@RestController
@RequestMapping("/lsa-rcc-connect")
public class RCCConnectController {
	
	private static final Logger LOGGER = LogManager.getLogger(RCCConnectController.class);
	
	@Autowired
	private OpenEventService openEventService;
	
	@Autowired
	private MeterEventService meterEventService;

    /*
     * This API return list of borough if the value of parameter is boro or list of event names if the value 
     * is event_name for disconnected meters. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields  	Valid input for this parameter are boro and event_name. 
     * @return 				 	ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/meters")
	public ResponseEntity<List<String>> getBoroughAndEventName(@RequestParam(name = "fields") String fields) {
		LOGGER.info(String.format("Connect : Request for open event borough list"));
		
		if ((fields.equalsIgnoreCase("boro") || fields.equalsIgnoreCase("event_name"))) {
			return openEventService.getBoroughAndEventNameForConnect(fields);
		} else {
			throw new IllegalArgumentException("Invalid input parameter, Valid parameters are boro or event_name.");
		}		
	}

    /*
     * API to return list of event names for disconnected meters by borough.
     * 
     * @PathVariable borough 	Name of the borough. 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/meters/{borough}")
	public ResponseEntity<List<String>> getEventNameByBorough(@PathVariable(name = "borough") String borough) {
		LOGGER.info(String.format("Connect : Request for open event event list by borough"));
		
		return openEventService.getOpenEventForConnect(borough);
	}

    /*
     * API to return list of disconnected meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @RequestBody meterOpenEvent  MeterOpenEvent 
     * @return 						ResponseEntity<MeterEventResponseMapper>  
     *                         
     */
	@PostMapping("/events/meters")
	public ResponseEntity<MeterEventResponseMapper> getValidMetersForConnect(HttpServletRequest request, @RequestBody MeterOpenEvent meterOpenEvent) {
		LOGGER.info(String.format("Connect : Request for list of meters by borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));
		
		String adid = request.getHeader("adid");
		if (null == adid || adid.equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		
		if(null==meterOpenEvent || isEmptyOrNull(meterOpenEvent.getBorough()) || isEmptyOrNull(meterOpenEvent.getEventName())){
			MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();
			meterEventResponseMapper.setMessage("Invalid paramter passed");
			return ResponseEntity.status(701).body(meterEventResponseMapper);
		}
		
		int startRowIndex =  meterOpenEvent.getStartRowIndex() == 0 ? 1 : meterOpenEvent.getStartRowIndex();
		int batchSize =  meterOpenEvent.getBatchSize() == 0 ? 500 : meterOpenEvent.getBatchSize();
		
		meterOpenEvent.setBatchSize(batchSize);
		meterOpenEvent.setStartRowIndex(startRowIndex);
		meterOpenEvent.setAdid(adid);

		return meterEventService.getValidMetersForConnect(meterOpenEvent);
	}
	
    /*
     * API to return list of connected meters created for the event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * @RequestParam startRowIndex  int
     * @RequestParam batchSize  	int
     * @return 						ResponseEntity<MeterEventResponseMapper>  
     *                         
     */
	@PostMapping("/events/connected/meters")
	public ResponseEntity<MeterEventResponseMapper> getConnectdMeters(@RequestBody MeterOpenEvent meterOpenEvent) {
		LOGGER.info(String.format("Connect : Request for list of meters by borough : %s", meterOpenEvent.getBorough(), " eventName : %s", meterOpenEvent.getEventName()));

		if(null==meterOpenEvent || isEmptyOrNull(meterOpenEvent.getBorough()) || isEmptyOrNull(meterOpenEvent.getEventName())){
			MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();
			meterEventResponseMapper.setMessage("Invalid paramter passed");
			return ResponseEntity.status(701).body(meterEventResponseMapper);
		}
		
		int startRowIndex =  meterOpenEvent.getStartRowIndex() == 0 ? 1 : meterOpenEvent.getStartRowIndex();
		int batchSize =  meterOpenEvent.getBatchSize() == 0 ? 500 : meterOpenEvent.getBatchSize();
		
		meterOpenEvent.setBatchSize(batchSize);
		meterOpenEvent.setStartRowIndex(startRowIndex);
		
		System.out.println("MeterOpenEvent : "+meterOpenEvent.toString());
		
		return meterEventService.getConnectdMeters(meterOpenEvent);
	}

    /*
     * API to finalize the list of meters selected in the Sub Event for connect.
     * 
     * @RequestBody subEvent SubEvent
     * @return				 ResponseEntity<MeterFinalizeResponseMapper> 
     *                         
     */
	@PostMapping("/events/finalize/sub-event/meters")
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(HttpServletRequest request, @RequestBody SubEvent subEvent) throws Exception {
		LOGGER.info(String.format("Connect : Request to finalize Sub Event based on borough : %s and event %s", subEvent.getBorough(), subEvent.getEvent()));

		String borough = subEvent.getBorough();
		String event  = subEvent.getEvent();
		String subEventName = subEvent.getSubEventName();

		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			throw new IllegalArgumentException("No adid found in the request.");
		}
		
		if(borough != null && !borough.equals("") && event != null && !event.equals("") && null != subEventName && !subEventName.equals("")){
			LOGGER.info(String.format("Request for finalize sub meter event list based on borough : %s and event %s and sub event name %s", borough, event, subEventName));
			
			ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter = meterEventService.finalizeSubEventMeter(subEvent, adid);
			return ResponseEntity.status(finalizeSubEventMeter.getStatusCodeValue()).body(finalizeSubEventMeter.getBody());
		} else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper();
			 meterFinalizeResponseMapper.setMessage("Invalid paramter passed");
			 
			 return ResponseEntity.status(701).body(meterFinalizeResponseMapper);
		}
	}

    /*
     * API to return Suffix for Sub Event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * @RequestParam items			String
     * @return				 		ResponseEntity<Long>
     *                         
     */
	@GetMapping("/events/finalize/sub-event/suffix")
	public ResponseEntity<Long> getSubEventSuffix(@RequestParam(name = "borough") final String borough, @RequestParam(name = "eventName") final String eventName,@RequestParam(name = "items") final String items){
		LOGGER.info(String.format("Request for sub event prefix based on borough : %s and event %s and items is %s", borough, eventName, items));
		if(borough != null && !borough.equals("" ) && eventName != null && !eventName.equals("") && null!= items && !items.equals("")){
			return meterEventService.getSubEventSuffix(borough, eventName, items);
		} else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper(false);
			 meterFinalizeResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new Long(0));
		}	 
	}

    /*
     * This API return list of borough for Sub Event if the value of parameter is sub_boro or list of event names 
     * if the value is sub_event_name. IllegalArgumentException will be thrown for any other input values.
     * 
     * @RequestParam fields  	Valid input for this parameter are sub_boro and sub_event_name. 
     * @return 				 	ResponseEntity<List<String>>
     * 
     */
	@GetMapping("/events/open/sub-event/meters")
	public ResponseEntity<List<String>> getSubBoroughAndEventName(@RequestParam(name = "fields") String fields) {
		LOGGER.info(String.format("Connect : Request for sub open event borough list"));
		ResponseEntity<List<String>> response = null;

		if((fields.equalsIgnoreCase("sub_boro") || fields.equalsIgnoreCase("sub_event_name"))){
			if(fields.equalsIgnoreCase("sub_boro")){
				return openEventService.getSubFinalizeBorough(fields);
			}else{
				return openEventService.getSubFinalizeEvent(fields);
			}
		}else{
			 LOGGER.info(String.format("Connect : Exception occured throw IllegalArgumentException"));
			 throw new IllegalArgumentException();
		}
	}
	
    /*
     * API to return list of event names for Sub Event.
     * 
     * @PathVariable borough 	Name of the borough. 
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/sub-event/meters/{borough}")
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(@PathVariable(name = "borough") String borough) {
		LOGGER.info(String.format("Connect : Request for open event list by borough %s", borough));
		
		return openEventService.getSubEventNameBySubBorough(borough);
	}
	
    /*
     * API to return list of Sub Event names for the event.
     * 
     * @RequestParam borough 	String 
     * @RequestParam eventName 	String
     * @return 				   	ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/open/sub/sub-event/meters")
	public ResponseEntity<List<String>> getSubEventNameBySubBorough(@RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") String eventName) {
		LOGGER.info(String.format("Connect : Request fro Sub Event names by borough %s and event %s", borough, eventName));
		
		if(borough != null && !borough.equals("") && eventName != null && !eventName.equals("")){
			return openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName);
		}else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
			 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new ArrayList<String>());
		}
	}

    /*
     * API to return list of meters in the Sub Event.
     * 
     * @RequestParam borough 		String 
     * @RequestParam eventName 		String
     * @RequestParam subEventName	String
     * @RequestParam startRowIndex  int
     * @RequestParam batchSize  	int
     * @return 				   		ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/sub-event/meters")
	public ResponseEntity<MeterEventResponseMapper> getSubEventMeters(@RequestParam(name = "borough") final String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "subEventName") final String subEventName,@RequestParam(name = "startRowIndex")final int startRowIndex,@RequestParam(name = "batchSize") final int batchSize) {
		LOGGER.info(String.format("Connect : Request for validate meter event list based on borough : %s and event %s and pagesize is %s", borough, eventName, batchSize));
		
		MeterEventResponseMapper meterEventResponseMapper = new MeterEventResponseMapper();
		
		if( null!= borough && null != eventName && batchSize!=0 && startRowIndex!=0){
			meterEventResponseMapper = meterEventService.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize);
			System.out.println("meterEventResponseMapper : "+meterEventResponseMapper);
			 return ResponseEntity.status(HttpStatus.OK).body(meterEventResponseMapper);
		} else{
			meterEventResponseMapper.setMessage("Invalide input parameters");
			 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(meterEventResponseMapper);
		}
		
	}

    /*
     * API to search list of disconnected meters created for event.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@PostMapping("/events/search/meters")
	public ResponseEntity<MeterEventResponseMapper> searchMeter(@RequestBody MeterSearch meterSearch) throws Exception {
		LOGGER.info(String.format("Connect : Request for list of disconnected meters based on borough : %s and event %s", meterSearch.getBorough(), meterSearch.getEvent()));
		
		if(null != meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			return meterEventService.searchMeters(meterSearch);
		}else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
				 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new MeterEventResponseMapper());
		}
	}

    /*
     * API to return list of values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/meters/fields/{borough}")
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		LOGGER.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));
		
		if(null!=borough && null!=eventName && null!=fieldName){
			return meterEventService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		}else{
			throw new IllegalArgumentException("Invalid arguments are found in the request.");
		}
	}
	
    /*
     * API to return list of Connected Meters values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					ResponseEntity<List<String>>  
     *                         
     */
	@GetMapping("/events/connected/meters/fields/{borough}")
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(@PathVariable(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName, @RequestParam(name = "fieldName") final String fieldName){
		LOGGER.info(String.format("Request for list of values for meters field by borough : %s", borough, " eventName : %s", eventName, " fieldName : %s", fieldName));

		ResponseEntity<List<String>> fieldValues = meterEventService.getConnectedMetersFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		return fieldValues;
	}	
	
    /*
     * API to search list of connected meters created for event.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@PostMapping("/events/connected/search/meters")
	public ResponseEntity<MeterEventResponseMapper> searchMeterConnected(@RequestBody MeterSearch meterSearch) throws Exception {
		LOGGER.info(String.format("Connect : Request for list of connected meters based on borough : %s and event %s", meterSearch.getBorough(), meterSearch.getEvent()));
		
		if(null != meterSearch && null != meterSearch.getBorough() && !meterSearch.getBorough().equals("") && 
				null != meterSearch.getEvent() && !meterSearch.getEvent().equals("")){
			return meterEventService.searchMetersConnected(meterSearch);
		}else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
				 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new MeterEventResponseMapper());
		}
	}

    /*
     * API to create Sub Event.
     * 
     * @RequestBody subEvent SubEvent
     * @return				 ResponseEntity<MeterEventResponseMapper>
     *                         
     */
	@PostMapping("/events/sub-event/meters")
	public ResponseEntity<MeterEventResponseMapper> getSubEventMeters(@RequestBody SubEvent subEvent) throws Exception {
		LOGGER.info(String.format("Connect : Request for creating Sub Event by borough : %s", subEvent.getBorough(), " eventName : %s", subEvent.getEvent()));
		
		long processStartTime = DateUtils.processStartTime();
		System.out.println("subEvent.getPageNumber() : "+subEvent.getPageNumber());
		System.out.println("subEvent.getPageSize() : "+subEvent.getPageSize());
		
		if(null != subEvent && null != subEvent.getBorough() && !subEvent.getBorough().equals("") && 
				null != subEvent.getEvent() && !subEvent.getEvent().equals("")){
			ResponseEntity<MeterEventResponseMapper> subEventMeters = meterEventService.getSubEventMeters(subEvent);
			LOGGER.info(String.format("RCC - Sub event meter list response - %s Sec.", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
			return subEventMeters;
		}else{
			 LOGGER.error(String.format("Connect : Invalid paramter passed."));
				 
			 MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
			 meterConnectResponseMapper.setMessage("Invalid paramter passed");
			 return ResponseEntity.status(701).body(new MeterEventResponseMapper());
		}
	}

    /*
     * API to check event is locked.
     * 
     * @RequestBody subEvent SubEvent
     * @return				 ResponseEntity<MeterEventResponseMapper>
     *                         
     */
	@GetMapping("/events/status/meters")
	public MeterLockedStatusResponseMapper isEventLocked(HttpServletRequest request, @RequestParam(name = "borough") String borough, @RequestParam(name = "eventName") final String eventName){
		LOGGER.info(String.format("Request to check event is locked by borough : %s", borough, " eventName : %s", eventName));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		return meterEventService.isEventLocked(borough, eventName, adid);
	}
	
	public boolean isEmptyOrNull(String string){
		return (isNull(string) || isEmpty(string));
	}
	
	public boolean isNull(final String string){
		return (null==string);
	}
	
	public boolean isEmpty(final String string){
		return (string.trim().length()<=0);
	}

    /*
     * API to unlocked the events.
     * 
     * @RequestBody request HttpServletRequest
     * @return				void
     *                         
     */
	@PutMapping("/events/status/meters")
	public void unlockEvents(HttpServletRequest request) {
		LOGGER.info(String.format("Request to unlock the events for userid : %s", request.getHeader("adid")));
		
		String adid = request.getHeader("adid");
		if (null == request.getHeader("adid") || request.getHeader("adid").equals("")) {
			new IllegalArgumentException("No adid found in the request.");
		}
		
		meterEventService.unlockEvents(adid);
	}
}