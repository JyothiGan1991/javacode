package com.coned.AOCCWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AoccwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
