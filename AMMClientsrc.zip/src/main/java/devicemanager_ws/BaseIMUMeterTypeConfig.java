
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseIMUMeterTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseIMUMeterTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConfigName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MfgCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Pressure" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="TemperatureCompensated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RolloverPoint" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MechanismType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MechanismType" minOccurs="0"/&gt;
 *         &lt;element name="ServiceRate" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="ReportingUnits" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseIMUMeterTypeConfig", propOrder = {
    "configName",
    "mfgCode",
    "mfgName",
    "mfgModel",
    "pressure",
    "temperatureCompensated",
    "rolloverPoint",
    "mechanismType",
    "serviceRate",
    "reportingUnits"
})
@XmlSeeAlso({
    IMUMeterTypeConfig.class
})
public class BaseIMUMeterTypeConfig {

    @XmlElement(name = "ConfigName", required = true)
    protected String configName;
    @XmlElement(name = "MfgCode", required = true)
    protected String mfgCode;
    @XmlElement(name = "MfgName")
    protected String mfgName;
    @XmlElement(name = "MfgModel")
    protected String mfgModel;
    @XmlElement(name = "Pressure")
    protected Double pressure;
    @XmlElement(name = "TemperatureCompensated")
    protected Boolean temperatureCompensated;
    @XmlElement(name = "RolloverPoint")
    protected Integer rolloverPoint;
    @XmlElement(name = "MechanismType")
    protected MechanismType mechanismType;
    @XmlElement(name = "ServiceRate")
    protected MeterModeType serviceRate;
    @XmlElement(name = "ReportingUnits")
    protected String reportingUnits;

    /**
     * Gets the value of the configName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigName() {
        return configName;
    }

    /**
     * Sets the value of the configName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigName(String value) {
        this.configName = value;
    }

    /**
     * Gets the value of the mfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgCode() {
        return mfgCode;
    }

    /**
     * Sets the value of the mfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgCode(String value) {
        this.mfgCode = value;
    }

    /**
     * Gets the value of the mfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgName() {
        return mfgName;
    }

    /**
     * Sets the value of the mfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgName(String value) {
        this.mfgName = value;
    }

    /**
     * Gets the value of the mfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgModel() {
        return mfgModel;
    }

    /**
     * Sets the value of the mfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgModel(String value) {
        this.mfgModel = value;
    }

    /**
     * Gets the value of the pressure property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPressure() {
        return pressure;
    }

    /**
     * Sets the value of the pressure property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPressure(Double value) {
        this.pressure = value;
    }

    /**
     * Gets the value of the temperatureCompensated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTemperatureCompensated() {
        return temperatureCompensated;
    }

    /**
     * Sets the value of the temperatureCompensated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTemperatureCompensated(Boolean value) {
        this.temperatureCompensated = value;
    }

    /**
     * Gets the value of the rolloverPoint property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRolloverPoint() {
        return rolloverPoint;
    }

    /**
     * Sets the value of the rolloverPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRolloverPoint(Integer value) {
        this.rolloverPoint = value;
    }

    /**
     * Gets the value of the mechanismType property.
     * 
     * @return
     *     possible object is
     *     {@link MechanismType }
     *     
     */
    public MechanismType getMechanismType() {
        return mechanismType;
    }

    /**
     * Sets the value of the mechanismType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MechanismType }
     *     
     */
    public void setMechanismType(MechanismType value) {
        this.mechanismType = value;
    }

    /**
     * Gets the value of the serviceRate property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getServiceRate() {
        return serviceRate;
    }

    /**
     * Sets the value of the serviceRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setServiceRate(MeterModeType value) {
        this.serviceRate = value;
    }

    /**
     * Gets the value of the reportingUnits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportingUnits() {
        return reportingUnits;
    }

    /**
     * Sets the value of the reportingUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportingUnits(String value) {
        this.reportingUnits = value;
    }

}
