
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MismatchedProgramType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MismatchedProgramType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MeterProgramFromMeter" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MeterProgramType"/&gt;
 *         &lt;element name="MeterProgramInUIQ" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MeterProgramType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MismatchedProgramType", propOrder = {
    "meterProgramFromMeter",
    "meterProgramInUIQ"
})
public class MismatchedProgramType {

    @XmlElement(name = "MeterProgramFromMeter", required = true)
    protected MeterProgramType meterProgramFromMeter;
    @XmlElement(name = "MeterProgramInUIQ", required = true)
    protected MeterProgramType meterProgramInUIQ;

    /**
     * Gets the value of the meterProgramFromMeter property.
     * 
     * @return
     *     possible object is
     *     {@link MeterProgramType }
     *     
     */
    public MeterProgramType getMeterProgramFromMeter() {
        return meterProgramFromMeter;
    }

    /**
     * Sets the value of the meterProgramFromMeter property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterProgramType }
     *     
     */
    public void setMeterProgramFromMeter(MeterProgramType value) {
        this.meterProgramFromMeter = value;
    }

    /**
     * Gets the value of the meterProgramInUIQ property.
     * 
     * @return
     *     possible object is
     *     {@link MeterProgramType }
     *     
     */
    public MeterProgramType getMeterProgramInUIQ() {
        return meterProgramInUIQ;
    }

    /**
     * Sets the value of the meterProgramInUIQ property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterProgramType }
     *     
     */
    public void setMeterProgramInUIQ(MeterProgramType value) {
        this.meterProgramInUIQ = value;
    }

}
