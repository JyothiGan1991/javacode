package com.coned.um.controller;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class LoginRequest {
	@NotNull(message = "Please enter username")
	@Size(max = 20)
	private String userName;

	@NotNull(message = "Please enter password")
	@Size(max = 120)
	private String password;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
