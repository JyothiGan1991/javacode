
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindLocationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindLocationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UtilPremiseID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DefinedLocationType" minOccurs="0"/&gt;
 *         &lt;element name="DescLong" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DescShort" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationRouteID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CountryID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RegionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CrossStreet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="TBPageNum" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TBCoordID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocLongitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="LocLatitude" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="LocHeight" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="LocGISMapCoords" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocGISGridCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocGISGridCoords" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocExtUrl" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *         &lt;element name="DistNetwork" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DistNetworkType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePoint" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindServicePtType" minOccurs="0"/&gt;
 *         &lt;element name="Proximity" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindByProximityType" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SecondaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TertiaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocationAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindLocationType", propOrder = {
    "utilPremiseID",
    "locationType",
    "descLong",
    "descShort",
    "locationRouteID",
    "address1",
    "address2",
    "city",
    "state",
    "postalCode",
    "countryID",
    "regionCode",
    "crossStreet",
    "timeZoneID",
    "tbPageNum",
    "tbCoordID",
    "locLongitude",
    "locLatitude",
    "locHeight",
    "locGISMapCoords",
    "locGISGridCode",
    "locGISGridCoords",
    "locExtUrl",
    "distNetwork",
    "servicePoint",
    "proximity",
    "primaryLoadCtrlGroup",
    "secondaryLoadCtrlGroup",
    "tertiaryLoadCtrlGroup",
    "locationAttribute1",
    "locationAttribute2",
    "locationAttribute3",
    "locationAttribute4",
    "locationAttribute5"
})
@XmlSeeAlso({
    FindLocationExtType.class
})
public class FindLocationType {

    @XmlElement(name = "UtilPremiseID")
    protected String utilPremiseID;
    @XmlElement(name = "LocationType")
    protected DefinedLocationType locationType;
    @XmlElement(name = "DescLong")
    protected String descLong;
    @XmlElement(name = "DescShort")
    protected String descShort;
    @XmlElement(name = "LocationRouteID")
    protected String locationRouteID;
    @XmlElement(name = "Address1")
    protected String address1;
    @XmlElement(name = "Address2")
    protected String address2;
    @XmlElement(name = "City")
    protected String city;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "PostalCode")
    protected String postalCode;
    @XmlElement(name = "CountryID")
    protected Integer countryID;
    @XmlElement(name = "RegionCode")
    protected String regionCode;
    @XmlElement(name = "CrossStreet")
    protected String crossStreet;
    @XmlElement(name = "TimeZoneID")
    protected TimeZoneType timeZoneID;
    @XmlElement(name = "TBPageNum")
    protected Integer tbPageNum;
    @XmlElement(name = "TBCoordID")
    protected String tbCoordID;
    @XmlElement(name = "LocLongitude")
    protected Double locLongitude;
    @XmlElement(name = "LocLatitude")
    protected Double locLatitude;
    @XmlElement(name = "LocHeight")
    protected Double locHeight;
    @XmlElement(name = "LocGISMapCoords")
    protected String locGISMapCoords;
    @XmlElement(name = "LocGISGridCode")
    protected String locGISGridCode;
    @XmlElement(name = "LocGISGridCoords")
    protected String locGISGridCoords;
    @XmlElement(name = "LocExtUrl")
    @XmlSchemaType(name = "anyURI")
    protected String locExtUrl;
    @XmlElement(name = "DistNetwork")
    protected DistNetworkType distNetwork;
    @XmlElement(name = "ServicePoint")
    protected FindServicePtType servicePoint;
    @XmlElement(name = "Proximity")
    protected FindByProximityType proximity;
    @XmlElement(name = "PrimaryLoadCtrlGroup")
    protected String primaryLoadCtrlGroup;
    @XmlElement(name = "SecondaryLoadCtrlGroup")
    protected String secondaryLoadCtrlGroup;
    @XmlElement(name = "TertiaryLoadCtrlGroup")
    protected String tertiaryLoadCtrlGroup;
    @XmlElement(name = "LocationAttribute1")
    protected String locationAttribute1;
    @XmlElement(name = "LocationAttribute2")
    protected String locationAttribute2;
    @XmlElement(name = "LocationAttribute3")
    protected String locationAttribute3;
    @XmlElement(name = "LocationAttribute4")
    protected String locationAttribute4;
    @XmlElement(name = "LocationAttribute5")
    protected String locationAttribute5;

    /**
     * Gets the value of the utilPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilPremiseID() {
        return utilPremiseID;
    }

    /**
     * Sets the value of the utilPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilPremiseID(String value) {
        this.utilPremiseID = value;
    }

    /**
     * Gets the value of the locationType property.
     * 
     * @return
     *     possible object is
     *     {@link DefinedLocationType }
     *     
     */
    public DefinedLocationType getLocationType() {
        return locationType;
    }

    /**
     * Sets the value of the locationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DefinedLocationType }
     *     
     */
    public void setLocationType(DefinedLocationType value) {
        this.locationType = value;
    }

    /**
     * Gets the value of the descLong property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescLong() {
        return descLong;
    }

    /**
     * Sets the value of the descLong property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescLong(String value) {
        this.descLong = value;
    }

    /**
     * Gets the value of the descShort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescShort() {
        return descShort;
    }

    /**
     * Sets the value of the descShort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescShort(String value) {
        this.descShort = value;
    }

    /**
     * Gets the value of the locationRouteID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationRouteID() {
        return locationRouteID;
    }

    /**
     * Sets the value of the locationRouteID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationRouteID(String value) {
        this.locationRouteID = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the countryID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCountryID() {
        return countryID;
    }

    /**
     * Sets the value of the countryID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCountryID(Integer value) {
        this.countryID = value;
    }

    /**
     * Gets the value of the regionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * Sets the value of the regionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegionCode(String value) {
        this.regionCode = value;
    }

    /**
     * Gets the value of the crossStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCrossStreet() {
        return crossStreet;
    }

    /**
     * Sets the value of the crossStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCrossStreet(String value) {
        this.crossStreet = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setTimeZoneID(TimeZoneType value) {
        this.timeZoneID = value;
    }

    /**
     * Gets the value of the tbPageNum property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTBPageNum() {
        return tbPageNum;
    }

    /**
     * Sets the value of the tbPageNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTBPageNum(Integer value) {
        this.tbPageNum = value;
    }

    /**
     * Gets the value of the tbCoordID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTBCoordID() {
        return tbCoordID;
    }

    /**
     * Sets the value of the tbCoordID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTBCoordID(String value) {
        this.tbCoordID = value;
    }

    /**
     * Gets the value of the locLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocLongitude() {
        return locLongitude;
    }

    /**
     * Sets the value of the locLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocLongitude(Double value) {
        this.locLongitude = value;
    }

    /**
     * Gets the value of the locLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocLatitude() {
        return locLatitude;
    }

    /**
     * Sets the value of the locLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocLatitude(Double value) {
        this.locLatitude = value;
    }

    /**
     * Gets the value of the locHeight property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLocHeight() {
        return locHeight;
    }

    /**
     * Sets the value of the locHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLocHeight(Double value) {
        this.locHeight = value;
    }

    /**
     * Gets the value of the locGISMapCoords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocGISMapCoords() {
        return locGISMapCoords;
    }

    /**
     * Sets the value of the locGISMapCoords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocGISMapCoords(String value) {
        this.locGISMapCoords = value;
    }

    /**
     * Gets the value of the locGISGridCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocGISGridCode() {
        return locGISGridCode;
    }

    /**
     * Sets the value of the locGISGridCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocGISGridCode(String value) {
        this.locGISGridCode = value;
    }

    /**
     * Gets the value of the locGISGridCoords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocGISGridCoords() {
        return locGISGridCoords;
    }

    /**
     * Sets the value of the locGISGridCoords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocGISGridCoords(String value) {
        this.locGISGridCoords = value;
    }

    /**
     * Gets the value of the locExtUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocExtUrl() {
        return locExtUrl;
    }

    /**
     * Sets the value of the locExtUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocExtUrl(String value) {
        this.locExtUrl = value;
    }

    /**
     * Gets the value of the distNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link DistNetworkType }
     *     
     */
    public DistNetworkType getDistNetwork() {
        return distNetwork;
    }

    /**
     * Sets the value of the distNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistNetworkType }
     *     
     */
    public void setDistNetwork(DistNetworkType value) {
        this.distNetwork = value;
    }

    /**
     * Gets the value of the servicePoint property.
     * 
     * @return
     *     possible object is
     *     {@link FindServicePtType }
     *     
     */
    public FindServicePtType getServicePoint() {
        return servicePoint;
    }

    /**
     * Sets the value of the servicePoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindServicePtType }
     *     
     */
    public void setServicePoint(FindServicePtType value) {
        this.servicePoint = value;
    }

    /**
     * Gets the value of the proximity property.
     * 
     * @return
     *     possible object is
     *     {@link FindByProximityType }
     *     
     */
    public FindByProximityType getProximity() {
        return proximity;
    }

    /**
     * Sets the value of the proximity property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindByProximityType }
     *     
     */
    public void setProximity(FindByProximityType value) {
        this.proximity = value;
    }

    /**
     * Gets the value of the primaryLoadCtrlGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryLoadCtrlGroup() {
        return primaryLoadCtrlGroup;
    }

    /**
     * Sets the value of the primaryLoadCtrlGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryLoadCtrlGroup(String value) {
        this.primaryLoadCtrlGroup = value;
    }

    /**
     * Gets the value of the secondaryLoadCtrlGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondaryLoadCtrlGroup() {
        return secondaryLoadCtrlGroup;
    }

    /**
     * Sets the value of the secondaryLoadCtrlGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondaryLoadCtrlGroup(String value) {
        this.secondaryLoadCtrlGroup = value;
    }

    /**
     * Gets the value of the tertiaryLoadCtrlGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTertiaryLoadCtrlGroup() {
        return tertiaryLoadCtrlGroup;
    }

    /**
     * Sets the value of the tertiaryLoadCtrlGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTertiaryLoadCtrlGroup(String value) {
        this.tertiaryLoadCtrlGroup = value;
    }

    /**
     * Gets the value of the locationAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationAttribute1() {
        return locationAttribute1;
    }

    /**
     * Sets the value of the locationAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationAttribute1(String value) {
        this.locationAttribute1 = value;
    }

    /**
     * Gets the value of the locationAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationAttribute2() {
        return locationAttribute2;
    }

    /**
     * Sets the value of the locationAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationAttribute2(String value) {
        this.locationAttribute2 = value;
    }

    /**
     * Gets the value of the locationAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationAttribute3() {
        return locationAttribute3;
    }

    /**
     * Sets the value of the locationAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationAttribute3(String value) {
        this.locationAttribute3 = value;
    }

    /**
     * Gets the value of the locationAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationAttribute4() {
        return locationAttribute4;
    }

    /**
     * Sets the value of the locationAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationAttribute4(String value) {
        this.locationAttribute4 = value;
    }

    /**
     * Gets the value of the locationAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationAttribute5() {
        return locationAttribute5;
    }

    /**
     * Sets the value of the locationAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationAttribute5(String value) {
        this.locationAttribute5 = value;
    }

}
