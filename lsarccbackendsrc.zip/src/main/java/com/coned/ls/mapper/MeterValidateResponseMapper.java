package com.coned.ls.mapper;

import java.util.List;

import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterEventLoad;

/**
 * 
 * Class to return response for valid event requests.
 *
 */
public class MeterValidateResponseMapper {

	private List<MeterEventLoad> meterEventLoads;
	private List<MeterEventLoadIdAndDemand> meterEventLoadIds;
	private int pageNumber;
	private int pageSize;
	private int totalRecord;
	private String recordOffsetRange;
	private String insertTime;
	private String borough;
	private String eventName;
	private String network;
	private int remainingRow; 
	private int totalValidRecord;
	private boolean isValidResponse; 
	private boolean isEventLocked;
	private boolean isEventFinalized;
	private String message;
	private String totalKVA;
	private int countOfMeters;

	public List<MeterEventLoadIdAndDemand> getMeterEventLoadIds() {
		return meterEventLoadIds;
	}
	public void setMeterEventLoadIds(List<MeterEventLoadIdAndDemand> meterEventLoadIds) {
		this.meterEventLoadIds = meterEventLoadIds;
	}
	public int getTotalValidRecord() {
		return totalValidRecord;
	}
	public void setTotalValidRecord(int totalValidRecord) {
		this.totalValidRecord = totalValidRecord;
	}
	public int getRemainingRow() {
		return remainingRow;
	}
	public void setRemainingRow(int remainingRow) {
		this.remainingRow = remainingRow;
	}
	public List<MeterEventLoad> getMeterEventLoads() {
		return meterEventLoads;
	}
	public void setMeterEventLoads(List<MeterEventLoad> meterEventLoads) {
		this.meterEventLoads = meterEventLoads;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}
	public String getRecordOffsetRange() {
		return recordOffsetRange;
	}
	public void setRecordOffsetRange(String recordOffsetRange) {
		this.recordOffsetRange = recordOffsetRange;
	}
	public String getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(String insertTime) {
		this.insertTime = insertTime;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isValidResponse() {
		return isValidResponse;
	}
	public void setValidResponse(boolean isValidResponse) {
		this.isValidResponse = isValidResponse;
	}
	public String getTotalKVA() {
		return totalKVA;
	}
	public void setTotalKVA(String totalKVA) {
		this.totalKVA = totalKVA;
	}
	public boolean getIsEventLocked() {
		return isEventLocked;
	}
	public void setIsEventLocked(boolean isEventLocked) {
		this.isEventLocked = isEventLocked;
	}
	public boolean getIsEventFinalized() {
		return isEventFinalized;
	}
	public void setIsEventFinalized(boolean isEventFinalized) {
		this.isEventFinalized = isEventFinalized;
	}
	public int getCountOfMeters() {
		return countOfMeters;
	}
	public void setCountOfMeters(int countOfMeters) {
		this.countOfMeters = countOfMeters;
	}
	public MeterValidateResponseMapper(String message) {
		super();
		this.message = message;
	}
	public MeterValidateResponseMapper() {
		super();
	}
	
	
}
