
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BillingCycleNum" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BillingCycleOffsetInDays" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="Hour" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}ZeroToTwentyThreeInt" minOccurs="0"/&gt;
 *         &lt;element name="Minute" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}ZeroToFiftyNineInt" minOccurs="0"/&gt;
 *         &lt;element name="Second" type="{urn:com:ssn:schema:service:v2.5:BasicTypes.xsd}ZeroToFiftyNineInt" minOccurs="0"/&gt;
 *         &lt;element name="StartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="UseReadDateInsteadOfBillingDate" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillingType", propOrder = {
    "billingCycleNum",
    "billingCycleOffsetInDays",
    "hour",
    "minute",
    "second",
    "startDate",
    "endDate"
})
public class BillingType {

    @XmlElement(name = "BillingCycleNum", required = true)
    protected String billingCycleNum;
    @XmlElement(name = "BillingCycleOffsetInDays")
    protected Integer billingCycleOffsetInDays;
    @XmlElement(name = "Hour")
    protected Integer hour;
    @XmlElement(name = "Minute")
    protected Integer minute;
    @XmlElement(name = "Second")
    protected Integer second;
    @XmlElement(name = "StartDate")
    protected String startDate;
    @XmlElement(name = "EndDate")
    protected String endDate;
    @XmlAttribute(name = "UseReadDateInsteadOfBillingDate")
    protected Boolean useReadDateInsteadOfBillingDate;

    /**
     * Gets the value of the billingCycleNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingCycleNum() {
        return billingCycleNum;
    }

    /**
     * Sets the value of the billingCycleNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingCycleNum(String value) {
        this.billingCycleNum = value;
    }

    /**
     * Gets the value of the billingCycleOffsetInDays property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBillingCycleOffsetInDays() {
        return billingCycleOffsetInDays;
    }

    /**
     * Sets the value of the billingCycleOffsetInDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBillingCycleOffsetInDays(Integer value) {
        this.billingCycleOffsetInDays = value;
    }

    /**
     * Gets the value of the hour property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHour() {
        return hour;
    }

    /**
     * Sets the value of the hour property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHour(Integer value) {
        this.hour = value;
    }

    /**
     * Gets the value of the minute property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMinute() {
        return minute;
    }

    /**
     * Sets the value of the minute property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMinute(Integer value) {
        this.minute = value;
    }

    /**
     * Gets the value of the second property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSecond() {
        return second;
    }

    /**
     * Sets the value of the second property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSecond(Integer value) {
        this.second = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(String value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(String value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the useReadDateInsteadOfBillingDate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isUseReadDateInsteadOfBillingDate() {
        if (useReadDateInsteadOfBillingDate == null) {
            return false;
        } else {
            return useReadDateInsteadOfBillingDate;
        }
    }

    /**
     * Sets the value of the useReadDateInsteadOfBillingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUseReadDateInsteadOfBillingDate(Boolean value) {
        this.useReadDateInsteadOfBillingDate = value;
    }

}
