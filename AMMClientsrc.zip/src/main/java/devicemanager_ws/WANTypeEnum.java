
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WANTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WANTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_POTS"/&gt;
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_CDMA_WIRELESS"/&gt;
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_CDMA_PACKET"/&gt;
 *     &lt;enumeration value="GATEWAY_WAN_TYPE_ETHERNET"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "WANTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd")
@XmlEnum
public enum WANTypeEnum {

    GATEWAY_WAN_TYPE_POTS("GATEWAY_WAN_TYPE_POTS"),
    GATEWAY_WAN_TYPE_CDMA_WIRELESS("GATEWAY_WAN_TYPE_CDMA_WIRELESS"),
    GATEWAY_WAN_TYPE_CDMA_PACKET("GATEWAY_WAN_TYPE_CDMA_PACKET"),
    GATEWAY_WAN_TYPE_ETHERNET("GATEWAY_WAN_TYPE_ETHERNET"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    WANTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WANTypeEnum fromValue(String v) {
        for (WANTypeEnum c: WANTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
