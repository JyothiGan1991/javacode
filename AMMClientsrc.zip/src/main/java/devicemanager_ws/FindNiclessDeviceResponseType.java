
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindNiclessDeviceResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindNiclessDeviceResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchResponse" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindNiclessDeviceResponse" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="NetworkInfrastructureDevices" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindNetworkInfrastructureDeviceType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SearchKey" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="RowCount" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="ExceededMaximumNumberOfRows" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindNiclessDeviceResponseType", propOrder = {
    "searchResponse",
    "networkInfrastructureDevices"
})
public class FindNiclessDeviceResponseType {

    @XmlElement(name = "SearchResponse")
    protected List<FindNiclessDeviceResponse> searchResponse;
    @XmlElement(name = "NetworkInfrastructureDevices")
    protected List<FindNetworkInfrastructureDeviceType> networkInfrastructureDevices;
    @XmlAttribute(name = "SearchKey", required = true)
    protected long searchKey;
    @XmlAttribute(name = "RowCount", required = true)
    protected long rowCount;
    @XmlAttribute(name = "ExceededMaximumNumberOfRows")
    protected Boolean exceededMaximumNumberOfRows;

    /**
     * Gets the value of the searchResponse property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the searchResponse property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSearchResponse().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FindNiclessDeviceResponse }
     * 
     * 
     */
    public List<FindNiclessDeviceResponse> getSearchResponse() {
        if (searchResponse == null) {
            searchResponse = new ArrayList<FindNiclessDeviceResponse>();
        }
        return this.searchResponse;
    }

    /**
     * Gets the value of the networkInfrastructureDevices property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the networkInfrastructureDevices property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNetworkInfrastructureDevices().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FindNetworkInfrastructureDeviceType }
     * 
     * 
     */
    public List<FindNetworkInfrastructureDeviceType> getNetworkInfrastructureDevices() {
        if (networkInfrastructureDevices == null) {
            networkInfrastructureDevices = new ArrayList<FindNetworkInfrastructureDeviceType>();
        }
        return this.networkInfrastructureDevices;
    }

    /**
     * Gets the value of the searchKey property.
     * 
     */
    public long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     */
    public void setSearchKey(long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     */
    public long getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     */
    public void setRowCount(long value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the exceededMaximumNumberOfRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isExceededMaximumNumberOfRows() {
        if (exceededMaximumNumberOfRows == null) {
            return false;
        } else {
            return exceededMaximumNumberOfRows;
        }
    }

    /**
     * Sets the value of the exceededMaximumNumberOfRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExceededMaximumNumberOfRows(Boolean value) {
        this.exceededMaximumNumberOfRows = value;
    }

}
