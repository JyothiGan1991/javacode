package com.coned.exception;

import java.util.Date;

public class ExceptionResponse {
	  private String result;
	  private String status;
//	  private Date timestamp;
	  private String message;	  

	  public ExceptionResponse(String result, String status, String message) {
	    super();
	    this.result = result;
	    this.status = status;	    
//	    this.timestamp = timestamp;
	    this.message = message;
	  }

		/*
		 * public Date getTimestamp() { return timestamp; }
		 */

	  public String getMessage() {
	    return message;
	  }

	  public String getStatus() {
	    return status;
	  }

	  public String getResult() {
		    return result;
	  }
	}