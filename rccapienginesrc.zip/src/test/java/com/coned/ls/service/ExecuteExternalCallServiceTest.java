/*package com.coned.ls.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.ExecuteExternalCall;
import com.coned.ls.exception.ExternalCallException;
import com.coned.ls.mapper.ExternalCallResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class ExecuteExternalCallServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@Mock
	private ExecuteExternalCallService executeExternalCallService = new ExecuteExternalCallServiceImpl();
	
	private ExecuteExternalCallService executeExternalCallServiceRestTemplet = new ExecuteExternalCallServiceImpl();
	
	private MockMvc mockMvc;
	
	ExternalCallResponseMapper  externalCallResponseMapper = new ExternalCallResponseMapper();
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		externalCallResponseMapper.setSuccess(true);
		externalCallResponseMapper.setMessage("Disconnect request registered successfully.");
	}
	@Test
	public void excuteDisconnect_Success() throws ExternalCallException{
		ExecuteExternalCall executeExternalCall = new ExecuteExternalCall();
		executeExternalCall.setBorough("A");
		executeExternalCall.setEventName("SheepsheadBaySampleData7.27.20-1703");
		Mockito.when(executeExternalCallService.excuteDisconnect(executeExternalCall)).thenReturn(externalCallResponseMapper);
		ExternalCallResponseMapper excuteDisconnect = executeExternalCallService.excuteDisconnect(executeExternalCall);
		Assert.assertEquals(excuteDisconnect.getMessage(), externalCallResponseMapper.getMessage());
	}
	
	@Test
	public void excuteDisconnect_Failure() throws ExternalCallException{
		ExecuteExternalCall executeExternalCall = new ExecuteExternalCall();
		executeExternalCall.setBorough("A");
		executeExternalCall.setEventName("SheepsheadBaySampleData7.27.20-1703");
		externalCallResponseMapper.setSuccess(false);
		externalCallResponseMapper.setMessage("Error registering the Disconnect request.");
		Mockito.when(executeExternalCallService.excuteDisconnect(executeExternalCall)).thenReturn(externalCallResponseMapper);
		ExternalCallResponseMapper excuteDisconnect = executeExternalCallService.excuteDisconnect(executeExternalCall);
		Assert.assertEquals(excuteDisconnect.getMessage(), externalCallResponseMapper.getMessage());
	}
	
	@Test
	public void excuteDisconnect_RestCall() throws ExternalCallException{
		ExecuteExternalCall executeExternalCall = new ExecuteExternalCall();
		executeExternalCall.setBorough("A");
		executeExternalCall.setEventName("SheepsheadBaySampleData7.27.20-1703");
		ExternalCallResponseMapper excuteDisconnect = executeExternalCallServiceRestTemplet.excuteDisconnect(executeExternalCall);
		Assert.assertEquals(excuteDisconnect.getMessage(), externalCallResponseMapper.getMessage());
	}
}
*/