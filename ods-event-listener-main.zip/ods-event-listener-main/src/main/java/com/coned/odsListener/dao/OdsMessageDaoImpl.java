/**
 * 
 */
package com.coned.odsListener.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.coned.odsListener.model.ODSEvent;

/**
 * @author DATHATHRIA
 *
 */
@Repository
@PropertySource(value = { "classpath:queries.properties" })
public class OdsMessageDaoImpl implements OdsMessageDao {
	private static Logger logger = LoggerFactory.getLogger(OdsMessageDaoImpl.class);
	
	/**
	 * The oracle data source. */
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Environment env;
	
	/**
	 * Gets the data source.
	 *
	 * @return the data source
	 */
	public DataSource getDataSource() {
		return dataSource;
	}

	/**
	 * Sets the data source.
	 *
	 * @param dataSource
	 *            the new data source
	 */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;		
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * Gets the jdbc template.
	 *
	 * @return the jdbc template
	 */
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	@Override
	public void persistOdsMessage(List<ODSEvent> listOfOdsEvents) {
		long startTime = System.nanoTime();
		logger.info("Persisting data in DB: " + listOfOdsEvents.size());
		
		if (listOfOdsEvents.size() > 0) {
			int[] rows = jdbcTemplate.batchUpdate(env.getProperty("INSERT_QUERY"), new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, listOfOdsEvents.get(i).getDeviceUtilId());
					ps.setString(2, listOfOdsEvents.get(i).getEventType());
					ps.setString(3, listOfOdsEvents.get(i).getDeviceType());
					ps.setString(4, listOfOdsEvents.get(i).getMacId());
					ps.setString(5, listOfOdsEvents.get(i).getMacAddress());
					ps.setString(6, listOfOdsEvents.get(i).getRegionCode());
					ps.setString(7, listOfOdsEvents.get(i).getReason());
					ps.setString(8, listOfOdsEvents.get(i).getServicePointId());
					ps.setString(9, listOfOdsEvents.get(i).getRebootCounter());
					ps.setInt(10, listOfOdsEvents.get(i).getIsStatusDateTimeEstimated());
					ps.setString(11, listOfOdsEvents.get(i).getEndDeviceEventTypeRef());
					ps.setTimestamp(12, new Timestamp(listOfOdsEvents.get(i).getEventTime().toGregorianCalendar().getTimeInMillis()));
				}

				@Override
				public int getBatchSize() {
					return listOfOdsEvents.size();
				}

			});
			logger.info("Successfully inserted [" + rows.length
					+ "] records of ODS Events from the list of size [" + listOfOdsEvents.size()
					+ "].");
		}
		
		long endTime = System.nanoTime();
		long durationInMillis = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
		logger.info("Time taken to save the message in DB in milliseconds is: " + durationInMillis);
	}

}
