
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeviceTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="DID_TYPE_GATEWAY"/>
 *     &lt;enumeration value="DID_TYPE_RELAY"/>
 *     &lt;enumeration value="DID_TYPE_METER"/>
 *     &lt;enumeration value="DID_TYPE_GAS"/>
 *     &lt;enumeration value="DID_TYPE_WATER"/>
 *     &lt;enumeration value="DID_TYPE_BRIDGE"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DeviceTypeEnum")
@XmlEnum
public enum DeviceTypeEnum {

    DID_TYPE_GATEWAY("DID_TYPE_GATEWAY"),
    DID_TYPE_RELAY("DID_TYPE_RELAY"),
    DID_TYPE_METER("DID_TYPE_METER"),
    DID_TYPE_GAS("DID_TYPE_GAS"),
    DID_TYPE_WATER("DID_TYPE_WATER"),
    DID_TYPE_BRIDGE("DID_TYPE_BRIDGE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    DeviceTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeviceTypeEnum fromValue(String v) {
        for (DeviceTypeEnum c: DeviceTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
