package com.coned.ls.mapper;

/**
 * 
 * Class to return response for finalized events.
 *
 */
public class MeterFinalizeResponseMapper {

	private String message;
	private boolean result;
	
	public MeterFinalizeResponseMapper(boolean result) {
		super();
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	
	public MeterFinalizeResponseMapper(String message, boolean result) {
		super();
		this.message = message;
		this.result = result;
	}
	public MeterFinalizeResponseMapper() {
		super();
	}
	
	
}
