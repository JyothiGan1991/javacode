
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetDeviceResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetDeviceResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetDeviceType" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="Meter" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetMeterType" minOccurs="0"/&gt;
 *           &lt;element name="Relay" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetRelayType" minOccurs="0"/&gt;
 *           &lt;element name="Gateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetGatewayType" minOccurs="0"/&gt;
 *           &lt;element name="WaterModule" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetIMUType" minOccurs="0"/&gt;
 *           &lt;element name="IMU" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetIMUType" minOccurs="0"/&gt;
 *           &lt;element name="Bridge" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetBridgeType" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetLocationType" minOccurs="0"/&gt;
 *         &lt;element name="LocAddnlInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetLocationAddnlInfoType" minOccurs="0"/&gt;
 *         &lt;element name="Route" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RouteType" minOccurs="0"/&gt;
 *         &lt;element name="Alarms" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AlarmsType" minOccurs="0"/&gt;
 *         &lt;element name="DeviceCapabilities" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceCapabilitiesType" minOccurs="0"/&gt;
 *         &lt;element name="NetworkInfrastructureDevices" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureDevicesType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetDeviceResponseType", propOrder = {
    "commonAttributes",
    "meter",
    "relay",
    "gateway",
    "waterModule",
    "imu",
    "bridge",
    "location",
    "locAddnlInfo",
    "route",
    "alarms",
    "deviceCapabilities",
    "networkInfrastructureDevices"
})
public class GetDeviceResponseType {

    @XmlElement(name = "CommonAttributes")
    protected GetDeviceType commonAttributes;
    @XmlElement(name = "Meter")
    protected GetMeterType meter;
    @XmlElement(name = "Relay")
    protected GetRelayType relay;
    @XmlElement(name = "Gateway")
    protected GetGatewayType gateway;
    @XmlElement(name = "WaterModule")
    protected GetIMUType waterModule;
    @XmlElement(name = "IMU")
    protected GetIMUType imu;
    @XmlElement(name = "Bridge")
    protected GetBridgeType bridge;
    @XmlElement(name = "Location")
    protected GetLocationType location;
    @XmlElement(name = "LocAddnlInfo")
    protected GetLocationAddnlInfoType locAddnlInfo;
    @XmlElement(name = "Route")
    protected RouteType route;
    @XmlElement(name = "Alarms")
    protected AlarmsType alarms;
    @XmlElement(name = "DeviceCapabilities")
    protected DeviceCapabilitiesType deviceCapabilities;
    @XmlElement(name = "NetworkInfrastructureDevices")
    protected NetworkInfrastructureDevicesType networkInfrastructureDevices;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link GetDeviceType }
     *     
     */
    public GetDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetDeviceType }
     *     
     */
    public void setCommonAttributes(GetDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the meter property.
     * 
     * @return
     *     possible object is
     *     {@link GetMeterType }
     *     
     */
    public GetMeterType getMeter() {
        return meter;
    }

    /**
     * Sets the value of the meter property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetMeterType }
     *     
     */
    public void setMeter(GetMeterType value) {
        this.meter = value;
    }

    /**
     * Gets the value of the relay property.
     * 
     * @return
     *     possible object is
     *     {@link GetRelayType }
     *     
     */
    public GetRelayType getRelay() {
        return relay;
    }

    /**
     * Sets the value of the relay property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetRelayType }
     *     
     */
    public void setRelay(GetRelayType value) {
        this.relay = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link GetGatewayType }
     *     
     */
    public GetGatewayType getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetGatewayType }
     *     
     */
    public void setGateway(GetGatewayType value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the waterModule property.
     * 
     * @return
     *     possible object is
     *     {@link GetIMUType }
     *     
     */
    public GetIMUType getWaterModule() {
        return waterModule;
    }

    /**
     * Sets the value of the waterModule property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetIMUType }
     *     
     */
    public void setWaterModule(GetIMUType value) {
        this.waterModule = value;
    }

    /**
     * Gets the value of the imu property.
     * 
     * @return
     *     possible object is
     *     {@link GetIMUType }
     *     
     */
    public GetIMUType getIMU() {
        return imu;
    }

    /**
     * Sets the value of the imu property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetIMUType }
     *     
     */
    public void setIMU(GetIMUType value) {
        this.imu = value;
    }

    /**
     * Gets the value of the bridge property.
     * 
     * @return
     *     possible object is
     *     {@link GetBridgeType }
     *     
     */
    public GetBridgeType getBridge() {
        return bridge;
    }

    /**
     * Sets the value of the bridge property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetBridgeType }
     *     
     */
    public void setBridge(GetBridgeType value) {
        this.bridge = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link GetLocationType }
     *     
     */
    public GetLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLocationType }
     *     
     */
    public void setLocation(GetLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the locAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link GetLocationAddnlInfoType }
     *     
     */
    public GetLocationAddnlInfoType getLocAddnlInfo() {
        return locAddnlInfo;
    }

    /**
     * Sets the value of the locAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLocationAddnlInfoType }
     *     
     */
    public void setLocAddnlInfo(GetLocationAddnlInfoType value) {
        this.locAddnlInfo = value;
    }

    /**
     * Gets the value of the route property.
     * 
     * @return
     *     possible object is
     *     {@link RouteType }
     *     
     */
    public RouteType getRoute() {
        return route;
    }

    /**
     * Sets the value of the route property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteType }
     *     
     */
    public void setRoute(RouteType value) {
        this.route = value;
    }

    /**
     * Gets the value of the alarms property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmsType }
     *     
     */
    public AlarmsType getAlarms() {
        return alarms;
    }

    /**
     * Sets the value of the alarms property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmsType }
     *     
     */
    public void setAlarms(AlarmsType value) {
        this.alarms = value;
    }

    /**
     * Gets the value of the deviceCapabilities property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceCapabilitiesType }
     *     
     */
    public DeviceCapabilitiesType getDeviceCapabilities() {
        return deviceCapabilities;
    }

    /**
     * Sets the value of the deviceCapabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceCapabilitiesType }
     *     
     */
    public void setDeviceCapabilities(DeviceCapabilitiesType value) {
        this.deviceCapabilities = value;
    }

    /**
     * Gets the value of the networkInfrastructureDevices property.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfrastructureDevicesType }
     *     
     */
    public NetworkInfrastructureDevicesType getNetworkInfrastructureDevices() {
        return networkInfrastructureDevices;
    }

    /**
     * Sets the value of the networkInfrastructureDevices property.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfrastructureDevicesType }
     *     
     */
    public void setNetworkInfrastructureDevices(NetworkInfrastructureDevicesType value) {
        this.networkInfrastructureDevices = value;
    }

}
