package com.oru.rest.dto;

public class IntegerResponse {
    private int result;
    public IntegerResponse() {}
    public IntegerResponse(int result) { this.result = result; }
    public int getResult() { return result; }
    public void setResult(int result) { this.result = result; }
}
