package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//import org.aspectj.lang.JoinPoint;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventService;
import com.coned.ls.service.OpenEventService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RCCConnectControllerTest {


	@InjectMocks
	final RestTemplate testTemplate = new RestTemplate();

	RCCConnectController rccConnectController;

	@Mock
	private OpenEventService openEventService;

	@Mock
	private MeterEventService meterEventService;

	List<MeterEventLoad> meterEventLoads = new ArrayList<>();
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();

	@Before
	public void setup() throws Exception {
		rccConnectController = new RCCConnectController();
		System.out.println("@Before annotation method is being called ....");
		ReflectionTestUtils.setField(rccConnectController, "openEventService", openEventService);
		ReflectionTestUtils.setField(rccConnectController, "meterEventService", meterEventService);

		String borough = "B";
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoad);

		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
		
	}

	@Test
	public void getBoroughName() throws Exception {
		
		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),HttpStatus.OK);
		String fields = "boro";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());

	}

	@Test(expected = IllegalArgumentException.class)
	public void getInvalidBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}

	@Test
	public void getEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();

		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK); 

		String fields = "event_name";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}


	@Test
	public void getEventNameByBorough() throws Exception {
		List<String> expectedEventNameList = new ArrayList<String>();

		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String borough = "M";
		Mockito.when(openEventService.getOpenEvent(borough)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccConnectController.getEventNameByBorough(borough);
		Assert.assertEquals("Null", "Null");
	}
	

	@Test
	public void getValidateMeterForConnect() throws Exception {
		MeterEventResponseMapper merp = new MeterEventResponseMapper();

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);

		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 50;
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		
		merp.setPageNumber(20);
		merp.setPageSize(1);
		merp.setTotalRecord(2);
		merp.setRecordOffsetRange("abcd");
		// merp.setInsertTime(date);
		merp.setBorough("M");
		merp.setEventName("QRST");
		merp.setNetwork("GHIJ");
		merp.setValidResponse(true);
		merp.setMessage("abcdef");

		ResponseEntity<MeterEventResponseMapper> meterEventResponseMapper = new ResponseEntity<MeterEventResponseMapper>(
				merp, HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);

		Mockito.when(meterEventService.getValidMetersForConnect(meterOpenEvent)).thenReturn(meterEventResponseMapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		
		ResponseEntity<MeterEventResponseMapper> actual = rccConnectController.getValidMetersForConnect(request,meterOpenEvent);
		Assert.assertEquals(meterEventResponseMapper.getBody().getBorough(), actual.getBody().getBorough());
	}
	


	@Test(expected=AssertionError.class)
	public void getInvalidValidateMeterForConnect() throws Exception {
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		merp.setPageNumber(20);
		merp.setPageSize(1);
		merp.setTotalRecord(2);
		merp.setRecordOffsetRange("abcd");
		// merp.setInsertTime(date);
		merp.setBorough("M");
		merp.setEventName("QRST");
		merp.setNetwork("GHIJ");
		merp.setValidResponse(true);
		merp.setMessage("abcdef");
		ResponseEntity<MeterEventResponseMapper> meterEventResponseMapper = new ResponseEntity<MeterEventResponseMapper>(merp, HttpStatus.OK);
		Mockito.when(meterEventService.getValidMetersForConnect(new MeterOpenEvent())).thenReturn(meterEventResponseMapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "null");
		ResponseEntity<MeterEventResponseMapper> actual = rccConnectController.getValidMetersForConnect(request, new MeterOpenEvent());
		Assert.assertEquals(meterEventResponseMapper.getBody().getBorough(), actual.getBody().getBorough());
	}
	@Test
	public void getConnectdMetersTest() {
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("B");
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(merp,
				HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough("B");
		meterOpenEvent.setEventName("Ridgewood.09.10/11/20-09:27:18.AUTO");
		meterOpenEvent.setStartRowIndex(10);
		meterOpenEvent.setBatchSize(50);
		
		Mockito.when(meterEventService.getConnectdMeters(meterOpenEvent))
				.thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> result = rccConnectController.getConnectdMeters(meterOpenEvent);
		Assert.assertEquals(mockData.getBody().getBorough(), result.getBody().getBorough());
	}

	
	//@Test(expected=AssertionError.class)
	@Test
	public void getInvalidConnectdMetersTest() {
		MeterEventResponseMapper merp = new MeterEventResponseMapper();
		merp.setBorough("B");
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(merp,HttpStatus.OK);
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		
		meterOpenEvent.setBorough("null");
		meterOpenEvent.setEventName("null");
		meterOpenEvent.setStartRowIndex(0);
		meterOpenEvent.setBatchSize(0);
		
		Mockito.when(meterEventService.getConnectdMeters(meterOpenEvent)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> result = rccConnectController.getConnectdMeters(meterOpenEvent);
		Assert.assertEquals(mockData.getBody().getBorough(), result.getBody().getBorough());
	}
	@Test
	public void finalizeSubEventMeter() throws Exception {
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		SubEvent subEvent = new SubEvent();
		merp.setMessage("SUCCESS");
		subEvent.setBorough("B");
		subEvent.setEvent("Ridgewood.09.10/11/20-09:27:18.AUTO");
		subEvent.setSubEventName("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<MeterFinalizeResponseMapper> mockData = new ResponseEntity<MeterFinalizeResponseMapper>(merp,HttpStatus.OK);
		Mockito.when(meterEventService.finalizeSubEventMeter(subEvent,"Test")).thenReturn(mockData);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "Test");
		ResponseEntity<MeterFinalizeResponseMapper> result = rccConnectController.finalizeSubEventMeter(request,subEvent);
		Assert.assertEquals(mockData.getBody(), result.getBody());

	}

	@Test(expected=AssertionError.class)
	public void InvalidfinalizeSubEventMeter() throws Exception {
		MeterFinalizeResponseMapper merp = new MeterFinalizeResponseMapper();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		SubEvent subEvent = new SubEvent();
		merp.setMessage("");
		subEvent.setBorough(null);
		subEvent.setEvent(null);
		subEvent.setSubEventName(null);
		ResponseEntity<MeterFinalizeResponseMapper> mockData = new ResponseEntity<MeterFinalizeResponseMapper>(merp,HttpStatus.OK);
		Mockito.when(meterEventService.finalizeSubEventMeter(subEvent,"Test")).thenReturn(mockData);
		ResponseEntity<MeterFinalizeResponseMapper> result = rccConnectController.finalizeSubEventMeter(request,subEvent);
		Assert.assertEquals(mockData.getBody(), result.getBody());
	}
	@Test
	public void getSubEventSuffix() throws Exception {

		String borough = "B";
		String eventName = "Flatbush.23.11/08/20-23:24:06.KUMARM";
		String items = "Suffix";
		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(meterEventService.getSubEventSuffix(borough, eventName, items)).thenReturn(mockData);
		ResponseEntity<Long> response = rccConnectController.getSubEventSuffix(borough, eventName, items);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());

	}
	
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidSubEventSuffix() throws Exception {
		Long value = new Long(11);
		ResponseEntity<Long> mockData = new ResponseEntity<Long>(value, HttpStatus.OK);
		Mockito.when(meterEventService.getSubEventSuffix(null,null,null)).thenReturn(mockData);
		ResponseEntity<Long> response = rccConnectController.getSubEventSuffix(null,null,null);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}

	@Test
	public void getSubBoroughAndEventName() throws Exception {
		String fields = "sub_boro";
		List<String> expectedBoroughList = new ArrayList<String>();
		expectedBoroughList.add("M");
		expectedBoroughList.add("Q");
		expectedBoroughList.add("X");
		expectedBoroughList.add("B");
		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedBoroughList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeBorough(fields)).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}
	
	@Test
	public void getSubBoroughAndEventNameTest() throws Exception {
		String fields = "sub_event_name";
		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedEventNameList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEvent(fields)).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidSubBoroughAndEventName() throws Exception {
		String fields = "test";
		List<String> expectedEventNameList = new ArrayList<String>();
		ResponseEntity<List<String>> mockData = new ResponseEntity<List<String>>(expectedEventNameList, HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeBorough(fields)).thenReturn(mockData);
		ResponseEntity<List<String>> response = rccConnectController.getSubBoroughAndEventName(fields);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}

	@Test
	public void getSubEventNameBySubBorough() throws Exception {
		String borough = "M";
		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);
		Mockito.when(openEventService.getSubEventNameBySubBorough(borough)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());
	}

   @Test
	public void getSubEventNameBySubBoroughTest() throws Exception {
	   String borough = "M";
	   String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		List<String> expectedEventNameList = new ArrayList<String>();
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough, eventName);
		Assert.assertEquals(result.getBody(), response.getBody());
	}
   
   @Test
	public void getInvalidSubEventNameBySubBoroughTest() throws Exception {
	   String borough = null;
	   String eventName = null;
		List<String> expectedEventNameList = new ArrayList<String>();
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(openEventService.getSubFinalizeEventByEventAndBorough(borough, eventName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getSubEventNameBySubBorough(borough, eventName);
		Assert.assertEquals(result.getBody(), response.getBody());
	}
	@Test
	public void getSubEventMeters() throws Exception {

		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String subEventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 50;

		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockdata = new ResponseEntity<MeterEventResponseMapper>(mapper,
				HttpStatus.OK);
		Mockito.when(meterEventService.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize))
				.thenReturn(mapper);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.getSubEventMeters(borough, eventName,
				subEventName, startRowIndex, batchSize);
		Assert.assertEquals(mockdata.getStatusCode(), response.getStatusCode());
	}
	
	
	@Test
	public void getInvalidSubEventMeters() throws Exception {

		String borough = null;
		String eventName = null;
		String subEventName = null;
		int startRowIndex = 0;
		int batchSize = 0;
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockdata = new ResponseEntity<MeterEventResponseMapper>(mapper,
				HttpStatus.BAD_REQUEST);
		Mockito.when(meterEventService.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize))
				.thenReturn(mapper);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.getSubEventMeters(borough, eventName,
				subEventName, startRowIndex, batchSize);
		Assert.assertEquals(mockdata.getStatusCode(), response.getStatusCode());
	}


	@Test
	public void searchMeter() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("Flatbush.23.11/08/20-23:24:06");
		meterSearch.setMeters("009445720");
		meterSearch.setSubEvent("Zone00323");
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();

		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,
				HttpStatus.OK);
		Mockito.when(meterEventService.searchMeters(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.searchMeter(meterSearch);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=AssertionError.class)
	public void InvalidsearchMeter() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		meterSearch.setMeters(null);
		meterSearch.setSubEvent(null);
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventService.searchMeters(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.searchMeter(meterSearch);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}
	@Test
	public void getFieldValuesByBoroughAndEventNameTest() throws Exception {
		List<String> expectedEventNameList = new ArrayList<String>();
		//MeterSearch meterSearch = new MeterSearch();
		String borough = "M";
		String eventName = "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String fieldName = "fieldName";
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(meterEventService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void getInvalidFieldValuesByBoroughAndEventNameTest() throws Exception {
		List<String> expectedEventNameList = new ArrayList<String>();
		MeterSearch meterSearch = new MeterSearch();
		String borough = null;
		String eventName = null;
		String fieldName = null;
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),HttpStatus.OK);
		Mockito.when(meterEventService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName)).thenReturn(result);
		ResponseEntity<List<String>> response = rccConnectController.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertEquals(result.getStatusCode(), response.getStatusCode());
	}

	@Test
	public void getSubEventMetersTest() throws Exception {

		SubEvent subEvent = new SubEvent();
		subEvent.setBorough("B");
		subEvent.setEvent("Flatbush.23.11/08/20-23:24:06");
		subEvent.setMeters("009445720");
		subEvent.setSubEventName("Zone00323");
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventService.getSubEventMeters(subEvent)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.getSubEventMeters(subEvent);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=AssertionError.class)
	public void getInvalidSubEventMetersTest() throws Exception {
		SubEvent subEvent = new SubEvent();
		subEvent.setBorough(null);
		subEvent.setEvent(null);
		subEvent.setMeters(null);
		subEvent.setSubEventName(null);
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventService.getSubEventMeters(subEvent)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.getSubEventMeters(subEvent);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}

	@Test
	public void searchMeterConnected() throws Exception {

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("B");
		meterSearch.setEvent("Flatbush.23.11/08/20-23:24:06");
		meterSearch.setMeters("009445720");
		meterSearch.setSubEvent("Zone00323");
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
        ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventService.searchMetersConnected(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.searchMeterConnected(meterSearch);
		Assert.assertEquals(mockData.getStatusCode(), response.getStatusCode());
	}
	
	@Test(expected=AssertionError.class)
	public void InvalidsearchMeterConnected() throws Exception {
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		meterSearch.setMeters(null);
		meterSearch.setSubEvent(null);
		MeterEventResponseMapper mapper = new MeterEventResponseMapper();
		ResponseEntity<MeterEventResponseMapper> mockData = new ResponseEntity<MeterEventResponseMapper>(mapper,HttpStatus.OK);
		Mockito.when(meterEventService.searchMetersConnected(meterSearch)).thenReturn(mockData);
		ResponseEntity<MeterEventResponseMapper> response = rccConnectController.searchMeterConnected(meterSearch);
		Assert.assertEquals(mockData.getBody(), response.getBody());
	}
	@Test
    public void isEventLocked(){
    	MeterLockedStatusResponseMapper mlsp = new MeterLockedStatusResponseMapper();
    	MockHttpServletRequest request = new MockHttpServletRequest();
    	request.addHeader("adid", "BUDIDHAK");
		Mockito.when(meterEventService.isEventLocked("B","SheepsheadBaySampleData7.27.20-1300","BUDIDHAK")).thenReturn((mlsp));
		MeterLockedStatusResponseMapper response = rccConnectController.isEventLocked(request,"B","SheepsheadBaySampleData7.27.20-1300");
		Assert.assertEquals(mlsp,response);
}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventService).unlockEvents(adid);
	    //assertEquals(0, rccConnectController.unlockEvents(request));
		rccConnectController.unlockEvents(request);
	}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents2(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "");
		String adid = "";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventService).unlockEvents(adid);
	    //assertEquals(0, rccConnectController.unlockEvents(request));
		rccConnectController.unlockEvents(request);
	}
}