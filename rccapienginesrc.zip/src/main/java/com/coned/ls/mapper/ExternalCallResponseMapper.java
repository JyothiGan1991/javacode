package com.coned.ls.mapper;

public class ExternalCallResponseMapper {

	private String message;
	private boolean isSuccess;
	private String borough;
	private String eventName;
	
	
	
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	
	public ExternalCallResponseMapper() {
		super();
	}
	public ExternalCallResponseMapper(String message, boolean isSuccess) {
		super();
		this.message = message;
		this.isSuccess = isSuccess;
	}
	
	
}
