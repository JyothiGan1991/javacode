
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.commonenumerations.OperatorEnumeration;
import com.ssn.schema.service.v2_6.commonenumerations.UIQDeviceStateTypeEnum;


/**
 * <p>Java class for UIQDeviceStateType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UIQDeviceStateType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}UIQDeviceStateTypeEnum"/>
 *         &lt;element name="LocalizedValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operator" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}OperatorEnumeration" default="SQL_EQUAL_TO" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UIQDeviceStateType", propOrder = {
    "name",
    "localizedValue"
})
public class UIQDeviceStateType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected UIQDeviceStateTypeEnum name;
    @XmlElement(name = "LocalizedValue")
    protected String localizedValue;
    @XmlAttribute(name = "Operator")
    protected OperatorEnumeration operator;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateTypeEnum }
     *     
     */
    public UIQDeviceStateTypeEnum getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateTypeEnum }
     *     
     */
    public void setName(UIQDeviceStateTypeEnum value) {
        this.name = value;
    }

    /**
     * Gets the value of the localizedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedValue() {
        return localizedValue;
    }

    /**
     * Sets the value of the localizedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedValue(String value) {
        this.localizedValue = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link OperatorEnumeration }
     *     
     */
    public OperatorEnumeration getOperator() {
        if (operator == null) {
            return OperatorEnumeration.SQL_EQUAL_TO;
        } else {
            return operator;
        }
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperatorEnumeration }
     *     
     */
    public void setOperator(OperatorEnumeration value) {
        this.operator = value;
    }

}
