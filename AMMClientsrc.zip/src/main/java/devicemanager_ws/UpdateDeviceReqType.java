
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateDeviceReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateDeviceReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateNetworkBaseDeviceType"/&gt;
 *         &lt;element name="DeviceAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateBaseDeviceType" minOccurs="0"/&gt;
 *         &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLocationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateDeviceReqType", propOrder = {
    "commonAttributes",
    "deviceAttributes",
    "location"
})
public class UpdateDeviceReqType {

    @XmlElement(name = "CommonAttributes", required = true)
    protected UpdateNetworkBaseDeviceType commonAttributes;
    @XmlElement(name = "DeviceAttributes")
    protected UpdateBaseDeviceType deviceAttributes;
    @XmlElement(name = "Location")
    protected NullableLocationType location;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateNetworkBaseDeviceType }
     *     
     */
    public UpdateNetworkBaseDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateNetworkBaseDeviceType }
     *     
     */
    public void setCommonAttributes(UpdateNetworkBaseDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the deviceAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateBaseDeviceType }
     *     
     */
    public UpdateBaseDeviceType getDeviceAttributes() {
        return deviceAttributes;
    }

    /**
     * Sets the value of the deviceAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateBaseDeviceType }
     *     
     */
    public void setDeviceAttributes(UpdateBaseDeviceType value) {
        this.deviceAttributes = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLocationType }
     *     
     */
    public NullableLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLocationType }
     *     
     */
    public void setLocation(NullableLocationType value) {
        this.location = value;
    }

}
