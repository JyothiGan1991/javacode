
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExportSubTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExportSubTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ADVANCED_METER"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_EVENT"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DEVICE"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_POWER_QUALITY"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ARB_METER_CMD"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_GENERIC"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DMD_RESET_FAILS"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_PREVIOUS_SEASON"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ExportSubTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum ExportSubTypeEnumeration {

    JOB_OP_EXPORT_ADVANCED_METER("JOB_OP_EXPORT_ADVANCED_METER"),
    JOB_OP_EXPORT_EVENT("JOB_OP_EXPORT_EVENT"),
    JOB_OP_EXPORT_DEVICE("JOB_OP_EXPORT_DEVICE"),
    JOB_OP_EXPORT_POWER_QUALITY("JOB_OP_EXPORT_POWER_QUALITY"),
    JOB_OP_EXPORT_ARB_METER_CMD("JOB_OP_EXPORT_ARB_METER_CMD"),
    JOB_OP_EXPORT_GENERIC("JOB_OP_EXPORT_GENERIC"),
    JOB_OP_EXPORT_DMD_RESET_FAILS("JOB_OP_EXPORT_DMD_RESET_FAILS"),
    JOB_OP_EXPORT_PREVIOUS_SEASON("JOB_OP_EXPORT_PREVIOUS_SEASON"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ExportSubTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ExportSubTypeEnumeration fromValue(String v) {
        for (ExportSubTypeEnumeration c: ExportSubTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
