
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningErrorStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RemoteProvisioningErrorStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="RMT_PROV_STS_COMM_ERROR"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_SWITCH_CTRL_ERROR"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_FAILED_OPEN"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_FAILED_CLOSE"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_ALT_SOURCE"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_BYPASSED"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_COMMAND_PENDING"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_OUTAGE_OPEN"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_PPM_ALERT"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_PPM_DISCONNECT"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_DLP_DISCONNECT"/&gt;
 *     &lt;enumeration value="MRS_SECURITY_RATE_LIMIT_EXCEED"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_NIC_RD_DENIED"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_CONF_FOR_ARM"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_AUTODISC_ENABLED"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_CONNECT_PENDING"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_DISC_PENDING"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_CONN"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_MSG_BUTT"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_WAIT_SCC_DISC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_ESCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_WT_ESCC_DISC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_LOAD_CHK_AUTO_DIS"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_ARM_MODE"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_WAIT_SCC_CONNECT"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_WAIT_ESCC_CONNECT"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_NET_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_NET_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_TOU_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_DISC_TOU_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_POWER_UP_DIV"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_UNKNOWN"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_NOT_AVAILABLE"/&gt;
 *     &lt;enumeration value="RMT_PROV_MD_INVALID"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1L2_SAMEASMAIN"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_BOOST"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_RMT_OVR"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_RUN_RMT_OVR"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_CONTACTOR_TEST"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_STOD"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_RUNNING_STOD"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_POWER_UP"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_UNDER_FREQ"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_LD_CYC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_RUN_LD_CYC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_WT_SCC_CON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_WT_ESCC_CON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_DISC_NET_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_DISC_NET_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_DISC_TOU_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_DISC_TOU_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_POWER_UP_DIV"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1MD_DEMAND_LIMIT"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_BOOST"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_RMT_OVR"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_RUN_RMT_OVR"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_CONTACTOR_TEST"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_STOD"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_RUNNING_STOD"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_POWER_UP"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_UNDER_FREQ"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_LD_CYCLE"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_RUN_LD_CYC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_DEMAND_LIMIT"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_WT_SCC_CON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_WT_ESCC_CON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_DISC_NET_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_DISC_NET_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_DISC_TOU_IMP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_DISC_TOU_EXP_SCC"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2MD_POWER_UP_DIV"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL1_UNKNOWN"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL1_NOT_AVLBL"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL1_INVALID"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL2_UNKNOWN"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL2_NOT_AVLBL"/&gt;
 *     &lt;enumeration value="RMT_PROV_MDL2_INVALID"/&gt;
 *     &lt;enumeration value="RMT_PROV_STS_DIAGNOSTIC_FLAG"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1_CONNECT_DIV_ON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L1_DISCONNECT_DIV_ON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2_CONNECT_DIV_ON"/&gt;
 *     &lt;enumeration value="RMT_PROV_L2_DISCONNECT_DIV_ON"/&gt;
 *     &lt;enumeration value="RMT_PROV_INCOMPLETE_EXTERNAL"/&gt;
 *     &lt;enumeration value="RMT_PROV_INCOMPLETE_INTERNAL"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RemoteProvisioningErrorStatusEnumeration")
@XmlEnum
public enum RemoteProvisioningErrorStatusEnumeration {

    RMT_PROV_STS_COMM_ERROR("RMT_PROV_STS_COMM_ERROR"),
    RMT_PROV_STS_SWITCH_CTRL_ERROR("RMT_PROV_STS_SWITCH_CTRL_ERROR"),
    RMT_PROV_STS_FAILED_OPEN("RMT_PROV_STS_FAILED_OPEN"),
    RMT_PROV_STS_FAILED_CLOSE("RMT_PROV_STS_FAILED_CLOSE"),
    RMT_PROV_STS_ALT_SOURCE("RMT_PROV_STS_ALT_SOURCE"),
    RMT_PROV_STS_BYPASSED("RMT_PROV_STS_BYPASSED"),
    RMT_PROV_STS_COMMAND_PENDING("RMT_PROV_STS_COMMAND_PENDING"),
    RMT_PROV_STS_OUTAGE_OPEN("RMT_PROV_STS_OUTAGE_OPEN"),
    RMT_PROV_STS_PPM_ALERT("RMT_PROV_STS_PPM_ALERT"),
    RMT_PROV_STS_PPM_DISCONNECT("RMT_PROV_STS_PPM_DISCONNECT"),
    RMT_PROV_STS_DLP_DISCONNECT("RMT_PROV_STS_DLP_DISCONNECT"),
    MRS_SECURITY_RATE_LIMIT_EXCEED("MRS_SECURITY_RATE_LIMIT_EXCEED"),
    RMT_PROV_STS_NIC_RD_DENIED("RMT_PROV_STS_NIC_RD_DENIED"),
    RMT_PROV_STS_CONF_FOR_ARM("RMT_PROV_STS_CONF_FOR_ARM"),
    RMT_PROV_STS_AUTODISC_ENABLED("RMT_PROV_STS_AUTODISC_ENABLED"),
    RMT_PROV_STS_CONNECT_PENDING("RMT_PROV_STS_CONNECT_PENDING"),
    RMT_PROV_STS_DISC_PENDING("RMT_PROV_STS_DISC_PENDING"),
    RMT_PROV_MD_CONN("RMT_PROV_MD_CONN"),
    RMT_PROV_MD_DISC_MSG_BUTT("RMT_PROV_MD_DISC_MSG_BUTT"),
    RMT_PROV_MD_DISC_SCC("RMT_PROV_MD_DISC_SCC"),
    RMT_PROV_MD_WAIT_SCC_DISC("RMT_PROV_MD_WAIT_SCC_DISC"),
    RMT_PROV_MD_DISC_ESCC("RMT_PROV_MD_DISC_ESCC"),
    RMT_PROV_MD_WT_ESCC_DISC("RMT_PROV_MD_WT_ESCC_DISC"),
    RMT_PROV_MD_LOAD_CHK_AUTO_DIS("RMT_PROV_MD_LOAD_CHK_AUTO_DIS"),
    RMT_PROV_MD_ARM_MODE("RMT_PROV_MD_ARM_MODE"),
    RMT_PROV_MD_WAIT_SCC_CONNECT("RMT_PROV_MD_WAIT_SCC_CONNECT"),
    RMT_PROV_MD_WAIT_ESCC_CONNECT("RMT_PROV_MD_WAIT_ESCC_CONNECT"),
    RMT_PROV_MD_DISC_NET_IMP_SCC("RMT_PROV_MD_DISC_NET_IMP_SCC"),
    RMT_PROV_MD_DISC_NET_EXP_SCC("RMT_PROV_MD_DISC_NET_EXP_SCC"),
    RMT_PROV_MD_DISC_TOU_IMP_SCC("RMT_PROV_MD_DISC_TOU_IMP_SCC"),
    RMT_PROV_MD_DISC_TOU_EXP_SCC("RMT_PROV_MD_DISC_TOU_EXP_SCC"),
    RMT_PROV_MD_POWER_UP_DIV("RMT_PROV_MD_POWER_UP_DIV"),
    RMT_PROV_MD_UNKNOWN("RMT_PROV_MD_UNKNOWN"),
    RMT_PROV_MD_NOT_AVAILABLE("RMT_PROV_MD_NOT_AVAILABLE"),
    RMT_PROV_MD_INVALID("RMT_PROV_MD_INVALID"),
    @XmlEnumValue("RMT_PROV_L1L2_SAMEASMAIN")
    RMT_PROV_L_1_L_2_SAMEASMAIN("RMT_PROV_L1L2_SAMEASMAIN"),
    @XmlEnumValue("RMT_PROV_L1MD_BOOST")
    RMT_PROV_L_1_MD_BOOST("RMT_PROV_L1MD_BOOST"),
    @XmlEnumValue("RMT_PROV_L1MD_RMT_OVR")
    RMT_PROV_L_1_MD_RMT_OVR("RMT_PROV_L1MD_RMT_OVR"),
    @XmlEnumValue("RMT_PROV_L1MD_RUN_RMT_OVR")
    RMT_PROV_L_1_MD_RUN_RMT_OVR("RMT_PROV_L1MD_RUN_RMT_OVR"),
    @XmlEnumValue("RMT_PROV_L1MD_CONTACTOR_TEST")
    RMT_PROV_L_1_MD_CONTACTOR_TEST("RMT_PROV_L1MD_CONTACTOR_TEST"),
    @XmlEnumValue("RMT_PROV_L1MD_STOD")
    RMT_PROV_L_1_MD_STOD("RMT_PROV_L1MD_STOD"),
    @XmlEnumValue("RMT_PROV_L1MD_RUNNING_STOD")
    RMT_PROV_L_1_MD_RUNNING_STOD("RMT_PROV_L1MD_RUNNING_STOD"),
    @XmlEnumValue("RMT_PROV_L1MD_POWER_UP")
    RMT_PROV_L_1_MD_POWER_UP("RMT_PROV_L1MD_POWER_UP"),
    @XmlEnumValue("RMT_PROV_L1MD_UNDER_FREQ")
    RMT_PROV_L_1_MD_UNDER_FREQ("RMT_PROV_L1MD_UNDER_FREQ"),
    @XmlEnumValue("RMT_PROV_L1MD_LD_CYC")
    RMT_PROV_L_1_MD_LD_CYC("RMT_PROV_L1MD_LD_CYC"),
    @XmlEnumValue("RMT_PROV_L1MD_RUN_LD_CYC")
    RMT_PROV_L_1_MD_RUN_LD_CYC("RMT_PROV_L1MD_RUN_LD_CYC"),
    @XmlEnumValue("RMT_PROV_L1MD_WT_SCC_CON")
    RMT_PROV_L_1_MD_WT_SCC_CON("RMT_PROV_L1MD_WT_SCC_CON"),
    @XmlEnumValue("RMT_PROV_L1MD_WT_ESCC_CON")
    RMT_PROV_L_1_MD_WT_ESCC_CON("RMT_PROV_L1MD_WT_ESCC_CON"),
    @XmlEnumValue("RMT_PROV_L1MD_DISC_NET_IMP_SCC")
    RMT_PROV_L_1_MD_DISC_NET_IMP_SCC("RMT_PROV_L1MD_DISC_NET_IMP_SCC"),
    @XmlEnumValue("RMT_PROV_L1MD_DISC_NET_EXP_SCC")
    RMT_PROV_L_1_MD_DISC_NET_EXP_SCC("RMT_PROV_L1MD_DISC_NET_EXP_SCC"),
    @XmlEnumValue("RMT_PROV_L1MD_DISC_TOU_IMP_SCC")
    RMT_PROV_L_1_MD_DISC_TOU_IMP_SCC("RMT_PROV_L1MD_DISC_TOU_IMP_SCC"),
    @XmlEnumValue("RMT_PROV_L1MD_DISC_TOU_EXP_SCC")
    RMT_PROV_L_1_MD_DISC_TOU_EXP_SCC("RMT_PROV_L1MD_DISC_TOU_EXP_SCC"),
    @XmlEnumValue("RMT_PROV_L1MD_POWER_UP_DIV")
    RMT_PROV_L_1_MD_POWER_UP_DIV("RMT_PROV_L1MD_POWER_UP_DIV"),
    @XmlEnumValue("RMT_PROV_L1MD_DEMAND_LIMIT")
    RMT_PROV_L_1_MD_DEMAND_LIMIT("RMT_PROV_L1MD_DEMAND_LIMIT"),
    @XmlEnumValue("RMT_PROV_L2MD_BOOST")
    RMT_PROV_L_2_MD_BOOST("RMT_PROV_L2MD_BOOST"),
    @XmlEnumValue("RMT_PROV_L2MD_RMT_OVR")
    RMT_PROV_L_2_MD_RMT_OVR("RMT_PROV_L2MD_RMT_OVR"),
    @XmlEnumValue("RMT_PROV_L2MD_RUN_RMT_OVR")
    RMT_PROV_L_2_MD_RUN_RMT_OVR("RMT_PROV_L2MD_RUN_RMT_OVR"),
    @XmlEnumValue("RMT_PROV_L2MD_CONTACTOR_TEST")
    RMT_PROV_L_2_MD_CONTACTOR_TEST("RMT_PROV_L2MD_CONTACTOR_TEST"),
    @XmlEnumValue("RMT_PROV_L2MD_STOD")
    RMT_PROV_L_2_MD_STOD("RMT_PROV_L2MD_STOD"),
    @XmlEnumValue("RMT_PROV_L2MD_RUNNING_STOD")
    RMT_PROV_L_2_MD_RUNNING_STOD("RMT_PROV_L2MD_RUNNING_STOD"),
    @XmlEnumValue("RMT_PROV_L2MD_POWER_UP")
    RMT_PROV_L_2_MD_POWER_UP("RMT_PROV_L2MD_POWER_UP"),
    @XmlEnumValue("RMT_PROV_L2MD_UNDER_FREQ")
    RMT_PROV_L_2_MD_UNDER_FREQ("RMT_PROV_L2MD_UNDER_FREQ"),
    @XmlEnumValue("RMT_PROV_L2MD_LD_CYCLE")
    RMT_PROV_L_2_MD_LD_CYCLE("RMT_PROV_L2MD_LD_CYCLE"),
    @XmlEnumValue("RMT_PROV_L2MD_RUN_LD_CYC")
    RMT_PROV_L_2_MD_RUN_LD_CYC("RMT_PROV_L2MD_RUN_LD_CYC"),
    @XmlEnumValue("RMT_PROV_L2MD_DEMAND_LIMIT")
    RMT_PROV_L_2_MD_DEMAND_LIMIT("RMT_PROV_L2MD_DEMAND_LIMIT"),
    @XmlEnumValue("RMT_PROV_L2MD_WT_SCC_CON")
    RMT_PROV_L_2_MD_WT_SCC_CON("RMT_PROV_L2MD_WT_SCC_CON"),
    @XmlEnumValue("RMT_PROV_L2MD_WT_ESCC_CON")
    RMT_PROV_L_2_MD_WT_ESCC_CON("RMT_PROV_L2MD_WT_ESCC_CON"),
    @XmlEnumValue("RMT_PROV_L2MD_DISC_NET_IMP_SCC")
    RMT_PROV_L_2_MD_DISC_NET_IMP_SCC("RMT_PROV_L2MD_DISC_NET_IMP_SCC"),
    @XmlEnumValue("RMT_PROV_L2MD_DISC_NET_EXP_SCC")
    RMT_PROV_L_2_MD_DISC_NET_EXP_SCC("RMT_PROV_L2MD_DISC_NET_EXP_SCC"),
    @XmlEnumValue("RMT_PROV_L2MD_DISC_TOU_IMP_SCC")
    RMT_PROV_L_2_MD_DISC_TOU_IMP_SCC("RMT_PROV_L2MD_DISC_TOU_IMP_SCC"),
    @XmlEnumValue("RMT_PROV_L2MD_DISC_TOU_EXP_SCC")
    RMT_PROV_L_2_MD_DISC_TOU_EXP_SCC("RMT_PROV_L2MD_DISC_TOU_EXP_SCC"),
    @XmlEnumValue("RMT_PROV_L2MD_POWER_UP_DIV")
    RMT_PROV_L_2_MD_POWER_UP_DIV("RMT_PROV_L2MD_POWER_UP_DIV"),
    @XmlEnumValue("RMT_PROV_MDL1_UNKNOWN")
    RMT_PROV_MDL_1_UNKNOWN("RMT_PROV_MDL1_UNKNOWN"),
    @XmlEnumValue("RMT_PROV_MDL1_NOT_AVLBL")
    RMT_PROV_MDL_1_NOT_AVLBL("RMT_PROV_MDL1_NOT_AVLBL"),
    @XmlEnumValue("RMT_PROV_MDL1_INVALID")
    RMT_PROV_MDL_1_INVALID("RMT_PROV_MDL1_INVALID"),
    @XmlEnumValue("RMT_PROV_MDL2_UNKNOWN")
    RMT_PROV_MDL_2_UNKNOWN("RMT_PROV_MDL2_UNKNOWN"),
    @XmlEnumValue("RMT_PROV_MDL2_NOT_AVLBL")
    RMT_PROV_MDL_2_NOT_AVLBL("RMT_PROV_MDL2_NOT_AVLBL"),
    @XmlEnumValue("RMT_PROV_MDL2_INVALID")
    RMT_PROV_MDL_2_INVALID("RMT_PROV_MDL2_INVALID"),
    RMT_PROV_STS_DIAGNOSTIC_FLAG("RMT_PROV_STS_DIAGNOSTIC_FLAG"),
    @XmlEnumValue("RMT_PROV_L1_CONNECT_DIV_ON")
    RMT_PROV_L_1_CONNECT_DIV_ON("RMT_PROV_L1_CONNECT_DIV_ON"),
    @XmlEnumValue("RMT_PROV_L1_DISCONNECT_DIV_ON")
    RMT_PROV_L_1_DISCONNECT_DIV_ON("RMT_PROV_L1_DISCONNECT_DIV_ON"),
    @XmlEnumValue("RMT_PROV_L2_CONNECT_DIV_ON")
    RMT_PROV_L_2_CONNECT_DIV_ON("RMT_PROV_L2_CONNECT_DIV_ON"),
    @XmlEnumValue("RMT_PROV_L2_DISCONNECT_DIV_ON")
    RMT_PROV_L_2_DISCONNECT_DIV_ON("RMT_PROV_L2_DISCONNECT_DIV_ON"),
    RMT_PROV_INCOMPLETE_EXTERNAL("RMT_PROV_INCOMPLETE_EXTERNAL"),
    RMT_PROV_INCOMPLETE_INTERNAL("RMT_PROV_INCOMPLETE_INTERNAL"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    RemoteProvisioningErrorStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RemoteProvisioningErrorStatusEnumeration fromValue(String v) {
        for (RemoteProvisioningErrorStatusEnumeration c: RemoteProvisioningErrorStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
