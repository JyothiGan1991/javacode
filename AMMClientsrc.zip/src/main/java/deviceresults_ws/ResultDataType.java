
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ResultDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ResultDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="ReadTable" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ReadTableType"/&gt;
 *         &lt;element name="ReadTableOffset" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ReadTableOffsetType"/&gt;
 *         &lt;element name="WriteTableOffset" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}WriteTableOffsetType"/&gt;
 *         &lt;element name="ExecuteProcedure" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ExecuteProcedureType"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="Status" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}CommandStatusEnumeration" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResultDataType", propOrder = {
    "readTable",
    "readTableOffset",
    "writeTableOffset",
    "executeProcedure"
})
public class ResultDataType {

    @XmlElement(name = "ReadTable")
    protected ReadTableType readTable;
    @XmlElement(name = "ReadTableOffset")
    protected ReadTableOffsetType readTableOffset;
    @XmlElement(name = "WriteTableOffset")
    protected WriteTableOffsetType writeTableOffset;
    @XmlElement(name = "ExecuteProcedure")
    protected ExecuteProcedureType executeProcedure;
    @XmlAttribute(name = "Status")
    protected CommandStatusEnumeration status;

    /**
     * Gets the value of the readTable property.
     * 
     * @return
     *     possible object is
     *     {@link ReadTableType }
     *     
     */
    public ReadTableType getReadTable() {
        return readTable;
    }

    /**
     * Sets the value of the readTable property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReadTableType }
     *     
     */
    public void setReadTable(ReadTableType value) {
        this.readTable = value;
    }

    /**
     * Gets the value of the readTableOffset property.
     * 
     * @return
     *     possible object is
     *     {@link ReadTableOffsetType }
     *     
     */
    public ReadTableOffsetType getReadTableOffset() {
        return readTableOffset;
    }

    /**
     * Sets the value of the readTableOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReadTableOffsetType }
     *     
     */
    public void setReadTableOffset(ReadTableOffsetType value) {
        this.readTableOffset = value;
    }

    /**
     * Gets the value of the writeTableOffset property.
     * 
     * @return
     *     possible object is
     *     {@link WriteTableOffsetType }
     *     
     */
    public WriteTableOffsetType getWriteTableOffset() {
        return writeTableOffset;
    }

    /**
     * Sets the value of the writeTableOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link WriteTableOffsetType }
     *     
     */
    public void setWriteTableOffset(WriteTableOffsetType value) {
        this.writeTableOffset = value;
    }

    /**
     * Gets the value of the executeProcedure property.
     * 
     * @return
     *     possible object is
     *     {@link ExecuteProcedureType }
     *     
     */
    public ExecuteProcedureType getExecuteProcedure() {
        return executeProcedure;
    }

    /**
     * Sets the value of the executeProcedure property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExecuteProcedureType }
     *     
     */
    public void setExecuteProcedure(ExecuteProcedureType value) {
        this.executeProcedure = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link CommandStatusEnumeration }
     *     
     */
    public CommandStatusEnumeration getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link CommandStatusEnumeration }
     *     
     */
    public void setStatus(CommandStatusEnumeration value) {
        this.status = value;
    }

}
