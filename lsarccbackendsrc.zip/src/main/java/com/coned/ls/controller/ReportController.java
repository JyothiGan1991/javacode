package com.coned.ls.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.ReportService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/lsa-rcc-report")
public class ReportController {
	private static final Logger LOGGER = LogManager.getLogger(RCCDisconnectController.class);

	@Autowired
	private ReportService reportService;
	
	@GetMapping("/{report_name}/events")
	public ResponseEntity<List<Map<String, Object>>> getEvents(@PathVariable(name = "report_name") String report_name) {
		LOGGER.debug(String.format("Request for get Connect FailedEvents :"));
		return reportService.getEvents(report_name);
	}
	@PostMapping("/cwr")
	public ResponseEntity<List<Map<String, Object>>> getCWR(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for get CWR Report from database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		return reportService.getCWR(payload);
	}
	@PostMapping("/cdr")
	public ResponseEntity<List<Map<String, Object>>> getCDR(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for get CDR Report from database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		return reportService.getCDR(payload);
	}
	@PostMapping("/crr")
	public ResponseEntity<List<Map<String, Object>>> getCRR(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for get CRR Report from database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		return reportService.getCRR(payload);
	}
	@PostMapping("/cer")
	public ResponseEntity<Map<String, Object>> getCER(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for get CER Report from database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		return reportService.getCER(payload);
	} 
	
	@PostMapping("/cmr")
	public ResponseEntity<Map<String, Object>> getCMR(HttpServletRequest request, @RequestBody Map<String, Object> payload) {
		LOGGER.info(String.format("Request for get CMR Report from database"));
		String header = request.getHeader("Authorization");
		if (request.getHeader("Authorization") == null) {
			throw new OperatorAuthorizationException("Request is incorrect ", HttpStatus.UNAUTHORIZED);
		}
		if (header.isEmpty()) {
			throw new OperatorAuthorizationException("Invalid Header Details ", HttpStatus.UNAUTHORIZED);
		}
		return reportService.getCMR(payload);
	}  
}