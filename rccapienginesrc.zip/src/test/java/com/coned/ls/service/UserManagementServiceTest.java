package com.coned.ls.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.repository.AuthorizationRepository;
import com.coned.ls.repository.UserManagementRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={UserManagementService.class})
@AutoConfigureMockMvc
public class UserManagementServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private UserManagementService userManagementService = new UserManagementServiceImpl();
	
	@Mock
	private UserManagementRepository  userManagementRepository;
	
	private MockMvc mockMvc;
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	
	@Test
	public void getUsers() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		
//		Mockito.when(userManagementService.getUsers()).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = userManagementService.getUsers();
		Assert.assertEquals("", "");
	}
		
	@Test
	public void createUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(userManagementService.createUser(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementService.createUser(payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void updateUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		payload.put("adid", username);
		
		Mockito.when(userManagementService.updateUser(username, payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementService.updateUser(username, payload);
		Assert.assertEquals("", "");
		
	}
	@Test
	public void deleteUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);

		String username = "ADID";
		String updatedBy = "ADID";
		
		Mockito.when(userManagementService.deleteUser(username, updatedBy)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementService.deleteUser(username, updatedBy);
		Assert.assertEquals("Null", "Null");
		
	}	
	
}
