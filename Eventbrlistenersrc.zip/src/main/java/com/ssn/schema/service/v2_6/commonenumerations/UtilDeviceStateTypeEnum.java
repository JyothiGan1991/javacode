
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UtilDeviceStateTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UtilDeviceStateTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UTL_DEVICE_STATE_NEW"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_ACTIVE"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_INACTIVE"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_MAINTENANCE"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_OPTIMIZE"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_RETIRED"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_DISCONNECTED"/>
 *     &lt;enumeration value="UTL_DEVICE_STATE_SVC_DISCONECT"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "UtilDeviceStateTypeEnum")
@XmlEnum
public enum UtilDeviceStateTypeEnum {

    UTL_DEVICE_STATE_NEW("UTL_DEVICE_STATE_NEW"),
    UTL_DEVICE_STATE_ACTIVE("UTL_DEVICE_STATE_ACTIVE"),
    UTL_DEVICE_STATE_INACTIVE("UTL_DEVICE_STATE_INACTIVE"),
    UTL_DEVICE_STATE_MAINTENANCE("UTL_DEVICE_STATE_MAINTENANCE"),
    UTL_DEVICE_STATE_OPTIMIZE("UTL_DEVICE_STATE_OPTIMIZE"),
    UTL_DEVICE_STATE_RETIRED("UTL_DEVICE_STATE_RETIRED"),
    UTL_DEVICE_STATE_DISCONNECTED("UTL_DEVICE_STATE_DISCONNECTED"),
    UTL_DEVICE_STATE_SVC_DISCONECT("UTL_DEVICE_STATE_SVC_DISCONECT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    UtilDeviceStateTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UtilDeviceStateTypeEnum fromValue(String v) {
        for (UtilDeviceStateTypeEnum c: UtilDeviceStateTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
