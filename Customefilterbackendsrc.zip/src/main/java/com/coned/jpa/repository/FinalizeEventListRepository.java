package com.coned.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import org.springframework.data.repository.query.Param;
import com.coned.model.FinalizedEventList;

@Repository
public interface FinalizeEventListRepository extends JpaRepository<FinalizedEventList, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
//	@Query(value = "SELECT u FROM ami_load_shedding.ls_finalize_event_list u WHERE u.event_name=:name")
	List<FinalizedEventList> findByEventnameAndBorough(String name, String borough);
	Long deleteByEventnameAndBorough(String name, String borough);
	
	/*
	 * @Query(value =
	 * "select meter_number from ami_load_shedding.ls_meter_event_load WHERE meter_event_load_id:melid"
	 * ) String findAllUsers(@Param("melid") Long melid);
	 */
}