package com.oru.rest.dto;

public class IncidentCountRequest {
    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;
    public IncidentCountRequest() {}
    public IncidentCountRequest(String startDate, String startTime, String endDate, String endTime) {
        this.startDate = startDate; this.startTime = startTime; this.endDate = endDate; this.endTime = endTime;
    }
    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
}
