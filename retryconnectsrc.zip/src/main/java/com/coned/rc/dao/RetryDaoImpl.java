
package com.coned.rc.dao;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionTemplate;

import com.coned.rc.beans.Event;
import com.coned.rc.beans.Meter;

@Repository
@Configuration
@PropertySource("classpath:retryqueries.properties")
public class RetryDaoImpl implements RetryDao{
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	private TransactionTemplate txTemplate;

	/**
	 * @return the txTemplate
	 */
	public TransactionTemplate getTxTemplate() {
		return txTemplate;
	}

	@Autowired
	private Environment env;

	public DataSource getDataSource() {
		return dataSource;
	}

	public Environment getEnv() {
		return this.env;
	}

	@Autowired
	public void setDataSource(DataSource datasource) {
		this.dataSource = datasource;
		this.jdbcTemplate = new JdbcTemplate(datasource);
		this.txTemplate = new TransactionTemplate(new DataSourceTransactionManager(datasource));
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	private NamedParameterJdbcTemplate getNamedParamTemplate() {
		return new NamedParameterJdbcTemplate(this.dataSource);
	}

	/*
	 * Fetch the events from the main table
	 */
	public List<Event> getEvents() {
		return jdbcTemplate.query(getEnv().getProperty("GET_EVENTS"), new EventRowMapper());
	}

	public List<Meter> getFailedMeters(List<BigDecimal> ids) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", ids);
		return getNamedParamTemplate().query(getEnv().getProperty("GET_FAILED_METERS"), (SqlParameterSource) params,
				new MeterRowMapper());
	}

	public Map<BigDecimal, Integer> getMeterCount(List<BigDecimal> ids) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", ids);
		return getNamedParamTemplate().query(getEnv().getProperty("GET_METER_CNT"), (SqlParameterSource) params,
				new ResultSetExtractor<Map<BigDecimal, Integer>>() {
					@Override
					public HashMap<BigDecimal, Integer> extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						HashMap<BigDecimal, Integer> mapRet = new HashMap<BigDecimal, Integer>();
						while (rs.next()) {
							mapRet.put(rs.getBigDecimal("REQUEST_IDX"), rs.getInt("COUNT"));
						}
						return mapRet;
					}
				});
	}

	public int getRetryCount(String eventName, String subEventName, String boro) {
		return jdbcTemplate.queryForObject(getEnv().getProperty("GET_RETRY_COUNT"), Integer.class,
				new Object[] { eventName, subEventName, boro });
	}

	public int saveRetry(Event req) {
		int readyForRetryRows = getJdbcTemplate().update(getEnv().getProperty("SAVE_RETRY"),
				new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setBigDecimal(1, req.getRequestId());
						ps.setString(2, req.getEventName());
						ps.setString(3, req.getSubEventName());
						ps.setString(4, req.getBoro());
						ps.setInt(5, req.getMeterCount());
						ps.setTimestamp(6, Timestamp.valueOf(req.getEventTime().toLocalDateTime()));
						ps.setTimestamp(7, Timestamp.valueOf(req.getExpireTime().toLocalDateTime()));
						ps.setInt(8, req.getMeterList().size());

					}
				});
		return readyForRetryRows;
	}

	/*
	 * public int[] saveRetry(List<Event> retryEventList) { if (retryEventList !=
	 * null && retryEventList.size() > 0) { return
	 * getJdbcTemplate().batchUpdate(env.getProperty("SAVE_RETRY"), new
	 * BatchPreparedStatementSetter() {
	 * 
	 * @Override public void setValues(PreparedStatement ps, int i) throws
	 * SQLException { Event e = retryEventList.get(i); ps.setBigDecimal(1,
	 * e.getRequestId()); ps.setString(2, e.getEventName()); ps.setString(3,
	 * e.getSubEventName()); ps.setString(4, e.getBoro()); ps.setInt(5,
	 * e.getMeterCount()); ps.setTimestamp(6,
	 * Timestamp.valueOf(e.getEventTime().toLocalDateTime())); ps.setTimestamp(7,
	 * Timestamp.valueOf(e.getExpireTime().toLocalDateTime())); ps.setInt(8,
	 * e.getMeterList().size()); }
	 * 
	 * @Override public int getBatchSize() { return retryEventList.size(); } }); }
	 * return null;
	 * 
	 * }
	 */

	public void updateRetry(Event req, String status) {
		int readyForRetryRows = getJdbcTemplate().update(getEnv().getProperty("UPDATE_RETRY"),
				new Object[] { status, req.getRequestId() });
		if (readyForRetryRows == 1) {
			logger.info("Successfully updated the status to {} for request id {} ", status, req.getRequestId());
		} else {
			logger.error("Error updated the status to {} for request id {} ", status, req.getRequestId());
		}

	}
}