
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ApprovalStatusEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ApprovalStatusEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MP_APPROVAL_STATUS_NOTYET"/&gt;
 *     &lt;enumeration value="MP_APPROVAL_STATUS_APPROVED"/&gt;
 *     &lt;enumeration value="MP_APPROVAL_STATUS_REJECTED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ApprovalStatusEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum ApprovalStatusEnum {

    MP_APPROVAL_STATUS_NOTYET("MP_APPROVAL_STATUS_NOTYET"),
    MP_APPROVAL_STATUS_APPROVED("MP_APPROVAL_STATUS_APPROVED"),
    MP_APPROVAL_STATUS_REJECTED("MP_APPROVAL_STATUS_REJECTED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ApprovalStatusEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ApprovalStatusEnum fromValue(String v) {
        for (ApprovalStatusEnum c: ApprovalStatusEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
