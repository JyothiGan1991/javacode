
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BroadcastParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BroadcastParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ProvisioningAction" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}ProvisioningActionType"/&gt;
 *         &lt;element name="AuxiliarySwitchControlParameters" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}AuxiliarySwitchControlParametersType" minOccurs="0"/&gt;
 *         &lt;element name="EmergencySupplyCapacityParameters" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}EmergencySupplyCapacityParametersType" minOccurs="0"/&gt;
 *         &lt;element name="PrimaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SecondaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TertiaryLoadCtrlGroup" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BroadcastParametersType", propOrder = {
    "provisioningAction",
    "auxiliarySwitchControlParameters",
    "emergencySupplyCapacityParameters",
    "primaryLoadCtrlGroup",
    "secondaryLoadCtrlGroup",
    "tertiaryLoadCtrlGroup"
})
public class BroadcastParametersType {

    @XmlElement(name = "ProvisioningAction", required = true)
    protected ProvisioningActionType provisioningAction;
    @XmlElement(name = "AuxiliarySwitchControlParameters")
    protected AuxiliarySwitchControlParametersType auxiliarySwitchControlParameters;
    @XmlElement(name = "EmergencySupplyCapacityParameters")
    protected EmergencySupplyCapacityParametersType emergencySupplyCapacityParameters;
    @XmlElement(name = "PrimaryLoadCtrlGroup", type = Integer.class)
    protected List<Integer> primaryLoadCtrlGroup;
    @XmlElement(name = "SecondaryLoadCtrlGroup", type = Integer.class)
    protected List<Integer> secondaryLoadCtrlGroup;
    @XmlElement(name = "TertiaryLoadCtrlGroup", type = Integer.class)
    protected List<Integer> tertiaryLoadCtrlGroup;

    /**
     * Gets the value of the provisioningAction property.
     * 
     * @return
     *     possible object is
     *     {@link ProvisioningActionType }
     *     
     */
    public ProvisioningActionType getProvisioningAction() {
        return provisioningAction;
    }

    /**
     * Sets the value of the provisioningAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProvisioningActionType }
     *     
     */
    public void setProvisioningAction(ProvisioningActionType value) {
        this.provisioningAction = value;
    }

    /**
     * Gets the value of the auxiliarySwitchControlParameters property.
     * 
     * @return
     *     possible object is
     *     {@link AuxiliarySwitchControlParametersType }
     *     
     */
    public AuxiliarySwitchControlParametersType getAuxiliarySwitchControlParameters() {
        return auxiliarySwitchControlParameters;
    }

    /**
     * Sets the value of the auxiliarySwitchControlParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuxiliarySwitchControlParametersType }
     *     
     */
    public void setAuxiliarySwitchControlParameters(AuxiliarySwitchControlParametersType value) {
        this.auxiliarySwitchControlParameters = value;
    }

    /**
     * Gets the value of the emergencySupplyCapacityParameters property.
     * 
     * @return
     *     possible object is
     *     {@link EmergencySupplyCapacityParametersType }
     *     
     */
    public EmergencySupplyCapacityParametersType getEmergencySupplyCapacityParameters() {
        return emergencySupplyCapacityParameters;
    }

    /**
     * Sets the value of the emergencySupplyCapacityParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmergencySupplyCapacityParametersType }
     *     
     */
    public void setEmergencySupplyCapacityParameters(EmergencySupplyCapacityParametersType value) {
        this.emergencySupplyCapacityParameters = value;
    }

    /**
     * Gets the value of the primaryLoadCtrlGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the primaryLoadCtrlGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrimaryLoadCtrlGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getPrimaryLoadCtrlGroup() {
        if (primaryLoadCtrlGroup == null) {
            primaryLoadCtrlGroup = new ArrayList<Integer>();
        }
        return this.primaryLoadCtrlGroup;
    }

    /**
     * Gets the value of the secondaryLoadCtrlGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the secondaryLoadCtrlGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecondaryLoadCtrlGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getSecondaryLoadCtrlGroup() {
        if (secondaryLoadCtrlGroup == null) {
            secondaryLoadCtrlGroup = new ArrayList<Integer>();
        }
        return this.secondaryLoadCtrlGroup;
    }

    /**
     * Gets the value of the tertiaryLoadCtrlGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tertiaryLoadCtrlGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTertiaryLoadCtrlGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getTertiaryLoadCtrlGroup() {
        if (tertiaryLoadCtrlGroup == null) {
            tertiaryLoadCtrlGroup = new ArrayList<Integer>();
        }
        return this.tertiaryLoadCtrlGroup;
    }

}
