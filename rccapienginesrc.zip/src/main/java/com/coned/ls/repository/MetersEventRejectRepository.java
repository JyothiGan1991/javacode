package com.coned.ls.repository;

import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.MeterRejectResponseMapper;

/**
 * 
 * Interface for Meter Event reject repository class.
 *
 */
public interface MetersEventRejectRepository {

	public MeterRejectResponseMapper rejectMeterEventList(final String borough, final String eventName) throws MeterRejectException;
}
