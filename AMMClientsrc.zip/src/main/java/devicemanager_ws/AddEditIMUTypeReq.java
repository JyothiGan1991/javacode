
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditIMUTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditIMUTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditIMUType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IMUTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="IMUMeterTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditIMUTypeReq", propOrder = {
    "imuTypeConfigID",
    "imuMeterTypeConfigID"
})
public class AddEditIMUTypeReq
    extends AddEditIMUType
{

    @XmlElement(name = "IMUTypeConfigID")
    protected Long imuTypeConfigID;
    @XmlElement(name = "IMUMeterTypeConfigID")
    protected Long imuMeterTypeConfigID;

    /**
     * Gets the value of the imuTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getIMUTypeConfigID() {
        return imuTypeConfigID;
    }

    /**
     * Sets the value of the imuTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setIMUTypeConfigID(Long value) {
        this.imuTypeConfigID = value;
    }

    /**
     * Gets the value of the imuMeterTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getIMUMeterTypeConfigID() {
        return imuMeterTypeConfigID;
    }

    /**
     * Sets the value of the imuMeterTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setIMUMeterTypeConfigID(Long value) {
        this.imuMeterTypeConfigID = value;
    }

}
