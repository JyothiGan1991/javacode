
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateServicePtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateServicePtType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServicePtID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilServicePtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MeterPhase" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="MeterLocCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ServicePhaseCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="ServiceVoltLevelCode" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="LineFreq" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="CurrTransRatio" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="VoltTransRatio" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="SpLongitude" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="SpLatitude" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="SpHeight" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="SpExtUrl" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableAnyURIArrayType" minOccurs="0"/&gt;
 *         &lt;element name="SpImage1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBase64Binary" minOccurs="0"/&gt;
 *         &lt;element name="SpImage1Note" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SpImage2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableBase64Binary" minOccurs="0"/&gt;
 *         &lt;element name="SpImage2Note" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SpInsertTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SpInsertBy" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SpUpdateTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="SpUpdateBy" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycle" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="Account" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableAccountType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointTransformer" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableServicePtTransformerType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute4" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="ServicePtAttribute5" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="TenantId" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateServicePtType", propOrder = {
    "servicePtID",
    "utilServicePtID",
    "serviceType",
    "meterPhase",
    "meterLocCode",
    "servicePhaseCode",
    "serviceVoltLevelCode",
    "lineFreq",
    "currTransRatio",
    "voltTransRatio",
    "spLongitude",
    "spLatitude",
    "spHeight",
    "spExtUrl",
    "spImage1",
    "spImage1Note",
    "spImage2",
    "spImage2Note",
    "spInsertTime",
    "spInsertBy",
    "spUpdateTime",
    "spUpdateBy",
    "billingCycle",
    "account",
    "servicePointTransformer",
    "servicePtAttribute1",
    "servicePtAttribute2",
    "servicePtAttribute3",
    "servicePtAttribute4",
    "servicePtAttribute5",
    "tenantId"
})
@XmlSeeAlso({
    NullableServicePtType.class
})
public class UpdateServicePtType {

    @XmlElement(name = "ServicePtID")
    protected Long servicePtID;
    @XmlElement(name = "UtilServicePtID")
    protected String utilServicePtID;
    @XmlElement(name = "ServiceType")
    protected String serviceType;
    @XmlElement(name = "MeterPhase")
    protected NullableString meterPhase;
    @XmlElement(name = "MeterLocCode")
    protected NullableString meterLocCode;
    @XmlElement(name = "ServicePhaseCode")
    protected NullableInt servicePhaseCode;
    @XmlElement(name = "ServiceVoltLevelCode")
    protected NullableString serviceVoltLevelCode;
    @XmlElement(name = "LineFreq")
    protected NullableInt lineFreq;
    @XmlElement(name = "CurrTransRatio")
    protected NullableDouble currTransRatio;
    @XmlElement(name = "VoltTransRatio")
    protected NullableDouble voltTransRatio;
    @XmlElement(name = "SpLongitude")
    protected NullableDouble spLongitude;
    @XmlElement(name = "SpLatitude")
    protected NullableDouble spLatitude;
    @XmlElement(name = "SpHeight")
    protected NullableDouble spHeight;
    @XmlElement(name = "SpExtUrl")
    protected NullableAnyURIArrayType spExtUrl;
    @XmlElement(name = "SpImage1")
    protected NullableBase64Binary spImage1;
    @XmlElement(name = "SpImage1Note")
    protected NullableString spImage1Note;
    @XmlElement(name = "SpImage2")
    protected NullableBase64Binary spImage2;
    @XmlElement(name = "SpImage2Note")
    protected NullableString spImage2Note;
    @XmlElement(name = "SpInsertTime")
    protected NullableString spInsertTime;
    @XmlElement(name = "SpInsertBy")
    protected NullableString spInsertBy;
    @XmlElement(name = "SpUpdateTime")
    protected NullableString spUpdateTime;
    @XmlElement(name = "SpUpdateBy")
    protected NullableString spUpdateBy;
    @XmlElement(name = "BillingCycle")
    protected NullableString billingCycle;
    @XmlElement(name = "Account")
    protected NullableAccountType account;
    @XmlElement(name = "ServicePointTransformer")
    protected NullableServicePtTransformerType servicePointTransformer;
    @XmlElement(name = "ServicePtAttribute1")
    protected NullableString servicePtAttribute1;
    @XmlElement(name = "ServicePtAttribute2")
    protected NullableString servicePtAttribute2;
    @XmlElement(name = "ServicePtAttribute3")
    protected NullableString servicePtAttribute3;
    @XmlElement(name = "ServicePtAttribute4")
    protected NullableString servicePtAttribute4;
    @XmlElement(name = "ServicePtAttribute5")
    protected NullableString servicePtAttribute5;
    @XmlElement(name = "TenantId")
    protected NullableString tenantId;

    /**
     * Gets the value of the servicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServicePtID() {
        return servicePtID;
    }

    /**
     * Sets the value of the servicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServicePtID(Long value) {
        this.servicePtID = value;
    }

    /**
     * Gets the value of the utilServicePtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilServicePtID() {
        return utilServicePtID;
    }

    /**
     * Sets the value of the utilServicePtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilServicePtID(String value) {
        this.utilServicePtID = value;
    }

    /**
     * Gets the value of the serviceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * Sets the value of the serviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceType(String value) {
        this.serviceType = value;
    }

    /**
     * Gets the value of the meterPhase property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getMeterPhase() {
        return meterPhase;
    }

    /**
     * Sets the value of the meterPhase property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setMeterPhase(NullableString value) {
        this.meterPhase = value;
    }

    /**
     * Gets the value of the meterLocCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getMeterLocCode() {
        return meterLocCode;
    }

    /**
     * Sets the value of the meterLocCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setMeterLocCode(NullableString value) {
        this.meterLocCode = value;
    }

    /**
     * Gets the value of the servicePhaseCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getServicePhaseCode() {
        return servicePhaseCode;
    }

    /**
     * Sets the value of the servicePhaseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setServicePhaseCode(NullableInt value) {
        this.servicePhaseCode = value;
    }

    /**
     * Gets the value of the serviceVoltLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServiceVoltLevelCode() {
        return serviceVoltLevelCode;
    }

    /**
     * Sets the value of the serviceVoltLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServiceVoltLevelCode(NullableString value) {
        this.serviceVoltLevelCode = value;
    }

    /**
     * Gets the value of the lineFreq property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getLineFreq() {
        return lineFreq;
    }

    /**
     * Sets the value of the lineFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setLineFreq(NullableInt value) {
        this.lineFreq = value;
    }

    /**
     * Gets the value of the currTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getCurrTransRatio() {
        return currTransRatio;
    }

    /**
     * Sets the value of the currTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setCurrTransRatio(NullableDouble value) {
        this.currTransRatio = value;
    }

    /**
     * Gets the value of the voltTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getVoltTransRatio() {
        return voltTransRatio;
    }

    /**
     * Sets the value of the voltTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setVoltTransRatio(NullableDouble value) {
        this.voltTransRatio = value;
    }

    /**
     * Gets the value of the spLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getSpLongitude() {
        return spLongitude;
    }

    /**
     * Sets the value of the spLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setSpLongitude(NullableDouble value) {
        this.spLongitude = value;
    }

    /**
     * Gets the value of the spLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getSpLatitude() {
        return spLatitude;
    }

    /**
     * Sets the value of the spLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setSpLatitude(NullableDouble value) {
        this.spLatitude = value;
    }

    /**
     * Gets the value of the spHeight property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getSpHeight() {
        return spHeight;
    }

    /**
     * Sets the value of the spHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setSpHeight(NullableDouble value) {
        this.spHeight = value;
    }

    /**
     * Gets the value of the spExtUrl property.
     * 
     * @return
     *     possible object is
     *     {@link NullableAnyURIArrayType }
     *     
     */
    public NullableAnyURIArrayType getSpExtUrl() {
        return spExtUrl;
    }

    /**
     * Sets the value of the spExtUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableAnyURIArrayType }
     *     
     */
    public void setSpExtUrl(NullableAnyURIArrayType value) {
        this.spExtUrl = value;
    }

    /**
     * Gets the value of the spImage1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBase64Binary }
     *     
     */
    public NullableBase64Binary getSpImage1() {
        return spImage1;
    }

    /**
     * Sets the value of the spImage1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBase64Binary }
     *     
     */
    public void setSpImage1(NullableBase64Binary value) {
        this.spImage1 = value;
    }

    /**
     * Gets the value of the spImage1Note property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpImage1Note() {
        return spImage1Note;
    }

    /**
     * Sets the value of the spImage1Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpImage1Note(NullableString value) {
        this.spImage1Note = value;
    }

    /**
     * Gets the value of the spImage2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableBase64Binary }
     *     
     */
    public NullableBase64Binary getSpImage2() {
        return spImage2;
    }

    /**
     * Sets the value of the spImage2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableBase64Binary }
     *     
     */
    public void setSpImage2(NullableBase64Binary value) {
        this.spImage2 = value;
    }

    /**
     * Gets the value of the spImage2Note property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpImage2Note() {
        return spImage2Note;
    }

    /**
     * Sets the value of the spImage2Note property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpImage2Note(NullableString value) {
        this.spImage2Note = value;
    }

    /**
     * Gets the value of the spInsertTime property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpInsertTime() {
        return spInsertTime;
    }

    /**
     * Sets the value of the spInsertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpInsertTime(NullableString value) {
        this.spInsertTime = value;
    }

    /**
     * Gets the value of the spInsertBy property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpInsertBy() {
        return spInsertBy;
    }

    /**
     * Sets the value of the spInsertBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpInsertBy(NullableString value) {
        this.spInsertBy = value;
    }

    /**
     * Gets the value of the spUpdateTime property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpUpdateTime() {
        return spUpdateTime;
    }

    /**
     * Sets the value of the spUpdateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpUpdateTime(NullableString value) {
        this.spUpdateTime = value;
    }

    /**
     * Gets the value of the spUpdateBy property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getSpUpdateBy() {
        return spUpdateBy;
    }

    /**
     * Sets the value of the spUpdateBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setSpUpdateBy(NullableString value) {
        this.spUpdateBy = value;
    }

    /**
     * Gets the value of the billingCycle property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getBillingCycle() {
        return billingCycle;
    }

    /**
     * Sets the value of the billingCycle property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setBillingCycle(NullableString value) {
        this.billingCycle = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link NullableAccountType }
     *     
     */
    public NullableAccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableAccountType }
     *     
     */
    public void setAccount(NullableAccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the servicePointTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link NullableServicePtTransformerType }
     *     
     */
    public NullableServicePtTransformerType getServicePointTransformer() {
        return servicePointTransformer;
    }

    /**
     * Sets the value of the servicePointTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableServicePtTransformerType }
     *     
     */
    public void setServicePointTransformer(NullableServicePtTransformerType value) {
        this.servicePointTransformer = value;
    }

    /**
     * Gets the value of the servicePtAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServicePtAttribute1() {
        return servicePtAttribute1;
    }

    /**
     * Sets the value of the servicePtAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServicePtAttribute1(NullableString value) {
        this.servicePtAttribute1 = value;
    }

    /**
     * Gets the value of the servicePtAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServicePtAttribute2() {
        return servicePtAttribute2;
    }

    /**
     * Sets the value of the servicePtAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServicePtAttribute2(NullableString value) {
        this.servicePtAttribute2 = value;
    }

    /**
     * Gets the value of the servicePtAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServicePtAttribute3() {
        return servicePtAttribute3;
    }

    /**
     * Sets the value of the servicePtAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServicePtAttribute3(NullableString value) {
        this.servicePtAttribute3 = value;
    }

    /**
     * Gets the value of the servicePtAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServicePtAttribute4() {
        return servicePtAttribute4;
    }

    /**
     * Sets the value of the servicePtAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServicePtAttribute4(NullableString value) {
        this.servicePtAttribute4 = value;
    }

    /**
     * Gets the value of the servicePtAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getServicePtAttribute5() {
        return servicePtAttribute5;
    }

    /**
     * Sets the value of the servicePtAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setServicePtAttribute5(NullableString value) {
        this.servicePtAttribute5 = value;
    }

    /**
     * Gets the value of the tenantId property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getTenantId() {
        return tenantId;
    }

    /**
     * Sets the value of the tenantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setTenantId(NullableString value) {
        this.tenantId = value;
    }

}
