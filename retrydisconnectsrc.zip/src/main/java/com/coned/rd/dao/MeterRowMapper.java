package com.coned.rd.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.rd.beans.Meter;

public class MeterRowMapper implements RowMapper<Meter> {
	public Meter mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Meter(rs.getBigDecimal(1), rs.getBigDecimal(2), rs.getString(3), rs.getString(4));
	}
}