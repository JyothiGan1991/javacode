/*package com.coned.ls.interceptor;

import java.lang.reflect.UndeclaredThrowableException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.HandlerInterceptor;

import com.coned.ls.exception.OperatorAuthorizationException;
//import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.service.AuthorizationService;

@Aspect
@Component 
public class APISecurityInterceptor{
	
	private static final Logger logger = LogManager.getLogger(APISecurityInterceptor.class);
	
	@Autowired
	private AuthorizationService authenticationService; 
	
	@Before(value = "execution(* com.coned.ls.controller.RCCDisconnectController.*(..))")  
    public boolean before(JoinPoint joinPoint) throws OperatorAuthorizationException{
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String adid = request.getParameter("adid");
        String apiKey = request.getParameter("apikey");
        
        boolean apiEndpointAuthorizeed = authenticationService.isAPIEndpointAuthorizeed(adid,apiKey,13, 10);
        
        System.out.println("apiEndpointAuthorizeed : "+apiEndpointAuthorizeed);
        if(!apiEndpointAuthorizeed){
        	throw new UndeclaredThrowableException(new Throwable(), "API_KEY_EXPIRE");
        }return false;
        
    }
}
*/