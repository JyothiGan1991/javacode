
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditBridgeTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditBridgeTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AddEditBridgeType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BridgeTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditBridgeTypeReq", propOrder = {
    "bridgeTypeConfigID"
})
public class AddEditBridgeTypeReq
    extends AddEditBridgeType
{

    @XmlElement(name = "BridgeTypeConfigID")
    protected long bridgeTypeConfigID;

    /**
     * Gets the value of the bridgeTypeConfigID property.
     * 
     */
    public long getBridgeTypeConfigID() {
        return bridgeTypeConfigID;
    }

    /**
     * Sets the value of the bridgeTypeConfigID property.
     * 
     */
    public void setBridgeTypeConfigID(long value) {
        this.bridgeTypeConfigID = value;
    }

}
