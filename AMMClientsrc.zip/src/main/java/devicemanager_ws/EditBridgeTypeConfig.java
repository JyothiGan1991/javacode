
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditBridgeTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditBridgeTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BridgeTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BridgeTypeConfig"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditBridgeTypeConfig", propOrder = {
    "bridgeTypeConfig"
})
public class EditBridgeTypeConfig {

    @XmlElement(name = "BridgeTypeConfig", required = true)
    protected BridgeTypeConfig bridgeTypeConfig;

    /**
     * Gets the value of the bridgeTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link BridgeTypeConfig }
     *     
     */
    public BridgeTypeConfig getBridgeTypeConfig() {
        return bridgeTypeConfig;
    }

    /**
     * Sets the value of the bridgeTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link BridgeTypeConfig }
     *     
     */
    public void setBridgeTypeConfig(BridgeTypeConfig value) {
        this.bridgeTypeConfig = value;
    }

}
