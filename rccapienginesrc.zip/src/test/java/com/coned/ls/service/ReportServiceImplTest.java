package com.coned.ls.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.repository.AuthorizationRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ReportService.class})
@AutoConfigureMockMvc
public class ReportServiceImplTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private ReportService reportService = new ReportServiceImpl();
	
	@Mock
	private ReportService  reportRepository;
	
	private MockMvc mockMvc;
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	
	@Test(expected = NullPointerException.class)
	public void getEvents() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		ResponseEntity<List<Map<String, Object>>> actual = reportService.getEvents(null);
		Assert.assertEquals("", "");
	}
		
	@Test(expected = NullPointerException.class)
	public void getCERData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCERData(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = reportService.getCERData(payload);
		Assert.assertEquals("", "");
	}
	@Test(expected = NullPointerException.class)
	public void getCDRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCDRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportService.getCDRData(payload);
		Assert.assertEquals("", "");
	}
	@Test(expected = NullPointerException.class)
	public void getCRRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCRRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportService.getCRRData(payload);
		Assert.assertEquals("", "");
	}
	@Test(expected = NullPointerException.class)
	public void getCWRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(reportService.getCWRData(payload)).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = reportService.getCWRData(payload);
		Assert.assertEquals("", "");
	}
	
}
