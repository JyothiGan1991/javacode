
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CronJobChoiceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CronJobChoiceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CronJobType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}CronJobTypeEnumeration" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CronJobChoiceType", propOrder = {
    "cronJobType"
})
public class CronJobChoiceType {

    @XmlElement(name = "CronJobType")
    @XmlSchemaType(name = "string")
    protected CronJobTypeEnumeration cronJobType;

    /**
     * Gets the value of the cronJobType property.
     * 
     * @return
     *     possible object is
     *     {@link CronJobTypeEnumeration }
     *     
     */
    public CronJobTypeEnumeration getCronJobType() {
        return cronJobType;
    }

    /**
     * Sets the value of the cronJobType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CronJobTypeEnumeration }
     *     
     */
    public void setCronJobType(CronJobTypeEnumeration value) {
        this.cronJobType = value;
    }

}
