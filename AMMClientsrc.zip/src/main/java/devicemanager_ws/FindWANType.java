
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindWANType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindWANType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GatewayWANTypeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GatewayWANTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANMfgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANMfgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANMfgModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANRevision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANPatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WANCommType" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}WANType" minOccurs="0"/&gt;
 *         &lt;element name="WANESN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindWANType", propOrder = {
    "gatewayWANTypeName",
    "gatewayWANTypeDesc",
    "wanMfgCode",
    "wanMfgName",
    "wanMfgModel",
    "wanVersion",
    "wanRevision",
    "wanPatch",
    "wanCommType",
    "wanesn"
})
public class FindWANType {

    @XmlElement(name = "GatewayWANTypeName")
    protected String gatewayWANTypeName;
    @XmlElement(name = "GatewayWANTypeDesc")
    protected String gatewayWANTypeDesc;
    @XmlElement(name = "WANMfgCode")
    protected String wanMfgCode;
    @XmlElement(name = "WANMfgName")
    protected String wanMfgName;
    @XmlElement(name = "WANMfgModel")
    protected String wanMfgModel;
    @XmlElement(name = "WANVersion")
    protected String wanVersion;
    @XmlElement(name = "WANRevision")
    protected String wanRevision;
    @XmlElement(name = "WANPatch")
    protected String wanPatch;
    @XmlElement(name = "WANCommType")
    protected WANType wanCommType;
    @XmlElement(name = "WANESN")
    protected String wanesn;

    /**
     * Gets the value of the gatewayWANTypeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayWANTypeName() {
        return gatewayWANTypeName;
    }

    /**
     * Sets the value of the gatewayWANTypeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayWANTypeName(String value) {
        this.gatewayWANTypeName = value;
    }

    /**
     * Gets the value of the gatewayWANTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayWANTypeDesc() {
        return gatewayWANTypeDesc;
    }

    /**
     * Sets the value of the gatewayWANTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayWANTypeDesc(String value) {
        this.gatewayWANTypeDesc = value;
    }

    /**
     * Gets the value of the wanMfgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANMfgCode() {
        return wanMfgCode;
    }

    /**
     * Sets the value of the wanMfgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANMfgCode(String value) {
        this.wanMfgCode = value;
    }

    /**
     * Gets the value of the wanMfgName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANMfgName() {
        return wanMfgName;
    }

    /**
     * Sets the value of the wanMfgName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANMfgName(String value) {
        this.wanMfgName = value;
    }

    /**
     * Gets the value of the wanMfgModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANMfgModel() {
        return wanMfgModel;
    }

    /**
     * Sets the value of the wanMfgModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANMfgModel(String value) {
        this.wanMfgModel = value;
    }

    /**
     * Gets the value of the wanVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANVersion() {
        return wanVersion;
    }

    /**
     * Sets the value of the wanVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANVersion(String value) {
        this.wanVersion = value;
    }

    /**
     * Gets the value of the wanRevision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANRevision() {
        return wanRevision;
    }

    /**
     * Sets the value of the wanRevision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANRevision(String value) {
        this.wanRevision = value;
    }

    /**
     * Gets the value of the wanPatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANPatch() {
        return wanPatch;
    }

    /**
     * Sets the value of the wanPatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANPatch(String value) {
        this.wanPatch = value;
    }

    /**
     * Gets the value of the wanCommType property.
     * 
     * @return
     *     possible object is
     *     {@link WANType }
     *     
     */
    public WANType getWANCommType() {
        return wanCommType;
    }

    /**
     * Sets the value of the wanCommType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WANType }
     *     
     */
    public void setWANCommType(WANType value) {
        this.wanCommType = value;
    }

    /**
     * Gets the value of the wanesn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWANESN() {
        return wanesn;
    }

    /**
     * Sets the value of the wanesn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWANESN(String value) {
        this.wanesn = value;
    }

}
