package com.coned.ls.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.service.AuthorizationService;
import com.coned.ls.service.UserManagementService;
import com.coned.ls.controller.UserManagementController;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = UserManagementController.class)
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class })
@WebMvcTest(UserManagementController.class)
public class UserManagementControllerTest {

	@Autowired
	private WebApplicationContext wac;

	private MockMvc mockMvc;
	
	@MockBean
	private UserManagementService userManagementService;

	@InjectMocks
	private UserManagementController userManagementController;

	@Test
	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		userManagementController = new UserManagementController();
		System.out.println("@Before annotation method is being called ....");

		ReflectionTestUtils.setField(userManagementController, "userManagementService", userManagementService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	@Test
	public void getUsers() {
		List<Map<String, Object>> expected = new ArrayList<Map<String, Object>>();
		ResponseEntity<List<Map<String, Object>>> result = new ResponseEntity<List<Map<String, Object>>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		Mockito.when(userManagementService.getUsers()).thenReturn(result);
		ResponseEntity<List<Map<String, Object>>> actual = userManagementController.getUsers();
		Assert.assertEquals("", "");
	}
	@Test
	public void listLDAPUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		
//		Mockito.when(userManagementService.listLDAPUser(username)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementController.listLDAPUsers(username);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
		
	@Test
	public void createUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
//		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(userManagementService.createUser(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementController.createUser(payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void updateUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
//		Map<String, Object> result = new HashMap<String, Object>();
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		payload.put("adid", username);
		
		Mockito.when(userManagementService.updateUser(username, payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementController.updateUser(username, payload);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		
	}
	@Test
	public void deleteUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
//		Map<String, Object> result = new HashMap<String, Object>();
		
		String username = "ADID";
		String updatedBy = "ADID";
		
		Mockito.when(userManagementService.deleteUser(username, updatedBy)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = userManagementController.deleteUser(username, updatedBy);
//		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		Assert.assertEquals("Null", "Null");
		
	}
	
}
