
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IntervalSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="IntervalSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="GatewaySerialNumber"/&gt;
 *     &lt;enumeration value="GatewayName"/&gt;
 *     &lt;enumeration value="GatewayCollectedTime"/&gt;
 *     &lt;enumeration value="IntervalTime"/&gt;
 *     &lt;enumeration value="BlockSequenceNumber"/&gt;
 *     &lt;enumeration value="IntervalSequenceNumber"/&gt;
 *     &lt;enumeration value="IntervalWidth"/&gt;
 *     &lt;enumeration value="UiqMeterProgramId"/&gt;
 *     &lt;enumeration value="LPSetId"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "IntervalSortColumnEnumeration")
@XmlEnum
public enum IntervalSortColumnEnumeration {

    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("GatewaySerialNumber")
    GATEWAY_SERIAL_NUMBER("GatewaySerialNumber"),
    @XmlEnumValue("GatewayName")
    GATEWAY_NAME("GatewayName"),
    @XmlEnumValue("GatewayCollectedTime")
    GATEWAY_COLLECTED_TIME("GatewayCollectedTime"),
    @XmlEnumValue("IntervalTime")
    INTERVAL_TIME("IntervalTime"),
    @XmlEnumValue("BlockSequenceNumber")
    BLOCK_SEQUENCE_NUMBER("BlockSequenceNumber"),
    @XmlEnumValue("IntervalSequenceNumber")
    INTERVAL_SEQUENCE_NUMBER("IntervalSequenceNumber"),
    @XmlEnumValue("IntervalWidth")
    INTERVAL_WIDTH("IntervalWidth"),
    @XmlEnumValue("UiqMeterProgramId")
    UIQ_METER_PROGRAM_ID("UiqMeterProgramId"),
    @XmlEnumValue("LPSetId")
    LP_SET_ID("LPSetId");
    private final String value;

    IntervalSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IntervalSortColumnEnumeration fromValue(String v) {
        for (IntervalSortColumnEnumeration c: IntervalSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
