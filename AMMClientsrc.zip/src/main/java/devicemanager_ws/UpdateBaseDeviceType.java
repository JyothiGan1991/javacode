
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="Relay" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateRelayTypeReq"/&gt;
 *           &lt;element name="Meter" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateMeterTypeReq"/&gt;
 *           &lt;element name="Gateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateGatewayTypeReq"/&gt;
 *           &lt;element name="IMU" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateIMUTypeReq"/&gt;
 *           &lt;element name="WaterModule" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateIMUTypeReq"/&gt;
 *           &lt;element name="Bridge" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateBridgeTypeReq"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateBaseDeviceType", propOrder = {
    "relay",
    "meter",
    "gateway",
    "imu",
    "waterModule",
    "bridge"
})
public class UpdateBaseDeviceType {

    @XmlElement(name = "Relay")
    protected UpdateRelayTypeReq relay;
    @XmlElement(name = "Meter")
    protected UpdateMeterTypeReq meter;
    @XmlElement(name = "Gateway")
    protected UpdateGatewayTypeReq gateway;
    @XmlElement(name = "IMU")
    protected UpdateIMUTypeReq imu;
    @XmlElement(name = "WaterModule")
    protected UpdateIMUTypeReq waterModule;
    @XmlElement(name = "Bridge")
    protected UpdateBridgeTypeReq bridge;

    /**
     * Gets the value of the relay property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateRelayTypeReq }
     *     
     */
    public UpdateRelayTypeReq getRelay() {
        return relay;
    }

    /**
     * Sets the value of the relay property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateRelayTypeReq }
     *     
     */
    public void setRelay(UpdateRelayTypeReq value) {
        this.relay = value;
    }

    /**
     * Gets the value of the meter property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateMeterTypeReq }
     *     
     */
    public UpdateMeterTypeReq getMeter() {
        return meter;
    }

    /**
     * Sets the value of the meter property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateMeterTypeReq }
     *     
     */
    public void setMeter(UpdateMeterTypeReq value) {
        this.meter = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateGatewayTypeReq }
     *     
     */
    public UpdateGatewayTypeReq getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateGatewayTypeReq }
     *     
     */
    public void setGateway(UpdateGatewayTypeReq value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the imu property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateIMUTypeReq }
     *     
     */
    public UpdateIMUTypeReq getIMU() {
        return imu;
    }

    /**
     * Sets the value of the imu property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateIMUTypeReq }
     *     
     */
    public void setIMU(UpdateIMUTypeReq value) {
        this.imu = value;
    }

    /**
     * Gets the value of the waterModule property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateIMUTypeReq }
     *     
     */
    public UpdateIMUTypeReq getWaterModule() {
        return waterModule;
    }

    /**
     * Sets the value of the waterModule property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateIMUTypeReq }
     *     
     */
    public void setWaterModule(UpdateIMUTypeReq value) {
        this.waterModule = value;
    }

    /**
     * Gets the value of the bridge property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateBridgeTypeReq }
     *     
     */
    public UpdateBridgeTypeReq getBridge() {
        return bridge;
    }

    /**
     * Sets the value of the bridge property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateBridgeTypeReq }
     *     
     */
    public void setBridge(UpdateBridgeTypeReq value) {
        this.bridge = value;
    }

}
