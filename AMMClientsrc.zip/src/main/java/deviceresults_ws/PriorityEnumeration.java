
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PriorityEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PriorityEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_PRIORITY_LOW"/&gt;
 *     &lt;enumeration value="JOB_PRIORITY_NORMAL"/&gt;
 *     &lt;enumeration value="JOB_PRIORITY_HIGH"/&gt;
 *     &lt;enumeration value="JOB_PRIORITY_CRITICAL"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "PriorityEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum PriorityEnumeration {

    JOB_PRIORITY_LOW("JOB_PRIORITY_LOW"),
    JOB_PRIORITY_NORMAL("JOB_PRIORITY_NORMAL"),
    JOB_PRIORITY_HIGH("JOB_PRIORITY_HIGH"),
    JOB_PRIORITY_CRITICAL("JOB_PRIORITY_CRITICAL"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    PriorityEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PriorityEnumeration fromValue(String v) {
        for (PriorityEnumeration c: PriorityEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
