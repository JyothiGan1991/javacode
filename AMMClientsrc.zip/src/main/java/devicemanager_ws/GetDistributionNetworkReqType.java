
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetDistributionNetworkReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetDistributionNetworkReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DistributionNetworkID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetDistributionNetworkReqType", propOrder = {
    "distributionNetworkID"
})
public class GetDistributionNetworkReqType {

    @XmlElement(name = "DistributionNetworkID")
    protected long distributionNetworkID;

    /**
     * Gets the value of the distributionNetworkID property.
     * 
     */
    public long getDistributionNetworkID() {
        return distributionNetworkID;
    }

    /**
     * Sets the value of the distributionNetworkID property.
     * 
     */
    public void setDistributionNetworkID(long value) {
        this.distributionNetworkID = value;
    }

}
