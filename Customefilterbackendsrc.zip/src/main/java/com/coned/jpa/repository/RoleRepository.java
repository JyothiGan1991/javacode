package com.coned.jpa.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coned.model.User;
import com.coned.model.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long>{
	  List<Role> findByNameContaining(String name);
	  Optional<Role> findByName(String name);
}