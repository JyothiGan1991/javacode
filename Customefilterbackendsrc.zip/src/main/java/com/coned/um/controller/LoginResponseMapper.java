package com.coned.um.controller;

public class LoginResponseMapper {
//	private boolean Authenticated;
	private String userName;
	private String loginTime;
	private String[] userClaim;
	
	public String getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}
	public String[] getUserClaim() {
		return userClaim;
	}
	public void setUserClaim(String[] userClaim) {
		this.userClaim = userClaim;
	}

	/*
	 * public boolean isAuthenticated() { return Authenticated; } public void
	 * setAuthenticated(boolean authenticated) { Authenticated = authenticated; }
	 */
	public String getBearerToken() {
		return bearerToken;
	}
	public void setBearerToken(String token) {
		this.bearerToken = token;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String name) {
		userName = name;
	}
	private String bearerToken;
	private String message;
}
