
package com.oru.soap.poe.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oru.soap.poe.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _IncidentCount_QNAME = new QName("http://poe.oru.com/", "incidentCount");
    private final static QName _IncidentCountResponse_QNAME = new QName("http://poe.oru.com/", "incidentCountResponse");
    private final static QName _IsGasMain_QNAME = new QName("http://poe.oru.com/", "isGasMain");
    private final static QName _IsGasMainResponse_QNAME = new QName("http://poe.oru.com/", "isGasMainResponse");
    private final static QName _VerifyPole_QNAME = new QName("http://poe.oru.com/", "verifyPole");
    private final static QName _VerifyPoleResponse_QNAME = new QName("http://poe.oru.com/", "verifyPoleResponse");
    private final static QName _POEServiceException_QNAME = new QName("http://poe.oru.com/", "POEServiceException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oru.soap.poe.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link IncidentCount }
     * 
     */
    public IncidentCount createIncidentCount() {
        return new IncidentCount();
    }

    /**
     * Create an instance of {@link IncidentCountResponse }
     * 
     */
    public IncidentCountResponse createIncidentCountResponse() {
        return new IncidentCountResponse();
    }

    /**
     * Create an instance of {@link IsGasMain }
     * 
     */
    public IsGasMain createIsGasMain() {
        return new IsGasMain();
    }

    /**
     * Create an instance of {@link IsGasMainResponse }
     * 
     */
    public IsGasMainResponse createIsGasMainResponse() {
        return new IsGasMainResponse();
    }

    /**
     * Create an instance of {@link VerifyPole }
     * 
     */
    public VerifyPole createVerifyPole() {
        return new VerifyPole();
    }

    /**
     * Create an instance of {@link VerifyPoleResponse }
     * 
     */
    public VerifyPoleResponse createVerifyPoleResponse() {
        return new VerifyPoleResponse();
    }

    /**
     * Create an instance of {@link POEServiceException }
     * 
     */
    public POEServiceException createPOEServiceException() {
        return new POEServiceException();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IncidentCount }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link IncidentCount }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "incidentCount")
    public JAXBElement<IncidentCount> createIncidentCount(IncidentCount value) {
        return new JAXBElement<IncidentCount>(_IncidentCount_QNAME, IncidentCount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IncidentCountResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link IncidentCountResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "incidentCountResponse")
    public JAXBElement<IncidentCountResponse> createIncidentCountResponse(IncidentCountResponse value) {
        return new JAXBElement<IncidentCountResponse>(_IncidentCountResponse_QNAME, IncidentCountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsGasMain }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link IsGasMain }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "isGasMain")
    public JAXBElement<IsGasMain> createIsGasMain(IsGasMain value) {
        return new JAXBElement<IsGasMain>(_IsGasMain_QNAME, IsGasMain.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsGasMainResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link IsGasMainResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "isGasMainResponse")
    public JAXBElement<IsGasMainResponse> createIsGasMainResponse(IsGasMainResponse value) {
        return new JAXBElement<IsGasMainResponse>(_IsGasMainResponse_QNAME, IsGasMainResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyPole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link VerifyPole }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "verifyPole")
    public JAXBElement<VerifyPole> createVerifyPole(VerifyPole value) {
        return new JAXBElement<VerifyPole>(_VerifyPole_QNAME, VerifyPole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyPoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link VerifyPoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "verifyPoleResponse")
    public JAXBElement<VerifyPoleResponse> createVerifyPoleResponse(VerifyPoleResponse value) {
        return new JAXBElement<VerifyPoleResponse>(_VerifyPoleResponse_QNAME, VerifyPoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link POEServiceException }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link POEServiceException }{@code >}
     */
    @XmlElementDecl(namespace = "http://poe.oru.com/", name = "POEServiceException")
    public JAXBElement<POEServiceException> createPOEServiceException(POEServiceException value) {
        return new JAXBElement<POEServiceException>(_POEServiceException_QNAME, POEServiceException.class, null, value);
    }

}
