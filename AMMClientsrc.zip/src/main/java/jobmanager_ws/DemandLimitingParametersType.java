
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DemandLimitingParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DemandLimitingParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DemandThresholdInKW" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="DemandCalculationPeriodInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="DisconnectPeriodInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="CalculationDelayAfterReconnectInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DemandLimitingParametersType", propOrder = {
    "demandThresholdInKW",
    "demandCalculationPeriodInMinutes",
    "disconnectPeriodInMinutes",
    "calculationDelayAfterReconnectInMinutes"
})
public class DemandLimitingParametersType {

    @XmlElement(name = "DemandThresholdInKW")
    protected Double demandThresholdInKW;
    @XmlElement(name = "DemandCalculationPeriodInMinutes")
    protected Integer demandCalculationPeriodInMinutes;
    @XmlElement(name = "DisconnectPeriodInMinutes")
    protected Integer disconnectPeriodInMinutes;
    @XmlElement(name = "CalculationDelayAfterReconnectInMinutes")
    protected Integer calculationDelayAfterReconnectInMinutes;

    /**
     * Gets the value of the demandThresholdInKW property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDemandThresholdInKW() {
        return demandThresholdInKW;
    }

    /**
     * Sets the value of the demandThresholdInKW property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDemandThresholdInKW(Double value) {
        this.demandThresholdInKW = value;
    }

    /**
     * Gets the value of the demandCalculationPeriodInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDemandCalculationPeriodInMinutes() {
        return demandCalculationPeriodInMinutes;
    }

    /**
     * Sets the value of the demandCalculationPeriodInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDemandCalculationPeriodInMinutes(Integer value) {
        this.demandCalculationPeriodInMinutes = value;
    }

    /**
     * Gets the value of the disconnectPeriodInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDisconnectPeriodInMinutes() {
        return disconnectPeriodInMinutes;
    }

    /**
     * Sets the value of the disconnectPeriodInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDisconnectPeriodInMinutes(Integer value) {
        this.disconnectPeriodInMinutes = value;
    }

    /**
     * Gets the value of the calculationDelayAfterReconnectInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCalculationDelayAfterReconnectInMinutes() {
        return calculationDelayAfterReconnectInMinutes;
    }

    /**
     * Sets the value of the calculationDelayAfterReconnectInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCalculationDelayAfterReconnectInMinutes(Integer value) {
        this.calculationDelayAfterReconnectInMinutes = value;
    }

}
