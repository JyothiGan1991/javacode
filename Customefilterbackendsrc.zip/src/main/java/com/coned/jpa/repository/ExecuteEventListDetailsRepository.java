package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coned.model.ExecuteEventListDetails;

@Repository
public interface ExecuteEventListDetailsRepository extends JpaRepository<ExecuteEventListDetails, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
}