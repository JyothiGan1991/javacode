/**
 * 
 */
package com.coned.odsListener.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.coned.odsListener.dao.OdsMessageDao;
import com.coned.odsListener.model.ODSEvent;
import com.coned.odsListener.publisher.MessagePublisher;
import com.tibco.ods.EndDeviceEvent;
import com.tibco.ods.EndDeviceEventDetail;
import com.tibco.ods.EndDeviceEvents;
import com.tibco.ods.EndDeviceEventsEventMessageType;
import org.apache.commons.lang3.StringUtils;


/**
 * @author DATHATHRIA
 *
 */
@Component
public class MessageHandlerImpl implements MessageHandler {
	private static Logger logger = LoggerFactory.getLogger(MessageHandlerImpl.class);

	@Autowired
	private Environment env;
	
	@Autowired
	private OdsMessageDao dao;

	@Autowired
	@Qualifier("ceconyOutageQueuePublisher")
	MessagePublisher ceconyOutageQueuePublisher;
	
	@Autowired
	@Qualifier("ceconyRestoreQueuePublisher")
	MessagePublisher ceconyRestoreQueuePublisher;
	
	@Autowired
	@Qualifier("onrQueuePublisher")
	MessagePublisher onrQueuePublisher;
	
	@Value("#{'${onr.region.codes}'.split(',')}")
	private List<String> onrRegionCodes;
	
	@Value("#{'${cecony.region.codes.to.suppress}'.split(',')}")
	private List<String> ceconySuppressedRegions;

	private static final String DEVICE_TYPE = "device type";
	private static final String MAC_ID = "outage mac id";
	private static final String REGION_CODE = "region code";
	private static final String SERVICE_POINT_ID = "service point id";
	private static final String REBOOT_COUNTER = "reboot counter";
	private static final String IS_STATUS_DATETIME_ESTIMATED = "status datetime is estimated";
	private static final String VSO_OPEN = "VSO_OPEN";

	@Override
	public void handleODSEvent(JAXBElement<EndDeviceEventsEventMessageType> events) {
		EndDeviceEvents endDeviceEvents = events.getValue().getPayload().getEndDeviceEvents();
		logger.info("Number of events received: " + endDeviceEvents.getEndDeviceEvent().size());

		List<ODSEvent> listOfOdsEvents = new ArrayList<ODSEvent>();
		List<ODSEvent> listOfCeconyOutageEvents = new ArrayList<ODSEvent>();
		List<ODSEvent> listOfCeconyRestoreEvents = new ArrayList<ODSEvent>();
		List<ODSEvent> listOfOnrEvents = new ArrayList<ODSEvent>();

		for (EndDeviceEvent event : endDeviceEvents.getEndDeviceEvent()) {
			Map<String, String> eventDetails = new HashMap<String, String>();
			for (EndDeviceEventDetail detail : event.getEndDeviceEventDetails()) {
				eventDetails.put(detail.getName().toLowerCase(), detail.getValue());
			}

			ODSEvent odsEvent = new ODSEvent();

			odsEvent.setDeviceUtilId(event.getAssets().getMRID());
			odsEvent.setEventType(event.getStatus().getValue());
			odsEvent.setMacAddress(event.getAssets().getNames().get(0).getName());
			odsEvent.setReason(event.getReason());
			odsEvent.setEndDeviceEventTypeRef(event.getEndDeviceEventType().getRef());
			odsEvent.setEventTime(event.getCreatedDateTime());
			odsEvent.setDeviceType(eventDetails.get(DEVICE_TYPE));
			odsEvent.setMacId(eventDetails.get(MAC_ID));
			odsEvent.setRegionCode(eventDetails.get(REGION_CODE));
			odsEvent.setServicePointId(eventDetails.get(SERVICE_POINT_ID));
			odsEvent.setRebootCounter(eventDetails.get(REBOOT_COUNTER));
			odsEvent.setIsStatusDateTimeEstimated(eventDetails.get(IS_STATUS_DATETIME_ESTIMATED) == "false" ? 0 : 1);

			listOfOdsEvents.add(odsEvent);
			
			String regionCode = odsEvent.getRegionCode();
			logger.info("********** OnR Region Codes: " + onrRegionCodes);
			logger.info("Region Code: " + regionCode);
			if (regionCode != null && onrRegionCodes.contains(regionCode.toUpperCase())) {
				logger.info("Adding to OnR events");
				listOfOnrEvents.add(odsEvent);
			} else {
				logger.info("Adding to Cecony events");
				logger.info("cecony region codes to suppress: "+ ceconySuppressedRegions);
				if (odsEvent.getEventType().toUpperCase().equals(VSO_OPEN)) {
						if(regionCode!=null && StringUtils.isNotBlank(regionCode.trim()) && !ceconySuppressedRegions.contains(regionCode.toUpperCase().trim())) 
							listOfCeconyOutageEvents.add(odsEvent);
					
				} else {
					listOfCeconyRestoreEvents.add(odsEvent);
				}
			}
		}

		dao.persistOdsMessage(listOfOdsEvents);
		
		if (listOfCeconyOutageEvents.size() > 0) {
			ceconyOutageQueuePublisher.publishMessage(listOfCeconyOutageEvents);
		}
		
		if (listOfCeconyRestoreEvents.size() > 0) {
			ceconyRestoreQueuePublisher.publishMessage(listOfCeconyRestoreEvents);
		}
		
		if (listOfOnrEvents.size() > 0) {
			if (Boolean.parseBoolean(env.getProperty("suppress.onr"))) {
				logger.info("OnR is suppressed. Ignoring the messages");
			} else {
				onrQueuePublisher.publishMessage(listOfOnrEvents);
				logger.info("OnR is unsuppressed. Forwarding the messages");
			}
		}
	}
}
