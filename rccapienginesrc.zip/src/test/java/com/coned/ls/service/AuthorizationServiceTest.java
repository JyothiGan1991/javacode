package com.coned.ls.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.repository.AuthorizationRepository;

import org.junit.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={AuthorizationService.class})
@AutoConfigureMockMvc
public class AuthorizationServiceTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private AuthorizationService authService = new AuthorizationServiceImpl();
	
	@Mock
	private AuthorizationRepository  authorizationRepository;
	
	private MockMvc mockMvc;
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void isOperatorAuthorizedTest(){
		try {
			Mockito.when(authorizationRepository.isOperatorAuthorized(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
			Boolean response = authService.isOperatorAuthorized(Mockito.anyString(), Mockito.anyString());
			Assert.assertEquals(true, response);
		} catch (OperatorAuthorizationException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void persistApiTest(){
		try {
			OperatorLoginDetail operatorLoginDetails = new OperatorLoginDetail();
			operatorLoginDetails.setAdid("XYZ");
			operatorLoginDetails.setApiKey("123XyzAbc");
			Mockito.when(authorizationRepository.persistApi(operatorLoginDetails)).thenReturn(operatorLoginDetails);
			
			OperatorLoginDetail persistApiResponse = authService.persistApi(operatorLoginDetails);
			Assert.assertEquals(operatorLoginDetails.getAdid(), persistApiResponse.getAdid());
		} catch (OperatorAuthorizationException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void isAPIEndpointAuthorizeedTest(){
		try {
			Mockito.when(authorizationRepository.isAPIEndpointAuthorizeed(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(true);
			Boolean response = authService.isAPIEndpointAuthorizeed(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt());
			Assert.assertEquals(true, response);
		} catch (OperatorAuthorizationException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getOperatorLoginDetailTest(){
		try {
			OperatorLoginDetail operatorLoginDetails = new OperatorLoginDetail();
			operatorLoginDetails.setAdid("XYZ");
			operatorLoginDetails.setApiKey("123XyzAbc");
			Mockito.when(authorizationRepository.getOperatorLoginDetail(Mockito.anyString(),Mockito.anyString())).thenReturn(operatorLoginDetails);
			
			OperatorLoginDetail getOperatorLoginDetailResponse = authService.getOperatorLoginDetail(Mockito.anyString(),Mockito.anyString());
			Assert.assertEquals(operatorLoginDetails.getAdid(), getOperatorLoginDetailResponse.getAdid());
		} catch (OperatorAuthorizationException e) {
			e.printStackTrace();
		}
	}
	
}
