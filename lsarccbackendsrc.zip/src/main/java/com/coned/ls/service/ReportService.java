package com.coned.ls.service;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.coned.ls.rest.RESTActionExecutor;

/**
 * 
 * Service class for RCC Report.
 *
 */
@Component
public class ReportService {

	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	

	public ResponseEntity<List<Map<String, Object>>> getEvents(String report_name){
		return restActionExecutor.getEvents(report_name);
	} 
	public ResponseEntity<List<Map<String, Object>>> getCWR(Map<String, Object> payload){
		return restActionExecutor.getCWR(payload);
	}
	public ResponseEntity<List<Map<String, Object>>> getCDR(Map<String, Object> payload){
		return restActionExecutor.getCDR(payload);
	}
	public ResponseEntity<List<Map<String, Object>>> getCRR(Map<String, Object> payload){
		return restActionExecutor.getCRR(payload);
	}
	public ResponseEntity<Map<String, Object>> getCER(Map<String, Object> payload){
		return restActionExecutor.getCER(payload);
	}
	public ResponseEntity<Map<String, Object>> getCMR(Map<String, Object> payload){
		return restActionExecutor.getCMR(payload);
	}

}