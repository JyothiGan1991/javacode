package com.oru.ui;

import org.springframework.web.bind.annotation.*;
import java.io.*;

@RestController
public class JarRunnerController {

    @PostMapping("/runJar")
    public String runJar(@RequestBody JarRequest request) {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder pb;

            if (request.getFolderPath() != null && !request.getFolderPath().isEmpty()) {

                if (os.contains("win")) {
                    pb = new ProcessBuilder("cmd.exe", "/c", "run.cmd");
                } else {
                    pb = new ProcessBuilder("sh", "run.sh");
                }

                pb.directory(new File(request.getFolderPath()));

            } else if (request.getJarPath() != null && !request.getJarPath().isEmpty()) {

                pb = new ProcessBuilder("java", "-jar", request.getJarPath());

            } else {
                return "Please provide folderPath or jarPath";
            }

            pb.redirectErrorStream(true);
            Process process = pb.start();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            StringBuilder output = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            int exitCode = process.waitFor();

            return "Exit Code: " + exitCode + "\n" + output;

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}