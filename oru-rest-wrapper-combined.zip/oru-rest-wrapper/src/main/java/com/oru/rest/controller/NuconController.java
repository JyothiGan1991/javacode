package com.oru.rest.controller;

import com.oru.rest.dto.AccountRequest;
import com.oru.rest.dto.ElectricInfoDto;
import com.oru.rest.dto.LocateInNrgViewerRequest;
import com.oru.rest.dto.PremiseRequest;
import com.oru.rest.dto.SendToNrgRequest;
import com.oru.rest.dto.SuccessResponse;
import com.oru.rest.dto.XYCoordinatesRequest;
import com.oru.rest.service.nucon.NuconSoapService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/nrg")
@Tag(name = "NRG - Nucon Services", description = "REST wrappers for Nucon SOAP operations")
@SecurityRequirement(name = "bearerAuth")
public class NuconController {

    private final NuconSoapService nuconSoapService;

    public NuconController(NuconSoapService nuconSoapService) {
        this.nuconSoapService = nuconSoapService;
    }

    @Operation(summary = "Get electric info by account")
    @PostMapping(value = "/electric-info/by-account", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByAccount(@RequestBody AccountRequest request) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByAccount(request));
    }

    @Operation(summary = "Get electric info by account (GET)")
    @GetMapping(value = "/electric-info/by-account", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByAccountGet(@RequestParam String account) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByAccount(new AccountRequest(account)));
    }

    @Operation(summary = "Get electric info by premise")
    @PostMapping(value = "/electric-info/by-premise", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByPremise(@RequestBody PremiseRequest request) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByPremise(request));
    }

    @Operation(summary = "Get electric info by premise (GET)")
    @GetMapping(value = "/electric-info/by-premise", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByPremiseGet(@RequestParam String premise) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByPremise(new PremiseRequest(premise)));
    }

    @Operation(summary = "Get electric info by XY coordinates")
    @PostMapping(value = "/electric-info/by-xy", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByXY(@RequestBody XYCoordinatesRequest request) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByXYCoordinates(request));
    }

    @Operation(summary = "Get electric info by XY coordinates (GET)")
    @GetMapping(value = "/electric-info/by-xy", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByXYGet(@RequestParam String x, @RequestParam String y) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByXYCoordinates(new XYCoordinatesRequest(x, y)));
    }

    @Operation(summary = "Send data to NRG")
    @PostMapping(value = "/send-to-nrg", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> sendToNRG(@RequestBody SendToNrgRequest request) {
        nuconSoapService.sendToNRG(request);
        return ResponseEntity.ok(new SuccessResponse(true, "sendToNRG completed"));
    }

    @Operation(summary = "Locate in NRG Viewer")
    @PostMapping(value = "/locate-in-nrg-viewer", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> locateInNRGViewer(@RequestBody LocateInNrgViewerRequest request) {
        nuconSoapService.locateInNRGViewer(request);
        return ResponseEntity.ok(new SuccessResponse(true, "locateInNRGViewer completed"));
    }
}
