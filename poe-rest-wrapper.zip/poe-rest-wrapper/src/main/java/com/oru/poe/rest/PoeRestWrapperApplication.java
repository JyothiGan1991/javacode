package com.oru.poe.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoeRestWrapperApplication {

    public static void main(String[] args) {
        SpringApplication.run(PoeRestWrapperApplication.class, args);
    }
}
