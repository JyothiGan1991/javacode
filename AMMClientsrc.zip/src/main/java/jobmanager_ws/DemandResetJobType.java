
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DemandResetJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DemandResetJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="DeviceGroupID" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="DeviceSearchKey" type="{http://www.w3.org/2001/XMLSchema}long" maxOccurs="unbounded"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="NumberRetries" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="Priority" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}PriorityType"/&gt;
 *         &lt;element name="PushResults" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}PushResultsType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="ForcedReset" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DemandResetJobType", propOrder = {
    "deviceGroupID",
    "deviceMacID",
    "deviceSearchKey",
    "numberRetries",
    "priority",
    "pushResults"
})
public class DemandResetJobType {

    @XmlElement(name = "DeviceGroupID", type = Long.class)
    protected List<Long> deviceGroupID;
    @XmlElement(name = "DeviceMacID")
    protected List<String> deviceMacID;
    @XmlElement(name = "DeviceSearchKey", type = Long.class)
    protected List<Long> deviceSearchKey;
    @XmlElement(name = "NumberRetries")
    protected int numberRetries;
    @XmlElement(name = "Priority", required = true)
    protected PriorityType priority;
    @XmlElement(name = "PushResults")
    protected PushResultsType pushResults;
    @XmlAttribute(name = "ForcedReset")
    protected Boolean forcedReset;

    /**
     * Gets the value of the deviceGroupID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceGroupID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceGroupID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceGroupID() {
        if (deviceGroupID == null) {
            deviceGroupID = new ArrayList<Long>();
        }
        return this.deviceGroupID;
    }

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the deviceSearchKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceSearchKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceSearchKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Long }
     * 
     * 
     */
    public List<Long> getDeviceSearchKey() {
        if (deviceSearchKey == null) {
            deviceSearchKey = new ArrayList<Long>();
        }
        return this.deviceSearchKey;
    }

    /**
     * Gets the value of the numberRetries property.
     * 
     */
    public int getNumberRetries() {
        return numberRetries;
    }

    /**
     * Sets the value of the numberRetries property.
     * 
     */
    public void setNumberRetries(int value) {
        this.numberRetries = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link PriorityType }
     *     
     */
    public PriorityType getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityType }
     *     
     */
    public void setPriority(PriorityType value) {
        this.priority = value;
    }

    /**
     * Gets the value of the pushResults property.
     * 
     * @return
     *     possible object is
     *     {@link PushResultsType }
     *     
     */
    public PushResultsType getPushResults() {
        return pushResults;
    }

    /**
     * Sets the value of the pushResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link PushResultsType }
     *     
     */
    public void setPushResults(PushResultsType value) {
        this.pushResults = value;
    }

    /**
     * Gets the value of the forcedReset property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isForcedReset() {
        if (forcedReset == null) {
            return false;
        } else {
            return forcedReset;
        }
    }

    /**
     * Sets the value of the forcedReset property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForcedReset(Boolean value) {
        this.forcedReset = value;
    }

}
