package com.coned.rd.beans;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

public class Meter {

	private BigDecimal id, requestId;

	private String meter, status;

	private ZonedDateTime resultTime;

	public Meter() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Meter(BigDecimal id, BigDecimal requestId, String meter, String status, ZonedDateTime rTime) {
		this.id = id;
		this.requestId = requestId;
		this.meter = meter;
		this.status = status;
		this.resultTime = rTime;
	}

	public Meter(BigDecimal id, BigDecimal requestId, String meter, String status) {
		this.id = id;
		this.requestId = requestId;
		this.meter = meter;
		this.status = status;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public BigDecimal getRequestId() {
		return requestId;
	}

	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}

	public String getMeter() {
		return meter;
	}

	public void setMeter(String meter) {
		this.meter = meter;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ZonedDateTime getResultTime() {
		return resultTime;
	}

	public void setResultTime(ZonedDateTime resultTime) {
		this.resultTime = resultTime;
	}

	@Override
	public String toString() {
		return "Meter [id=" + id + ", requestId=" + requestId + ", meter=" + meter + ", status=" + status
				+ ", resultTime=" + resultTime + "]";
	}

}
