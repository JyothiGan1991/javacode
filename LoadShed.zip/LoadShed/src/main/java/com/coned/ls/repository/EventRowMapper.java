package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.Meter;

public class EventRowMapper implements RowMapper<Meter> {

	@Override
	public Meter mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Meter(rs.getBigDecimal(1), rs.getBigDecimal(2), rs.getString(3), rs.getString(4), rs.getString(5),
				rs.getInt(6));
	}
}