
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateIMUTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateIMUTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ZeroFlowThreshold" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="LeakDetectionThreshold" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="EncoderNumber" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="EncoderType" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="PulseWeight" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="RouteNumber" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableString" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult1" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult2" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="RadioLinkResult3" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableDouble" minOccurs="0"/&gt;
 *         &lt;element name="IMUGroupID" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="TransmitDayStartMin" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="TransmitIntervalMin" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="TransmitOffsetMin" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;element name="TransmitRandSec" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableInt" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="IMUTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="IMUTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateIMUTypeReq", propOrder = {
    "zeroFlowThreshold",
    "leakDetectionThreshold",
    "encoderNumber",
    "encoderType",
    "pulseWeight",
    "routeNumber",
    "radioLinkResult1",
    "radioLinkResult2",
    "radioLinkResult3",
    "imuGroupID",
    "transmitDayStartMin",
    "transmitIntervalMin",
    "transmitOffsetMin",
    "transmitRandSec",
    "imuTypeConfigID",
    "imuTypeConfigName"
})
public class UpdateIMUTypeReq {

    @XmlElement(name = "ZeroFlowThreshold")
    protected NullableDouble zeroFlowThreshold;
    @XmlElement(name = "LeakDetectionThreshold")
    protected NullableDouble leakDetectionThreshold;
    @XmlElement(name = "EncoderNumber")
    protected NullableString encoderNumber;
    @XmlElement(name = "EncoderType")
    protected NullableString encoderType;
    @XmlElement(name = "PulseWeight")
    protected NullableDouble pulseWeight;
    @XmlElement(name = "RouteNumber")
    protected NullableString routeNumber;
    @XmlElement(name = "RadioLinkResult1")
    protected NullableDouble radioLinkResult1;
    @XmlElement(name = "RadioLinkResult2")
    protected NullableDouble radioLinkResult2;
    @XmlElement(name = "RadioLinkResult3")
    protected NullableDouble radioLinkResult3;
    @XmlElement(name = "IMUGroupID")
    protected NullableInt imuGroupID;
    @XmlElement(name = "TransmitDayStartMin")
    protected NullableInt transmitDayStartMin;
    @XmlElement(name = "TransmitIntervalMin")
    protected NullableInt transmitIntervalMin;
    @XmlElement(name = "TransmitOffsetMin")
    protected NullableInt transmitOffsetMin;
    @XmlElement(name = "TransmitRandSec")
    protected NullableInt transmitRandSec;
    @XmlElement(name = "IMUTypeConfigID")
    protected Long imuTypeConfigID;
    @XmlElement(name = "IMUTypeConfigName")
    protected String imuTypeConfigName;

    /**
     * Gets the value of the zeroFlowThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getZeroFlowThreshold() {
        return zeroFlowThreshold;
    }

    /**
     * Sets the value of the zeroFlowThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setZeroFlowThreshold(NullableDouble value) {
        this.zeroFlowThreshold = value;
    }

    /**
     * Gets the value of the leakDetectionThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getLeakDetectionThreshold() {
        return leakDetectionThreshold;
    }

    /**
     * Sets the value of the leakDetectionThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setLeakDetectionThreshold(NullableDouble value) {
        this.leakDetectionThreshold = value;
    }

    /**
     * Gets the value of the encoderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getEncoderNumber() {
        return encoderNumber;
    }

    /**
     * Sets the value of the encoderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setEncoderNumber(NullableString value) {
        this.encoderNumber = value;
    }

    /**
     * Gets the value of the encoderType property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getEncoderType() {
        return encoderType;
    }

    /**
     * Sets the value of the encoderType property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setEncoderType(NullableString value) {
        this.encoderType = value;
    }

    /**
     * Gets the value of the pulseWeight property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getPulseWeight() {
        return pulseWeight;
    }

    /**
     * Sets the value of the pulseWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setPulseWeight(NullableDouble value) {
        this.pulseWeight = value;
    }

    /**
     * Gets the value of the routeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link NullableString }
     *     
     */
    public NullableString getRouteNumber() {
        return routeNumber;
    }

    /**
     * Sets the value of the routeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableString }
     *     
     */
    public void setRouteNumber(NullableString value) {
        this.routeNumber = value;
    }

    /**
     * Gets the value of the radioLinkResult1 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getRadioLinkResult1() {
        return radioLinkResult1;
    }

    /**
     * Sets the value of the radioLinkResult1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setRadioLinkResult1(NullableDouble value) {
        this.radioLinkResult1 = value;
    }

    /**
     * Gets the value of the radioLinkResult2 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getRadioLinkResult2() {
        return radioLinkResult2;
    }

    /**
     * Sets the value of the radioLinkResult2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setRadioLinkResult2(NullableDouble value) {
        this.radioLinkResult2 = value;
    }

    /**
     * Gets the value of the radioLinkResult3 property.
     * 
     * @return
     *     possible object is
     *     {@link NullableDouble }
     *     
     */
    public NullableDouble getRadioLinkResult3() {
        return radioLinkResult3;
    }

    /**
     * Sets the value of the radioLinkResult3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableDouble }
     *     
     */
    public void setRadioLinkResult3(NullableDouble value) {
        this.radioLinkResult3 = value;
    }

    /**
     * Gets the value of the imuGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getIMUGroupID() {
        return imuGroupID;
    }

    /**
     * Sets the value of the imuGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setIMUGroupID(NullableInt value) {
        this.imuGroupID = value;
    }

    /**
     * Gets the value of the transmitDayStartMin property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getTransmitDayStartMin() {
        return transmitDayStartMin;
    }

    /**
     * Sets the value of the transmitDayStartMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setTransmitDayStartMin(NullableInt value) {
        this.transmitDayStartMin = value;
    }

    /**
     * Gets the value of the transmitIntervalMin property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getTransmitIntervalMin() {
        return transmitIntervalMin;
    }

    /**
     * Sets the value of the transmitIntervalMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setTransmitIntervalMin(NullableInt value) {
        this.transmitIntervalMin = value;
    }

    /**
     * Gets the value of the transmitOffsetMin property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getTransmitOffsetMin() {
        return transmitOffsetMin;
    }

    /**
     * Sets the value of the transmitOffsetMin property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setTransmitOffsetMin(NullableInt value) {
        this.transmitOffsetMin = value;
    }

    /**
     * Gets the value of the transmitRandSec property.
     * 
     * @return
     *     possible object is
     *     {@link NullableInt }
     *     
     */
    public NullableInt getTransmitRandSec() {
        return transmitRandSec;
    }

    /**
     * Sets the value of the transmitRandSec property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableInt }
     *     
     */
    public void setTransmitRandSec(NullableInt value) {
        this.transmitRandSec = value;
    }

    /**
     * Gets the value of the imuTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getIMUTypeConfigID() {
        return imuTypeConfigID;
    }

    /**
     * Sets the value of the imuTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setIMUTypeConfigID(Long value) {
        this.imuTypeConfigID = value;
    }

    /**
     * Gets the value of the imuTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMUTypeConfigName() {
        return imuTypeConfigName;
    }

    /**
     * Sets the value of the imuTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMUTypeConfigName(String value) {
        this.imuTypeConfigName = value;
    }

}
