
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PingSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PingSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="JobExecutionTime"/&gt;
 *     &lt;enumeration value="PacketLost"/&gt;
 *     &lt;enumeration value="RoundtripMS"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "PingSortColumnEnumeration")
@XmlEnum
public enum PingSortColumnEnumeration {

    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("JobExecutionTime")
    JOB_EXECUTION_TIME("JobExecutionTime"),
    @XmlEnumValue("PacketLost")
    PACKET_LOST("PacketLost"),
    @XmlEnumValue("RoundtripMS")
    ROUNDTRIP_MS("RoundtripMS");
    private final String value;

    PingSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PingSortColumnEnumeration fromValue(String v) {
        for (PingSortColumnEnumeration c: PingSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
