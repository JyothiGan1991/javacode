
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExecutionStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExecutionStatusType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}ExecutionStatusEnumeration"/>
 *         &lt;element name="LocalizedValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExecutionStatusType", propOrder = {
    "name",
    "localizedValue"
})
public class ExecutionStatusType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected ExecutionStatusEnumeration name;
    @XmlElement(name = "LocalizedValue")
    protected String localizedValue;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link ExecutionStatusEnumeration }
     *     
     */
    public ExecutionStatusEnumeration getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExecutionStatusEnumeration }
     *     
     */
    public void setName(ExecutionStatusEnumeration value) {
        this.name = value;
    }

    /**
     * Gets the value of the localizedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedValue() {
        return localizedValue;
    }

    /**
     * Sets the value of the localizedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedValue(String value) {
        this.localizedValue = value;
    }

}
