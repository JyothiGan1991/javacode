package com.coned.jpa.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coned.model.ExecuteEventListDetails;
import com.coned.model.FinalizeEventListDetails;
import com.coned.model.UserLogin;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.ExecuteEventListDetailsRepository;
import com.coned.jpa.repository.FinalizeEventListDetailsRepository;
import com.coned.jpa.repository.UserLoginRepository;

@RestController
public class ExecuteEventListDetailsController {

	@Autowired
	private ExecuteEventListDetailsRepository exeRep;

	@GetMapping("/executeEvents")
	public List getFinalizedEventListDetails2() {
		List<ExecuteEventListDetails> events = exeRep.findAll();
		Map<String, List<ExecuteEventListDetails>> byEventList = events.stream()
				.collect(Collectors.groupingBy(ExecuteEventListDetails::getBorough));

		byEventList.forEach((k, v) -> System.out.println("EventId:" + k + "   " + ((List<ExecuteEventListDetails>) v)
				.stream().map(m -> m.getEventname()).collect(Collectors.joining(","))));

		String[] keys = new String[byEventList.size()];
		Object[] values = new Object[byEventList.size()];
		int index = 0;
		List allevents = new ArrayList();
		Map map = new HashMap();
		for (Entry<String, List<ExecuteEventListDetails>> mapEntry : byEventList.entrySet()) {
			map = new HashMap();
			keys[index] = mapEntry.getKey();
			map.put("boroughName", keys[index]);
			values[index] = mapEntry.getValue();
			map.put("events", values[index]);
			allevents.add(map);
			index++;
		}

		return allevents;
	}

	@GetMapping("/executeEvents/{id}")
	public ResponseEntity<ExecuteEventListDetails> getFinalizedEventListDetailsById(
			@PathVariable(value = "id") Long rEventDetailsId) throws ResourceMissingException {
		ExecuteEventListDetails rEventDetails = exeRep.findById(rEventDetailsId).orElseThrow(
				() -> new ResourceMissingException("ExecuteEventListDetails not found :: " + rEventDetailsId));
		return ResponseEntity.ok().body(rEventDetails);
	}

	@PostMapping("/executeEvents")
	public ExecuteEventListDetails createExecuteEvent(@Valid @RequestBody ExecuteEventListDetails revent) {
		return exeRep.save(revent);
	}

	@DeleteMapping("/executeEvents/{id}")
	@Transactional
	public Map<String, Boolean> deleteUser(@PathVariable(value = "id") Long rEventId) throws ResourceMissingException {
		ExecuteEventListDetails rEvent = exeRep.findById(rEventId)
				.orElseThrow(() -> new ResourceMissingException("ExecuteEventListDetails not found :: " + rEventId));

		exeRep.delete(rEvent);
		/*
		 * int a = 10/0; System.out.println(a);
		 */
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
