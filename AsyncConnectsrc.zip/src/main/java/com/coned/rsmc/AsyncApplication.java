package com.coned.rsmc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@EnableAutoConfiguration
@SpringBootApplication(scanBasePackages = { "com.coned" })
public class AsyncApplication {
/*
	@Value("${connect_timeout}")
	private int connectTimeout;

	@Value("${read_timeout}")
	private int readTimeout;*/

	/**
	 * Builder used to configure and create this template to perform HTTP requests.
	 * Configured the connect and read timeouts.
	 * 
	 * @param builder the rest template builder
	 * @return the rest template
	 */
	@Bean
	public RestTemplate getRestTemplate(RestTemplateBuilder builder) {

	/*	return builder.setConnectTimeout(Duration.ofMillis(connectTimeout))
				.setReadTimeout(Duration.ofMillis(readTimeout)).build();*/
		
	/*	  HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
	       requestFactory.setReadTimeout(readTimeout);
	       requestFactory.setConnectTimeout(connectTimeout);
	       return new RestTemplate(requestFactory);*/
	       
	     return new RestTemplate();
	}

	public static void main(String[] args) {
		// close the application context to shut down the custom ExecutorService
		SpringApplication.run(AsyncApplication.class, args).close();
	}
}