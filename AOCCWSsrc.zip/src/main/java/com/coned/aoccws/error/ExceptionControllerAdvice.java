package com.coned.aoccws.error;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import org.springframework.http.HttpStatusCode;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.coned.aoccws.beans.AoccResponse;

/**
 * Controller for handling Global exceptions
 */
@ControllerAdvice
public class ExceptionControllerAdvice extends ResponseEntityExceptionHandler {	 
	private final static Logger logger = LoggerFactory.getLogger(ExceptionControllerAdvice.class);
	
	@Override
	protected ResponseEntity<Object> handleTypeMismatch(
	        TypeMismatchException ex,
	        HttpHeaders headers,
	        HttpStatusCode status,
	        WebRequest request) {

	    logger.error("Error[" + ex + "] captured for request[" + request + "]");

	    char quotes = '"';
	    String error = "Invalid date " + quotes + ex.getValue() + quotes
	            + ".. Please enter date in yyyy-MM-dd HH:mm:ss.";

	    AoccResponse res = new AoccResponse(Boolean.FALSE, error);

	    return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
	}

	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
	        MethodArgumentNotValidException exception,
	        HttpHeaders headers,
	        HttpStatusCode status,
	        WebRequest request) {

	    logger.error("Error[" + exception + "] captured for request[" + request + "]");
	    logger.error("Error Count " + exception.getBindingResult().getErrorCount());

	    BindingResult bindingResult = exception.getBindingResult();

	    List<String> errormsg = new ArrayList<>();

	    bindingResult.getAllErrors()
	            .forEach(error -> errormsg.add(error.getDefaultMessage()));

	    logger.error("Error Msg: " + errormsg);

	    return new ResponseEntity<>(
	            new AoccResponse(Boolean.FALSE, errormsg.toString()),
	            HttpStatus.BAD_REQUEST);
	}

	  
	@ExceptionHandler(ConstraintViolationException.class)
    public final ResponseEntity<?> handleConstraintViolation(
                                            ConstraintViolationException ex,
                                            WebRequest request){
		logger.error("Error[" + ex +"] captured for request[" + request +"]");
        List<String> details = ex.getConstraintViolations()
                                    .parallelStream()
                                    .map(e -> e.getMessage())
                                    .collect(Collectors.toList());
       /* ErrorResponse errorDetails = new ErrorResponse(LocalDateTime.now(), "Bad Request",
        		details.toString());*/
        return new ResponseEntity<>(new AoccResponse(Boolean.FALSE, details.toString()), HttpStatus.BAD_REQUEST);
    }
	
	/**
	 * Set up and send the user the default error view
	 * 
	 * @param ex
	 *            the Exception
	 * @return the ErrorResponse
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> exceptionHandler(Exception ex) {
		logger.error("" + ex);
		/*ErrorResponse error = new ErrorResponse();
		error.setTimestamp(LocalDateTime.now());				 
		error.setMessage(ex.getMessage());*/
		return new ResponseEntity<>(new AoccResponse(Boolean.FALSE, ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		 
	}
	

	/**
	 * Convert a predefined exception to an HTTP Status code
	 * 
	 * @param ex
	 *            the DashboardException
	 * @return the ErrorResponse
	 */
	@ExceptionHandler(AMMException.class)
	public ResponseEntity<?> handleAMMException(Exception ex) {
		logger.error("" + ex);
		ErrorResponse error = new ErrorResponse();
		error.setTimestamp(LocalDateTime.now());
		ResponseEntity<AoccResponse> obj = null;
		if (ex.getMessage().startsWith("Found an active record")) {			
			error.setMessage(ex.getMessage());
			obj = new ResponseEntity<>(new AoccResponse(Boolean.FALSE, ex.getMessage()), HttpStatus.CONFLICT);
		}
		else {
			obj = new ResponseEntity<>(new AoccResponse(Boolean.FALSE, "Error processing the request. Please try again later."), 
					HttpStatus.UNPROCESSABLE_ENTITY);
		}
		return obj;
	}

	@ExceptionHandler({ DataIntegrityViolationException.class, SQLIntegrityConstraintViolationException.class,SQLException.class, DataAccessException.class })
	public ResponseEntity<?> handleConflictException(final Exception e) {
		logger.error("" + e);		
		return new ResponseEntity<>(new AoccResponse(Boolean.FALSE, "Error processing the request. Please try again later."), HttpStatus.UNPROCESSABLE_ENTITY);
	}
	

}
