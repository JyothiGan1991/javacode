/**
 * 
 */
package com.coned.odsListener.publisher;

import java.util.List;

import com.coned.odsListener.model.ODSEvent;

/**
 * @author DATHATHRIA
 *
 */
public interface MessagePublisher {
	void publishMessage(List<ODSEvent> listOfOdsEvents);
}
