
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetAlarmStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetAlarmStatusType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AlarmID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetAlarmStatusType", propOrder = {
    "alarmID",
    "macID"
})
public class GetAlarmStatusType {

    @XmlElement(name = "AlarmID")
    protected long alarmID;
    @XmlElement(name = "MacID", required = true)
    protected String macID;

    /**
     * Gets the value of the alarmID property.
     * 
     */
    public long getAlarmID() {
        return alarmID;
    }

    /**
     * Sets the value of the alarmID property.
     * 
     */
    public void setAlarmID(long value) {
        this.alarmID = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

}
