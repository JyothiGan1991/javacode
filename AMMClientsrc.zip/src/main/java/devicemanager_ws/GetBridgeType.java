
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetBridgeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetBridgeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BridgeType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BridgeTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BridgeTypeConfig" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetBridgeType", propOrder = {
    "bridgeTypeConfig"
})
public class GetBridgeType
    extends BridgeType
{

    @XmlElement(name = "BridgeTypeConfig")
    protected BridgeTypeConfig bridgeTypeConfig;

    /**
     * Gets the value of the bridgeTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link BridgeTypeConfig }
     *     
     */
    public BridgeTypeConfig getBridgeTypeConfig() {
        return bridgeTypeConfig;
    }

    /**
     * Sets the value of the bridgeTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link BridgeTypeConfig }
     *     
     */
    public void setBridgeTypeConfig(BridgeTypeConfig value) {
        this.bridgeTypeConfig = value;
    }

}
