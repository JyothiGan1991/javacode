
package com.ssn.schema.service.v2_6.eventmanager;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetSubscriptionStatusResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetSubscriptionStatusResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="eventSubscriptionStatus" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}EventSubscriptionStatusType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetSubscriptionStatusResponseType", propOrder = {
    "eventSubscriptionStatus"
})
public class GetSubscriptionStatusResponseType {

    protected List<EventSubscriptionStatusType> eventSubscriptionStatus;

    /**
     * Gets the value of the eventSubscriptionStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventSubscriptionStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventSubscriptionStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EventSubscriptionStatusType }
     * 
     * 
     */
    public List<EventSubscriptionStatusType> getEventSubscriptionStatus() {
        if (eventSubscriptionStatus == null) {
            eventSubscriptionStatus = new ArrayList<EventSubscriptionStatusType>();
        }
        return this.eventSubscriptionStatus;
    }

}
