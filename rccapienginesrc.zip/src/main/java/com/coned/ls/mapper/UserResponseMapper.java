package com.coned.ls.mapper;


public class UserResponseMapper {

	
	private String message;
	private boolean isSuccess;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public UserResponseMapper(String message, boolean isSuccess) {
		super();
		this.message = message;
		this.isSuccess = isSuccess;
	}
	public UserResponseMapper() {
		super();
	}
	
	
	
}
