
package deviceresults_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LogReadType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LogReadType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;attribute name="LastCalibratedTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CalibratorName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="LastProgramTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ProgrammerName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ProgramCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="DemandResetCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastDemandResetTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CommSessionCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastCommSessionTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="BadPasswordCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="RTPEntryCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastRTPEntryTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CumulativePowerOutageSeconds" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="PowerOutageCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastPowerOutageTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="EEPROMWriteCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastTLCUpdateTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="TLCName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="LastTransInaccAdjustTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="TransInaccAdjustName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="LastTimeChangeTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="CumulativeSustainedOutageMinutes" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="SustainedOutageCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="MomentaryOutageCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="MomentaryEventCount" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="LastAMRCommTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="GatewayCollectedTime" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LogReadType")
public class LogReadType {

    @XmlAttribute(name = "LastCalibratedTime")
    protected String lastCalibratedTime;
    @XmlAttribute(name = "CalibratorName")
    protected String calibratorName;
    @XmlAttribute(name = "LastProgramTime")
    protected String lastProgramTime;
    @XmlAttribute(name = "ProgrammerName")
    protected String programmerName;
    @XmlAttribute(name = "ProgramCount")
    protected Integer programCount;
    @XmlAttribute(name = "DemandResetCount")
    protected Integer demandResetCount;
    @XmlAttribute(name = "LastDemandResetTime")
    protected String lastDemandResetTime;
    @XmlAttribute(name = "CommSessionCount")
    protected Integer commSessionCount;
    @XmlAttribute(name = "LastCommSessionTime")
    protected String lastCommSessionTime;
    @XmlAttribute(name = "BadPasswordCount")
    protected Integer badPasswordCount;
    @XmlAttribute(name = "RTPEntryCount")
    protected Integer rtpEntryCount;
    @XmlAttribute(name = "LastRTPEntryTime")
    protected String lastRTPEntryTime;
    @XmlAttribute(name = "CumulativePowerOutageSeconds")
    protected Integer cumulativePowerOutageSeconds;
    @XmlAttribute(name = "PowerOutageCount")
    protected Integer powerOutageCount;
    @XmlAttribute(name = "LastPowerOutageTime")
    protected String lastPowerOutageTime;
    @XmlAttribute(name = "EEPROMWriteCount")
    protected Integer eepromWriteCount;
    @XmlAttribute(name = "LastTLCUpdateTime")
    protected String lastTLCUpdateTime;
    @XmlAttribute(name = "TLCName")
    protected String tlcName;
    @XmlAttribute(name = "LastTransInaccAdjustTime")
    protected String lastTransInaccAdjustTime;
    @XmlAttribute(name = "TransInaccAdjustName")
    protected String transInaccAdjustName;
    @XmlAttribute(name = "LastTimeChangeTime")
    protected String lastTimeChangeTime;
    @XmlAttribute(name = "CumulativeSustainedOutageMinutes")
    protected Integer cumulativeSustainedOutageMinutes;
    @XmlAttribute(name = "SustainedOutageCount")
    protected Integer sustainedOutageCount;
    @XmlAttribute(name = "MomentaryOutageCount")
    protected Integer momentaryOutageCount;
    @XmlAttribute(name = "MomentaryEventCount")
    protected Integer momentaryEventCount;
    @XmlAttribute(name = "LastAMRCommTime")
    protected String lastAMRCommTime;
    @XmlAttribute(name = "GatewayCollectedTime")
    protected String gatewayCollectedTime;

    /**
     * Gets the value of the lastCalibratedTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastCalibratedTime() {
        return lastCalibratedTime;
    }

    /**
     * Sets the value of the lastCalibratedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastCalibratedTime(String value) {
        this.lastCalibratedTime = value;
    }

    /**
     * Gets the value of the calibratorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalibratorName() {
        return calibratorName;
    }

    /**
     * Sets the value of the calibratorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalibratorName(String value) {
        this.calibratorName = value;
    }

    /**
     * Gets the value of the lastProgramTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastProgramTime() {
        return lastProgramTime;
    }

    /**
     * Sets the value of the lastProgramTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastProgramTime(String value) {
        this.lastProgramTime = value;
    }

    /**
     * Gets the value of the programmerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgrammerName() {
        return programmerName;
    }

    /**
     * Sets the value of the programmerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgrammerName(String value) {
        this.programmerName = value;
    }

    /**
     * Gets the value of the programCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProgramCount() {
        return programCount;
    }

    /**
     * Sets the value of the programCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProgramCount(Integer value) {
        this.programCount = value;
    }

    /**
     * Gets the value of the demandResetCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDemandResetCount() {
        return demandResetCount;
    }

    /**
     * Sets the value of the demandResetCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDemandResetCount(Integer value) {
        this.demandResetCount = value;
    }

    /**
     * Gets the value of the lastDemandResetTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastDemandResetTime() {
        return lastDemandResetTime;
    }

    /**
     * Sets the value of the lastDemandResetTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastDemandResetTime(String value) {
        this.lastDemandResetTime = value;
    }

    /**
     * Gets the value of the commSessionCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCommSessionCount() {
        return commSessionCount;
    }

    /**
     * Sets the value of the commSessionCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCommSessionCount(Integer value) {
        this.commSessionCount = value;
    }

    /**
     * Gets the value of the lastCommSessionTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastCommSessionTime() {
        return lastCommSessionTime;
    }

    /**
     * Sets the value of the lastCommSessionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastCommSessionTime(String value) {
        this.lastCommSessionTime = value;
    }

    /**
     * Gets the value of the badPasswordCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBadPasswordCount() {
        return badPasswordCount;
    }

    /**
     * Sets the value of the badPasswordCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBadPasswordCount(Integer value) {
        this.badPasswordCount = value;
    }

    /**
     * Gets the value of the rtpEntryCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRTPEntryCount() {
        return rtpEntryCount;
    }

    /**
     * Sets the value of the rtpEntryCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRTPEntryCount(Integer value) {
        this.rtpEntryCount = value;
    }

    /**
     * Gets the value of the lastRTPEntryTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastRTPEntryTime() {
        return lastRTPEntryTime;
    }

    /**
     * Sets the value of the lastRTPEntryTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastRTPEntryTime(String value) {
        this.lastRTPEntryTime = value;
    }

    /**
     * Gets the value of the cumulativePowerOutageSeconds property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCumulativePowerOutageSeconds() {
        return cumulativePowerOutageSeconds;
    }

    /**
     * Sets the value of the cumulativePowerOutageSeconds property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCumulativePowerOutageSeconds(Integer value) {
        this.cumulativePowerOutageSeconds = value;
    }

    /**
     * Gets the value of the powerOutageCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPowerOutageCount() {
        return powerOutageCount;
    }

    /**
     * Sets the value of the powerOutageCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPowerOutageCount(Integer value) {
        this.powerOutageCount = value;
    }

    /**
     * Gets the value of the lastPowerOutageTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPowerOutageTime() {
        return lastPowerOutageTime;
    }

    /**
     * Sets the value of the lastPowerOutageTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPowerOutageTime(String value) {
        this.lastPowerOutageTime = value;
    }

    /**
     * Gets the value of the eepromWriteCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEEPROMWriteCount() {
        return eepromWriteCount;
    }

    /**
     * Sets the value of the eepromWriteCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEEPROMWriteCount(Integer value) {
        this.eepromWriteCount = value;
    }

    /**
     * Gets the value of the lastTLCUpdateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTLCUpdateTime() {
        return lastTLCUpdateTime;
    }

    /**
     * Sets the value of the lastTLCUpdateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTLCUpdateTime(String value) {
        this.lastTLCUpdateTime = value;
    }

    /**
     * Gets the value of the tlcName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTLCName() {
        return tlcName;
    }

    /**
     * Sets the value of the tlcName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTLCName(String value) {
        this.tlcName = value;
    }

    /**
     * Gets the value of the lastTransInaccAdjustTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTransInaccAdjustTime() {
        return lastTransInaccAdjustTime;
    }

    /**
     * Sets the value of the lastTransInaccAdjustTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTransInaccAdjustTime(String value) {
        this.lastTransInaccAdjustTime = value;
    }

    /**
     * Gets the value of the transInaccAdjustName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransInaccAdjustName() {
        return transInaccAdjustName;
    }

    /**
     * Sets the value of the transInaccAdjustName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransInaccAdjustName(String value) {
        this.transInaccAdjustName = value;
    }

    /**
     * Gets the value of the lastTimeChangeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTimeChangeTime() {
        return lastTimeChangeTime;
    }

    /**
     * Sets the value of the lastTimeChangeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTimeChangeTime(String value) {
        this.lastTimeChangeTime = value;
    }

    /**
     * Gets the value of the cumulativeSustainedOutageMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCumulativeSustainedOutageMinutes() {
        return cumulativeSustainedOutageMinutes;
    }

    /**
     * Sets the value of the cumulativeSustainedOutageMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCumulativeSustainedOutageMinutes(Integer value) {
        this.cumulativeSustainedOutageMinutes = value;
    }

    /**
     * Gets the value of the sustainedOutageCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSustainedOutageCount() {
        return sustainedOutageCount;
    }

    /**
     * Sets the value of the sustainedOutageCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSustainedOutageCount(Integer value) {
        this.sustainedOutageCount = value;
    }

    /**
     * Gets the value of the momentaryOutageCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMomentaryOutageCount() {
        return momentaryOutageCount;
    }

    /**
     * Sets the value of the momentaryOutageCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMomentaryOutageCount(Integer value) {
        this.momentaryOutageCount = value;
    }

    /**
     * Gets the value of the momentaryEventCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMomentaryEventCount() {
        return momentaryEventCount;
    }

    /**
     * Sets the value of the momentaryEventCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMomentaryEventCount(Integer value) {
        this.momentaryEventCount = value;
    }

    /**
     * Gets the value of the lastAMRCommTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastAMRCommTime() {
        return lastAMRCommTime;
    }

    /**
     * Sets the value of the lastAMRCommTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastAMRCommTime(String value) {
        this.lastAMRCommTime = value;
    }

    /**
     * Gets the value of the gatewayCollectedTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayCollectedTime() {
        return gatewayCollectedTime;
    }

    /**
     * Sets the value of the gatewayCollectedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayCollectedTime(String value) {
        this.gatewayCollectedTime = value;
    }

}
