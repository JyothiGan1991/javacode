
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddEditLocationReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddEditLocationReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditLocationType" minOccurs="0"/&gt;
 *         &lt;element name="LocationAddnlInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EditLocationAddnlInfoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddEditLocationReqType", propOrder = {
    "location",
    "locationAddnlInfo"
})
public class AddEditLocationReqType {

    @XmlElement(name = "Location")
    protected EditLocationType location;
    @XmlElement(name = "LocationAddnlInfo")
    protected EditLocationAddnlInfoType locationAddnlInfo;

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link EditLocationType }
     *     
     */
    public EditLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditLocationType }
     *     
     */
    public void setLocation(EditLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the locationAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link EditLocationAddnlInfoType }
     *     
     */
    public EditLocationAddnlInfoType getLocationAddnlInfo() {
        return locationAddnlInfo;
    }

    /**
     * Sets the value of the locationAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link EditLocationAddnlInfoType }
     *     
     */
    public void setLocationAddnlInfo(EditLocationAddnlInfoType value) {
        this.locationAddnlInfo = value;
    }

}
