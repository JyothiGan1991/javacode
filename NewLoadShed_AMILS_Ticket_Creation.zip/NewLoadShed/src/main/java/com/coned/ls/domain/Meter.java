package com.coned.ls.domain;

import java.math.BigDecimal;

public class Meter {
	private BigDecimal id, requestId;
	private String meterNumber, macAddress, boro, eventName;
	private int requestType;

	public Meter(BigDecimal id, BigDecimal requestId, String eventName, String meterNumber, String boro,
			int requestType) {
		super();
		this.id = id;
		this.requestId = requestId;
		this.eventName = eventName;
		this.meterNumber = meterNumber;
		this.boro = boro;
		this.requestType = requestType;
	}

	public Meter(BigDecimal requestId, String meterNumber, String macAddress) {
		super();
		this.requestId = requestId;
		this.meterNumber = meterNumber;
		this.macAddress = macAddress;
	}

	/**
	 * Constructor used for disconnect/connect processing that also carries event name.
	 */
	public Meter(BigDecimal requestId, String meterNumber, String macAddress, String eventName) {
		super();
		this.requestId = requestId;
		this.meterNumber = meterNumber;
		this.macAddress = macAddress;
		this.eventName = eventName;
	}

	/**
	 * @return the requestId
	 */
	public BigDecimal getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId
	 *            the requestId to set
	 */
	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the meterNumber
	 */
	public String getMeterNumber() {
		return meterNumber;
	}

	/**
	 * @param meterNumber
	 *            the meterNumber to set
	 */
	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}

	/**
	 * @param macAddress
	 *            the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	/**
	 * @return the boro
	 */
	public String getBoro() {
		return boro;
	}

	/**
	 * @param boro
	 *            the boro to set
	 */
	public void setBoro(String boro) {
		this.boro = boro;
	}

	/**
	 * @return the id
	 */
	public BigDecimal getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(BigDecimal id) {
		this.id = id;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName
	 *            the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the requestType
	 */
	public int getRequestType() {
		return requestType;
	}

	/**
	 * @param requestType
	 *            the requestType to set
	 */
	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Meter [id=" + id + ", requestId=" + requestId + ", meterNumber=" + meterNumber + ", macAddress="
				+ macAddress + ", boro=" + boro + ", eventName=" + eventName + ", requestType=" + requestType + "]";
	}

}
