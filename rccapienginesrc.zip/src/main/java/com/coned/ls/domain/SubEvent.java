package com.coned.ls.domain;

import java.util.List;

public class SubEvent {

	private String borough;
	private String event;
	private String meters;
	private String subEventName;
	private Long countOfMeters;
	private List<String> listOfMeters;
	private Long subEventPrefix;
	private boolean isSelectAll;
	private boolean isCreateSubEvent;
	
	private boolean exclude;
	private int pageNumber;
	private int pageSize;
	
	private String totalKva;
	private String adid;
	
	
	public boolean getIsCreateSubEvent() {
		return isCreateSubEvent;
	}
	public void setIsCreateSubEvent(boolean isCreateSubEvent) {
		this.isCreateSubEvent = isCreateSubEvent;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getMeters() {
		return meters;
	}
	public void setMeters(String meters) {
		this.meters = meters;
	}
	public String getSubEventName() {
		return subEventName;
	}
	public void setSubEventName(String subEventName) {
		this.subEventName = subEventName;
	}
	public Long getCountOfMeters() {
		return countOfMeters;
	}
	public void setCountOfMeters(Long countOfMeters) {
		this.countOfMeters = countOfMeters;
	}
	
	public List<String> getListOfMeters() {
		return listOfMeters;
	}
	public void setListOfMeters(List<String> listOfMeters) {
		this.listOfMeters = listOfMeters;
	}
	public Long getSubEventPrefix() {
		return subEventPrefix;
	}
	public void setSubEventPrefix(Long subEventPrefix) {
		this.subEventPrefix = subEventPrefix;
	}
	public boolean getIsSelectAll() {
		return isSelectAll;
	}
	public void setIsSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}
	public boolean isExclude() {
		return exclude;
	}
	public void setExclude(boolean exclude) {
		this.exclude = exclude;
	}
	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getTotalKva() {
		return totalKva;
	}
	public void setTotalKva(String totalKva) {
		this.totalKva = totalKva;
	}
	public String getAdid() {
		return adid;
	}
	public void setAdid(String adid) {
		this.adid = adid;
	}
	
}
