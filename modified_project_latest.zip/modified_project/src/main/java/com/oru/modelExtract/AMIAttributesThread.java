/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class AMIAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(AMIAttributesThread.class);

    AMIAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //System.out.println("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename, \n" +
                                "GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue, \n" +
                                "ST_Y(geom) yValue, ami.*  \n" +
                                "from ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_ami ami \n" +
                                "where geom.featuretypeid = def.featuretypeid \n" +
                                "and ami.fid = geom.fid   \n" +
                                "and ami.fid in (" + assetToQuery + ") \n" +
                                "order by ami.fid ";

            //####System.out.println(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));
                    
                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    
                    // *************************************

                    long fid1 = rs.getLong("fid1");
                    asset.setNmsAttributes("fid1", Long.toString(fid1));
                    
                    long fid2 = rs.getLong("fid2");
                    asset.setNmsAttributes("fid2", Long.toString(fid2));
                    
                    String type = rs.getString("type");
                    asset.setNmsAttributes("type", type);

                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);

                    String seg = rs.getString("seg");
                    asset.setNmsAttributes("seg", seg);

                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));
                    
                    double volt = rs.getFloat("volt");
                    //asset.setNmsAttributes("volt", String.valueOf(volt));
                    asset.setNmsAttributes("volt", String.format("%.2f", volt));  
                    
                    String streetcode = rs.getString("streetcode");
                    asset.setNmsAttributes("streetcode", streetcode);

                    String street = rs.getString("street");
                    asset.setNmsAttributes("street", street);
                    
                    String taxdistrict = rs.getString("taxdistrict");
                    asset.setNmsAttributes("taxdistrict", taxdistrict);
                    
                    String taxdistrictdesc = rs.getString("taxdistrictdesc");
                    asset.setNmsAttributes("taxdistrictdesc", taxdistrictdesc);
                                        
                    String carriertype = rs.getString("carriertype");
                    asset.setNmsAttributes("carriertype", carriertype);
                    
                    Timestamp inservicedate = rs.getTimestamp("inservicedate");
                    if(inservicedate != null)
                    {
                        String inservicedateStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(inservicedate);
                        asset.setNmsAttributes("inservicedate", inservicedateStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("inservicedate", "");
                    }
                    
                    String serialnumber = rs.getString("serialnumber");
                    asset.setNmsAttributes("serialnumber", serialnumber);
                    
                    String premise = rs.getString("premise");
                    asset.setNmsAttributes("premise", premise);
                    
                    String wmsnumber = rs.getString("wmsnumber");
                    asset.setNmsAttributes("wmsnumber", wmsnumber);
                    
                    String subseg = rs.getString("subseg");
                    asset.setNmsAttributes("subseg", subseg);
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);
                    
                    
                    
                
                }

            }
            rs.close();
            //####System.out.println("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
