/*package com.coned.ls.repository;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.utility.DateUtils;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={ApiEngineApplication.class})
@AutoConfigureMockMvc
public class MeterEventValidateRepositoryTest {

	@Autowired
	private WebApplicationContext wac;
	
	@MockBean
	private MeterEventValidateRepository meterEventValidateRepository;
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
	}
	
	@Test
	public void getValidateMeterTest(){	
		
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
	    Assert.assertEquals(meterEventLoads.get(0), meterEventLoad);
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeterTest_Empty(){	
		List<MeterEventLoad> meterEventLoadTemp = meterEventLoads;
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoadTemp.clear();
	    Assert.assertEquals(meterEventLoads.get(0), meterEventLoad);
	}
	
	@Test
	public void getValidateMeter_Mock() throws MeterValidateException, VcapRecordNotFoundException{	
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300",0, 500, DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		Assert.assertEquals(meterValidateResponseMapper.getMeterEventLoads().get(0), meterEventLoads.get(0)); 		
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void getValidateMeter_IndexOutOfBoundsException() throws MeterValidateException, VcapRecordNotFoundException{	
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		List<MeterEventLoad> meterEventLoadTemp = meterEventLoads;
		meterEventLoadTemp.clear();
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoadTemp);
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300",0, 500, DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);
		Assert.assertEquals(meterValidateResponseMapper.getMeterEventLoads().get(0), meterEventLoads.get(0)); 		
	}
	
	@Test
	public void getOperatorLock_Mock() throws MeterValidateException, VcapRecordNotFoundException{	
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		meterValidateResponseMapper.setMessage("This event is locked.");
		Mockito.when(meterEventValidateRepository.getValidateMeter("B", "SheepsheadBaySampleData7.27.20-1300",0, 500, DateUtils.get3DaysOldDateAsString(), DateUtils.getCurrentDateAsString())).thenReturn(meterValidateResponseMapper);	
		Assert.assertEquals(meterValidateResponseMapper.getMessage(), "This event is locked."); 		
	}
}
*/