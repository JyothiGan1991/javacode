package com.coned.ls.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.MeterEventLoad;


public class NewEventListRowMapper implements RowMapper<MeterEventLoad>{

	@Override
	public MeterEventLoad mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		
		meterEventLoad.setAccountNumber(rs.getString("Account"));
		meterEventLoad.setBorough(rs.getString("Boro"));
		meterEventLoad.setBuildingNumber(rs.getString("BuildingNum"));
		meterEventLoad.setCustomerName(rs.getString("CustomerName"));
		meterEventLoad.setCustomerZipCode(rs.getString("ZipCode"));
		meterEventLoad.setDemand(rs.getString("Demand"));
		meterEventLoad.setEventName(rs.getString("EventName"));
		meterEventLoad.setFeeder(rs.getString("Feeder"));
		meterEventLoad.setFeederNetworkAbbr(rs.getString("FeederNetworkAbbr"));
		meterEventLoad.setVcapInsertTime(rs.getString("InsertTime"));
		meterEventLoad.setMeterNumber(rs.getString("Meter"));
		meterEventLoad.setMeterType(rs.getString("MeterType"));
		meterEventLoad.setNetwork(rs.getString("Network"));
		meterEventLoad.setNetworkAbbr(rs.getString("NetworkAbbr"));
		meterEventLoad.setPhone1(rs.getString("Phone1"));
		meterEventLoad.setPhone2(rs.getString("Phone2"));
		meterEventLoad.setSdpid(rs.getString("SDPID"));
		meterEventLoad.setServiceAddress(rs.getString("ServiceAddress"));
		
		return meterEventLoad;
	}
	
	
}
