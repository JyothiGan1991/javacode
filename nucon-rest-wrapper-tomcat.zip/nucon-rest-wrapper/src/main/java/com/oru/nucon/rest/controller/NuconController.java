package com.oru.nucon.rest.controller;

import com.oru.nucon.rest.dto.AccountRequest;
import com.oru.nucon.rest.dto.ElectricInfoDto;
import com.oru.nucon.rest.dto.LocateInNrgViewerRequest;
import com.oru.nucon.rest.dto.PremiseRequest;
import com.oru.nucon.rest.dto.SendToNrgRequest;
import com.oru.nucon.rest.dto.SuccessResponse;
import com.oru.nucon.rest.dto.XYCoordinatesRequest;
import com.oru.nucon.rest.service.NuconSoapService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/nucon")
public class NuconController {

    private final NuconSoapService nuconSoapService;

    public NuconController(NuconSoapService nuconSoapService) {
        this.nuconSoapService = nuconSoapService;
    }

    @PostMapping(value = "/electric-info/by-account",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByAccount(@RequestBody AccountRequest request) {
        ElectricInfoDto result = nuconSoapService.getElectricInfoByAccount(request);
        return ResponseEntity.ok(result);
    }

    @GetMapping(value = "/electric-info/by-account", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByAccountGet(@RequestParam String account) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByAccount(new AccountRequest(account)));
    }

    @PostMapping(value = "/electric-info/by-premise",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByPremise(@RequestBody PremiseRequest request) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByPremise(request));
    }

    @GetMapping(value = "/electric-info/by-premise", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByPremiseGet(@RequestParam String premise) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByPremise(new PremiseRequest(premise)));
    }

    @PostMapping(value = "/electric-info/by-xy",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByXY(@RequestBody XYCoordinatesRequest request) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByXYCoordinates(request));
    }

    @GetMapping(value = "/electric-info/by-xy", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ElectricInfoDto> getElectricInfoByXYGet(
            @RequestParam String x, @RequestParam String y) {
        return ResponseEntity.ok(nuconSoapService.getElectricInfoByXYCoordinates(new XYCoordinatesRequest(x, y)));
    }

    @PostMapping(value = "/send-to-nrg",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> sendToNRG(@RequestBody SendToNrgRequest request) {
        nuconSoapService.sendToNRG(request);
        return ResponseEntity.ok(new SuccessResponse(true, "sendToNRG completed"));
    }

    @PostMapping(value = "/locate-in-nrg-viewer",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SuccessResponse> locateInNRGViewer(@RequestBody LocateInNrgViewerRequest request) {
        nuconSoapService.locateInNRGViewer(request);
        return ResponseEntity.ok(new SuccessResponse(true, "locateInNRGViewer completed"));
    }
}
