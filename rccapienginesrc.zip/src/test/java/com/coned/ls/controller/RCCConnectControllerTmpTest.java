package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.AuthorizationService;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.MeterEventValidateServiceImpl;
import com.coned.ls.service.MetersEventFinalizeService;
import com.coned.ls.service.MetersEventFinalizeServiceImpl;
import com.coned.ls.service.MetersEventFinalizeServiceTmp;
import com.coned.ls.service.OpenEventService;
import com.coned.ls.service.OpenEventServiceImpl;
import com.coned.ls.service.OpenEventServiceTmp;
import com.coned.ls.utility.DateUtils;



@RunWith(SpringRunner.class)
@ContextConfiguration(classes= {RCCConnectControllerTmp.class,MetersEventFinalizeServiceTmp.class, OpenEventServiceTmp.class})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
@WebMvcTest(RCCConnectControllerTmp.class)
//@SpringBootTest(classes = ApiEngineApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) 
//@AutoConfigureMockMvc
public class RCCConnectControllerTmpTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	
	@MockBean
	private MeterEventValidateService meterEventValidateService; 
	
	@MockBean
	private MetersEventFinalizeServiceTmp metersEventFinalizeServiceTmp; 
	
	@MockBean
	private OpenEventServiceTmp openEventServiceTmp; 
	
	
	@InjectMocks
	RCCConnectControllerTmp rccDisconnectController;
	
	final RestTemplate testTemplate = new RestTemplate();
	
	List<MeterEventLoad> meterEventLoads= new ArrayList<>();
	
	
	@Test
	@Before
	public void setup() throws Exception{
	    MockitoAnnotations.initMocks(this);
		rccDisconnectController = new RCCConnectControllerTmp();
		System.out.println("@Before annotation method is being called ....");
		
		ReflectionTestUtils.setField(rccDisconnectController, "openEventServiceTmp", openEventServiceTmp);
		ReflectionTestUtils.setField(rccDisconnectController, "meterEventValidateService", meterEventValidateService);
		ReflectionTestUtils.setField(rccDisconnectController, "metersEventFinalizeServiceTmp", metersEventFinalizeServiceTmp);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void getBoroughName() throws Exception {
		List<String> expected = new ArrayList<String>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected,new HttpHeaders(), HttpStatus.OK);
		
		String fields = "boro";
		Mockito.when(openEventServiceTmp.getNewAndActiveBorough()).thenReturn(result);
		
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveBorough(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventServiceTmp.getNewAndActiveBorough()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getNewAndActiveBorough(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}
	@Test
	public void getEventName() throws Exception {
		List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);
		String fields = "event_name";
		Mockito.when(openEventServiceTmp.getNewAndActiveEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveBorough(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventServiceTmp.getNewAndActiveEvent()).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getNewAndActiveBorough(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}

	
	@Test
	public void getEventNameByBorough() throws Exception{
        List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		Mockito.when(openEventServiceTmp.getNewAndActiveEventByBorough(borough)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getNewAndActiveEventByBorough(borough);
		Assert.assertEquals(result.getBody().size(), actual.getBody().size());
	}
	
	
	@Test
	public void finalizeValidateMeters() throws Exception{
		MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
		mfrp.setMessage("success");
		mfrp.setResult(true);
		ResponseEntity<MeterFinalizeResponseMapper> mapper = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp  , new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid = "XYZ";
		Mockito.when(metersEventFinalizeServiceTmp.finalizeMeterEvent(meterEventFinalize,adid )).thenReturn(mapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterFinalizeResponseMapper> actual = rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals(mapper.getBody().getMessage() , actual.getBody().getMessage());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void InvalidfinalizeValidateMeters() throws Exception{
		MeterFinalizeResponseMapper mfrp = new MeterFinalizeResponseMapper();
		ResponseEntity<MeterFinalizeResponseMapper> mapper = new ResponseEntity<MeterFinalizeResponseMapper>(mfrp  , new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid= null;
		Mockito.when(metersEventFinalizeServiceTmp.finalizeMeterEvent(meterEventFinalize,adid)).thenReturn(mapper);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(null, null);
		ResponseEntity<MeterFinalizeResponseMapper> actual= rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals(mapper.getBody(), actual.getBody());
	}
}