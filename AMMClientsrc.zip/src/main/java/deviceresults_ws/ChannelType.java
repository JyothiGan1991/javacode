
package deviceresults_ws;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChannelType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChannelType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReadValue" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="EngineeringUnitReadValue" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="BlockEndReadValue" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="EngineeringUnitBlockEndReadValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="BlockEndTimestamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ChannelStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ChannelStatusType" minOccurs="0"/&gt;
 *         &lt;element name="Uom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Number" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChannelType", propOrder = {
    "readValue",
    "engineeringUnitReadValue",
    "blockEndReadValue",
    "engineeringUnitBlockEndReadValue",
    "blockEndTimestamp",
    "channelStatus",
    "uom",
    "ieeExportChannelID"
})
public class ChannelType {

    @XmlElement(name = "ReadValue")
    protected double readValue;
    @XmlElement(name = "EngineeringUnitReadValue", required = true)
    protected BigDecimal engineeringUnitReadValue;
    @XmlElement(name = "BlockEndReadValue")
    protected Double blockEndReadValue;
    @XmlElement(name = "EngineeringUnitBlockEndReadValue")
    protected BigDecimal engineeringUnitBlockEndReadValue;
    @XmlElement(name = "BlockEndTimestamp")
    protected String blockEndTimestamp;
    @XmlElement(name = "ChannelStatus")
    @XmlSchemaType(name = "string")
    protected ChannelStatusType channelStatus;
    @XmlElement(name = "Uom")
    protected String uom;
    @XmlElement(name = "IEEExportChannelID", required = true)
    protected String ieeExportChannelID;
    @XmlAttribute(name = "Number")
    protected Integer number;

    /**
     * Gets the value of the readValue property.
     * 
     */
    public double getReadValue() {
        return readValue;
    }

    /**
     * Sets the value of the readValue property.
     * 
     */
    public void setReadValue(double value) {
        this.readValue = value;
    }

    /**
     * Gets the value of the engineeringUnitReadValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEngineeringUnitReadValue() {
        return engineeringUnitReadValue;
    }

    /**
     * Sets the value of the engineeringUnitReadValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEngineeringUnitReadValue(BigDecimal value) {
        this.engineeringUnitReadValue = value;
    }

    /**
     * Gets the value of the blockEndReadValue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getBlockEndReadValue() {
        return blockEndReadValue;
    }

    /**
     * Sets the value of the blockEndReadValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setBlockEndReadValue(Double value) {
        this.blockEndReadValue = value;
    }

    /**
     * Gets the value of the engineeringUnitBlockEndReadValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEngineeringUnitBlockEndReadValue() {
        return engineeringUnitBlockEndReadValue;
    }

    /**
     * Sets the value of the engineeringUnitBlockEndReadValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEngineeringUnitBlockEndReadValue(BigDecimal value) {
        this.engineeringUnitBlockEndReadValue = value;
    }

    /**
     * Gets the value of the blockEndTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlockEndTimestamp() {
        return blockEndTimestamp;
    }

    /**
     * Sets the value of the blockEndTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlockEndTimestamp(String value) {
        this.blockEndTimestamp = value;
    }

    /**
     * Gets the value of the channelStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ChannelStatusType }
     *     
     */
    public ChannelStatusType getChannelStatus() {
        return channelStatus;
    }

    /**
     * Sets the value of the channelStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChannelStatusType }
     *     
     */
    public void setChannelStatus(ChannelStatusType value) {
        this.channelStatus = value;
    }

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUom() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUom(String value) {
        this.uom = value;
    }

    /**
     * Gets the value of the ieeExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIEEExportChannelID() {
        return ieeExportChannelID;
    }

    /**
     * Sets the value of the ieeExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIEEExportChannelID(String value) {
        this.ieeExportChannelID = value;
    }

    /**
     * Gets the value of the number property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumber(Integer value) {
        this.number = value;
    }

}
