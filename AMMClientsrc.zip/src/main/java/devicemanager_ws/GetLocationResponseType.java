
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetLocationResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetLocationResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Location" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetLocationType" minOccurs="0"/&gt;
 *         &lt;element name="LocationAddnlInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetLocationAddnlInfoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetLocationResponseType", propOrder = {
    "location",
    "locationAddnlInfo"
})
public class GetLocationResponseType {

    @XmlElement(name = "Location")
    protected GetLocationType location;
    @XmlElement(name = "LocationAddnlInfo")
    protected GetLocationAddnlInfoType locationAddnlInfo;

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link GetLocationType }
     *     
     */
    public GetLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLocationType }
     *     
     */
    public void setLocation(GetLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the locationAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link GetLocationAddnlInfoType }
     *     
     */
    public GetLocationAddnlInfoType getLocationAddnlInfo() {
        return locationAddnlInfo;
    }

    /**
     * Sets the value of the locationAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLocationAddnlInfoType }
     *     
     */
    public void setLocationAddnlInfo(GetLocationAddnlInfoType value) {
        this.locationAddnlInfo = value;
    }

}
