/**
 * 
 */
package com.coned.ls;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.coned.ls.service.RemoteOperationService;

@EnableAutoConfiguration
@SpringBootApplication(scanBasePackages = { "com.coned" })
public class LoadSheddingApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(LoadSheddingApplication.class);

	/*
	 * @Autowired private JMService jmService;
	 * 
	 * @Autowired private DvcResultsService dvcrService;
	 * 
	 * @Autowired private DmgrService dMgrService;
	 */
	@Autowired
	private RemoteOperationService rmService;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(LoadSheddingApplication.class, args);
	}

	@Override
	public void run(String... args) {
		while (true) {
			try {
				rmService.processMetersWithNullMacAddr();
				// Fetch the meters requested for disconnect from the master
				// table,
				// invoke RSM Disconnect and capture the jobid
				rmService.disconnectMeters();
				// UPDATE THE STATUS OF THE REQUEST IF ALL THE METERS ARE
				// PROCESSED
				rmService.updateStatus();

				// Fetch the meters requested for connect from the master table,
				// invoke RSM Connect and capture the jobid
				rmService.connectMeters();
			} catch (Exception e) {
				logger.error("Error in RSM Disconnect/connect " + e);
			}
		}
	}

	private void pause(long seconds) {
		try {
			logger.info("Pause for few seconds");
			TimeUnit.SECONDS.sleep(seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * private void getUIQVersion() { SystemInfoPortType sip =
	 * systemInfoService(); systemInfo_ws.EmptyType empt = new
	 * systemInfo_ws.EmptyType();
	 * 
	 * logger.infoln("@@@@@@@@@@@@" + sip);
	 * 
	 * try { UIQVersionType uiqversiontype = sip.getUIQVersion(empt);
	 * logger.infoln("Build Id " + uiqversiontype.getBuildID());
	 * logger.infoln("Version Number for AMM is : \n");
	 * logger.info(uiqversiontype.getVersionNumber()); } catch
	 * (systemInfo_ws.ErrorCodeFault errorCodeFault) {
	 * errorCodeFault.printStackTrace(); } }
	 */

	/*
	 * private void systemInfo() { try { siClient.test(); } catch (SOAPException
	 * e) { // TODO Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * private void retrieveMACID(String utilDeviceID) { Object response = null;
	 * try { response = dmClient.retrieveMACID(utilDeviceID); logger.info("" +
	 * response); } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * // log.info("MAC ID: " + response.getMacID()); }
	 * 
	 * private void disconnectJob(String utilDeviceID, String macID) { Object
	 * disconnectresponse = null; try { disconnectresponse =
	 * jmClient.disconnectJob(utilDeviceID, macID); } catch (Exception e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); } logger.info("" +
	 * disconnectresponse); // log.info("MAC ID: " + response.getValue()); }
	 */

	/*
	 * private SystemInfoPortType systemInfoService() { SystemInfoService sis =
	 * new SystemInfoService(); SystemInfoPortType sip =
	 * sis.getSystemInfoPort();
	 * 
	 * ((BindingProvider)
	 * sip).getRequestContext().put(BindingProvider.SESSION_MAINTAIN_PROPERTY,
	 * true);
	 * 
	 * // Set Webservice credentials ((BindingProvider)
	 * sip).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
	 * WS_URL); ((BindingProvider)
	 * sip).getRequestContext().put(BindingProvider.USERNAME_PROPERTY,
	 * "chebroluh"); ((BindingProvider)
	 * sip).getRequestContext().put(BindingProvider.PASSWORD_PROPERTY,
	 * "UIQDev01!"); return sip; }
	 */

}
