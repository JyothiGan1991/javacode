package com.coned.rc;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.coned.rc.beans.Event;
import com.coned.rc.service.RetryService;

@Component
public class AppRunner implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(AppRunner.class);

	@Autowired
	private RetryService serv;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public void run(String... args) throws Exception {
		processEvents();
		// Thread.sleep(300000);
	}

	private void processEvents() {
		try {
			Collection<Event> eventList = serv.calculateTimeouts();

			/** extract the events that are marked for retry **/
			List<Event> retryEventList = eventList.stream().filter(e -> e.isRetry()).collect(Collectors.toList());
			logger.debug("Events that are marked for retry {}", retryEventList);
			logger.info("Events list size [{}] marked for retry", retryEventList.size());

			/**
			 * Fetch the failed meters for the events that are ready for retry and push them
			 * for connect retry
			 **/
			serv.getFailedMeters(retryEventList, restTemplate);
		} catch (Exception e) {
			logger.error(" ", e);
		}
	}

}
