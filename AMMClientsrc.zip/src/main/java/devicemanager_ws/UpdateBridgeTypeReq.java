
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateBridgeTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateBridgeTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DNP3Address" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NullableLong" minOccurs="0"/&gt;
 *         &lt;element name="EthernetMacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="BridgeTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="BridgeTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateBridgeTypeReq", propOrder = {
    "dnp3Address",
    "ethernetMacID",
    "bridgeTypeConfigID",
    "bridgeTypeConfigName"
})
public class UpdateBridgeTypeReq {

    @XmlElement(name = "DNP3Address")
    protected NullableLong dnp3Address;
    @XmlElement(name = "EthernetMacID")
    protected String ethernetMacID;
    @XmlElement(name = "BridgeTypeConfigID")
    protected Long bridgeTypeConfigID;
    @XmlElement(name = "BridgeTypeConfigName")
    protected String bridgeTypeConfigName;

    /**
     * Gets the value of the dnp3Address property.
     * 
     * @return
     *     possible object is
     *     {@link NullableLong }
     *     
     */
    public NullableLong getDNP3Address() {
        return dnp3Address;
    }

    /**
     * Sets the value of the dnp3Address property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullableLong }
     *     
     */
    public void setDNP3Address(NullableLong value) {
        this.dnp3Address = value;
    }

    /**
     * Gets the value of the ethernetMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEthernetMacID() {
        return ethernetMacID;
    }

    /**
     * Sets the value of the ethernetMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEthernetMacID(String value) {
        this.ethernetMacID = value;
    }

    /**
     * Gets the value of the bridgeTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBridgeTypeConfigID() {
        return bridgeTypeConfigID;
    }

    /**
     * Sets the value of the bridgeTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBridgeTypeConfigID(Long value) {
        this.bridgeTypeConfigID = value;
    }

    /**
     * Gets the value of the bridgeTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBridgeTypeConfigName() {
        return bridgeTypeConfigName;
    }

    /**
     * Sets the value of the bridgeTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBridgeTypeConfigName(String value) {
        this.bridgeTypeConfigName = value;
    }

}
