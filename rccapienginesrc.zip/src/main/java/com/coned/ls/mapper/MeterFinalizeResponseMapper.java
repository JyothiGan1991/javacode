package com.coned.ls.mapper;

public class MeterFinalizeResponseMapper {

	private String message;
	private boolean result;
	private int statusCode;
	
	public MeterFinalizeResponseMapper(boolean result) {
		super();
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	
	
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public MeterFinalizeResponseMapper(String message, boolean result) {
		super();
		this.message = message;
		this.result = result;
	}
	public MeterFinalizeResponseMapper() {
		super();
	}
	
	@Override
	public String toString() {
		return "MeterFinalize [message=" + message + ", result=" + result + "]";
	}		
}
