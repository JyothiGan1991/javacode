package com.coned.ls.service;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;

public interface UserManagementService {

	public ResponseEntity<Map<String, Object>> createUser(Map<String, Object> payload);
	public ResponseEntity<Map<String, Object>> updateUser(String username, Map<String, Object> payload);
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy);
	public ResponseEntity<List<Map<String, Object>>> getUsers();

}
