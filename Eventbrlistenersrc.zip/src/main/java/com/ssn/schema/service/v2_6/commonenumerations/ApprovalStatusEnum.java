
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ApprovalStatusEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ApprovalStatusEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MP_APPROVAL_STATUS_NOTYET"/>
 *     &lt;enumeration value="MP_APPROVAL_STATUS_APPROVED"/>
 *     &lt;enumeration value="MP_APPROVAL_STATUS_REJECTED"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ApprovalStatusEnum")
@XmlEnum
public enum ApprovalStatusEnum {

    MP_APPROVAL_STATUS_NOTYET("MP_APPROVAL_STATUS_NOTYET"),
    MP_APPROVAL_STATUS_APPROVED("MP_APPROVAL_STATUS_APPROVED"),
    MP_APPROVAL_STATUS_REJECTED("MP_APPROVAL_STATUS_REJECTED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ApprovalStatusEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ApprovalStatusEnum fromValue(String v) {
        for (ApprovalStatusEnum c: ApprovalStatusEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
