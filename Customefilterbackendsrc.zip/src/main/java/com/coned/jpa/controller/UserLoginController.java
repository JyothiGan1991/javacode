/*package com.coned.jpa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coned.model.Role;
import com.coned.model.User;
import com.coned.model.UserLogin;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.UserLoginRepository;
import com.coned.jpa.repository.RoleRepository;

@RestController
public class UserLoginController {

	@Autowired
    private UserLoginRepository userloginRepository;


    @GetMapping("/userlogin")
    public List < UserLogin > getUserlogins() {
        return userloginRepository.findAll();
    }

    @GetMapping("/userlogin/{id}")
    public ResponseEntity < UserLogin > getInstructorById(
        @PathVariable(value = "id") Long userloginId) throws ResourceMissingException {
        UserLogin userlogin = userloginRepository.findById(userloginId)
            .orElseThrow(() -> new ResourceMissingException("UserLogin not found :: " + userloginId));
        return ResponseEntity.ok().body(userlogin);
    }

    @PostMapping("/userlogin")
    public UserLogin createUserlogin(@Valid @RequestBody UserLogin userlogin) {
        return userloginRepository.save(userlogin);
    }

    @PutMapping("/userlogin/{id}")
    public ResponseEntity < UserLogin > updateUserLogin(
        @PathVariable(value = "id") Long userloginId,
        @Valid @RequestBody UserLogin userLoginDetails) throws ResourceMissingException {
    	UserLogin userlogin = userloginRepository.findById(userloginId)
            .orElseThrow(() -> new ResourceMissingException("UserLogin not found :: " + userloginId));
        userlogin.setToken(userLoginDetails.getToken());
        final UserLogin updatedUserlogin = userloginRepository.save(userlogin);
        return ResponseEntity.ok(updatedUserlogin);
    }
*/
	/*
	 * @DeleteMapping("/roles/{id}") public Map < String, Boolean > deleteUser(
	 * 
	 * @PathVariable(value = "id") Long roleId) throws ResourceMissingException {
	 * Role instructor = userloginRepository.findById(roleId) .orElseThrow(() -> new
	 * ResourceMissingException("Role not found :: " + roleId));
	 * 
	 * userloginRepository.delete(instructor); Map < String, Boolean > response =
	 * new HashMap < > (); response.put("deleted", Boolean.TRUE); return response; }
	 */
//}
