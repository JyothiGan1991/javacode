package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

/**
 * 
 * Interface for RCC Connect Service class.
 *
 */
public interface MeterEventConnectService {
	
	public ResponseEntity<MeterConnectResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent)  throws Exception;
	public ResponseEntity<MeterConnectResponseMapper> getConnectedMeters(final MeterOpenEvent meterOpenEvent) throws MeterEventConnectException;
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(final SubEvent subEvent) throws Exception;

	public ResponseEntity<MeterConnectResponseMapper> searchMeters(final MeterSearch meterSearch);
	public ResponseEntity<MeterConnectResponseMapper> searchMeterConnected(final MeterSearch meterSearch);
	
	public ResponseEntity<Long> getSubEventSuffix(final String borough, final String event);
	
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex, final int batchSize);
	
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(final SubEvent subEvent);
	
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(String borough, final String eventName, String fieldName);
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(String borough, final String eventName, String fieldName);
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid);
	public void unlockEvents(final String adid);
}
