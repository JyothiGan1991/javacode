package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

/**
 * Interface for Open Event Service class.
 *
 */
public interface OpenEventServiceTmp {
	
	// RCC Disconnect
	public ResponseEntity<List<String>> getNewAndActiveBorough();
	public ResponseEntity<List<String>> getNewAndActiveEvent();
	public ResponseEntity<List<String>> getNewAndActiveEventByBorough(final String borough);
	
}
