
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RouteHop" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RouteHopType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="GatewayTimestamp" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="PingSequenceNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="RoundtripMS" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="PacketLost" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PingType", propOrder = {
    "routeHop"
})
public class PingType {

    @XmlElement(name = "RouteHop")
    protected List<RouteHopType> routeHop;
    @XmlAttribute(name = "GatewayTimestamp")
    protected String gatewayTimestamp;
    @XmlAttribute(name = "PingSequenceNumber", required = true)
    protected long pingSequenceNumber;
    @XmlAttribute(name = "RoundtripMS")
    protected Long roundtripMS;
    @XmlAttribute(name = "PacketLost")
    protected Boolean packetLost;

    /**
     * Gets the value of the routeHop property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the routeHop property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRouteHop().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RouteHopType }
     * 
     * 
     */
    public List<RouteHopType> getRouteHop() {
        if (routeHop == null) {
            routeHop = new ArrayList<RouteHopType>();
        }
        return this.routeHop;
    }

    /**
     * Gets the value of the gatewayTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGatewayTimestamp() {
        return gatewayTimestamp;
    }

    /**
     * Sets the value of the gatewayTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGatewayTimestamp(String value) {
        this.gatewayTimestamp = value;
    }

    /**
     * Gets the value of the pingSequenceNumber property.
     * 
     */
    public long getPingSequenceNumber() {
        return pingSequenceNumber;
    }

    /**
     * Sets the value of the pingSequenceNumber property.
     * 
     */
    public void setPingSequenceNumber(long value) {
        this.pingSequenceNumber = value;
    }

    /**
     * Gets the value of the roundtripMS property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRoundtripMS() {
        return roundtripMS;
    }

    /**
     * Sets the value of the roundtripMS property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRoundtripMS(Long value) {
        this.roundtripMS = value;
    }

    /**
     * Gets the value of the packetLost property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isPacketLost() {
        if (packetLost == null) {
            return false;
        } else {
            return packetLost;
        }
    }

    /**
     * Sets the value of the packetLost property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPacketLost(Boolean value) {
        this.packetLost = value;
    }

}
