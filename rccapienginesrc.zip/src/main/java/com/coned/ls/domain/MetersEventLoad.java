package com.coned.ls.domain;

public class MetersEventLoad {
	
	private String meterType;
	private String demand; 
	private String borough;
	
	
	
	public MetersEventLoad(String meterType, String demand, String borough) {
		super();
		this.meterType = meterType;
		this.demand = demand;
		this.borough = borough;
	}
	
	public MetersEventLoad(String demand, String borough) {
		super();
		this.demand = demand;
		this.borough = borough;
	}
	
	public String getMeterType() {
		return meterType;
	}
	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}
	public String getDemand() {
		return demand;
	}
	public void setDemand(String demand) {
		this.demand = demand;
	}
	public String getBorough() {
		return borough;
	}
	public void setBorough(String borough) {
		this.borough = borough;
	}
	
	
	
	

}
