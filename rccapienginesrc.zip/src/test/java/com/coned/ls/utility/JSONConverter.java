package com.coned.ls.utility;

import java.io.File;
import java.io.FileReader;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JSONConverter {

	public static void loadJsonFile(final String fileName, String object) {
		ClassLoader classLoader = JSONConverter.class.getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		System.out.println(file.getAbsolutePath());
		readJsonResponse(file.getAbsolutePath());
	}
	public static void readJsonResponse(String path) {
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader(path));
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println(jsonObject);
			JSONArray companyList = (JSONArray) jsonObject.get("meterEventLoads");
			Iterator<JSONObject> iterator = companyList.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
