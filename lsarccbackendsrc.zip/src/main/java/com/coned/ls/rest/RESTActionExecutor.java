package com.coned.ls.rest;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OperatorDetail;
import com.coned.ls.domain.OperatorLoginDetail;
import com.coned.ls.exception.OperatorAuthorizationException;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

/**
 * 
 * Class to call API Engine and return the response for RCC Disconnect.
 *
 */
public class RESTActionExecutor {
	
	private static final Logger logger = LogManager.getLogger(RESTActionExecutor.class);
	
	private static RestTemplate restTemplate = new RestTemplate();
	
	/*
	 * This method call API Engine to read list of open events by borough.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getOpenEvent(final String fields){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));

		Map<String, String> params = new HashMap<String, String>();
		params.put("borought", fields);
		URI uri = RestClientBuilder.buildURI("/rcc/disconnect/events/open/meters/{borought}", params);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	public ResponseEntity<List<String>> getOpenEventTmp(final String fields){
		logger.info(String.format("**TEMP** Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));

		Map<String, String> params = new HashMap<String, String>();
		params.put("borought", fields);
		URI uri = RestClientBuilder.buildURI("/rcc/connect-tmp/events/open/meters/{borought}", params);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}catch(Exception ex){
			logger.info(String.format("Exception occured : "+ex.getMessage()));
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	/*
	 * This method call API Engine to read list of Users.
	 * 
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<Object>> getUsers() {
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/users");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		return restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<Object>>() {});
	}
	
	/*
	 * This method call API Engine to read list of Connected FailedEvents.
	 * 
     * @return        ResponseEntity<List<Map<String, Object>>>
	 */
	public ResponseEntity<List<Map<String, Object>>> getEvents(String report_name) {
		URI uri = RestClientBuilder.customBuildURI("/rcc/report/" + report_name+"/events");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		return restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<Map<String, Object>>>() {});
	}
	public ResponseEntity<List<Map<String, Object>>> getCWR(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/report/cwr");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<List<Map<String, Object>>>) (Class) List.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			List<Map<String, Object>> error_res = new ArrayList<Map<String, Object>>();
			error_res.add(error);
			return ResponseEntity.status(ex.getRawStatusCode()).body(error_res);
		}
	}
	public ResponseEntity<List<Map<String, Object>>> getCDR(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/report/cdr");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<List<Map<String, Object>>>) (Class) List.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			List<Map<String, Object>> error_res = new ArrayList<Map<String, Object>>();
			error_res.add(error);
			return ResponseEntity.status(ex.getRawStatusCode()).body(error_res);
		}
	}
	public ResponseEntity<List<Map<String, Object>>> getCRR(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/report/crr");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<List<Map<String, Object>>>) (Class) List.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			List<Map<String, Object>> error_res = new ArrayList<Map<String, Object>>();
			error_res.add(error);
			return ResponseEntity.status(ex.getRawStatusCode()).body(error_res);
		}
	}
	public ResponseEntity<Map<String, Object>> getCER(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/report/cer");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<Map<String, Object>>) (Class) Map.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			return ResponseEntity.status(ex.getRawStatusCode()).body(error);
		}
	}
	
	public ResponseEntity<Map<String, Object>> getCMR(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/report/cmr");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<Map<String, Object>>) (Class) Map.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			return ResponseEntity.status(ex.getRawStatusCode()).body(error);
		}
	}
	
	/*
	 * This method call API Engine to check LDAP User.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<Map<String, Object>>
	 */
	public ResponseEntity<Map<String, Object>> listLDAPUser(String username) {
		URI uri = RestClientBuilder.customBuildURI("/rcc/um/adusers/" + username);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		return restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<Map<String, Object>>() {});
	}
	/*
	 * This method call API Engine to create User.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<Map<String, Object>>
	 */
	public ResponseEntity<Map<String, Object>> createUser(final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/um/users");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.postForEntity(uri, entity, (Class<Map<String, Object>>) (Class) Map.class);
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			return ResponseEntity.status(ex.getRawStatusCode()).body(error);
		}
	}
	/*
	 * This method call API Engine to update User.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<Map<String, Object>>
	 */
	public ResponseEntity<Map<String, Object>> updateUser(String username, final Map<String, Object> payload) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/um/users/" + username);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(payload, headers);
			return restTemplate.exchange(uri, HttpMethod.PUT, entity,
					new ParameterizedTypeReference<Map<String, Object>>() {});
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			return ResponseEntity.status(ex.getRawStatusCode()).body(error);
		}
	}
	/*
	 * This method call API Engine to Delete User.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<Map<String, Object>>
	 */
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy) {
		try {
			URI uri = RestClientBuilder.customBuildURI("/rcc/um/users/" + username+"?updatedBy="+updatedBy);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<Object>(headers);
			return restTemplate.exchange(uri, HttpMethod.DELETE, entity,
					new ParameterizedTypeReference<Map<String, Object>>() {});
		} catch (HttpClientErrorException ex) {
			logger.info(String.format("Exception occured : " + ex.getResponseBodyAsString()));
			Map<String, Object> error = new HashMap<String, Object>();
			error.put("message", "Exception occured : " + ex.getResponseBodyAsString());
			return ResponseEntity.status(ex.getRawStatusCode()).body(error);
		}
	}
	/*
	 * This method call API Engine to read list of borough or event names.
	 * 
	 * @param  fields String
     * @return        ResponseEntity<List<String>>
	 */
	public ResponseEntity<List<String>> getBoroughAndEventName(final String fields){
		
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/open/meters?fields="+fields);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	    
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	
	public ResponseEntity<List<String>> getBoroughAndEventNameTmp(final String fields){
		
		logger.info(String.format("** TEMP ** Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[1]));
		URI uri = RestClientBuilder.customBuildURI("/rcc/connect-tmp/events/open/meters?fields="+fields);
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
	    
		try{
			ResponseEntity<List<String>> response = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
			if(response.getBody().isEmpty()){
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response.getBody());
			}else{
				return ResponseEntity.ok().body(response.getBody());
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	/*
	 * Method to call API Engine to read list of meters created for the event.
	 * 
	 * @param  meterOpenEvent MeterOpenEvent
     * @return 				  ResponseEntity<MeterValidateResponseMapper>
	 */	
	public ResponseEntity<MeterValidateResponseMapper> getValidateMeter(final MeterOpenEvent meterOpenEvent){
		
		logger.info(String.format("Preparing REST API endpoint for getValidateMeter"));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/meters");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", meterOpenEvent.getAdid());
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterOpenEvent, headers);

		    return restTemplate.postForEntity(uri, entity, MeterValidateResponseMapper.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
			return ResponseEntity.status(ex.getRawStatusCode()).body(new MeterValidateResponseMapper("Exception occured : "+ex.getResponseBodyAsString()));
		}
	}

	/*
	 * Method to call API Engine to read list of values for given field.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  fieldName String
     * @return 			 ResponseEntity<List<String>>
	 */	
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		logger.info(String.format("Preparing REST API endpoint for getFieldValuesByBoroughAndEventName()"));
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("eventName="+eventName);
		stringBuilder.append("&fieldName="+fieldName);
		
		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/meters/fields/" + borough + "?", stringBuilder.toString());
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		ResponseEntity<List<String>> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<String>>() {});
		
		return responseEntity;		
	}

	/*
	 * Method to call API Engine to read list of invalid meters for given borough and event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 			     MeterValidateResponseMapper 
	 */	
	public MeterValidateResponseMapper getInvalidateMeter(final String borough, final String eventName, final int startRowIndex,final int batchSize){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));
		
		MeterValidateResponseMapper validateMeter = new MeterValidateResponseMapper();
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);
		stringBuilder.append("&startRowIndex="+String.valueOf(startRowIndex));
		stringBuilder.append("&batchSize="+String.valueOf(batchSize));

		URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/invalid/meters?", stringBuilder.toString());
		
		try{
			validateMeter = restTemplate.getForObject(uri, MeterValidateResponseMapper.class);			
		}catch(HttpClientErrorException ex){
			logger.error(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		logger.info(String.format("REST API response"));	 
		
		return validateMeter;
	}

	/*
	 * Method to call API Engine to finalize the meters for disconnect.
	 * 
	 * @param  meterEventFinalize MeterEventFinalize
	 * @param  adid 	 		  String
     * @return 			     	  ResponseEntity<String> 
	 */	
	public ResponseEntity<String> finalizeValidateMeters(final MeterEventFinalize meterEventFinalize, final String adid){
		logger.info(String.format("Preparing REST API endpoint for finalizeValidateMeters"));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/finalize/meters");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterEventFinalize, headers);

		    return restTemplate.postForEntity(uri, entity, String.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
			
			 return ResponseEntity.status(ex.getRawStatusCode()).body(ex.getResponseBodyAsString());
		}
	}

	public ResponseEntity<String> finalizeValidateMetersTmp(final MeterEventFinalize meterEventFinalize, final String adid){
		logger.info(String.format("2------ Preparing REST API endpoint for finalizeValidateMeters - Tmp"));

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/connect-tmp/events/finalize/meters");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    		
		    HttpEntity<Object> entity = new HttpEntity<Object>(meterEventFinalize, headers);

		    return restTemplate.postForEntity(uri, entity, String.class);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
			
			 return ResponseEntity.status(ex.getRawStatusCode()).body(ex.getResponseBodyAsString());
		}
	}
	
	
	/*
	 * Method to call API Engine to check user is authorized to access RCC API's.
	 * 
	 * @param  adid String
	 * @param  role String
     * @return 		boolean 
	 */	
	public boolean isOperatorAuthorized(final String adid, final String role) throws ResourceAccessException{
		logger.info(String.format("Preparing REST API endpoint to varify operator autherization %s", this.getClass().getDeclaredMethods()[2]));
		
		OperatorDetail operatorDetail = new OperatorDetail();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("adid="+adid);
		stringBuilder.append("&role="+role);

		URI uri = RestClientBuilder.customBuildURI("/operator/auth?", stringBuilder.toString());
		operatorDetail = restTemplate.getForObject(uri, OperatorDetail.class);

		if(null!=operatorDetail){
			logger.info(String.format("REST API response operator authorization %s", operatorDetail.getMessage()));
			
			return true;	
		}throw new ResourceAccessException("Connection Refuse");
		
	}

	/*
	 * Method to call API Engine to save the apiKey in the database.
	 * 
	 * @param  adid   String
	 * @param  apiKey String
	 * @param  type   String
     * @return 		  OperatorLoginDetail 
	 */	
	public OperatorLoginDetail persistAPIKey(final String adid,final String apiKey, final String type){
		logger.info(String.format("Preparing REST API endpoint to persist API Key inot database %s", this.getClass().getDeclaredMethods()[2]));
		
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(adid.toUpperCase());
		operatorLoginDetail.setApiKey(apiKey);
		operatorLoginDetail.setLoginTimeStamp(new Date());
		operatorLoginDetail.setRole("RCC");
		
		if(type.equalsIgnoreCase("login")){
			operatorLoginDetail.setApiKeyStatus(13);
			operatorLoginDetail.setLoginStatus(10);
		} else if (type.equalsIgnoreCase("logout")){
			operatorLoginDetail.setApiKeyStatus(12);
			operatorLoginDetail.setLoginStatus(11);
		}

		URI uri = RestClientBuilder.customBuildURI("/operator/auth/persistApi/");
		
		try{
			ResponseEntity<OperatorLoginDetail> postForEntity = restTemplate.postForEntity(uri, operatorLoginDetail, OperatorLoginDetail.class);
			operatorLoginDetail = postForEntity.getBody();
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		logger.info(String.format("REST API response operator authorization {}"));	 
		
		return operatorLoginDetail;
	}	

	/*
	 * Method to call API Engine to read login details of the user.
	 * 
	 * @param  adid String
     * @return 		OperatorLoginDetail 
	 */	
	public OperatorLoginDetail getOperatorLoginDetail(final String adid){
		logger.info(String.format("Preparing REST API endpoint to get the operator login detail from database %s", this.getClass().getDeclaredMethods()[2]));
		
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(adid);
		operatorLoginDetail.setRole("RCC");
		
		URI uri = RestClientBuilder.customBuildURI("/operator/principal/");
		
		try{
			ResponseEntity<OperatorLoginDetail> postForEntity = restTemplate.postForEntity(uri, operatorLoginDetail,OperatorLoginDetail.class);
			operatorLoginDetail = postForEntity.getBody();
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		logger.info(String.format("REST API response operator authorization {}"));	 
		
		return operatorLoginDetail;
	}
	
	/*
	 * Method to call API Engine to check user is authorized to access API's.
	 * 
	 * @param  adid   		String
	 * @param  apiKey 		String
	 * @param  apiKeyStatus int
	 * @param  loginStatus  int
     * @return 				boolean 
	 */	
	public boolean isAPIEndpointAuthorized(final String adid,final String apiKey, final int apiKeyStatus, final int loginStatus) throws OperatorAuthorizationException{
		logger.info(String.format("Preparing REST API endpoint to check If API Endpoint is Authorized %s", this.getClass().getDeclaredMethods()[2]));
		
		OperatorLoginDetail operatorLoginDetail = new OperatorLoginDetail();
		operatorLoginDetail.setAdid(adid);
		operatorLoginDetail.setApiKey(apiKey);
		operatorLoginDetail.setApiKeyStatus(apiKeyStatus);
		operatorLoginDetail.setLoginStatus(loginStatus);
		
		Boolean isAPIEndpointAuthorized = false;
		
		URI uri = RestClientBuilder.customBuildURI("/operator/principal/permission/");
		
		OperatorDetail operatorDetail = new OperatorDetail();
		try{
			
			ResponseEntity<OperatorDetail> postForEntity = restTemplate.postForEntity(uri, operatorLoginDetail, OperatorDetail.class);

			operatorDetail = postForEntity.getBody();
			if(null!=operatorDetail && operatorDetail.isAuthenticate() == true  ){
				logger.info(String.format("REST API response operator authorization %s", operatorDetail.getMessage()));
				return true;	
			}else{
				return false;
			}
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		logger.info(String.format("REST API response operator authorization {}"));	 
		return isAPIEndpointAuthorized;
	}
	
	/*
	 * Method to call API Engine to search for a list of disconnected meters.
	 * 
	 * @param  meterSearch MeterSearch
     * @return 			   MeterValidateResponseMapper 
	 */	
	public MeterValidateResponseMapper searchMeter(final MeterSearch meterSearch){
		logger.info(String.format("Preparing REST API endpoint for %s", this.getClass().getDeclaredMethods()[2]));
		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/search/meters");
			
			ResponseEntity<MeterValidateResponseMapper> postForEntity = restTemplate.postForEntity(uri, meterSearch, MeterValidateResponseMapper.class);
			meterValidateResponseMapper = postForEntity.getBody();
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		return meterValidateResponseMapper;
	}

	/*
	 * Method to call API Engine to check event is locked by some other user.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  adid		 String
     * @return 			 MeterLockedStatusResponseMapper 
	 */	
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(final String borough, final String eventName, final String adid) {
		logger.info("Preparing REST API endpoint for getLockedStatusByBoroughAndEventName");
		
		MeterLockedStatusResponseMapper meterLockedStatusResponseMapper = new MeterLockedStatusResponseMapper();
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("borough="+borough);
		stringBuilder.append("&eventName="+eventName);

		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/status/meters?", stringBuilder.toString());
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    return restTemplate.exchange(uri, HttpMethod.GET, entity, MeterLockedStatusResponseMapper.class).getBody();
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}
		
		return meterLockedStatusResponseMapper;		
	}

	/*
	 * Method to call API Engine to unlock the event.
	 * 
	 * @param  adid	String
     * @return 		void 
	 */
	public void unlockEvents(final String adid) {
		logger.info("Preparing REST API endpoint for unlockEvents");
		
		try{
			URI uri = RestClientBuilder.customBuildURI("/rcc/disconnect/events/status/meters?");
			
			HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    headers.set("adid", adid);
		    
		    HttpEntity<Object> entity = new HttpEntity<Object>(headers);
		    restTemplate.put(uri, entity);
		}catch(HttpClientErrorException ex){
			logger.info(String.format("Exception occured : "+ex.getResponseBodyAsString()));
		}		
	}
}
