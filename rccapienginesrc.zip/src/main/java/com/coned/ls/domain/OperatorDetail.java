package com.coned.ls.domain;

public class OperatorDetail {

	private boolean isAuthenticate;
	private String message;

	public OperatorDetail() {
	}

	public boolean isAuthenticate() {
		return isAuthenticate;
	}

	public void setAuthenticate(boolean isAuthenticate) {
		this.isAuthenticate = isAuthenticate;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public OperatorDetail(boolean isAuthenticate, String message) {
		super();
		this.isAuthenticate = isAuthenticate;
		this.message = message;
	}

}
