
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseDeviceConfigType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseDeviceConfigType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MfgDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoftwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HardwareConfig" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseDeviceConfigType", propOrder = {
    "mfgDate",
    "softwareConfig",
    "hardwareConfig"
})
public class BaseDeviceConfigType {

    @XmlElement(name = "MfgDate")
    protected String mfgDate;
    @XmlElement(name = "SoftwareConfig")
    protected String softwareConfig;
    @XmlElement(name = "HardwareConfig")
    protected String hardwareConfig;

    /**
     * Gets the value of the mfgDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMfgDate() {
        return mfgDate;
    }

    /**
     * Sets the value of the mfgDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMfgDate(String value) {
        this.mfgDate = value;
    }

    /**
     * Gets the value of the softwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareConfig() {
        return softwareConfig;
    }

    /**
     * Sets the value of the softwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareConfig(String value) {
        this.softwareConfig = value;
    }

    /**
     * Gets the value of the hardwareConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHardwareConfig() {
        return hardwareConfig;
    }

    /**
     * Sets the value of the hardwareConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHardwareConfig(String value) {
        this.hardwareConfig = value;
    }

}
