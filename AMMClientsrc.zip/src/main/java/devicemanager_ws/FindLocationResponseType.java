
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindLocationResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindLocationResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Summary" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindLocationResponse" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SearchKey" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="RowCount" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="ExceededMaximumNumberOfRows" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindLocationResponseType", propOrder = {
    "summary"
})
public class FindLocationResponseType {

    @XmlElement(name = "Summary")
    protected List<FindLocationResponse> summary;
    @XmlAttribute(name = "SearchKey", required = true)
    protected long searchKey;
    @XmlAttribute(name = "RowCount", required = true)
    protected long rowCount;
    @XmlAttribute(name = "ExceededMaximumNumberOfRows")
    protected Boolean exceededMaximumNumberOfRows;

    /**
     * Gets the value of the summary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the summary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSummary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FindLocationResponse }
     * 
     * 
     */
    public List<FindLocationResponse> getSummary() {
        if (summary == null) {
            summary = new ArrayList<FindLocationResponse>();
        }
        return this.summary;
    }

    /**
     * Gets the value of the searchKey property.
     * 
     */
    public long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     */
    public void setSearchKey(long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     */
    public long getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     */
    public void setRowCount(long value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the exceededMaximumNumberOfRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isExceededMaximumNumberOfRows() {
        if (exceededMaximumNumberOfRows == null) {
            return false;
        } else {
            return exceededMaximumNumberOfRows;
        }
    }

    /**
     * Sets the value of the exceededMaximumNumberOfRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExceededMaximumNumberOfRows(Boolean value) {
        this.exceededMaximumNumberOfRows = value;
    }

}
