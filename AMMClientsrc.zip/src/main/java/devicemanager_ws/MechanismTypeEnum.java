
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MechanismTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MechanismTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="IMU_METER_MECH_TYPE_DIAPHRAGM"/&gt;
 *     &lt;enumeration value="IMU_METER_MECH_TYPE_ROTARY"/&gt;
 *     &lt;enumeration value="IMU_METER_MECH_TYPE_TURBINE"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MechanismTypeEnum")
@XmlEnum
public enum MechanismTypeEnum {

    IMU_METER_MECH_TYPE_DIAPHRAGM("IMU_METER_MECH_TYPE_DIAPHRAGM"),
    IMU_METER_MECH_TYPE_ROTARY("IMU_METER_MECH_TYPE_ROTARY"),
    IMU_METER_MECH_TYPE_TURBINE("IMU_METER_MECH_TYPE_TURBINE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MechanismTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MechanismTypeEnum fromValue(String v) {
        for (MechanismTypeEnum c: MechanismTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
