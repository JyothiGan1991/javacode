
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkDeviceSummaryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkDeviceSummaryType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="UtilDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType"/&gt;
 *         &lt;element name="UtilNmState" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UtilNetworkStateType" minOccurs="0"/&gt;
 *         &lt;element name="UiqDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UIQDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="NicSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkDeviceSummaryType", propOrder = {
    "didType",
    "didSubtype",
    "utilDeviceID",
    "utilDeviceState",
    "utilNmState",
    "uiqDeviceState",
    "name",
    "nicSerialNumber",
    "macID",
    "serialNumber",
    "ipAddress",
    "description",
    "timeZoneID"
})
public class NetworkDeviceSummaryType {

    @XmlElement(name = "DidType", required = true)
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype", required = true)
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "UtilDeviceID", required = true)
    protected String utilDeviceID;
    @XmlElement(name = "UtilDeviceState", required = true)
    protected UtilDeviceStateType utilDeviceState;
    @XmlElement(name = "UtilNmState")
    protected UtilNetworkStateType utilNmState;
    @XmlElement(name = "UiqDeviceState")
    protected UIQDeviceStateType uiqDeviceState;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "NicSerialNumber")
    protected String nicSerialNumber;
    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "SerialNumber")
    protected String serialNumber;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "TimeZoneID")
    protected TimeZoneType timeZoneID;

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the utilDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceState() {
        return utilDeviceState;
    }

    /**
     * Sets the value of the utilDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceState(UtilDeviceStateType value) {
        this.utilDeviceState = value;
    }

    /**
     * Gets the value of the utilNmState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public UtilNetworkStateType getUtilNmState() {
        return utilNmState;
    }

    /**
     * Sets the value of the utilNmState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public void setUtilNmState(UtilNetworkStateType value) {
        this.utilNmState = value;
    }

    /**
     * Gets the value of the uiqDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getUiqDeviceState() {
        return uiqDeviceState;
    }

    /**
     * Sets the value of the uiqDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setUiqDeviceState(UIQDeviceStateType value) {
        this.uiqDeviceState = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the nicSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSerialNumber() {
        return nicSerialNumber;
    }

    /**
     * Sets the value of the nicSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSerialNumber(String value) {
        this.nicSerialNumber = value;
    }

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setTimeZoneID(TimeZoneType value) {
        this.timeZoneID = value;
    }

}
