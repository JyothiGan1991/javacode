
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProvisioningCommandStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ProvisioningCommandStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="GMI_RSM_CMD_UNSUPPORTED"/&gt;
 *     &lt;enumeration value="GMI_RSM_BAD_STATE"/&gt;
 *     &lt;enumeration value="GMI_RSM_SUCCESS_PENDING"/&gt;
 *     &lt;enumeration value="GMI_RSM_NO_METER_OR_COMM"/&gt;
 *     &lt;enumeration value="GMI_RSM_SEQ_NUM_LOW"/&gt;
 *     &lt;enumeration value="GMI_RSM_SUCCESS"/&gt;
 *     &lt;enumeration value="GMI_RSM_MULTIPLE_PATH_FAILURE"/&gt;
 *     &lt;enumeration value="GMI_RSM_FAILURE"/&gt;
 *     &lt;enumeration value="GMI_RSM_TIMEOUT"/&gt;
 *     &lt;enumeration value="GMI_RSM_METER_REJECT"/&gt;
 *     &lt;enumeration value="GMI_RSM_NET_MGR_FAILED"/&gt;
 *     &lt;enumeration value="GMI_RSM_STATUS_UNKNOWN"/&gt;
 *     &lt;enumeration value="GMI_RSM_BYPASS"/&gt;
 *     &lt;enumeration value="GMI_RSM_ALT_SRC"/&gt;
 *     &lt;enumeration value="GMI_RSM_COMM_ERROR"/&gt;
 *     &lt;enumeration value="GMI_RSM_SWITCH_CTRL_ERROR"/&gt;
 *     &lt;enumeration value="GMI_RSM_FAILED_OPEN"/&gt;
 *     &lt;enumeration value="GMI_RSM_FAILED_CLOSE"/&gt;
 *     &lt;enumeration value="GMI_RSM_STATE_PENDING"/&gt;
 *     &lt;enumeration value="GMI_RSM_FAILED_ARM"/&gt;
 *     &lt;enumeration value="GMI_RSM_LS_VOLTAGE_ERROR"/&gt;
 *     &lt;enumeration value="GMI_RSM_TEST_MODE"/&gt;
 *     &lt;enumeration value="GMI_RSM_SWITCH_CHARGING"/&gt;
 *     &lt;enumeration value="GMI_RSM_SD_IN_OPERATION"/&gt;
 *     &lt;enumeration value="GMI_RSM_STANDBY_MODE"/&gt;
 *     &lt;enumeration value="GMI_RSM_SWITCH_ARMED"/&gt;
 *     &lt;enumeration value="GMI_RSM_LOCKOUT"/&gt;
 *     &lt;enumeration value="GMI_RSM_INSUFF_PRIVLEGE"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ProvisioningCommandStatusEnumeration")
@XmlEnum
public enum ProvisioningCommandStatusEnumeration {

    GMI_RSM_CMD_UNSUPPORTED("GMI_RSM_CMD_UNSUPPORTED"),
    GMI_RSM_BAD_STATE("GMI_RSM_BAD_STATE"),
    GMI_RSM_SUCCESS_PENDING("GMI_RSM_SUCCESS_PENDING"),
    GMI_RSM_NO_METER_OR_COMM("GMI_RSM_NO_METER_OR_COMM"),
    GMI_RSM_SEQ_NUM_LOW("GMI_RSM_SEQ_NUM_LOW"),
    GMI_RSM_SUCCESS("GMI_RSM_SUCCESS"),
    GMI_RSM_MULTIPLE_PATH_FAILURE("GMI_RSM_MULTIPLE_PATH_FAILURE"),
    GMI_RSM_FAILURE("GMI_RSM_FAILURE"),
    GMI_RSM_TIMEOUT("GMI_RSM_TIMEOUT"),
    GMI_RSM_METER_REJECT("GMI_RSM_METER_REJECT"),
    GMI_RSM_NET_MGR_FAILED("GMI_RSM_NET_MGR_FAILED"),
    GMI_RSM_STATUS_UNKNOWN("GMI_RSM_STATUS_UNKNOWN"),
    GMI_RSM_BYPASS("GMI_RSM_BYPASS"),
    GMI_RSM_ALT_SRC("GMI_RSM_ALT_SRC"),
    GMI_RSM_COMM_ERROR("GMI_RSM_COMM_ERROR"),
    GMI_RSM_SWITCH_CTRL_ERROR("GMI_RSM_SWITCH_CTRL_ERROR"),
    GMI_RSM_FAILED_OPEN("GMI_RSM_FAILED_OPEN"),
    GMI_RSM_FAILED_CLOSE("GMI_RSM_FAILED_CLOSE"),
    GMI_RSM_STATE_PENDING("GMI_RSM_STATE_PENDING"),
    GMI_RSM_FAILED_ARM("GMI_RSM_FAILED_ARM"),
    GMI_RSM_LS_VOLTAGE_ERROR("GMI_RSM_LS_VOLTAGE_ERROR"),
    GMI_RSM_TEST_MODE("GMI_RSM_TEST_MODE"),
    GMI_RSM_SWITCH_CHARGING("GMI_RSM_SWITCH_CHARGING"),
    GMI_RSM_SD_IN_OPERATION("GMI_RSM_SD_IN_OPERATION"),
    GMI_RSM_STANDBY_MODE("GMI_RSM_STANDBY_MODE"),
    GMI_RSM_SWITCH_ARMED("GMI_RSM_SWITCH_ARMED"),
    GMI_RSM_LOCKOUT("GMI_RSM_LOCKOUT"),
    GMI_RSM_INSUFF_PRIVLEGE("GMI_RSM_INSUFF_PRIVLEGE"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ProvisioningCommandStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ProvisioningCommandStatusEnumeration fromValue(String v) {
        for (ProvisioningCommandStatusEnumeration c: ProvisioningCommandStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
