
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DistanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DistanceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DistanceValue" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="DistanceUOM" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DistanceUOMEnumeration"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DistanceType", propOrder = {
    "distanceValue",
    "distanceUOM"
})
public class DistanceType {

    @XmlElement(name = "DistanceValue")
    protected double distanceValue;
    @XmlElement(name = "DistanceUOM", required = true)
    @XmlSchemaType(name = "string")
    protected DistanceUOMEnumeration distanceUOM;

    /**
     * Gets the value of the distanceValue property.
     * 
     */
    public double getDistanceValue() {
        return distanceValue;
    }

    /**
     * Sets the value of the distanceValue property.
     * 
     */
    public void setDistanceValue(double value) {
        this.distanceValue = value;
    }

    /**
     * Gets the value of the distanceUOM property.
     * 
     * @return
     *     possible object is
     *     {@link DistanceUOMEnumeration }
     *     
     */
    public DistanceUOMEnumeration getDistanceUOM() {
        return distanceUOM;
    }

    /**
     * Sets the value of the distanceUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistanceUOMEnumeration }
     *     
     */
    public void setDistanceUOM(DistanceUOMEnumeration value) {
        this.distanceUOM = value;
    }

}
