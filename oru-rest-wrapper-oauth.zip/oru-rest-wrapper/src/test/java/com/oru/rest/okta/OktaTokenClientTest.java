package com.oru.rest.okta;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

class OktaTokenClientTest {

    private OktaProperties properties;
    private OktaTokenClient client;
    private MockRestServiceServer server;

    @BeforeEach
    void setUp() throws Exception {
        properties = new OktaProperties();
        properties.setEnabled(true);
        properties.setDomain("example.okta.com");
        properties.setAuthorizationServerId("default");
        properties.setClientId("client-id");
        properties.setClientSecret("client-secret");
        properties.setScope("api.read");

        client = new OktaTokenClient(properties, new ObjectMapper());

        Field field = OktaTokenClient.class.getDeclaredField("restTemplate");
        field.setAccessible(true);
        RestTemplate restTemplate = (RestTemplate) field.get(client);
        server = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    void requestAccessToken_success() {
        String json = "{\"access_token\":\"tok-123\",\"token_type\":\"Bearer\",\"expires_in\":3600,\"scope\":\"api.read\"}";
        server.expect(requestTo("https://example.okta.com/oauth2/default/v1/token"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(header("Content-Type", "application/x-www-form-urlencoded"))
                .andRespond(withSuccess(json, MediaType.APPLICATION_JSON));

        OktaTokenResponse response = client.requestAccessToken();
        assertNotNull(response);
        assertEquals("tok-123", response.getAccessToken());
        assertEquals(3600L, response.getExpiresIn().longValue());
        server.verify();
    }

    @Test
    void requestAccessToken_missingCredentials() {
        properties.setClientId("");
        assertThrows(IllegalStateException.class, () -> client.requestAccessToken());
    }
}
