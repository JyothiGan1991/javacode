package com.coned.event.subscriber;

import java.io.StringReader;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import com.coned.event.repository.EventRepository;
import com.ssn.schema.service.v2_6.eventmanager.FindEventResponseType;
import com.ssn.schema.service.v2_6.eventmanager.FindEventResultType;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.Unmarshaller;

@Service
public class EventBridgeListener {
	private static Logger logger = LoggerFactory.getLogger(EventBridgeListener.class);

	@Autowired
	protected Unmarshaller unmarshaller;

	@Autowired
	protected EventRepository dao;

	/**
	 * The listenerConnFactory is used to create the listener container and is
	 * responsible for destination end point
	 * 
	 * @param obj the JMS data type
	 * @throws JMSException
	 */
	@JmsListener(destination = "${tibco.ssn.ods.queue}", containerFactory = "listenerConnFactory")
	public void processMessage(Object obj) throws JMSException {
		logger.info("### Message received in queue ### " + obj);
		try {
			final TextMessage textMessage = (TextMessage) obj;
			logger.debug("" + textMessage.getText());

			StringReader reader = new StringReader(textMessage.getText());
			Source source = new StreamSource(reader);
			JAXBElement<FindEventResponseType> root = unmarshaller.unmarshal(source, FindEventResponseType.class);
			FindEventResponseType event = root.getValue();

			logger.info("FindEventResponseType -> size {}", event.getResult().size());

			// Itron confirmed that it is one message(FindEventResultType) per event
			FindEventResultType result = event.getResult().get(0);

			logger.info("FindEventResponseType -> EventId {}", event.getResult().get(0).getEventId());
			logger.info("FindEventResponseType -> EventName {}", event.getResult().get(0).getEventName());
			logger.info("FindEventResponseType -> Meter Number {}", event.getResult().get(0).getSourceUtilID());
			logger.info("FindEventResponseType -> Mac Address {}", event.getResult().get(0).getSourceId());
			logger.info("FindEventResponseType -> Job Id {}", event.getResult().get(0).getJobId());

			int row = dao.saveEventStatus(result);
			logger.info("Successfully inserted {} event to LSB_EVT_RESPONSE table", row);

		} catch (Exception e) {
			logger.error("Error processing the message from the bridge queue; ", e);
		}
	}
}
