package com.coned.model;

import java.sql.Date;
import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ls_reject_event_list", schema = "AMI_LOAD_SHEDDING")
public class RejectEventList {

	@Id
	@JsonIgnore
	@Column(name = "fk_meter_event_load_id")
	private Long id;

	@Column(name = "event_name")
	private String eventName;

	@Column(name = "boro_muni")
	private String borough;

	@Column(name = "reject_time")
	private LocalDateTime rejectDateTime;

	@Column(name = "operator_ad_id")
	private String operatorAdId;

	public String getOperatorAdId() {
		return operatorAdId;
	}

	public void setOperatorAdId(String operatorAdId) {
		this.operatorAdId = operatorAdId;
	}
	public RejectEventList() {

    }
	public RejectEventList(Long id, String eventname, String borough) { 
		this.id = id;
		this.eventName = eventname; 
		this.borough = borough;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEventname() {
		return eventName;
	}

	public void setEventname(String eventname) {
		this.eventName = eventname;
	}

	public String getBorough() {
		return borough;
	}

	public void setBoromuni(String boromuni) {
		this.borough = boromuni;
	}

	public LocalDateTime getRejetDateTime() {
		return rejectDateTime;
	}

	public void setRejetDateTime(LocalDateTime rejettime) {
		this.rejectDateTime = rejettime;
	}

	@Override
	public String toString() {
        return "User [id=" + id + ", eventName=" + eventName + ", rejectDateTime=" + rejectDateTime + "]";
//		return "User [id=" + id + ", eventName=" + eventName + "]";
	}
}
