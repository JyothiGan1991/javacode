
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetAccountType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetAccountType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AccountType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="InsertTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InsertBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UpdateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UpdateBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetAccountType", propOrder = {
    "insertTime",
    "insertBy",
    "updateTime",
    "updateBy"
})
public class GetAccountType
    extends AccountType
{

    @XmlElement(name = "InsertTime")
    protected String insertTime;
    @XmlElement(name = "InsertBy")
    protected String insertBy;
    @XmlElement(name = "UpdateTime")
    protected String updateTime;
    @XmlElement(name = "UpdateBy")
    protected String updateBy;

    /**
     * Gets the value of the insertTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertTime() {
        return insertTime;
    }

    /**
     * Sets the value of the insertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertTime(String value) {
        this.insertTime = value;
    }

    /**
     * Gets the value of the insertBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertBy() {
        return insertBy;
    }

    /**
     * Sets the value of the insertBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertBy(String value) {
        this.insertBy = value;
    }

    /**
     * Gets the value of the updateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateTime() {
        return updateTime;
    }

    /**
     * Sets the value of the updateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateTime(String value) {
        this.updateTime = value;
    }

    /**
     * Gets the value of the updateBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * Sets the value of the updateBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateBy(String value) {
        this.updateBy = value;
    }

}
