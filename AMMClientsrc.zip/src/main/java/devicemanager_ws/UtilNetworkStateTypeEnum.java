
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UtilNetworkStateTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UtilNetworkStateTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="UTL_NETWORK_STATE_NEW"/&gt;
 *     &lt;enumeration value="UTL_NETWORK_STATE_ACTIVE"/&gt;
 *     &lt;enumeration value="UTL_NETWORK_STATE_INACTIVE"/&gt;
 *     &lt;enumeration value="UTL_NETWORK_STATE_REMOVED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "UtilNetworkStateTypeEnum")
@XmlEnum
public enum UtilNetworkStateTypeEnum {

    UTL_NETWORK_STATE_NEW("UTL_NETWORK_STATE_NEW"),
    UTL_NETWORK_STATE_ACTIVE("UTL_NETWORK_STATE_ACTIVE"),
    UTL_NETWORK_STATE_INACTIVE("UTL_NETWORK_STATE_INACTIVE"),
    UTL_NETWORK_STATE_REMOVED("UTL_NETWORK_STATE_REMOVED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    UtilNetworkStateTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UtilNetworkStateTypeEnum fromValue(String v) {
        for (UtilNetworkStateTypeEnum c: UtilNetworkStateTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
