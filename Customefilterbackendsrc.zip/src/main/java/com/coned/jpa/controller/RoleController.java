/*package com.coned.jpa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coned.model.User;
import com.coned.model.Role;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.RoleRepository;

@RestController
//@RequestMapping("/api/v1")
public class RoleController {

    @Autowired
    private RoleRepository roleRepository;


    @GetMapping("/roles")
    public List < Role > getRoles() {
        return roleRepository.findAll();
    }

    @GetMapping("/roles/{id}")
    public ResponseEntity < Role > getInstructorById(
        @PathVariable(value = "id") Long roleId) throws ResourceMissingException {
        Role user = roleRepository.findById(roleId)
            .orElseThrow(() -> new ResourceMissingException("Role not found :: " + roleId));
        return ResponseEntity.ok().body(user);
    }
    */
    /*@GetMapping("/roles/search/{firstName}")
    public ResponseEntity < Role > getInstructorByFirstName(
        @PathVariable(value = "firstName") String firstName) throws ResourceMissingException {
        Role user = (Role) roleRepository.findByFirstNameLike(firstName);//.orElseThrow(() -> new ResourceMissingException("Role not found :: " + firstName));
		Optional<Role> credentials = roleRepository.findByFirstName(firstname);

        return ResponseEntity.ok().body(user);
    }
    @GetMapping("/roles/search/{firstname}")
    public List<Role> getByFirstName(@PathVariable("firstname") String firstname) {
        List< Role > ret = roleRepository.findByFirstNameContaining(firstname);
        return ( ret );
    }
    
	@GetMapping("/check/{firstname}")
	public String check(@PathVariable("firstname") String firstname) {
		Optional<Role> credentials = roleRepository.findByFirstName(firstname);
		return credentials.isPresent() ? "exist" : "doesn't exist";
	}
     */
/*
    @PostMapping("/roles")
    public Role createUser(@Valid @RequestBody Role role) {
        return roleRepository.save(role);
    }

    @PutMapping("/roles/{id}")
    public ResponseEntity < Role > updateUser(
        @PathVariable(value = "id") Long roleId,
        @Valid @RequestBody Role userDetails) throws ResourceMissingException {
        Role user = roleRepository.findById(roleId)
            .orElseThrow(() -> new ResourceMissingException("Role not found :: " + roleId));
        user.setName(userDetails.getName());
        final Role updatedUser = roleRepository.save(user);
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/roles/{id}")
    public Map < String, Boolean > deleteUser(
        @PathVariable(value = "id") Long roleId) throws ResourceMissingException {
        Role instructor = roleRepository.findById(roleId)
            .orElseThrow(() -> new ResourceMissingException("Role not found :: " + roleId));

        roleRepository.delete(instructor);
        Map < String, Boolean > response = new HashMap < > ();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
}
*/