
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UtilDeviceStateTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UtilDeviceStateTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_NEW"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_ACTIVE"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_INACTIVE"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_MAINTENANCE"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_OPTIMIZE"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_RETIRED"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_DISCONNECTED"/&gt;
 *     &lt;enumeration value="UTL_DEVICE_STATE_SVC_DISCONECT"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "UtilDeviceStateTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum UtilDeviceStateTypeEnum {

    UTL_DEVICE_STATE_NEW("UTL_DEVICE_STATE_NEW"),
    UTL_DEVICE_STATE_ACTIVE("UTL_DEVICE_STATE_ACTIVE"),
    UTL_DEVICE_STATE_INACTIVE("UTL_DEVICE_STATE_INACTIVE"),
    UTL_DEVICE_STATE_MAINTENANCE("UTL_DEVICE_STATE_MAINTENANCE"),
    UTL_DEVICE_STATE_OPTIMIZE("UTL_DEVICE_STATE_OPTIMIZE"),
    UTL_DEVICE_STATE_RETIRED("UTL_DEVICE_STATE_RETIRED"),
    UTL_DEVICE_STATE_DISCONNECTED("UTL_DEVICE_STATE_DISCONNECTED"),
    UTL_DEVICE_STATE_SVC_DISCONECT("UTL_DEVICE_STATE_SVC_DISCONECT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    UtilDeviceStateTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UtilDeviceStateTypeEnum fromValue(String v) {
        for (UtilDeviceStateTypeEnum c: UtilDeviceStateTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
