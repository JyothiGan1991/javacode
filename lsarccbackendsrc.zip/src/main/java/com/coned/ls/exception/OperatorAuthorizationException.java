package com.coned.ls.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 
 * Custom exception for unauthorized requests.
 *
 */
@ResponseStatus(value=HttpStatus.UNAUTHORIZED)
public class OperatorAuthorizationException extends RuntimeException {

	private static final long serialVersionUID = -470180507998010368L;

	public OperatorAuthorizationException() {
		super();
	}
	
	public OperatorAuthorizationException(String message) {
		super(message);
		
	}
	public OperatorAuthorizationException(String message,HttpStatus status) {
		super(message);
		
	}
	public OperatorAuthorizationException(String message,Throwable cause) {
		   super(message,cause);
		}
}
