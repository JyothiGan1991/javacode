
package devicemanager_ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the devicemanager_ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AddBatteryTypeConfig_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddBatteryTypeConfig");
    private final static QName _AddDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddDeviceResponse");
    private final static QName _AddDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddDevice");
    private final static QName _AddDistributionNetwork_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddDistributionNetwork");
    private final static QName _AddEditTypeConfigResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddEditTypeConfigResponse");
    private final static QName _AddLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddLocation");
    private final static QName _AddLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddLocationResponse");
    private final static QName _AddLocationNew_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddLocationNew");
    private final static QName _AddNote_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddNote");
    private final static QName _AddNoteResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddNoteResponse");
    private final static QName _AddServicePoint_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "AddServicePoint");
    private final static QName _EditDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditDevice");
    private final static QName _EditDeviceNew_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditDeviceNew");
    private final static QName _EditDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditDeviceResponse");
    private final static QName _EditDistributionNetwork_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditDistributionNetwork");
    private final static QName _EditLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditLocation");
    private final static QName _EditLocationNew_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditLocationNew");
    private final static QName _EditLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditLocationResponse");
    private final static QName _EditServicePoint_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "EditServicePoint");
    private final static QName _FindDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindDevice");
    private final static QName _FindDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindDeviceResponse");
    private final static QName _FindLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindLocation");
    private final static QName _FindLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindLocationResponse");
    private final static QName _FindNic_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindNic");
    private final static QName _FindNicResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindNicResponse");
    private final static QName _FindNiclessDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindNiclessDevice");
    private final static QName _FindNiclessDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "FindNiclessDeviceResponse");
    private final static QName _GetDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDevice");
    private final static QName _GetDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDeviceResponse");
    private final static QName _GetDeviceStateHistory_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDeviceStateHistory");
    private final static QName _GetDeviceStateHistoryResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDeviceStateHistoryResponse");
    private final static QName _GetDistributionNetwork_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDistributionNetwork");
    private final static QName _GetDistributionNetworkResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetDistributionNetworkResponse");
    private final static QName _GetLastReadPointers_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetLastReadPointers");
    private final static QName _GetLastReadPointersResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetLastReadPointersResponse");
    private final static QName _GetLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetLocation");
    private final static QName _GetLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetLocationResponse");
    private final static QName _GetServicePoint_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetServicePoint");
    private final static QName _GetServicePointResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "GetServicePointResponse");
    private final static QName _ListNetworkDevicesResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ListNetworkDevicesResponse");
    private final static QName _ListNetworkDevices_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ListNetworkDevices");
    private final static QName _ReInitializeDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReInitializeDevice");
    private final static QName _ReInitializeDeviceResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReInitializeDeviceResponse");
    private final static QName _ReplaceDeviceAtLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReplaceDeviceAtLocation");
    private final static QName _ReplaceDeviceAtLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReplaceDeviceAtLocationResponse");
    private final static QName _ReplaceLocation_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReplaceLocation");
    private final static QName _ReplaceLocationResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ReplaceLocationResponse");
    private final static QName _SetAdminState_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "SetAdminState");
    private final static QName _SetAdminStateResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "SetAdminStateResponse");
    private final static QName _SelectDevicesFromSearchResult_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "SelectDevicesFromSearchResult");
    private final static QName _SelectDevicesFromSearchResultResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "SelectDevicesFromSearchResultResponse");
    private final static QName _UpdateDevice_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "UpdateDevice");
    private final static QName _UpdateServicePoint_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "UpdateServicePoint");
    private final static QName _ErrorCodeFault_QNAME = new QName("urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", "ErrorCodeFault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: devicemanager_ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CachedResultsType }
     * 
     */
    public CachedResultsType createCachedResultsType() {
        return new CachedResultsType();
    }

    /**
     * Create an instance of {@link JobIDType }
     * 
     */
    public JobIDType createJobIDType() {
        return new JobIDType();
    }

    /**
     * Create an instance of {@link TotalCountType }
     * 
     */
    public TotalCountType createTotalCountType() {
        return new TotalCountType();
    }

    /**
     * Create an instance of {@link ActivationStatusType }
     * 
     */
    public ActivationStatusType createActivationStatusType() {
        return new ActivationStatusType();
    }

    /**
     * Create an instance of {@link ApprovalStatusType }
     * 
     */
    public ApprovalStatusType createApprovalStatusType() {
        return new ApprovalStatusType();
    }

    /**
     * Create an instance of {@link CronJobTypeType }
     * 
     */
    public CronJobTypeType createCronJobTypeType() {
        return new CronJobTypeType();
    }

    /**
     * Create an instance of {@link DayType }
     * 
     */
    public DayType createDayType() {
        return new DayType();
    }

    /**
     * Create an instance of {@link DeviceTypeType }
     * 
     */
    public DeviceTypeType createDeviceTypeType() {
        return new DeviceTypeType();
    }

    /**
     * Create an instance of {@link ExecutionStatusType }
     * 
     */
    public ExecutionStatusType createExecutionStatusType() {
        return new ExecutionStatusType();
    }

    /**
     * Create an instance of {@link JobSubTypeType }
     * 
     */
    public JobSubTypeType createJobSubTypeType() {
        return new JobSubTypeType();
    }

    /**
     * Create an instance of {@link JobTypeType }
     * 
     */
    public JobTypeType createJobTypeType() {
        return new JobTypeType();
    }

    /**
     * Create an instance of {@link MeterReadTypeType }
     * 
     */
    public MeterReadTypeType createMeterReadTypeType() {
        return new MeterReadTypeType();
    }

    /**
     * Create an instance of {@link DeviceCapabilityType }
     * 
     */
    public DeviceCapabilityType createDeviceCapabilityType() {
        return new DeviceCapabilityType();
    }

    /**
     * Create an instance of {@link MonthType }
     * 
     */
    public MonthType createMonthType() {
        return new MonthType();
    }

    /**
     * Create an instance of {@link NotificationTypeType }
     * 
     */
    public NotificationTypeType createNotificationTypeType() {
        return new NotificationTypeType();
    }

    /**
     * Create an instance of {@link PositionType }
     * 
     */
    public PositionType createPositionType() {
        return new PositionType();
    }

    /**
     * Create an instance of {@link PriorityType }
     * 
     */
    public PriorityType createPriorityType() {
        return new PriorityType();
    }

    /**
     * Create an instance of {@link ProvisioningActionType }
     * 
     */
    public ProvisioningActionType createProvisioningActionType() {
        return new ProvisioningActionType();
    }

    /**
     * Create an instance of {@link ScheduleType }
     * 
     */
    public ScheduleType createScheduleType() {
        return new ScheduleType();
    }

    /**
     * Create an instance of {@link TaskStatusType }
     * 
     */
    public TaskStatusType createTaskStatusType() {
        return new TaskStatusType();
    }

    /**
     * Create an instance of {@link TimeZoneType }
     * 
     */
    public TimeZoneType createTimeZoneType() {
        return new TimeZoneType();
    }

    /**
     * Create an instance of {@link TOUTierWeekdayType }
     * 
     */
    public TOUTierWeekdayType createTOUTierWeekdayType() {
        return new TOUTierWeekdayType();
    }

    /**
     * Create an instance of {@link UIQDeviceStateType }
     * 
     */
    public UIQDeviceStateType createUIQDeviceStateType() {
        return new UIQDeviceStateType();
    }

    /**
     * Create an instance of {@link UtilDeviceStateType }
     * 
     */
    public UtilDeviceStateType createUtilDeviceStateType() {
        return new UtilDeviceStateType();
    }

    /**
     * Create an instance of {@link WeekdayType }
     * 
     */
    public WeekdayType createWeekdayType() {
        return new WeekdayType();
    }

    /**
     * Create an instance of {@link DefinedLocationType }
     * 
     */
    public DefinedLocationType createDefinedLocationType() {
        return new DefinedLocationType();
    }

    /**
     * Create an instance of {@link DeviceSubTypeType }
     * 
     */
    public DeviceSubTypeType createDeviceSubTypeType() {
        return new DeviceSubTypeType();
    }

    /**
     * Create an instance of {@link MeterModeType }
     * 
     */
    public MeterModeType createMeterModeType() {
        return new MeterModeType();
    }

    /**
     * Create an instance of {@link WANType }
     * 
     */
    public WANType createWANType() {
        return new WANType();
    }

    /**
     * Create an instance of {@link BaseBatteryInfoType }
     * 
     */
    public BaseBatteryInfoType createBaseBatteryInfoType() {
        return new BaseBatteryInfoType();
    }

    /**
     * Create an instance of {@link AddEditDeviceResponseType }
     * 
     */
    public AddEditDeviceResponseType createAddEditDeviceResponseType() {
        return new AddEditDeviceResponseType();
    }

    /**
     * Create an instance of {@link AddDeviceReqType }
     * 
     */
    public AddDeviceReqType createAddDeviceReqType() {
        return new AddDeviceReqType();
    }

    /**
     * Create an instance of {@link DistNetworkType }
     * 
     */
    public DistNetworkType createDistNetworkType() {
        return new DistNetworkType();
    }

    /**
     * Create an instance of {@link AddEditTypeConfigResponseType }
     * 
     */
    public AddEditTypeConfigResponseType createAddEditTypeConfigResponseType() {
        return new AddEditTypeConfigResponseType();
    }

    /**
     * Create an instance of {@link AddEditLocationReqType }
     * 
     */
    public AddEditLocationReqType createAddEditLocationReqType() {
        return new AddEditLocationReqType();
    }

    /**
     * Create an instance of {@link AddEditLocationResponseType }
     * 
     */
    public AddEditLocationResponseType createAddEditLocationResponseType() {
        return new AddEditLocationResponseType();
    }

    /**
     * Create an instance of {@link AddLocationType }
     * 
     */
    public AddLocationType createAddLocationType() {
        return new AddLocationType();
    }

    /**
     * Create an instance of {@link AddNoteReqType }
     * 
     */
    public AddNoteReqType createAddNoteReqType() {
        return new AddNoteReqType();
    }

    /**
     * Create an instance of {@link EmptyType }
     * 
     */
    public EmptyType createEmptyType() {
        return new EmptyType();
    }

    /**
     * Create an instance of {@link ServicePtType }
     * 
     */
    public ServicePtType createServicePtType() {
        return new ServicePtType();
    }

    /**
     * Create an instance of {@link EditDeviceReqType }
     * 
     */
    public EditDeviceReqType createEditDeviceReqType() {
        return new EditDeviceReqType();
    }

    /**
     * Create an instance of {@link EditDeviceNewReqType }
     * 
     */
    public EditDeviceNewReqType createEditDeviceNewReqType() {
        return new EditDeviceNewReqType();
    }

    /**
     * Create an instance of {@link LocationType }
     * 
     */
    public LocationType createLocationType() {
        return new LocationType();
    }

    /**
     * Create an instance of {@link FindDeviceReqType }
     * 
     */
    public FindDeviceReqType createFindDeviceReqType() {
        return new FindDeviceReqType();
    }

    /**
     * Create an instance of {@link FindDeviceResponseType }
     * 
     */
    public FindDeviceResponseType createFindDeviceResponseType() {
        return new FindDeviceResponseType();
    }

    /**
     * Create an instance of {@link FindLocationReqType }
     * 
     */
    public FindLocationReqType createFindLocationReqType() {
        return new FindLocationReqType();
    }

    /**
     * Create an instance of {@link FindLocationResponseType }
     * 
     */
    public FindLocationResponseType createFindLocationResponseType() {
        return new FindLocationResponseType();
    }

    /**
     * Create an instance of {@link FindNicResponseType }
     * 
     */
    public FindNicResponseType createFindNicResponseType() {
        return new FindNicResponseType();
    }

    /**
     * Create an instance of {@link FindNiclessDeviceResponseType }
     * 
     */
    public FindNiclessDeviceResponseType createFindNiclessDeviceResponseType() {
        return new FindNiclessDeviceResponseType();
    }

    /**
     * Create an instance of {@link GetDeviceReqType }
     * 
     */
    public GetDeviceReqType createGetDeviceReqType() {
        return new GetDeviceReqType();
    }

    /**
     * Create an instance of {@link GetDeviceResponseType }
     * 
     */
    public GetDeviceResponseType createGetDeviceResponseType() {
        return new GetDeviceResponseType();
    }

    /**
     * Create an instance of {@link GetDeviceStateType }
     * 
     */
    public GetDeviceStateType createGetDeviceStateType() {
        return new GetDeviceStateType();
    }

    /**
     * Create an instance of {@link GetDeviceStateResponseType }
     * 
     */
    public GetDeviceStateResponseType createGetDeviceStateResponseType() {
        return new GetDeviceStateResponseType();
    }

    /**
     * Create an instance of {@link GetDistributionNetworkReqType }
     * 
     */
    public GetDistributionNetworkReqType createGetDistributionNetworkReqType() {
        return new GetDistributionNetworkReqType();
    }

    /**
     * Create an instance of {@link GetLastReadPointersReqType }
     * 
     */
    public GetLastReadPointersReqType createGetLastReadPointersReqType() {
        return new GetLastReadPointersReqType();
    }

    /**
     * Create an instance of {@link GetLastReadPointersResponseType }
     * 
     */
    public GetLastReadPointersResponseType createGetLastReadPointersResponseType() {
        return new GetLastReadPointersResponseType();
    }

    /**
     * Create an instance of {@link GetLocationReqType }
     * 
     */
    public GetLocationReqType createGetLocationReqType() {
        return new GetLocationReqType();
    }

    /**
     * Create an instance of {@link GetLocationResponseType }
     * 
     */
    public GetLocationResponseType createGetLocationResponseType() {
        return new GetLocationResponseType();
    }

    /**
     * Create an instance of {@link GetServicePtReqType }
     * 
     */
    public GetServicePtReqType createGetServicePtReqType() {
        return new GetServicePtReqType();
    }

    /**
     * Create an instance of {@link GetServicePtType }
     * 
     */
    public GetServicePtType createGetServicePtType() {
        return new GetServicePtType();
    }

    /**
     * Create an instance of {@link ListNetworkDevicesResponseType }
     * 
     */
    public ListNetworkDevicesResponseType createListNetworkDevicesResponseType() {
        return new ListNetworkDevicesResponseType();
    }

    /**
     * Create an instance of {@link ListNetworkDevicesReqType }
     * 
     */
    public ListNetworkDevicesReqType createListNetworkDevicesReqType() {
        return new ListNetworkDevicesReqType();
    }

    /**
     * Create an instance of {@link ReInitializeDeviceReqType }
     * 
     */
    public ReInitializeDeviceReqType createReInitializeDeviceReqType() {
        return new ReInitializeDeviceReqType();
    }

    /**
     * Create an instance of {@link ReplaceDeviceAtLocationReqType }
     * 
     */
    public ReplaceDeviceAtLocationReqType createReplaceDeviceAtLocationReqType() {
        return new ReplaceDeviceAtLocationReqType();
    }

    /**
     * Create an instance of {@link ReplaceLocationReqType }
     * 
     */
    public ReplaceLocationReqType createReplaceLocationReqType() {
        return new ReplaceLocationReqType();
    }

    /**
     * Create an instance of {@link SetAdminStateReqType }
     * 
     */
    public SetAdminStateReqType createSetAdminStateReqType() {
        return new SetAdminStateReqType();
    }

    /**
     * Create an instance of {@link SelectDevicesFromSearchResultType }
     * 
     */
    public SelectDevicesFromSearchResultType createSelectDevicesFromSearchResultType() {
        return new SelectDevicesFromSearchResultType();
    }

    /**
     * Create an instance of {@link SelectDevicesFromSearchResultResponseType }
     * 
     */
    public SelectDevicesFromSearchResultResponseType createSelectDevicesFromSearchResultResponseType() {
        return new SelectDevicesFromSearchResultResponseType();
    }

    /**
     * Create an instance of {@link UpdateDeviceReqType }
     * 
     */
    public UpdateDeviceReqType createUpdateDeviceReqType() {
        return new UpdateDeviceReqType();
    }

    /**
     * Create an instance of {@link UpdateServicePtType }
     * 
     */
    public UpdateServicePtType createUpdateServicePtType() {
        return new UpdateServicePtType();
    }

    /**
     * Create an instance of {@link ErrorCodeFaultType }
     * 
     */
    public ErrorCodeFaultType createErrorCodeFaultType() {
        return new ErrorCodeFaultType();
    }

    /**
     * Create an instance of {@link AccountType }
     * 
     */
    public AccountType createAccountType() {
        return new AccountType();
    }

    /**
     * Create an instance of {@link AddEditBaseDeviceType }
     * 
     */
    public AddEditBaseDeviceType createAddEditBaseDeviceType() {
        return new AddEditBaseDeviceType();
    }

    /**
     * Create an instance of {@link AddEditBridgeTypeReq }
     * 
     */
    public AddEditBridgeTypeReq createAddEditBridgeTypeReq() {
        return new AddEditBridgeTypeReq();
    }

    /**
     * Create an instance of {@link AddEditBridgeType }
     * 
     */
    public AddEditBridgeType createAddEditBridgeType() {
        return new AddEditBridgeType();
    }

    /**
     * Create an instance of {@link AddEditGatewayTypeReq }
     * 
     */
    public AddEditGatewayTypeReq createAddEditGatewayTypeReq() {
        return new AddEditGatewayTypeReq();
    }

    /**
     * Create an instance of {@link AddEditGatewayType }
     * 
     */
    public AddEditGatewayType createAddEditGatewayType() {
        return new AddEditGatewayType();
    }

    /**
     * Create an instance of {@link AddEditIMUTypeReq }
     * 
     */
    public AddEditIMUTypeReq createAddEditIMUTypeReq() {
        return new AddEditIMUTypeReq();
    }

    /**
     * Create an instance of {@link AddEditIMUType }
     * 
     */
    public AddEditIMUType createAddEditIMUType() {
        return new AddEditIMUType();
    }

    /**
     * Create an instance of {@link AddEditMeterType }
     * 
     */
    public AddEditMeterType createAddEditMeterType() {
        return new AddEditMeterType();
    }

    /**
     * Create an instance of {@link AddEditMeterTypeReq }
     * 
     */
    public AddEditMeterTypeReq createAddEditMeterTypeReq() {
        return new AddEditMeterTypeReq();
    }

    /**
     * Create an instance of {@link AddEditRelayTypeReq }
     * 
     */
    public AddEditRelayTypeReq createAddEditRelayTypeReq() {
        return new AddEditRelayTypeReq();
    }

    /**
     * Create an instance of {@link AddNetworkBaseDeviceType }
     * 
     */
    public AddNetworkBaseDeviceType createAddNetworkBaseDeviceType() {
        return new AddNetworkBaseDeviceType();
    }

    /**
     * Create an instance of {@link AlarmStatusType }
     * 
     */
    public AlarmStatusType createAlarmStatusType() {
        return new AlarmStatusType();
    }

    /**
     * Create an instance of {@link AlarmType }
     * 
     */
    public AlarmType createAlarmType() {
        return new AlarmType();
    }

    /**
     * Create an instance of {@link AlarmsType }
     * 
     */
    public AlarmsType createAlarmsType() {
        return new AlarmsType();
    }

    /**
     * Create an instance of {@link AllDevicesType }
     * 
     */
    public AllDevicesType createAllDevicesType() {
        return new AllDevicesType();
    }

    /**
     * Create an instance of {@link BaseBridgeTypeConfig }
     * 
     */
    public BaseBridgeTypeConfig createBaseBridgeTypeConfig() {
        return new BaseBridgeTypeConfig();
    }

    /**
     * Create an instance of {@link BaseDeviceConfigType }
     * 
     */
    public BaseDeviceConfigType createBaseDeviceConfigType() {
        return new BaseDeviceConfigType();
    }

    /**
     * Create an instance of {@link BaseGatewayTypeConfig }
     * 
     */
    public BaseGatewayTypeConfig createBaseGatewayTypeConfig() {
        return new BaseGatewayTypeConfig();
    }

    /**
     * Create an instance of {@link BaseIMUTypeConfig }
     * 
     */
    public BaseIMUTypeConfig createBaseIMUTypeConfig() {
        return new BaseIMUTypeConfig();
    }

    /**
     * Create an instance of {@link BaseIMUMeterTypeConfig }
     * 
     */
    public BaseIMUMeterTypeConfig createBaseIMUMeterTypeConfig() {
        return new BaseIMUMeterTypeConfig();
    }

    /**
     * Create an instance of {@link BaseMeterTypeConfig }
     * 
     */
    public BaseMeterTypeConfig createBaseMeterTypeConfig() {
        return new BaseMeterTypeConfig();
    }

    /**
     * Create an instance of {@link BaseNicSoftwareTypeConfig }
     * 
     */
    public BaseNicSoftwareTypeConfig createBaseNicSoftwareTypeConfig() {
        return new BaseNicSoftwareTypeConfig();
    }

    /**
     * Create an instance of {@link BaseNicTypeConfig }
     * 
     */
    public BaseNicTypeConfig createBaseNicTypeConfig() {
        return new BaseNicTypeConfig();
    }

    /**
     * Create an instance of {@link BaseRelayTypeConfig }
     * 
     */
    public BaseRelayTypeConfig createBaseRelayTypeConfig() {
        return new BaseRelayTypeConfig();
    }

    /**
     * Create an instance of {@link BaseWANTypeConfig }
     * 
     */
    public BaseWANTypeConfig createBaseWANTypeConfig() {
        return new BaseWANTypeConfig();
    }

    /**
     * Create an instance of {@link BatteryInfoType }
     * 
     */
    public BatteryInfoType createBatteryInfoType() {
        return new BatteryInfoType();
    }

    /**
     * Create an instance of {@link BatteryIdentifier }
     * 
     */
    public BatteryIdentifier createBatteryIdentifier() {
        return new BatteryIdentifier();
    }

    /**
     * Create an instance of {@link BridgeType }
     * 
     */
    public BridgeType createBridgeType() {
        return new BridgeType();
    }

    /**
     * Create an instance of {@link BridgeTypeConfig }
     * 
     */
    public BridgeTypeConfig createBridgeTypeConfig() {
        return new BridgeTypeConfig();
    }

    /**
     * Create an instance of {@link ContactType }
     * 
     */
    public ContactType createContactType() {
        return new ContactType();
    }

    /**
     * Create an instance of {@link DefinedContactType }
     * 
     */
    public DefinedContactType createDefinedContactType() {
        return new DefinedContactType();
    }

    /**
     * Create an instance of {@link DeviceCapabilitiesType }
     * 
     */
    public DeviceCapabilitiesType createDeviceCapabilitiesType() {
        return new DeviceCapabilitiesType();
    }

    /**
     * Create an instance of {@link DeviceIdentifier }
     * 
     */
    public DeviceIdentifier createDeviceIdentifier() {
        return new DeviceIdentifier();
    }

    /**
     * Create an instance of {@link DeviceList }
     * 
     */
    public DeviceList createDeviceList() {
        return new DeviceList();
    }

    /**
     * Create an instance of {@link DeviceListByID }
     * 
     */
    public DeviceListByID createDeviceListByID() {
        return new DeviceListByID();
    }

    /**
     * Create an instance of {@link DeviceSearchParametersType }
     * 
     */
    public DeviceSearchParametersType createDeviceSearchParametersType() {
        return new DeviceSearchParametersType();
    }

    /**
     * Create an instance of {@link DeviceSortMap }
     * 
     */
    public DeviceSortMap createDeviceSortMap() {
        return new DeviceSortMap();
    }

    /**
     * Create an instance of {@link DeviceStateType }
     * 
     */
    public DeviceStateType createDeviceStateType() {
        return new DeviceStateType();
    }

    /**
     * Create an instance of {@link DistanceType }
     * 
     */
    public DistanceType createDistanceType() {
        return new DistanceType();
    }

    /**
     * Create an instance of {@link EditBridgeTypeConfig }
     * 
     */
    public EditBridgeTypeConfig createEditBridgeTypeConfig() {
        return new EditBridgeTypeConfig();
    }

    /**
     * Create an instance of {@link EditContactReqType }
     * 
     */
    public EditContactReqType createEditContactReqType() {
        return new EditContactReqType();
    }

    /**
     * Create an instance of {@link EditDevContactType }
     * 
     */
    public EditDevContactType createEditDevContactType() {
        return new EditDevContactType();
    }

    /**
     * Create an instance of {@link EditDevContactListType }
     * 
     */
    public EditDevContactListType createEditDevContactListType() {
        return new EditDevContactListType();
    }

    /**
     * Create an instance of {@link EditLocationAddnlInfoType }
     * 
     */
    public EditLocationAddnlInfoType createEditLocationAddnlInfoType() {
        return new EditLocationAddnlInfoType();
    }

    /**
     * Create an instance of {@link EditLocationType }
     * 
     */
    public EditLocationType createEditLocationType() {
        return new EditLocationType();
    }

    /**
     * Create an instance of {@link EditNetworkBaseDeviceType }
     * 
     */
    public EditNetworkBaseDeviceType createEditNetworkBaseDeviceType() {
        return new EditNetworkBaseDeviceType();
    }

    /**
     * Create an instance of {@link EditNicTypeConfig }
     * 
     */
    public EditNicTypeConfig createEditNicTypeConfig() {
        return new EditNicTypeConfig();
    }

    /**
     * Create an instance of {@link EditServicePtType }
     * 
     */
    public EditServicePtType createEditServicePtType() {
        return new EditServicePtType();
    }

    /**
     * Create an instance of {@link FindAccountType }
     * 
     */
    public FindAccountType createFindAccountType() {
        return new FindAccountType();
    }

    /**
     * Create an instance of {@link FindBaseDeviceType }
     * 
     */
    public FindBaseDeviceType createFindBaseDeviceType() {
        return new FindBaseDeviceType();
    }

    /**
     * Create an instance of {@link FindBatteryInfoType }
     * 
     */
    public FindBatteryInfoType createFindBatteryInfoType() {
        return new FindBatteryInfoType();
    }

    /**
     * Create an instance of {@link FindBridgeType }
     * 
     */
    public FindBridgeType createFindBridgeType() {
        return new FindBridgeType();
    }

    /**
     * Create an instance of {@link FindContactType }
     * 
     */
    public FindContactType createFindContactType() {
        return new FindContactType();
    }

    /**
     * Create an instance of {@link FindDeviceByJobSearchParametersType }
     * 
     */
    public FindDeviceByJobSearchParametersType createFindDeviceByJobSearchParametersType() {
        return new FindDeviceByJobSearchParametersType();
    }

    /**
     * Create an instance of {@link FindDeviceConfigType }
     * 
     */
    public FindDeviceConfigType createFindDeviceConfigType() {
        return new FindDeviceConfigType();
    }

    /**
     * Create an instance of {@link FindDeviceContactListType }
     * 
     */
    public FindDeviceContactListType createFindDeviceContactListType() {
        return new FindDeviceContactListType();
    }

    /**
     * Create an instance of {@link FindDeviceResponse }
     * 
     */
    public FindDeviceResponse createFindDeviceResponse() {
        return new FindDeviceResponse();
    }

    /**
     * Create an instance of {@link FindGatewayType }
     * 
     */
    public FindGatewayType createFindGatewayType() {
        return new FindGatewayType();
    }

    /**
     * Create an instance of {@link FindIMUType }
     * 
     */
    public FindIMUType createFindIMUType() {
        return new FindIMUType();
    }

    /**
     * Create an instance of {@link FindLocationAddnlInfoType }
     * 
     */
    public FindLocationAddnlInfoType createFindLocationAddnlInfoType() {
        return new FindLocationAddnlInfoType();
    }

    /**
     * Create an instance of {@link FindLocationExtType }
     * 
     */
    public FindLocationExtType createFindLocationExtType() {
        return new FindLocationExtType();
    }

    /**
     * Create an instance of {@link FindLocationResponse }
     * 
     */
    public FindLocationResponse createFindLocationResponse() {
        return new FindLocationResponse();
    }

    /**
     * Create an instance of {@link FindLocationType }
     * 
     */
    public FindLocationType createFindLocationType() {
        return new FindLocationType();
    }

    /**
     * Create an instance of {@link FindMeterType }
     * 
     */
    public FindMeterType createFindMeterType() {
        return new FindMeterType();
    }

    /**
     * Create an instance of {@link FindNetworkInfrastructureDeviceType }
     * 
     */
    public FindNetworkInfrastructureDeviceType createFindNetworkInfrastructureDeviceType() {
        return new FindNetworkInfrastructureDeviceType();
    }

    /**
     * Create an instance of {@link FindNiclessDeviceResponse }
     * 
     */
    public FindNiclessDeviceResponse createFindNiclessDeviceResponse() {
        return new FindNiclessDeviceResponse();
    }

    /**
     * Create an instance of {@link FindNicResponse }
     * 
     */
    public FindNicResponse createFindNicResponse() {
        return new FindNicResponse();
    }

    /**
     * Create an instance of {@link FindServicePtTransformerType }
     * 
     */
    public FindServicePtTransformerType createFindServicePtTransformerType() {
        return new FindServicePtTransformerType();
    }

    /**
     * Create an instance of {@link FindServicePtType }
     * 
     */
    public FindServicePtType createFindServicePtType() {
        return new FindServicePtType();
    }

    /**
     * Create an instance of {@link FindWANType }
     * 
     */
    public FindWANType createFindWANType() {
        return new FindWANType();
    }

    /**
     * Create an instance of {@link FindByProximityType }
     * 
     */
    public FindByProximityType createFindByProximityType() {
        return new FindByProximityType();
    }

    /**
     * Create an instance of {@link GatewayHopType }
     * 
     */
    public GatewayHopType createGatewayHopType() {
        return new GatewayHopType();
    }

    /**
     * Create an instance of {@link GatewayType }
     * 
     */
    public GatewayType createGatewayType() {
        return new GatewayType();
    }

    /**
     * Create an instance of {@link GatewayTypeConfig }
     * 
     */
    public GatewayTypeConfig createGatewayTypeConfig() {
        return new GatewayTypeConfig();
    }

    /**
     * Create an instance of {@link GetAccountType }
     * 
     */
    public GetAccountType createGetAccountType() {
        return new GetAccountType();
    }

    /**
     * Create an instance of {@link GetBridgeType }
     * 
     */
    public GetBridgeType createGetBridgeType() {
        return new GetBridgeType();
    }

    /**
     * Create an instance of {@link GetDevContactListType }
     * 
     */
    public GetDevContactListType createGetDevContactListType() {
        return new GetDevContactListType();
    }

    /**
     * Create an instance of {@link GetDevContactType }
     * 
     */
    public GetDevContactType createGetDevContactType() {
        return new GetDevContactType();
    }

    /**
     * Create an instance of {@link GetDeviceType }
     * 
     */
    public GetDeviceType createGetDeviceType() {
        return new GetDeviceType();
    }

    /**
     * Create an instance of {@link GetGatewayType }
     * 
     */
    public GetGatewayType createGetGatewayType() {
        return new GetGatewayType();
    }

    /**
     * Create an instance of {@link GetIMUType }
     * 
     */
    public GetIMUType createGetIMUType() {
        return new GetIMUType();
    }

    /**
     * Create an instance of {@link GetLocationAddnlInfoType }
     * 
     */
    public GetLocationAddnlInfoType createGetLocationAddnlInfoType() {
        return new GetLocationAddnlInfoType();
    }

    /**
     * Create an instance of {@link GetLocationType }
     * 
     */
    public GetLocationType createGetLocationType() {
        return new GetLocationType();
    }

    /**
     * Create an instance of {@link GetMeterType }
     * 
     */
    public GetMeterType createGetMeterType() {
        return new GetMeterType();
    }

    /**
     * Create an instance of {@link GetRelayType }
     * 
     */
    public GetRelayType createGetRelayType() {
        return new GetRelayType();
    }

    /**
     * Create an instance of {@link HopType }
     * 
     */
    public HopType createHopType() {
        return new HopType();
    }

    /**
     * Create an instance of {@link IMUTypeConfig }
     * 
     */
    public IMUTypeConfig createIMUTypeConfig() {
        return new IMUTypeConfig();
    }

    /**
     * Create an instance of {@link IMUMeterTypeConfig }
     * 
     */
    public IMUMeterTypeConfig createIMUMeterTypeConfig() {
        return new IMUMeterTypeConfig();
    }

    /**
     * Create an instance of {@link IMUType }
     * 
     */
    public IMUType createIMUType() {
        return new IMUType();
    }

    /**
     * Create an instance of {@link JobOpType }
     * 
     */
    public JobOpType createJobOpType() {
        return new JobOpType();
    }

    /**
     * Create an instance of {@link LastReadPointersType }
     * 
     */
    public LastReadPointersType createLastReadPointersType() {
        return new LastReadPointersType();
    }

    /**
     * Create an instance of {@link ListNetworkDevicesParametersType }
     * 
     */
    public ListNetworkDevicesParametersType createListNetworkDevicesParametersType() {
        return new ListNetworkDevicesParametersType();
    }

    /**
     * Create an instance of {@link LocationAddnlInfoType }
     * 
     */
    public LocationAddnlInfoType createLocationAddnlInfoType() {
        return new LocationAddnlInfoType();
    }

    /**
     * Create an instance of {@link LocationSortMap }
     * 
     */
    public LocationSortMap createLocationSortMap() {
        return new LocationSortMap();
    }

    /**
     * Create an instance of {@link MechanismType }
     * 
     */
    public MechanismType createMechanismType() {
        return new MechanismType();
    }

    /**
     * Create an instance of {@link MeterDetailsType }
     * 
     */
    public MeterDetailsType createMeterDetailsType() {
        return new MeterDetailsType();
    }

    /**
     * Create an instance of {@link MeterProgramType }
     * 
     */
    public MeterProgramType createMeterProgramType() {
        return new MeterProgramType();
    }

    /**
     * Create an instance of {@link MeterScheduleType }
     * 
     */
    public MeterScheduleType createMeterScheduleType() {
        return new MeterScheduleType();
    }

    /**
     * Create an instance of {@link MeterType }
     * 
     */
    public MeterType createMeterType() {
        return new MeterType();
    }

    /**
     * Create an instance of {@link MeterTypeConfig }
     * 
     */
    public MeterTypeConfig createMeterTypeConfig() {
        return new MeterTypeConfig();
    }

    /**
     * Create an instance of {@link MismatchedProgramType }
     * 
     */
    public MismatchedProgramType createMismatchedProgramType() {
        return new MismatchedProgramType();
    }

    /**
     * Create an instance of {@link NetworkDeviceSummaryType }
     * 
     */
    public NetworkDeviceSummaryType createNetworkDeviceSummaryType() {
        return new NetworkDeviceSummaryType();
    }

    /**
     * Create an instance of {@link NetworkBaseDeviceType }
     * 
     */
    public NetworkBaseDeviceType createNetworkBaseDeviceType() {
        return new NetworkBaseDeviceType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureDevicesType }
     * 
     */
    public NetworkInfrastructureDevicesType createNetworkInfrastructureDevicesType() {
        return new NetworkInfrastructureDevicesType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureDeviceType }
     * 
     */
    public NetworkInfrastructureDeviceType createNetworkInfrastructureDeviceType() {
        return new NetworkInfrastructureDeviceType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureGatewaysType }
     * 
     */
    public NetworkInfrastructureGatewaysType createNetworkInfrastructureGatewaysType() {
        return new NetworkInfrastructureGatewaysType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureGatewayType }
     * 
     */
    public NetworkInfrastructureGatewayType createNetworkInfrastructureGatewayType() {
        return new NetworkInfrastructureGatewayType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureRelaysType }
     * 
     */
    public NetworkInfrastructureRelaysType createNetworkInfrastructureRelaysType() {
        return new NetworkInfrastructureRelaysType();
    }

    /**
     * Create an instance of {@link NetworkInfrastructureRelayType }
     * 
     */
    public NetworkInfrastructureRelayType createNetworkInfrastructureRelayType() {
        return new NetworkInfrastructureRelayType();
    }

    /**
     * Create an instance of {@link NicArchitectureType }
     * 
     */
    public NicArchitectureType createNicArchitectureType() {
        return new NicArchitectureType();
    }

    /**
     * Create an instance of {@link NicTypeConfig }
     * 
     */
    public NicTypeConfig createNicTypeConfig() {
        return new NicTypeConfig();
    }

    /**
     * Create an instance of {@link NicSoftwareTypeConfig }
     * 
     */
    public NicSoftwareTypeConfig createNicSoftwareTypeConfig() {
        return new NicSoftwareTypeConfig();
    }

    /**
     * Create an instance of {@link NullableBatteryIdentifier }
     * 
     */
    public NullableBatteryIdentifier createNullableBatteryIdentifier() {
        return new NullableBatteryIdentifier();
    }

    /**
     * Create an instance of {@link NullableNicArchitectureType }
     * 
     */
    public NullableNicArchitectureType createNullableNicArchitectureType() {
        return new NullableNicArchitectureType();
    }

    /**
     * Create an instance of {@link NullableString }
     * 
     */
    public NullableString createNullableString() {
        return new NullableString();
    }

    /**
     * Create an instance of {@link NullableLong }
     * 
     */
    public NullableLong createNullableLong() {
        return new NullableLong();
    }

    /**
     * Create an instance of {@link NullableInt }
     * 
     */
    public NullableInt createNullableInt() {
        return new NullableInt();
    }

    /**
     * Create an instance of {@link NullableBoolean }
     * 
     */
    public NullableBoolean createNullableBoolean() {
        return new NullableBoolean();
    }

    /**
     * Create an instance of {@link NullableDouble }
     * 
     */
    public NullableDouble createNullableDouble() {
        return new NullableDouble();
    }

    /**
     * Create an instance of {@link NullableBase64Binary }
     * 
     */
    public NullableBase64Binary createNullableBase64Binary() {
        return new NullableBase64Binary();
    }

    /**
     * Create an instance of {@link NullableUtilNetworkStateType }
     * 
     */
    public NullableUtilNetworkStateType createNullableUtilNetworkStateType() {
        return new NullableUtilNetworkStateType();
    }

    /**
     * Create an instance of {@link NullableTimeZoneType }
     * 
     */
    public NullableTimeZoneType createNullableTimeZoneType() {
        return new NullableTimeZoneType();
    }

    /**
     * Create an instance of {@link NullableLocationType }
     * 
     */
    public NullableLocationType createNullableLocationType() {
        return new NullableLocationType();
    }

    /**
     * Create an instance of {@link NullableDistNetworkType }
     * 
     */
    public NullableDistNetworkType createNullableDistNetworkType() {
        return new NullableDistNetworkType();
    }

    /**
     * Create an instance of {@link NullableServicePtType }
     * 
     */
    public NullableServicePtType createNullableServicePtType() {
        return new NullableServicePtType();
    }

    /**
     * Create an instance of {@link NullableDevContactListType }
     * 
     */
    public NullableDevContactListType createNullableDevContactListType() {
        return new NullableDevContactListType();
    }

    /**
     * Create an instance of {@link NullableAccountType }
     * 
     */
    public NullableAccountType createNullableAccountType() {
        return new NullableAccountType();
    }

    /**
     * Create an instance of {@link NullableAnyURIArrayType }
     * 
     */
    public NullableAnyURIArrayType createNullableAnyURIArrayType() {
        return new NullableAnyURIArrayType();
    }

    /**
     * Create an instance of {@link NullableNetworkMaskType }
     * 
     */
    public NullableNetworkMaskType createNullableNetworkMaskType() {
        return new NullableNetworkMaskType();
    }

    /**
     * Create an instance of {@link NullableServicePtTransformerType }
     * 
     */
    public NullableServicePtTransformerType createNullableServicePtTransformerType() {
        return new NullableServicePtTransformerType();
    }

    /**
     * Create an instance of {@link ParentGatewayType }
     * 
     */
    public ParentGatewayType createParentGatewayType() {
        return new ParentGatewayType();
    }

    /**
     * Create an instance of {@link RelayType }
     * 
     */
    public RelayType createRelayType() {
        return new RelayType();
    }

    /**
     * Create an instance of {@link RelayTypeConfig }
     * 
     */
    public RelayTypeConfig createRelayTypeConfig() {
        return new RelayTypeConfig();
    }

    /**
     * Create an instance of {@link RemoteProvisioningModeStatusType }
     * 
     */
    public RemoteProvisioningModeStatusType createRemoteProvisioningModeStatusType() {
        return new RemoteProvisioningModeStatusType();
    }

    /**
     * Create an instance of {@link RouteType }
     * 
     */
    public RouteType createRouteType() {
        return new RouteType();
    }

    /**
     * Create an instance of {@link RssiType }
     * 
     */
    public RssiType createRssiType() {
        return new RssiType();
    }

    /**
     * Create an instance of {@link SerialNumberType }
     * 
     */
    public SerialNumberType createSerialNumberType() {
        return new SerialNumberType();
    }

    /**
     * Create an instance of {@link ServicePtTransformerType }
     * 
     */
    public ServicePtTransformerType createServicePtTransformerType() {
        return new ServicePtTransformerType();
    }

    /**
     * Create an instance of {@link SortMapType }
     * 
     */
    public SortMapType createSortMapType() {
        return new SortMapType();
    }

    /**
     * Create an instance of {@link StateTransitionType }
     * 
     */
    public StateTransitionType createStateTransitionType() {
        return new StateTransitionType();
    }

    /**
     * Create an instance of {@link ThirdPartyDevice }
     * 
     */
    public ThirdPartyDevice createThirdPartyDevice() {
        return new ThirdPartyDevice();
    }

    /**
     * Create an instance of {@link TimeRangeType }
     * 
     */
    public TimeRangeType createTimeRangeType() {
        return new TimeRangeType();
    }

    /**
     * Create an instance of {@link TimestampType }
     * 
     */
    public TimestampType createTimestampType() {
        return new TimestampType();
    }

    /**
     * Create an instance of {@link UiqDeviceStateTypeWithOp }
     * 
     */
    public UiqDeviceStateTypeWithOp createUiqDeviceStateTypeWithOp() {
        return new UiqDeviceStateTypeWithOp();
    }

    /**
     * Create an instance of {@link UpdateDeviceLocationType }
     * 
     */
    public UpdateDeviceLocationType createUpdateDeviceLocationType() {
        return new UpdateDeviceLocationType();
    }

    /**
     * Create an instance of {@link UpdateNetworkBaseDeviceType }
     * 
     */
    public UpdateNetworkBaseDeviceType createUpdateNetworkBaseDeviceType() {
        return new UpdateNetworkBaseDeviceType();
    }

    /**
     * Create an instance of {@link UpdateBaseDeviceType }
     * 
     */
    public UpdateBaseDeviceType createUpdateBaseDeviceType() {
        return new UpdateBaseDeviceType();
    }

    /**
     * Create an instance of {@link UpdateLocationType }
     * 
     */
    public UpdateLocationType createUpdateLocationType() {
        return new UpdateLocationType();
    }

    /**
     * Create an instance of {@link UpdateDistNetworkType }
     * 
     */
    public UpdateDistNetworkType createUpdateDistNetworkType() {
        return new UpdateDistNetworkType();
    }

    /**
     * Create an instance of {@link UpdateAccountType }
     * 
     */
    public UpdateAccountType createUpdateAccountType() {
        return new UpdateAccountType();
    }

    /**
     * Create an instance of {@link UpdateMeterTypeReq }
     * 
     */
    public UpdateMeterTypeReq createUpdateMeterTypeReq() {
        return new UpdateMeterTypeReq();
    }

    /**
     * Create an instance of {@link UpdateRelayTypeReq }
     * 
     */
    public UpdateRelayTypeReq createUpdateRelayTypeReq() {
        return new UpdateRelayTypeReq();
    }

    /**
     * Create an instance of {@link UpdateBridgeTypeReq }
     * 
     */
    public UpdateBridgeTypeReq createUpdateBridgeTypeReq() {
        return new UpdateBridgeTypeReq();
    }

    /**
     * Create an instance of {@link UpdateGatewayTypeReq }
     * 
     */
    public UpdateGatewayTypeReq createUpdateGatewayTypeReq() {
        return new UpdateGatewayTypeReq();
    }

    /**
     * Create an instance of {@link UpdateIMUTypeReq }
     * 
     */
    public UpdateIMUTypeReq createUpdateIMUTypeReq() {
        return new UpdateIMUTypeReq();
    }

    /**
     * Create an instance of {@link UpdateServicePointTransformerType }
     * 
     */
    public UpdateServicePointTransformerType createUpdateServicePointTransformerType() {
        return new UpdateServicePointTransformerType();
    }

    /**
     * Create an instance of {@link UtilNetworkStateType }
     * 
     */
    public UtilNetworkStateType createUtilNetworkStateType() {
        return new UtilNetworkStateType();
    }

    /**
     * Create an instance of {@link UtilLocationIDType }
     * 
     */
    public UtilLocationIDType createUtilLocationIDType() {
        return new UtilLocationIDType();
    }

    /**
     * Create an instance of {@link WANTypeConfig }
     * 
     */
    public WANTypeConfig createWANTypeConfig() {
        return new WANTypeConfig();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BaseBatteryInfoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BaseBatteryInfoType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddBatteryTypeConfig")
    public JAXBElement<BaseBatteryInfoType> createAddBatteryTypeConfig(BaseBatteryInfoType value) {
        return new JAXBElement<BaseBatteryInfoType>(_AddBatteryTypeConfig_QNAME, BaseBatteryInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditDeviceResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditDeviceResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddDeviceResponse")
    public JAXBElement<AddEditDeviceResponseType> createAddDeviceResponse(AddEditDeviceResponseType value) {
        return new JAXBElement<AddEditDeviceResponseType>(_AddDeviceResponse_QNAME, AddEditDeviceResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddDevice")
    public JAXBElement<AddDeviceReqType> createAddDevice(AddDeviceReqType value) {
        return new JAXBElement<AddDeviceReqType>(_AddDevice_QNAME, AddDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddDistributionNetwork")
    public JAXBElement<DistNetworkType> createAddDistributionNetwork(DistNetworkType value) {
        return new JAXBElement<DistNetworkType>(_AddDistributionNetwork_QNAME, DistNetworkType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditTypeConfigResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditTypeConfigResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddEditTypeConfigResponse")
    public JAXBElement<AddEditTypeConfigResponseType> createAddEditTypeConfigResponse(AddEditTypeConfigResponseType value) {
        return new JAXBElement<AddEditTypeConfigResponseType>(_AddEditTypeConfigResponse_QNAME, AddEditTypeConfigResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddLocation")
    public JAXBElement<AddEditLocationReqType> createAddLocation(AddEditLocationReqType value) {
        return new JAXBElement<AddEditLocationReqType>(_AddLocation_QNAME, AddEditLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditLocationResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditLocationResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddLocationResponse")
    public JAXBElement<AddEditLocationResponseType> createAddLocationResponse(AddEditLocationResponseType value) {
        return new JAXBElement<AddEditLocationResponseType>(_AddLocationResponse_QNAME, AddEditLocationResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddLocationType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddLocationType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddLocationNew")
    public JAXBElement<AddLocationType> createAddLocationNew(AddLocationType value) {
        return new JAXBElement<AddLocationType>(_AddLocationNew_QNAME, AddLocationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddNoteReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddNoteReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddNote")
    public JAXBElement<AddNoteReqType> createAddNote(AddNoteReqType value) {
        return new JAXBElement<AddNoteReqType>(_AddNote_QNAME, AddNoteReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddNoteResponse")
    public JAXBElement<EmptyType> createAddNoteResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_AddNoteResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePtType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ServicePtType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "AddServicePoint")
    public JAXBElement<ServicePtType> createAddServicePoint(ServicePtType value) {
        return new JAXBElement<ServicePtType>(_AddServicePoint_QNAME, ServicePtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EditDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EditDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditDevice")
    public JAXBElement<EditDeviceReqType> createEditDevice(EditDeviceReqType value) {
        return new JAXBElement<EditDeviceReqType>(_EditDevice_QNAME, EditDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EditDeviceNewReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EditDeviceNewReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditDeviceNew")
    public JAXBElement<EditDeviceNewReqType> createEditDeviceNew(EditDeviceNewReqType value) {
        return new JAXBElement<EditDeviceNewReqType>(_EditDeviceNew_QNAME, EditDeviceNewReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditDeviceResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditDeviceResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditDeviceResponse")
    public JAXBElement<AddEditDeviceResponseType> createEditDeviceResponse(AddEditDeviceResponseType value) {
        return new JAXBElement<AddEditDeviceResponseType>(_EditDeviceResponse_QNAME, AddEditDeviceResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditDistributionNetwork")
    public JAXBElement<DistNetworkType> createEditDistributionNetwork(DistNetworkType value) {
        return new JAXBElement<DistNetworkType>(_EditDistributionNetwork_QNAME, DistNetworkType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditLocation")
    public JAXBElement<AddEditLocationReqType> createEditLocation(AddEditLocationReqType value) {
        return new JAXBElement<AddEditLocationReqType>(_EditLocation_QNAME, AddEditLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocationType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LocationType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditLocationNew")
    public JAXBElement<LocationType> createEditLocationNew(LocationType value) {
        return new JAXBElement<LocationType>(_EditLocationNew_QNAME, LocationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEditLocationResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AddEditLocationResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditLocationResponse")
    public JAXBElement<AddEditLocationResponseType> createEditLocationResponse(AddEditLocationResponseType value) {
        return new JAXBElement<AddEditLocationResponseType>(_EditLocationResponse_QNAME, AddEditLocationResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePtType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ServicePtType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "EditServicePoint")
    public JAXBElement<ServicePtType> createEditServicePoint(ServicePtType value) {
        return new JAXBElement<ServicePtType>(_EditServicePoint_QNAME, ServicePtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindDevice")
    public JAXBElement<FindDeviceReqType> createFindDevice(FindDeviceReqType value) {
        return new JAXBElement<FindDeviceReqType>(_FindDevice_QNAME, FindDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindDeviceResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindDeviceResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindDeviceResponse")
    public JAXBElement<FindDeviceResponseType> createFindDeviceResponse(FindDeviceResponseType value) {
        return new JAXBElement<FindDeviceResponseType>(_FindDeviceResponse_QNAME, FindDeviceResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindLocation")
    public JAXBElement<FindLocationReqType> createFindLocation(FindLocationReqType value) {
        return new JAXBElement<FindLocationReqType>(_FindLocation_QNAME, FindLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindLocationResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindLocationResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindLocationResponse")
    public JAXBElement<FindLocationResponseType> createFindLocationResponse(FindLocationResponseType value) {
        return new JAXBElement<FindLocationResponseType>(_FindLocationResponse_QNAME, FindLocationResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindNic")
    public JAXBElement<FindDeviceReqType> createFindNic(FindDeviceReqType value) {
        return new JAXBElement<FindDeviceReqType>(_FindNic_QNAME, FindDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindNicResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindNicResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindNicResponse")
    public JAXBElement<FindNicResponseType> createFindNicResponse(FindNicResponseType value) {
        return new JAXBElement<FindNicResponseType>(_FindNicResponse_QNAME, FindNicResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindNiclessDevice")
    public JAXBElement<FindDeviceReqType> createFindNiclessDevice(FindDeviceReqType value) {
        return new JAXBElement<FindDeviceReqType>(_FindNiclessDevice_QNAME, FindDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindNiclessDeviceResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link FindNiclessDeviceResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "FindNiclessDeviceResponse")
    public JAXBElement<FindNiclessDeviceResponseType> createFindNiclessDeviceResponse(FindNiclessDeviceResponseType value) {
        return new JAXBElement<FindNiclessDeviceResponseType>(_FindNiclessDeviceResponse_QNAME, FindNiclessDeviceResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDevice")
    public JAXBElement<GetDeviceReqType> createGetDevice(GetDeviceReqType value) {
        return new JAXBElement<GetDeviceReqType>(_GetDevice_QNAME, GetDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDeviceResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDeviceResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDeviceResponse")
    public JAXBElement<GetDeviceResponseType> createGetDeviceResponse(GetDeviceResponseType value) {
        return new JAXBElement<GetDeviceResponseType>(_GetDeviceResponse_QNAME, GetDeviceResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDeviceStateType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDeviceStateType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDeviceStateHistory")
    public JAXBElement<GetDeviceStateType> createGetDeviceStateHistory(GetDeviceStateType value) {
        return new JAXBElement<GetDeviceStateType>(_GetDeviceStateHistory_QNAME, GetDeviceStateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDeviceStateResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDeviceStateResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDeviceStateHistoryResponse")
    public JAXBElement<GetDeviceStateResponseType> createGetDeviceStateHistoryResponse(GetDeviceStateResponseType value) {
        return new JAXBElement<GetDeviceStateResponseType>(_GetDeviceStateHistoryResponse_QNAME, GetDeviceStateResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDistributionNetworkReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDistributionNetworkReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDistributionNetwork")
    public JAXBElement<GetDistributionNetworkReqType> createGetDistributionNetwork(GetDistributionNetworkReqType value) {
        return new JAXBElement<GetDistributionNetworkReqType>(_GetDistributionNetwork_QNAME, GetDistributionNetworkReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DistNetworkType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetDistributionNetworkResponse")
    public JAXBElement<DistNetworkType> createGetDistributionNetworkResponse(DistNetworkType value) {
        return new JAXBElement<DistNetworkType>(_GetDistributionNetworkResponse_QNAME, DistNetworkType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLastReadPointersReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetLastReadPointersReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetLastReadPointers")
    public JAXBElement<GetLastReadPointersReqType> createGetLastReadPointers(GetLastReadPointersReqType value) {
        return new JAXBElement<GetLastReadPointersReqType>(_GetLastReadPointers_QNAME, GetLastReadPointersReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLastReadPointersResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetLastReadPointersResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetLastReadPointersResponse")
    public JAXBElement<GetLastReadPointersResponseType> createGetLastReadPointersResponse(GetLastReadPointersResponseType value) {
        return new JAXBElement<GetLastReadPointersResponseType>(_GetLastReadPointersResponse_QNAME, GetLastReadPointersResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetLocation")
    public JAXBElement<GetLocationReqType> createGetLocation(GetLocationReqType value) {
        return new JAXBElement<GetLocationReqType>(_GetLocation_QNAME, GetLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLocationResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetLocationResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetLocationResponse")
    public JAXBElement<GetLocationResponseType> createGetLocationResponse(GetLocationResponseType value) {
        return new JAXBElement<GetLocationResponseType>(_GetLocationResponse_QNAME, GetLocationResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetServicePtReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetServicePtReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetServicePoint")
    public JAXBElement<GetServicePtReqType> createGetServicePoint(GetServicePtReqType value) {
        return new JAXBElement<GetServicePtReqType>(_GetServicePoint_QNAME, GetServicePtReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetServicePtType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetServicePtType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "GetServicePointResponse")
    public JAXBElement<GetServicePtType> createGetServicePointResponse(GetServicePtType value) {
        return new JAXBElement<GetServicePtType>(_GetServicePointResponse_QNAME, GetServicePtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListNetworkDevicesResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListNetworkDevicesResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ListNetworkDevicesResponse")
    public JAXBElement<ListNetworkDevicesResponseType> createListNetworkDevicesResponse(ListNetworkDevicesResponseType value) {
        return new JAXBElement<ListNetworkDevicesResponseType>(_ListNetworkDevicesResponse_QNAME, ListNetworkDevicesResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListNetworkDevicesReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListNetworkDevicesReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ListNetworkDevices")
    public JAXBElement<ListNetworkDevicesReqType> createListNetworkDevices(ListNetworkDevicesReqType value) {
        return new JAXBElement<ListNetworkDevicesReqType>(_ListNetworkDevices_QNAME, ListNetworkDevicesReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReInitializeDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReInitializeDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReInitializeDevice")
    public JAXBElement<ReInitializeDeviceReqType> createReInitializeDevice(ReInitializeDeviceReqType value) {
        return new JAXBElement<ReInitializeDeviceReqType>(_ReInitializeDevice_QNAME, ReInitializeDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReInitializeDeviceResponse")
    public JAXBElement<EmptyType> createReInitializeDeviceResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_ReInitializeDeviceResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReplaceDeviceAtLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReplaceDeviceAtLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReplaceDeviceAtLocation")
    public JAXBElement<ReplaceDeviceAtLocationReqType> createReplaceDeviceAtLocation(ReplaceDeviceAtLocationReqType value) {
        return new JAXBElement<ReplaceDeviceAtLocationReqType>(_ReplaceDeviceAtLocation_QNAME, ReplaceDeviceAtLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReplaceDeviceAtLocationResponse")
    public JAXBElement<EmptyType> createReplaceDeviceAtLocationResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_ReplaceDeviceAtLocationResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReplaceLocationReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReplaceLocationReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReplaceLocation")
    public JAXBElement<ReplaceLocationReqType> createReplaceLocation(ReplaceLocationReqType value) {
        return new JAXBElement<ReplaceLocationReqType>(_ReplaceLocation_QNAME, ReplaceLocationReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ReplaceLocationResponse")
    public JAXBElement<EmptyType> createReplaceLocationResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_ReplaceLocationResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetAdminStateReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetAdminStateReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "SetAdminState")
    public JAXBElement<SetAdminStateReqType> createSetAdminState(SetAdminStateReqType value) {
        return new JAXBElement<SetAdminStateReqType>(_SetAdminState_QNAME, SetAdminStateReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "SetAdminStateResponse")
    public JAXBElement<EmptyType> createSetAdminStateResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_SetAdminStateResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SelectDevicesFromSearchResultType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SelectDevicesFromSearchResultType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "SelectDevicesFromSearchResult")
    public JAXBElement<SelectDevicesFromSearchResultType> createSelectDevicesFromSearchResult(SelectDevicesFromSearchResultType value) {
        return new JAXBElement<SelectDevicesFromSearchResultType>(_SelectDevicesFromSearchResult_QNAME, SelectDevicesFromSearchResultType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SelectDevicesFromSearchResultResponseType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SelectDevicesFromSearchResultResponseType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "SelectDevicesFromSearchResultResponse")
    public JAXBElement<SelectDevicesFromSearchResultResponseType> createSelectDevicesFromSearchResultResponse(SelectDevicesFromSearchResultResponseType value) {
        return new JAXBElement<SelectDevicesFromSearchResultResponseType>(_SelectDevicesFromSearchResultResponse_QNAME, SelectDevicesFromSearchResultResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateDeviceReqType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UpdateDeviceReqType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "UpdateDevice")
    public JAXBElement<UpdateDeviceReqType> createUpdateDevice(UpdateDeviceReqType value) {
        return new JAXBElement<UpdateDeviceReqType>(_UpdateDevice_QNAME, UpdateDeviceReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateServicePtType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UpdateServicePtType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "UpdateServicePoint")
    public JAXBElement<UpdateServicePtType> createUpdateServicePoint(UpdateServicePtType value) {
        return new JAXBElement<UpdateServicePtType>(_UpdateServicePoint_QNAME, UpdateServicePtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorCodeFaultType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ErrorCodeFaultType }{@code >}
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.5:DeviceManager.xsd", name = "ErrorCodeFault")
    public JAXBElement<ErrorCodeFaultType> createErrorCodeFault(ErrorCodeFaultType value) {
        return new JAXBElement<ErrorCodeFaultType>(_ErrorCodeFault_QNAME, ErrorCodeFaultType.class, null, value);
    }

}
