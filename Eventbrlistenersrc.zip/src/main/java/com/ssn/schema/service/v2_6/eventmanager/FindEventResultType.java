
package com.ssn.schema.service.v2_6.eventmanager;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.commonenumerations.JobTypeType;
import com.ssn.schema.service.v2_6.commonenumerations.UtilDeviceStateType;
import com.ssn.schema.service.v2_6.devicetypes.DeviceSubTypeType;


/**
 * <p>Java class for FindEventResultType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindEventResultType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EventLogId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EventId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="EventName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EventCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EventDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EventTime" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}TimestampType"/>
 *         &lt;element name="SourceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceDeviceType" type="{urn:com:ssn:schema:service:v2.6:DeviceTypes.xsd}DeviceSubTypeType" minOccurs="0"/>
 *         &lt;element name="SourceFeederUtilID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceSubstationUtilID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceUIQState" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}UIQDeviceStateType" minOccurs="0"/>
 *         &lt;element name="SourceUtilState" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}UtilDeviceStateType" minOccurs="0"/>
 *         &lt;element name="SourceUtilID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceType" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}SourceType"/>
 *         &lt;element name="ProxyDeviceType" type="{urn:com:ssn:schema:service:v2.6:DeviceTypes.xsd}DeviceSubTypeType" minOccurs="0"/>
 *         &lt;element name="ProxyUtilID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmitterId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmitterName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmitterType" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}SourceType"/>
 *         &lt;element name="EventText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Template" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Parameter" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}ParameterType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Severity" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}SeverityType" minOccurs="0"/>
 *         &lt;element name="EventVisibility" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="NumOfDaysToKeep" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="JobId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="JobOpType" type="{urn:com:ssn:schema:service:v2.6:CommonEnumerations.xsd}JobTypeType" minOccurs="0"/>
 *         &lt;element name="ClearingJobId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="Ack" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}DefinedAckType" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignedTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Alarm" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}AlarmType" minOccurs="0"/>
 *         &lt;element name="EventToClear" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="LocationDetails" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}EventLocationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindEventResultType", propOrder = {
    "eventLogId",
    "eventId",
    "eventName",
    "eventCode",
    "eventDesc",
    "eventTime",
    "sourceId",
    "sourceName",
    "sourceDeviceType",
    "sourceFeederUtilID",
    "sourceSubstationUtilID",
    "sourceUIQState",
    "sourceUtilState",
    "sourceUtilID",
    "sourceType",
    "proxyDeviceType",
    "proxyUtilID",
    "emitterId",
    "emitterName",
    "emitterType",
    "eventText",
    "template",
    "parameter",
    "severity",
    "eventVisibility",
    "numOfDaysToKeep",
    "jobId",
    "jobOpType",
    "clearingJobId",
    "ack",
    "updatedBy",
    "assignedTo",
    "alarm",
    "eventToClear",
    "locationDetails"
})
public class FindEventResultType {

    @XmlElement(name = "EventLogId", required = true)
    protected String eventLogId;
    @XmlElement(name = "EventId")
    protected int eventId;
    @XmlElement(name = "EventName", required = true)
    protected String eventName;
    @XmlElement(name = "EventCode", required = true)
    protected String eventCode;
    @XmlElement(name = "EventDesc", required = true)
    protected String eventDesc;
    @XmlElement(name = "EventTime", required = true)
    protected TimestampType eventTime;
    @XmlElement(name = "SourceId")
    protected String sourceId;
    @XmlElement(name = "SourceName")
    protected String sourceName;
    @XmlElement(name = "SourceDeviceType")
    protected DeviceSubTypeType sourceDeviceType;
    @XmlElement(name = "SourceFeederUtilID")
    protected String sourceFeederUtilID;
    @XmlElement(name = "SourceSubstationUtilID")
    protected String sourceSubstationUtilID;
    @XmlElement(name = "SourceUIQState")
    protected UIQDeviceStateType sourceUIQState;
    @XmlElement(name = "SourceUtilState")
    protected UtilDeviceStateType sourceUtilState;
    @XmlElement(name = "SourceUtilID")
    protected String sourceUtilID;
    @XmlElement(name = "SourceType", required = true)
    protected SourceType sourceType;
    @XmlElement(name = "ProxyDeviceType")
    protected DeviceSubTypeType proxyDeviceType;
    @XmlElement(name = "ProxyUtilID")
    protected String proxyUtilID;
    @XmlElement(name = "EmitterId")
    protected String emitterId;
    @XmlElement(name = "EmitterName")
    protected String emitterName;
    @XmlElement(name = "EmitterType", required = true)
    protected SourceType emitterType;
    @XmlElement(name = "EventText", required = true)
    protected String eventText;
    @XmlElement(name = "Template", required = true)
    protected String template;
    @XmlElement(name = "Parameter")
    protected List<ParameterType> parameter;
    @XmlElement(name = "Severity")
    protected SeverityType severity;
    @XmlElement(name = "EventVisibility")
    protected Integer eventVisibility;
    @XmlElement(name = "NumOfDaysToKeep")
    protected int numOfDaysToKeep;
    @XmlElement(name = "JobId")
    protected Long jobId;
    @XmlElement(name = "JobOpType")
    protected JobTypeType jobOpType;
    @XmlElement(name = "ClearingJobId")
    protected Long clearingJobId;
    @XmlElement(name = "Ack")
    protected DefinedAckType ack;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "AssignedTo")
    protected String assignedTo;
    @XmlElement(name = "Alarm")
    protected AlarmType alarm;
    @XmlElement(name = "EventToClear")
    protected Integer eventToClear;
    @XmlElement(name = "LocationDetails")
    protected EventLocationType locationDetails;

    /**
     * Gets the value of the eventLogId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventLogId() {
        return eventLogId;
    }

    /**
     * Sets the value of the eventLogId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventLogId(String value) {
        this.eventLogId = value;
    }

    /**
     * Gets the value of the eventId property.
     * 
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * Sets the value of the eventId property.
     * 
     */
    public void setEventId(int value) {
        this.eventId = value;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the eventCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventCode() {
        return eventCode;
    }

    /**
     * Sets the value of the eventCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventCode(String value) {
        this.eventCode = value;
    }

    /**
     * Gets the value of the eventDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventDesc() {
        return eventDesc;
    }

    /**
     * Sets the value of the eventDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventDesc(String value) {
        this.eventDesc = value;
    }

    /**
     * Gets the value of the eventTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimestampType }
     *     
     */
    public TimestampType getEventTime() {
        return eventTime;
    }

    /**
     * Sets the value of the eventTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimestampType }
     *     
     */
    public void setEventTime(TimestampType value) {
        this.eventTime = value;
    }

    /**
     * Gets the value of the sourceId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * Sets the value of the sourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceId(String value) {
        this.sourceId = value;
    }

    /**
     * Gets the value of the sourceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * Sets the value of the sourceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceName(String value) {
        this.sourceName = value;
    }

    /**
     * Gets the value of the sourceDeviceType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getSourceDeviceType() {
        return sourceDeviceType;
    }

    /**
     * Sets the value of the sourceDeviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setSourceDeviceType(DeviceSubTypeType value) {
        this.sourceDeviceType = value;
    }

    /**
     * Gets the value of the sourceFeederUtilID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceFeederUtilID() {
        return sourceFeederUtilID;
    }

    /**
     * Sets the value of the sourceFeederUtilID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceFeederUtilID(String value) {
        this.sourceFeederUtilID = value;
    }

    /**
     * Gets the value of the sourceSubstationUtilID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSubstationUtilID() {
        return sourceSubstationUtilID;
    }

    /**
     * Sets the value of the sourceSubstationUtilID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSubstationUtilID(String value) {
        this.sourceSubstationUtilID = value;
    }

    /**
     * Gets the value of the sourceUIQState property.
     * 
     * @return
     *     possible object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public UIQDeviceStateType getSourceUIQState() {
        return sourceUIQState;
    }

    /**
     * Sets the value of the sourceUIQState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UIQDeviceStateType }
     *     
     */
    public void setSourceUIQState(UIQDeviceStateType value) {
        this.sourceUIQState = value;
    }

    /**
     * Gets the value of the sourceUtilState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getSourceUtilState() {
        return sourceUtilState;
    }

    /**
     * Sets the value of the sourceUtilState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setSourceUtilState(UtilDeviceStateType value) {
        this.sourceUtilState = value;
    }

    /**
     * Gets the value of the sourceUtilID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceUtilID() {
        return sourceUtilID;
    }

    /**
     * Sets the value of the sourceUtilID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceUtilID(String value) {
        this.sourceUtilID = value;
    }

    /**
     * Gets the value of the sourceType property.
     * 
     * @return
     *     possible object is
     *     {@link SourceType }
     *     
     */
    public SourceType getSourceType() {
        return sourceType;
    }

    /**
     * Sets the value of the sourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SourceType }
     *     
     */
    public void setSourceType(SourceType value) {
        this.sourceType = value;
    }

    /**
     * Gets the value of the proxyDeviceType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getProxyDeviceType() {
        return proxyDeviceType;
    }

    /**
     * Sets the value of the proxyDeviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setProxyDeviceType(DeviceSubTypeType value) {
        this.proxyDeviceType = value;
    }

    /**
     * Gets the value of the proxyUtilID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProxyUtilID() {
        return proxyUtilID;
    }

    /**
     * Sets the value of the proxyUtilID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxyUtilID(String value) {
        this.proxyUtilID = value;
    }

    /**
     * Gets the value of the emitterId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmitterId() {
        return emitterId;
    }

    /**
     * Sets the value of the emitterId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmitterId(String value) {
        this.emitterId = value;
    }

    /**
     * Gets the value of the emitterName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmitterName() {
        return emitterName;
    }

    /**
     * Sets the value of the emitterName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmitterName(String value) {
        this.emitterName = value;
    }

    /**
     * Gets the value of the emitterType property.
     * 
     * @return
     *     possible object is
     *     {@link SourceType }
     *     
     */
    public SourceType getEmitterType() {
        return emitterType;
    }

    /**
     * Sets the value of the emitterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SourceType }
     *     
     */
    public void setEmitterType(SourceType value) {
        this.emitterType = value;
    }

    /**
     * Gets the value of the eventText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventText() {
        return eventText;
    }

    /**
     * Sets the value of the eventText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventText(String value) {
        this.eventText = value;
    }

    /**
     * Gets the value of the template property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplate() {
        return template;
    }

    /**
     * Sets the value of the template property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplate(String value) {
        this.template = value;
    }

    /**
     * Gets the value of the parameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ParameterType }
     * 
     * 
     */
    public List<ParameterType> getParameter() {
        if (parameter == null) {
            parameter = new ArrayList<ParameterType>();
        }
        return this.parameter;
    }

    /**
     * Gets the value of the severity property.
     * 
     * @return
     *     possible object is
     *     {@link SeverityType }
     *     
     */
    public SeverityType getSeverity() {
        return severity;
    }

    /**
     * Sets the value of the severity property.
     * 
     * @param value
     *     allowed object is
     *     {@link SeverityType }
     *     
     */
    public void setSeverity(SeverityType value) {
        this.severity = value;
    }

    /**
     * Gets the value of the eventVisibility property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEventVisibility() {
        return eventVisibility;
    }

    /**
     * Sets the value of the eventVisibility property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEventVisibility(Integer value) {
        this.eventVisibility = value;
    }

    /**
     * Gets the value of the numOfDaysToKeep property.
     * 
     */
    public int getNumOfDaysToKeep() {
        return numOfDaysToKeep;
    }

    /**
     * Sets the value of the numOfDaysToKeep property.
     * 
     */
    public void setNumOfDaysToKeep(int value) {
        this.numOfDaysToKeep = value;
    }

    /**
     * Gets the value of the jobId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobId(Long value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the jobOpType property.
     * 
     * @return
     *     possible object is
     *     {@link JobTypeType }
     *     
     */
    public JobTypeType getJobOpType() {
        return jobOpType;
    }

    /**
     * Sets the value of the jobOpType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JobTypeType }
     *     
     */
    public void setJobOpType(JobTypeType value) {
        this.jobOpType = value;
    }

    /**
     * Gets the value of the clearingJobId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getClearingJobId() {
        return clearingJobId;
    }

    /**
     * Sets the value of the clearingJobId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setClearingJobId(Long value) {
        this.clearingJobId = value;
    }

    /**
     * Gets the value of the ack property.
     * 
     * @return
     *     possible object is
     *     {@link DefinedAckType }
     *     
     */
    public DefinedAckType getAck() {
        return ack;
    }

    /**
     * Sets the value of the ack property.
     * 
     * @param value
     *     allowed object is
     *     {@link DefinedAckType }
     *     
     */
    public void setAck(DefinedAckType value) {
        this.ack = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the assignedTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets the value of the assignedTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets the value of the alarm property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmType }
     *     
     */
    public AlarmType getAlarm() {
        return alarm;
    }

    /**
     * Sets the value of the alarm property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmType }
     *     
     */
    public void setAlarm(AlarmType value) {
        this.alarm = value;
    }

    /**
     * Gets the value of the eventToClear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEventToClear() {
        return eventToClear;
    }

    /**
     * Sets the value of the eventToClear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEventToClear(Integer value) {
        this.eventToClear = value;
    }

    /**
     * Gets the value of the locationDetails property.
     * 
     * @return
     *     possible object is
     *     {@link EventLocationType }
     *     
     */
    public EventLocationType getLocationDetails() {
        return locationDetails;
    }

    /**
     * Sets the value of the locationDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventLocationType }
     *     
     */
    public void setLocationDetails(EventLocationType value) {
        this.locationDetails = value;
    }

}
