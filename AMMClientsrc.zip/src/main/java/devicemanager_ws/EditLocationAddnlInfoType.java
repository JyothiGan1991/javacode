
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EditLocationAddnlInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EditLocationAddnlInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}LocationAddnlInfoType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LocationID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditLocationAddnlInfoType", propOrder = {
    "locationID"
})
public class EditLocationAddnlInfoType
    extends LocationAddnlInfoType
{

    @XmlElement(name = "LocationID")
    protected Long locationID;

    /**
     * Gets the value of the locationID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocationID() {
        return locationID;
    }

    /**
     * Sets the value of the locationID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocationID(Long value) {
        this.locationID = value;
    }

}
