package com.coned.jpa.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.coned.model.FinalizeEventListDetails;
import com.coned.model.RejectEventListDetails;
import com.coned.model.UserLogin;
import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.FinalizeEventListDetailsRepository;
import com.coned.jpa.repository.RejectEventListDetailsRepository;
import com.coned.jpa.repository.UserLoginRepository;

@RestController
public class RejectEventListDetailsController {

	@Autowired
	private RejectEventListDetailsRepository reventRep;

	@GetMapping("/rejectEvents")
	public List getFinalizedEventListDetails2() {
		List<RejectEventListDetails> events = reventRep.findAll();
		Map<String, List<RejectEventListDetails>> byEventList = events.stream()
				.collect(Collectors.groupingBy(RejectEventListDetails::getBorough));

		byEventList.forEach((k, v) -> System.out.println("DeptId:" + k + "   " + ((List<RejectEventListDetails>) v)
				.stream().map(m -> m.getEventname()).collect(Collectors.joining(","))));

		String[] keys = new String[byEventList.size()];
		Object[] values = new Object[byEventList.size()];
		int index = 0;
		List allevents = new ArrayList();
		Map map = new HashMap();
		for (Entry<String, List<RejectEventListDetails>> mapEntry : byEventList.entrySet()) {
			map = new HashMap();
			keys[index] = mapEntry.getKey();
			map.put("boroughName", keys[index]);
			values[index] = mapEntry.getValue();
			map.put("events", values[index]);
			allevents.add(map);
			index++;
		}

		return allevents;
	}

	@GetMapping("/rejectEvents/{id}")
	public ResponseEntity<RejectEventListDetails> getFinalizedEventListDetailsById(
			@PathVariable(value = "id") Long rEventDetailsId) throws ResourceMissingException {
		RejectEventListDetails rEventDetails = reventRep.findById(rEventDetailsId).orElseThrow(
				() -> new ResourceMissingException("RejectEventListDetails not found :: " + rEventDetailsId));
		return ResponseEntity.ok().body(rEventDetails);
	}

	@PostMapping("/rejectEvent")
	public RejectEventListDetails createRejectEvent(@Valid @RequestBody RejectEventListDetails revent) {
		return reventRep.save(revent);
	}

	@DeleteMapping("/rejectEvents/{id}")
	@Transactional
	public Map<String, Boolean> deleteUser(@PathVariable(value = "id") Long rEventId) throws ResourceMissingException {
		RejectEventListDetails rEvent = reventRep.findById(rEventId)
				.orElseThrow(() -> new ResourceMissingException("RejectEventListDetails not found :: " + rEventId));
		reventRep.delete(rEvent);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
