package com.coned.ls.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.coned.ls.controller.UserManagementController;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;
import com.coned.ls.rest.RESTActionExecutorConnect;

import jakarta.servlet.http.HttpServletRequest;

@RunWith(MockitoJUnitRunner.class)
public class UserManagementServiceTest {
	
	@Mock
	UserManagementController usermgmtController;

	@InjectMocks
	private UserManagementService userManagementService;


	@Test
	public void getUsers() {
		List<Object> expected = new ArrayList<Object>();
		ResponseEntity<List<Object>> result = new ResponseEntity<List<Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		Mockito.when(userManagementService.getUsers()).thenReturn(result);
		ResponseEntity<List<Object>> actual = usermgmtController.getUsers();
		Assert.assertEquals("", "");
	}
	@Test
	public void listLDAPUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		HttpServletRequest request = null;
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		
		Mockito.when(userManagementService.listLDAPUser(username)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.listLDAPUser(username);
		Assert.assertEquals("", "");
	}
		
	@Test
	public void createUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		request.setAttribute("Authorization", "abc-varangalr");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		Mockito.when(userManagementService.createUser(payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.createUser(request, payload);
		Assert.assertEquals("", "");
	}
	@Test
	public void updateUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");
		 Map<String, Object> payload = new HashMap<String, Object>();
		
		String username = "ADID";
		payload.put("adid", username);
		
		Mockito.when(userManagementService.updateUser(username, payload)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.updateUser(username, request, payload);
		Assert.assertEquals("", "");
		
	}
	@Test
	public void deleteUser() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "XYZ-ABCD");

		String username = "ADID";
		String adid = "ADID";
		
		Mockito.when(userManagementService.deleteUser(username, adid)).thenReturn(result);
		ResponseEntity<Map<String, Object>> actual = usermgmtController.deleteUser(username, request);
//		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
		Assert.assertEquals("Null", "Null");
		
	}	
}
