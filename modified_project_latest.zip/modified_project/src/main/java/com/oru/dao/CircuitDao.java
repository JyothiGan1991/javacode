package com.oru.dao;

import java.util.List;
import java.util.Map;

public interface CircuitDao {
    List<Map<String, String>> getCircuitData(int duration);
}
