package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.FilterAttribute;
import com.coned.ls.repository.MeterFilterRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={MeterFilterService.class})
@AutoConfigureMockMvc
public class MeterFilterServiceTest {


	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private MeterFilterService mfs = new MeterFilterServiceImpl();
	
	@Mock
	private MeterFilterRepository meterFilterRepository;
	
	private MockMvc mockMvc;

	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void initMeterFilter(){
		List<FilterAttribute> response = new ArrayList<FilterAttribute>();
		FilterAttribute fa = new FilterAttribute();
		fa.setFilterAttribute("XYZ");
		fa.setSuccess(true);
		response.add(fa);
		Mockito.when(meterFilterRepository.initMeterFilter(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(response);
		List<FilterAttribute> result = mfs.initMeterFilter(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt());
		Assert.assertEquals(response.get(0).getFilterAttribute(), result.get(0).getFilterAttribute());
	}
}
