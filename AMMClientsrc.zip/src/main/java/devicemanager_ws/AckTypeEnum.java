
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AckTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AckTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="EVENT_RESOLVED"/&gt;
 *     &lt;enumeration value="EVENT_UNRESOLVED"/&gt;
 *     &lt;enumeration value="EVENT_ASSIGNED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "AckTypeEnum", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum AckTypeEnum {

    EVENT_RESOLVED("EVENT_RESOLVED"),
    EVENT_UNRESOLVED("EVENT_UNRESOLVED"),
    EVENT_ASSIGNED("EVENT_ASSIGNED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    AckTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AckTypeEnum fromValue(String v) {
        for (AckTypeEnum c: AckTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
