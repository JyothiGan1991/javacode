package com.coned.ls.mapper;

import java.io.Serializable;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OpenEventResponseMapper implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private Set<String> responseEntityList;
	private boolean isEmptyList;

	public boolean isEmptyList() {
		return isEmptyList;
	}

	public void setEmptyList(boolean isEmptyList) {
		this.isEmptyList = isEmptyList;
	}

	public Set<String> getResponseEntityList() {
		return responseEntityList;
	}

	public void setResponseEntityList(Set<String> responseEntityList) {
		this.responseEntityList = responseEntityList;
	}

	public OpenEventResponseMapper(Set<String> responseEntityList,
			boolean isEmptyList) {
		super();
		this.responseEntityList = responseEntityList;
		this.isEmptyList = isEmptyList;
	}

	public OpenEventResponseMapper() {
		super();
	}
}
