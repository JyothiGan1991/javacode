
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RssiType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RssiType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TxCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="RxCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="RssiMin" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="RssiMax" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="RssiAve" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RssiType", propOrder = {
    "txCount",
    "rxCount",
    "rssiMin",
    "rssiMax",
    "rssiAve"
})
public class RssiType {

    @XmlElement(name = "TxCount")
    protected int txCount;
    @XmlElement(name = "RxCount")
    protected int rxCount;
    @XmlElement(name = "RssiMin")
    protected int rssiMin;
    @XmlElement(name = "RssiMax")
    protected int rssiMax;
    @XmlElement(name = "RssiAve")
    protected int rssiAve;

    /**
     * Gets the value of the txCount property.
     * 
     */
    public int getTxCount() {
        return txCount;
    }

    /**
     * Sets the value of the txCount property.
     * 
     */
    public void setTxCount(int value) {
        this.txCount = value;
    }

    /**
     * Gets the value of the rxCount property.
     * 
     */
    public int getRxCount() {
        return rxCount;
    }

    /**
     * Sets the value of the rxCount property.
     * 
     */
    public void setRxCount(int value) {
        this.rxCount = value;
    }

    /**
     * Gets the value of the rssiMin property.
     * 
     */
    public int getRssiMin() {
        return rssiMin;
    }

    /**
     * Sets the value of the rssiMin property.
     * 
     */
    public void setRssiMin(int value) {
        this.rssiMin = value;
    }

    /**
     * Gets the value of the rssiMax property.
     * 
     */
    public int getRssiMax() {
        return rssiMax;
    }

    /**
     * Sets the value of the rssiMax property.
     * 
     */
    public void setRssiMax(int value) {
        this.rssiMax = value;
    }

    /**
     * Gets the value of the rssiAve property.
     * 
     */
    public int getRssiAve() {
        return rssiAve;
    }

    /**
     * Sets the value of the rssiAve property.
     * 
     */
    public void setRssiAve(int value) {
        this.rssiAve = value;
    }

}
