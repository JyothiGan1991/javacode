package com.coned.ls.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadAction;
import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for RCC Connect.
 *
 */
@Repository
public class JdbcMeterEventConnectRepository  implements MeterEventConnectRepository{

	private static final Logger LOGGER = LogManager.getLogger(JdbcMeterEventConnectRepository.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	final String REQ_STATUS_COMPLETE = "C";
	final String REQ_STATUS_UNKNOWN = "U";
	final String REQ_STATUS_FAIL = "F";
	final String CONNECTED_COMPLETED = "CONNECTED";
	final String CONNECTED_UNKNOWN = "UNKNOWN";
	final String CONNECTED_FAILED = "NOT REQUESTED";

    /*
     * Method to return list of disconnected meters created for the event, Method supports sorting, filtering and pagination.
     * 
     * @RequestBody meterOpenEvent  MeterOpenEvent 
     * 
     * @return 						ResponseEntity<MeterConnectResponseMapper> 
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent) throws Exception {
		String borough = meterOpenEvent.getBorough();
		String eventName = meterOpenEvent.getEventName();
		int startRowIndex = meterOpenEvent.getStartRowIndex();
		int batchSize = meterOpenEvent.getBatchSize();
		String adid = meterOpenEvent.getAdid();
		
		int begin  = (startRowIndex-1)*batchSize+1; 
		int end  = startRowIndex*batchSize;
		
		String filterList = " ";
		String sortList = " ";
		if(meterOpenEvent.isFilterApplied()){
			filterList = buildFilterQuery(meterOpenEvent.getFilterList(),"mel.");
		}
		if(meterOpenEvent.isSortApplied()){
			sortList = buildSortQuery(meterOpenEvent.getSortList(),"mel.");
		}
		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
		String query = "select METER_EVENT_LOAD_ID,boro_muni,event_name,demand,feeder,building_num,service_address,cust_zip_code,meter_number,account_number,network,VCAP_INSERT_TIME,transformer,structure from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) " + filterList + sortList + ") t1 where rownum<=?) where rn>=?";
		List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{borough,eventName,end,begin},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
				meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
				return meterEventLoad;
			}
        });
    	meterConnectResponseMapper.setBorough(borough);
    	meterConnectResponseMapper.setEventName(eventName);
    	meterConnectResponseMapper.setTotalRecord(getMeterCountExcludeFinalized(borough,eventName)); // Total meter count exclude finalized sub event 
    	meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(borough,eventName)); // Total meter count in the finalized event 
    	meterConnectResponseMapper.setPageNumber(startRowIndex);
    	meterConnectResponseMapper.setPageSize(batchSize);
    	meterConnectResponseMapper.setTotalValidRecord(getValidTotalRecord(borough, eventName)); // Total meter count in the validate event
    	meterConnectResponseMapper.setTotalKVA(getTotalKva(borough, eventName, filterList)); // Total kva based on filter, exclude from finalized sub event
    	meterConnectResponseMapper.setCountOfMeters(getCountOfMeters(borough, eventName, filterList)); // Total meter count exclude finalized sub event and with filter, if applied

	    if(!meterEventLoadList.isEmpty()){
	    	MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
	    	meterConnectResponseMapper.setNetwork(meterEventLoad.getNetwork());
	    	meterConnectResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
	    	meterConnectResponseMapper.setValidResponse(true);
	    	meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
	    	meterConnectResponseMapper.setIsEventFinalized(false);
	    	
	    	if(meterOpenEvent.isFilterApplied()){
	    		meterConnectResponseMapper.setMeterEventLoadIds(getMeterEventLoadIds(borough, eventName, filterList));
	    	}
	    } else {
	    	meterConnectResponseMapper.setMeterEventLoads(new ArrayList<MeterEventLoad>());
	    	if (isEventFinalized(borough, eventName))
	    		meterConnectResponseMapper.setIsEventFinalized(true);
	    	else
	    		meterConnectResponseMapper.setIsEventFinalized(false);
	    }
	    
	    checkAndUpdateIfEventUnlocked(adid, meterConnectResponseMapper);
	    return ResponseEntity.ok().body(meterConnectResponseMapper);
	}

    /*
     * Method to check event is finalized.
     * 
     * @Param borough   String
     * @Param eventName String
	 *
     * @return 			boolean
     *                         
     */
	private boolean isEventFinalized(String borough, final String eventName) {
		String totalCountQuery = "SELECT COUNT(FINALIZED_EVENT_ID) FROM LS_FINALIZE_SUB_EVENT_LIST_DET WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
		Integer countOfEvent = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);

		if (countOfEvent > 0) {
			return true;
		}
		return false;
	}

    /*
     * Method to return list of values for a given field.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					List<String> 
     *                         
     */
	@Override
	public List<String> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) throws IllegalArgumentException {
		String query="";
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code"})
		        .collect(Collectors.toList());
		if(fieldsFromVEL.contains(fieldName)){
			query = "select distinct NVL(vel." + fieldName + ", 'No Data') " + fieldName + " from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number  AND mel.boro_muni = eel.boro_muni AND mel.event_name = eel.event_name inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id) ORDER BY " + fieldName + " ASC";
		}else{
			query = "select distinct NVL(mel." + fieldName + ", 'No Data') " + fieldName + " from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number  AND mel.boro_muni = eel.boro_muni AND mel.event_name = eel.event_name where mel.boro_muni = ? and mel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id) ORDER BY " + fieldName + " ASC";
		}
		 List<String> fieldValueList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString(fieldName));
			}
        });
		return fieldValueList;
	}
	
    /*
     * Method to return list of values for a given field for Connected Meters.
     * 
     * @PathVariable borough  	String 
     * @RequestParam eventName  String
     * @RequestParam fieldName  String
     * 
     * @return 					List<String> 
     *                         
     */
	@Override
	public List<String> getConnectedMetersFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) throws IllegalArgumentException {
		String selectQuery;
		if (fieldName.equalsIgnoreCase("req_status")) {
			selectQuery = "select distinct NVL(msv." + fieldName + ", 'No Data') " + fieldName;
		} else if (fieldName.equalsIgnoreCase("sub_event_name")) {
			selectQuery = "select distinct NVL(eel." + fieldName + ", 'No Data') " + fieldName;
		} else {
			selectQuery = "select distinct NVL(mel." + fieldName + ", 'No Data') " + fieldName;
		}

		String query = selectQuery + " from ls_meter_event_load mel inner join lsb_meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and "
					+ " msv.event_name = mel.event_name INNER JOIN ls_execute_event_list_connect eel on eel.fk_meter_event_load_id = mel.meter_event_load_id where msv.REQUEST_TYPE = 2 AND "
					+ " msv.boro_muni= ? and msv.event_name = ? ORDER BY " + fieldName + " ASC";
		List<String> fieldValueList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				if (fieldName.equalsIgnoreCase("req_status")) {
					String reqStatus = rs.getString(fieldName);
		    		if(reqStatus.equals(REQ_STATUS_COMPLETE)){
		    			return CONNECTED_COMPLETED;
		    		}else if(reqStatus.equals(REQ_STATUS_UNKNOWN)){
		    			return CONNECTED_UNKNOWN;
		    		}else if(reqStatus.equals(REQ_STATUS_FAIL)){
		    			return CONNECTED_FAILED;
		    		}
					return reqStatus;
				} else {
					return new String(rs.getString(fieldName));
				}
			}
        });
		return fieldValueList;
	}

    /*
     * Method to return list of connected meters created for the event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * @RequestParam startRowIndex  int
     * @RequestParam batchSize  	int
     * 
     * @return 						ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getConnectedMeters(final MeterOpenEvent meterOpenEvent) throws MeterEventConnectException {
		String borough = meterOpenEvent.getBorough();
		String eventName = meterOpenEvent.getEventName();
		int startRowIndex = meterOpenEvent.getStartRowIndex();
		int batchSize = meterOpenEvent.getBatchSize();
			
		int begin  = (startRowIndex-1)*batchSize+1; 
		int end  = startRowIndex*batchSize;
			
		String filterList = " ";
		String sortList = " ";
			
		if(meterOpenEvent.isFilterApplied()){
			filterList = buildConnectedMeterFilterQuery(meterOpenEvent.getFilterList());
		}
		if(meterOpenEvent.isSortApplied()){
			sortList = buildConnectedMeterSortQuery(meterOpenEvent.getSortList());
		}
		
		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
		try {
			LOGGER.info(String.format("Request for (getConnectedMeters) list details with borough: %s and event name    : %s", borough, eventName));
	
			String query = "select METER_EVENT_LOAD_ID,boro_muni,event_name,demand,feeder,building_num,service_address,cust_zip_code,"
					+ "meter_number,account_number,network,VCAP_INSERT_TIME,transformer,structure,req_status,"
					+ "sub_event_name from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,"
					+ "mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,"
					+ "lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,"
					+ "mel.transformer, mel.structure, msv.req_status, eel.sub_event_name "
					+ "from ls_meter_event_load mel "
					+ "inner join lsb_meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name "
					+ "join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number "
					+ "INNER JOIN ls_execute_event_list_connect eel on eel.boro_muni = msv.boro_muni AND eel.event_name = msv.event_name AND eel.meter_number = msv.meter_number "
					+ "where msv.REQUEST_TYPE = 2 AND msv.boro_muni=? and msv.event_name = ? " + filterList + sortList + ") t1 where rownum<=?) where rn>=?";
			LOGGER.info("connect - Query: "+query);
			LOGGER.info("borough: "+borough +" eventName: "+ eventName +" end: "+ end +" begin: "+ begin);
	//		oracleJdbcTemplate.queryForMap(query, new Object[]{borough, eventName,end,begin});
		    List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName,end,begin},new RowMapper<MeterEventLoad>() {
		    	@Override
				public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
					MeterEventLoad meterEventLoad = new MeterEventLoad();
					meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
					meterEventLoad.setBorough(rs.getString("boro_muni"));
					meterEventLoad.setEventName(rs.getString("event_name"));
					meterEventLoad.setDemand(rs.getString("demand"));
					meterEventLoad.setFeeder(rs.getString("feeder"));
					meterEventLoad.setBuildingNumber(rs.getString("building_num"));
					meterEventLoad.setServiceAddress(rs.getString("service_address"));
					meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
					meterEventLoad.setMeterNumber(rs.getString("meter_number"));
					meterEventLoad.setAccountNumber(rs.getString("account_number"));
					meterEventLoad.setNetwork(rs.getString("network"));
					meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
					meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
					meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
					meterEventLoad.setReqStatus(rs.getString("req_status"));
					meterEventLoad.setSubEvent(rs.getString("sub_event_name"));
					return meterEventLoad;
				}
	        });
		    LOGGER.info("Before Setting Mapper Parameter: ");
	    	meterConnectResponseMapper.setBorough(borough);
	    	meterConnectResponseMapper.setEventName(eventName);
	    	LOGGER.info("Before setTotalRecord Mapper Parameter: ");
	    	meterConnectResponseMapper.setTotalRecord(getMeterCountExcludeFinalized(borough, eventName));
	    	LOGGER.info("Before setTotalMeterCount Mapper Parameter: ");
	    	meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(borough,eventName));
	    	LOGGER.info("Before setTotalFinalizeRecordInEvent Mapper Parameter: ");
	    	meterConnectResponseMapper.setTotalFinalizeRecordInEvent(getTotalFinalizeRecordInEvent(borough, eventName));
	    	LOGGER.info("Before setCountOfMeters Mapper Parameter: ");
	    	meterConnectResponseMapper.setCountOfMeters(getTotalConnectedMeterCount(borough,eventName));
	    	LOGGER.info("Before setTotalExecutedMeterCount Mapper Parameter: ");
	    	meterConnectResponseMapper.setTotalExecutedMeterCount(getTotalExecutedMeterCount(borough,eventName, filterList, sortList));
	    	LOGGER.info("Before setTotalKVA Mapper Parameter: ");
	    	meterConnectResponseMapper.setTotalKVA(String.valueOf(getTotalKVAForConnectedMeters(borough, eventName)));
	    	
	    	meterConnectResponseMapper.setPageNumber(startRowIndex);
	    	meterConnectResponseMapper.setPageSize(batchSize);
	
		    if(!meterEventLoadList.isEmpty()){
		    	convertMeterStatus(meterEventLoadList);
		    	MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
		    	meterConnectResponseMapper.setNetwork(meterEventLoad.getNetwork());
		    	meterConnectResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
		    	meterConnectResponseMapper.setValidResponse(true);
		    	meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
		    } else {
		    	meterConnectResponseMapper.setMeterEventLoads(new ArrayList<MeterEventLoad>());
		    }
		    LOGGER.info("After Setting Mapper Parameter: ");
		    return ResponseEntity.ok().body(meterConnectResponseMapper);	
		}catch (Exception ex){
			ex.printStackTrace();
			LOGGER.error(ex.getMessage(), ex);
			meterConnectResponseMapper.setMessage(ex.getMessage());
			return ResponseEntity.ok().body(meterConnectResponseMapper);	
		}
	}

    /*
     * Method to finalize the list of meters selected in the Sub Event for connect.
     * 
     * @RequestBody subEvent SubEvent
     * 
     * @return				 ResponseEntity<MeterFinalizeResponseMapper> 
     *                         
     */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class}, value="oracleTx")
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(SubEvent subEvent) throws Exception {
		MeterFinalizeResponseMapper meterFinalizeResponseMapper = new MeterFinalizeResponseMapper();
		
		long processStartTime = DateUtils.processStartTime();
		boolean isSuccess = true;
		Long totalCount = new Long(0);
		try {
			
				if(verifySubEventNameIfExist(subEvent.getBorough(), subEvent.getEvent(), subEvent.getSubEventName())){
					meterFinalizeResponseMapper.setResult(false);
					meterFinalizeResponseMapper.setMessage("Duplicate Subevent Name!!!");
					isSuccess = false;
					return ResponseEntity.status(708).body(meterFinalizeResponseMapper);
				}else{
					Pattern pattern = Pattern.compile("[a-zA-z0-9]*");
					Matcher matcher = pattern.matcher(subEvent.getSubEventName());
					if (!matcher.matches()) {
						meterFinalizeResponseMapper.setResult(false);
						meterFinalizeResponseMapper.setMessage("Subevent name contains special character !!!");
						isSuccess = false;
						return ResponseEntity.status(709).body(meterFinalizeResponseMapper);
					} 
				}
				totalCount = finalizeSubEventMeterCount(subEvent.getBorough(), subEvent.getEvent());
				if(totalCount > 0){
					finalizeSubEventMeterDetails(subEvent.getBorough(), subEvent.getEvent(), subEvent.getSubEventName(), totalCount, subEvent.getSubEventPrefix(), subEvent.getAdid());
					String SELECT_DET_SQL = "SELECT MAX(FINALIZED_EVENT_ID) FROM LS_FINALIZE_SUB_EVENT_LIST_DET WHERE BORO_MUNI = ? AND EVENT_NAME = ?";
					Integer eventId = oracleJdbcTemplate.queryForObject(SELECT_DET_SQL,  new Object[]{subEvent.getBorough(), subEvent.getEvent()}, Integer.class);
					if(eventId > 0){
						isSuccess = finalizeSubEventMeter(subEvent.getBorough(), subEvent.getEvent(), subEvent.getSubEventName(), eventId);
					}
					
					oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET SUB_EVENT_SUFFIX = ? WHERE BORO_MUNI = ? AND EVENT_NAME = ?", new Object[]{subEvent.getSubEventPrefix(), subEvent.getBorough(), subEvent.getEvent()});
				}
				if(!isSuccess){
					meterFinalizeResponseMapper.setResult(false);
					meterFinalizeResponseMapper.setMessage("Sub event was not finalized successfully.");
					return ResponseEntity.ok().body(meterFinalizeResponseMapper);
				}else{
					meterFinalizeResponseMapper.setResult(true);
					meterFinalizeResponseMapper.setMessage("Sub event has been finalized successfully. Please notify Operator.");
					 LOGGER.info(String.format("Subevent finalization response time %s Sec.", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
					return ResponseEntity.ok().body(meterFinalizeResponseMapper);			
				}
			
		}catch (Exception ex){
			ex.printStackTrace();
			meterFinalizeResponseMapper.setResult(false);
			meterFinalizeResponseMapper.setMessage(ex.getMessage());
			return ResponseEntity.ok().body(meterFinalizeResponseMapper);	
		}
	}
	
    /*
     * Method to search list of disconnected meters created for event.
     * 
     * @RequestBody meterSearch  MeterSearch 
     * 
     * @return 					 ResponseEntity<MeterConnectResponseMapper>  
     *                         
     */
	@Override
	public MeterConnectResponseMapper searchMeters(final MeterSearch meterSearch){
		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();

		List<MeterEventLoad> meterEventLoadList = new ArrayList<MeterEventLoad>();
		
		Double selectedKVA = new Double(0);
		String[] meterArry = meterSearch.getMeters().split(",");
		for (int bgn=0; bgn<meterArry.length; bgn+=900) {
	    	StringBuffer metersStr = new StringBuffer();
	    	boolean isFirst = true;
	    	int end = bgn+900 < meterArry.length ? bgn+900 : meterArry.length;
	    	for (int indx=bgn; indx<end; indx++) {
	    		if (isFirst) {
	    			metersStr.append(meterArry[indx]);
	    			isFirst = false;
	    		} else {
	    			metersStr.append(", " + meterArry[indx]);
	    		}
	    	}
	    	
			String query = "select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number and eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? and mel.meter_number IN(" + metersStr.toString() + ") AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id) AND NOT EXISTS ( SELECT eelc.fk_meter_event_load_id FROM ls_execute_event_list_connect eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id) ORDER BY mel.meter_number ASC";
			LOGGER.info(String.format("Query for searchMeters - %s", query));
			List<MeterEventLoad> meterEventLoadLst = oracleJdbcTemplate.query(query, new Object[]{meterSearch.getBorough(), meterSearch.getEvent()},new RowMapper<MeterEventLoad>() {
				@Override
				public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
					MeterEventLoad meterEventLoad = new MeterEventLoad();
					meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
					meterEventLoad.setBorough(rs.getString("boro_muni"));
					meterEventLoad.setEventName(rs.getString("event_name"));
					meterEventLoad.setDemand(rs.getString("demand"));
					meterEventLoad.setFeeder(rs.getString("feeder"));
					meterEventLoad.setBuildingNumber(rs.getString("building_num"));
					meterEventLoad.setServiceAddress(rs.getString("service_address"));
					meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
					meterEventLoad.setMeterNumber(rs.getString("meter_number"));
					meterEventLoad.setAccountNumber(rs.getString("account_number"));
					meterEventLoad.setNetwork(rs.getString("network"));
					meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
					meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
					meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
					return meterEventLoad;
				}
	        });
			
			meterConnectResponseMapper.setBorough(meterSearch.getBorough());
			meterConnectResponseMapper.setEventName(meterSearch.getEvent());

			String totKva = getValidSearchedTotalKVA(meterSearch.getBorough(), meterSearch.getEvent(), metersStr.toString());
			if (totKva != null)
				selectedKVA += Double.parseDouble(totKva);

			meterEventLoadList.addAll(meterEventLoadLst);			
		}
		
		if(!meterEventLoadList.isEmpty()){
			MeterEventLoad meterEventLoad=meterEventLoadList.get(0);
			meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
			meterConnectResponseMapper.setTotalRecord(getMeterCountExcludeFinalized(meterSearch.getBorough(), meterSearch.getEvent()));
			meterConnectResponseMapper.setTotalKVA(Double.toString(selectedKVA));
			meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(meterSearch.getBorough(),meterSearch.getEvent()));
			meterConnectResponseMapper.setCountOfMeters(meterEventLoadList.size());
			meterConnectResponseMapper.setValidResponse(true);
			meterConnectResponseMapper.setNetwork(meterEventLoad.getNetwork());
			meterConnectResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
		}	
		
		return meterConnectResponseMapper;
	}

    /*
     * Method to return Suffix for Sub Event.
     * 
     * @RequestParam borough  		String
     * @RequestParam eventName  	String 
     * 
     * @return				 		ResponseEntity<Long>
     *                         
     */
	@Override
	public ResponseEntity<Long> getSubEventSuffix(final String borough, final String event){
		Long queryForObject = oracleJdbcTemplate.queryForObject("select SUB_EVENT_SUFFIX from LS_BOROUGH_EVENT_MAPPING where boro_muni = ? and event_name = ?",  new Object[]{borough, event}, Long.class);
		if(null == queryForObject){
			return ResponseEntity.ok().body(new Long(0));	
		}else{
			return ResponseEntity.ok().body(new Long(queryForObject));
		}
	}
	
	@Override
	public ResponseEntity<MeterConnectResponseMapper> getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex, final int batchSize){
		int begin  = (startRowIndex-1)*batchSize+1; 
		int end  = startRowIndex*batchSize;

		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
		
		LOGGER.info(String.format("Request for (getSubEventMeters) list details with borough: %s and event name : %s", borough, eventName));

		String query = "select METER_EVENT_LOAD_ID,boro_muni,event_name,demand,feeder,building_num,service_address,cust_zip_code,meter_number,account_number,network,VCAP_INSERT_TIME,transformer,structure from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure from ls_meter_event_load mel inner join LS_FINALIZE_SUB_EVENT_LIST fsel on fsel.fk_meter_event_load_id = mel.meter_event_load_id join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number and fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name where fsel.boro_muni=? and fsel.event_name = ? and fsel.sub_event_name = ? order by mel.meter_event_load_id) t1 where rownum<=?) where rn>=?";
	    List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName,subEventName,end,begin},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
				meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
				return meterEventLoad;
			}
        });
	    if(!meterEventLoadList.isEmpty()){
	    	MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
	    	meterConnectResponseMapper.setBorough(meterEventLoad.getBorough());
	    	meterConnectResponseMapper.setEventName(meterEventLoad.getEventName());
	    	meterConnectResponseMapper.setNetwork(meterEventLoad.getNetwork());
	    	meterConnectResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
	    	meterConnectResponseMapper.setTotalRecord(getMeterCountExcludeFinalized(borough, eventName));
	    	meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(borough,eventName));
	    	meterConnectResponseMapper.setTotalSubEventMeters(getTotalCountForFinalSubEvent(borough, eventName, subEventName));
	    	meterConnectResponseMapper.setCountOfMeters(getTotalCountForFinalSubEvent(borough, eventName, subEventName));
	    	meterConnectResponseMapper.setTotalKVA(getKVAForFinalSubevent(borough, eventName, subEventName));
	    	meterConnectResponseMapper.setValidResponse(true);
	    	meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
	    	meterConnectResponseMapper.setPageNumber(startRowIndex);
	    	meterConnectResponseMapper.setPageSize(batchSize);
	    }
	    
	    return ResponseEntity.ok().body(meterConnectResponseMapper);
	}
	
    /*
     * Method to check Sub Event name is already used.
     * 
     * @Param borough  		String
     * @Param subEventName  String 
     * @Param eventName  	String 
     * 
     * @return				boolean
     *                         
     */
	private boolean verifySubEventNameIfExist(final String borough, final String event, final String subEventName){
		if (oracleJdbcTemplate.queryForObject("select count(FINALIZED_EVENT_ID) from LS_FINALIZE_SUB_EVENT_LIST_DET where boro_muni = ? and event_name = ? and sub_event_name = ?",  new Object[]{borough, event,subEventName}, Long.class) > 0){
			return true;
		}
		else{
			return false;
		}
	}
	
    /*
     * Method to convert Meter Status.
     * 
     * @Param meterEventLoadList List<MeterEventLoad>
     * 
     * @return					 List<MeterEventLoad
     *                         
     */
	private List<MeterEventLoad> convertMeterStatus(List<MeterEventLoad> meterEventLoadList){
    	for(MeterEventLoad meterEventLoad : meterEventLoadList){
    		if(meterEventLoad.getReqStatus().equals(REQ_STATUS_COMPLETE)){
    			meterEventLoad.setExecuteCommandMeterStatus(CONNECTED_COMPLETED);
    		}else if(meterEventLoad.getReqStatus().equals(REQ_STATUS_UNKNOWN)){
    			meterEventLoad.setExecuteCommandMeterStatus(CONNECTED_UNKNOWN);
    		}else if(meterEventLoad.getReqStatus().equals(REQ_STATUS_FAIL)){
    			meterEventLoad.setExecuteCommandMeterStatus(CONNECTED_FAILED);
    		}
    	}
    	return meterEventLoadList;
	}
	
    /*
     * Method to search list of connected meters created for event.
     * 
     * @Param meterSearch  MeterSearch 
     * 
     * @return 		  	   MeterConnectResponseMapper  
     *                         
     */
	@Override
	public MeterConnectResponseMapper searchMeterConnected(final MeterSearch meterSearch){
		MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();

		String query = "select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure,req_status,eel.sub_event_name from ls_meter_event_load mel inner join lsb_meter_status_vw msv on msv.meter_number = mel.meter_number and msv.boro_muni = mel.boro_muni and msv.event_name = mel.event_name join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number INNER JOIN ls_execute_event_list_connect eel on eel.fk_meter_event_load_id = mel.meter_event_load_id where msv.boro_muni=? and msv.event_name = ? and msv.request_type = 2 and mel.meter_number IN("+meterSearch.getMeters()+")";
		LOGGER.info(String.format("Query for searchMeters - %s", query));
		List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{meterSearch.getBorough(), meterSearch.getEvent()},new RowMapper<MeterEventLoad>() {
			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
				meterEventLoad.setStructureName(rs.getString("STRUCTURE"));
				meterEventLoad.setReqStatus(rs.getString("req_status"));
				meterEventLoad.setSubEvent(rs.getString("sub_event_name"));
				return meterEventLoad;
			}
        });
		if(!meterEventLoadList.isEmpty()){
			convertMeterStatus(meterEventLoadList);
			meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
			meterConnectResponseMapper.setTotalRecord(getTotalCountForConnected(meterSearch.getBorough(), meterSearch.getEvent()));
			meterConnectResponseMapper.setTotalKVA(String.valueOf(getKVAForConnectedSelectedMeters(meterSearch.getBorough(), meterSearch.getEvent(), meterSearch.getMeters())));
			meterConnectResponseMapper.setCountOfMeters(meterEventLoadList.size());
			meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(meterSearch.getBorough(),meterSearch.getEvent()));
			meterConnectResponseMapper.setValidResponse(true);
		}	
		return meterConnectResponseMapper;
	}

    /*
     * Method to create Sub Event.
     * 
     * @Param  subEvent SubEvent
     * 
     * @return 			MeterConnectResponseMapper
     *                         
     */
	@Override
	public MeterConnectResponseMapper getSubEventMeters(final SubEvent subEvent) {
		
		createSubEventMeters(subEvent);
		
		int startRowIndex = subEvent.getPageNumber();
		int batchSize = subEvent.getPageSize();
		
		int begin  = (startRowIndex-1)*batchSize+1; 
		int end  = startRowIndex*batchSize;
		long processStartTime = DateUtils.processStartTime();
	    String query = "select METER_EVENT_LOAD_ID,boro_muni,event_name,demand,feeder,building_num,service_address,cust_zip_code,meter_number,account_number,network,VCAP_INSERT_TIME,transformer,structure from (select t1.*,rownum rn from (select mel.METER_EVENT_LOAD_ID,mel.boro_muni,mel.event_name,mel.demand,mel.feeder,lve.building_num,lve.service_address,lve.cust_zip_code,mel.meter_number,lve.account_number,mel.network,TO_CHAR(mel.VCAP_INSERT_TIME, 'MM-DD-YYYY HH24:MI:SS') VCAP_INSERT_TIME,mel.transformer, mel.structure from ls_meter_event_load mel join ls_validate_event_list lve on lve.boro_muni=mel.boro_muni AND lve.event_name = mel.event_name and lve.meter_number=mel.meter_number INNER JOIN ls_connect_event_list cse ON cse.meter_number = mel.meter_number AND cse.fk_meter_event_load_id = mel.meter_event_load_id  WHERE cse.boro_muni = ? AND cse.event_name = ? order by mel.meter_event_load_id) t1 where rownum<=?) where rn>=?";

	    LOGGER.info(String.format("Query for meters - %s", query));
		List<MeterEventLoad> meterEventLoadList = oracleJdbcTemplate.query(query, new Object[]{subEvent.getBorough(),subEvent.getEvent(),end,begin},new RowMapper<MeterEventLoad>() {

			@Override
			public MeterEventLoad mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoad meterEventLoad = new MeterEventLoad();
				meterEventLoad.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventLoad.setBorough(rs.getString("boro_muni"));
				meterEventLoad.setEventName(rs.getString("event_name"));
				meterEventLoad.setDemand(rs.getString("demand"));
				meterEventLoad.setFeeder(rs.getString("feeder"));
				meterEventLoad.setBuildingNumber(rs.getString("building_num"));
				meterEventLoad.setServiceAddress(rs.getString("service_address"));
				meterEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
				meterEventLoad.setMeterNumber(rs.getString("meter_number"));
				meterEventLoad.setAccountNumber(rs.getString("account_number"));
				meterEventLoad.setNetwork(rs.getString("network"));
				meterEventLoad.setVcapInsertTime(rs.getString("VCAP_INSERT_TIME"));
				meterEventLoad.setTransformer(rs.getString("TRANSFORMER"));
				meterEventLoad.setStructureName(rs.getString("STRUCTURE"));

				return meterEventLoad;
			}
        });
		
		LOGGER.info(String.format("Sub event meter list response - %s Sec.", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		
	    long processStartTime1 = DateUtils.processStartTime();
	    MeterConnectResponseMapper meterConnectResponseMapper = new MeterConnectResponseMapper();
	    if(!meterEventLoadList.isEmpty()){
	    	MeterEventLoad meterEventLoad = meterEventLoadList.get(0);
	    	meterConnectResponseMapper.setBorough(meterEventLoad.getBorough());
	    	meterConnectResponseMapper.setEventName(meterEventLoad.getEventName());
	    	meterConnectResponseMapper.setNetwork(meterEventLoad.getNetwork());
	    	meterConnectResponseMapper.setInsertTime(meterEventLoad.getVcapInsertTime());
	    	Long meterCountSubEventBeforeFinalized = meterCountSubEventBeforeFinalized(subEvent.getBorough(),subEvent.getEvent());
	    	meterConnectResponseMapper.setTotalRecord(meterCountSubEventBeforeFinalized);
	    	meterConnectResponseMapper.setCountOfMeters(meterCountSubEventBeforeFinalized);
	    	meterConnectResponseMapper.setTotalMeterCount(getTotalMeterCount(subEvent.getBorough(), subEvent.getEvent()));
	    	meterConnectResponseMapper.setTotalKVA(String.valueOf(meterSubeventKVABeforeFinalized(subEvent.getBorough(), subEvent.getEvent())));
	    	meterConnectResponseMapper.setValidResponse(true);
	    	meterConnectResponseMapper.setMeterEventLoads(meterEventLoadList);
	    	meterConnectResponseMapper.setPageNumber(startRowIndex);
	    	meterConnectResponseMapper.setPageSize(batchSize);
	    }
	    
	    LOGGER.info(String.format("Sub event header response - %s Sec.", DateUtils.processResponseTime(processStartTime1, DateUtils.processEndTime())));
	    
	    return meterConnectResponseMapper;
	}
	
    /*
     * Method to unlock Event.
     * 
     * @Param  adid String
     * 
     * @return      void
     *                         
     */
	@Override
	public void unlockEvents(final String adid) {
		oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE OPERATOR_AD_ID = ?", new Object[]{adid});
	}
	
	@Override
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid) {
		MeterLockedStatusResponseMapper meterLockedStatusResponseMapper = new MeterLockedStatusResponseMapper(); 

		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Integer countOfOperator = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
		
		String lockOperatorADID = "";
		if (countOfOperator > 0) {
			String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
			lockOperatorADID = oracleJdbcTemplate.queryForObject(operatorADIDQuery,  new Object[]{borough, eventName}, String.class);
			
			if(!adid.equals(lockOperatorADID)) {
				meterLockedStatusResponseMapper.setStatus(true);
				meterLockedStatusResponseMapper.setMessage("This event is locked. User "+lockOperatorADID+" is currently working on this event.");
				
				return meterLockedStatusResponseMapper;
			}
		} 

		meterLockedStatusResponseMapper.setStatus(false);
		meterLockedStatusResponseMapper.setMessage("This event is not locked.");

		return meterLockedStatusResponseMapper;
	}
	
    /*
     * Method to create Sub Event.
     * 
     * @Param  subEvent SubEvent
     * 
     * @return 			void
     *                         
     */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class}, value="oracleTx")
	private void createSubEventMeters(final SubEvent subEvent) {
		if (subEvent.getIsCreateSubEvent()) {
			long processStartTime = DateUtils.processStartTime();
			oracleJdbcTemplate.update("DELETE LS_CONNECT_EVENT_LIST WHERE BORO_MUNI = ? AND EVENT_NAME = ?", new Object[]{subEvent.getBorough(), subEvent.getEvent()});
			LOGGER.info(String.format("Detele Query Response - %s Sec.", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
			
			if(subEvent.isExclude()){
				getSubEventMeterListsAfterExclude(subEvent);
			}else if(subEvent.getIsSelectAll()){
				getSubEventMeterListsSelectAll(subEvent);
			}else{
				getSubEventMeterLists(subEvent);
			}
		}		
	}

    /*
     * Method to create Sub Event for exclude case.
     * 
     * @Param  subEvent SubEvent
     * 
     * @return 			boolean
     *                         
     */
	private boolean getSubEventMeterListsAfterExclude(final SubEvent subEvent){	
		long processStartTime = DateUtils.processStartTime();
		boolean result = false;
		
		String query = "SELECT distinct eel.fk_meter_event_load_id, eel.boro_muni, eel.event_name, eel.meter_number FROM ls_execute_event_list eel where eel.boro_muni = ? AND eel.event_name = ? AND NOT EXISTS ( SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE eel.fk_meter_event_load_id = esel.fk_meter_event_load_id)";
		List<MeterEventLoadAction> meterEventLoadActionList = oracleJdbcTemplate.query(query,  new Object[]{subEvent.getBorough(), subEvent.getEvent()},new RowMapper<MeterEventLoadAction>() {
			@Override
			public MeterEventLoadAction mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction();

				meterEventLoadAction.setMeterEventLoadId(rs.getLong("FK_METER_EVENT_LOAD_ID"));
				meterEventLoadAction.setBorough(rs.getString("BORO_MUNI"));
				meterEventLoadAction.setEventName(rs.getString("EVENT_NAME"));
				meterEventLoadAction.setMeterNumber(rs.getString("METER_NUMBER"));
				return meterEventLoadAction;
			}
        });	
		
		LOGGER.info(String.format("Execute list query response in - %s Sec. for list of %s meters", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()),meterEventLoadActionList.size()));
		
		long processStartTime1 = DateUtils.processStartTime();
		
		MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction();
		List<MeterEventLoadAction> convertSubEventToMeterEvent = meterEventLoadAction.convertSubEventToMeterEvent(subEvent.getListOfMeters());
		
		if (subEvent.getListOfMeters().size() > 0) {
			meterEventLoadActionList.removeAll(convertSubEventToMeterEvent);
		}
		
		LOGGER.info(String.format("Exclude %s meters out of %s response time - %s Sec.", subEvent.getListOfMeters().size(), meterEventLoadActionList.size(),DateUtils.processResponseTime(processStartTime1, DateUtils.processEndTime())));

		try{
			batchInsertMeterSubEventLoad(meterEventLoadActionList, 30000, "");
			result = true;
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			result = false;
		}
		
		return result;
	}
	
    /*
     * Method to create Sub Event for selected list of meters.
     * 
     * @Param  subEvent SubEvent
     * 
     * @return 			boolean
     *                         
     */
	private boolean getSubEventMeterLists(final SubEvent subEvent){
		long processStartTime = DateUtils.processStartTime();
		boolean result = false;
		
		String query = "SELECT distinct eel.fk_meter_event_load_id, eel.boro_muni, eel.event_name, eel.meter_number FROM ls_execute_event_list eel where eel.boro_muni = ? AND eel.event_name = ? AND NOT EXISTS ( SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE eel.fk_meter_event_load_id = esel.fk_meter_event_load_id)";
		List<MeterEventLoadAction> meterEventLoadActionList = oracleJdbcTemplate.query(query,  new Object[]{subEvent.getBorough(), subEvent.getEvent()},new RowMapper<MeterEventLoadAction>() {
			@Override
			public MeterEventLoadAction mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction();

				meterEventLoadAction.setMeterEventLoadId(rs.getLong("FK_METER_EVENT_LOAD_ID"));
				meterEventLoadAction.setBorough(rs.getString("BORO_MUNI"));
				meterEventLoadAction.setEventName(rs.getString("EVENT_NAME"));
				meterEventLoadAction.setMeterNumber(rs.getString("METER_NUMBER"));
				return meterEventLoadAction;
			}
        });	
		
		LOGGER.info(String.format("Execute list query response in - %s Sec. for list of %s meters", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()),meterEventLoadActionList.size()));
		
		long processStartTime1 = DateUtils.processStartTime();
		
		MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction();
		List<MeterEventLoadAction> convertSubEventToMeterEvent = meterEventLoadAction.convertSubEventToMeterEvent(subEvent.getListOfMeters());
		int sizeOfMeterEventLoadActionList = meterEventLoadActionList.size();
		
		if (subEvent.getListOfMeters().size() > 0) {
			meterEventLoadActionList.retainAll(convertSubEventToMeterEvent);
		}
		
		LOGGER.info(String.format("Retain %s meters out of %s response time - %s Sec.", subEvent.getListOfMeters().size(), sizeOfMeterEventLoadActionList,DateUtils.processResponseTime(processStartTime1, DateUtils.processEndTime())));

		try{
			batchInsertMeterSubEventLoad(meterEventLoadActionList, 30000, "");
			result = true;
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			result = false;
		}
		
		return result;
	}
	
    /*
     * Method to create Sub Event for all meters.
     * 
     * @Param  subEvent SubEvent
     * 
     * @return 			boolean
     *                         
     */
	private boolean getSubEventMeterListsSelectAll(final SubEvent subEvent){	
		long processStartTime = DateUtils.processStartTime();
		boolean result = false;
		
		String query = "SELECT distinct eel.fk_meter_event_load_id, eel.boro_muni, eel.event_name, eel.meter_number FROM ls_execute_event_list eel where eel.boro_muni = ? AND eel.event_name = ? AND NOT EXISTS ( SELECT esel.fk_meter_event_load_id FROM ls_finalize_sub_event_list esel WHERE eel.fk_meter_event_load_id = esel.fk_meter_event_load_id)  AND NOT EXISTS ( SELECT eelc.fk_meter_event_load_id FROM ls_execute_event_list_connect eelc WHERE eel.fk_meter_event_load_id = eelc.fk_meter_event_load_id)";
		List<MeterEventLoadAction> meterEventLoadActionList = oracleJdbcTemplate.query(query,  new Object[]{subEvent.getBorough(), subEvent.getEvent()},new RowMapper<MeterEventLoadAction>() {
			@Override
			public MeterEventLoadAction mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoadAction meterEventLoadAction = new MeterEventLoadAction();

				meterEventLoadAction.setMeterEventLoadId(rs.getLong("FK_METER_EVENT_LOAD_ID"));
				meterEventLoadAction.setBorough(rs.getString("BORO_MUNI"));
				meterEventLoadAction.setEventName(rs.getString("EVENT_NAME"));
				meterEventLoadAction.setMeterNumber(rs.getString("METER_NUMBER"));
				return meterEventLoadAction;
			}
        });	
		
		LOGGER.info(String.format("Execute list query response in - %s Sec. for list of %s meters", DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()),meterEventLoadActionList.size()));
		
		if(meterEventLoadActionList.isEmpty()){
			LOGGER.info(String.format("Meter List is empty"));
			return false;
		}

		try{
			batchInsertMeterSubEventLoad(meterEventLoadActionList, 30000, "");
			result = true;
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			result = false;
		}
		
		return result;
	}

    /*
     * Method to check and lock the event.
     * 
     * @Param  adid 					  String
     * @Param  meterConnectResponseMapper MeterConnectResponseMapper
     * 
     * @return 							  MeterConnectResponseMapper
     *                         
     */	
	private MeterConnectResponseMapper checkAndUpdateIfEventUnlocked(final String adid, MeterConnectResponseMapper meterConnectResponseMapper) {
		
		String borough =  meterConnectResponseMapper.getBorough();
		String eventName= meterConnectResponseMapper.getEventName();
		
		String totalCountQuery = "SELECT COUNT(OPERATOR_AD_ID) FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
		Integer CountOfOperator = (Integer)oracleJdbcTemplate.queryForObject(totalCountQuery,  new Object[]{borough, eventName}, Integer.class);
		
		String lockOperatorADID = "";
		if (CountOfOperator > 0) {
			String operatorADIDQuery = "SELECT OPERATOR_AD_ID FROM LS_BOROUGH_EVENT_MAPPING WHERE BORO_MUNI = ? AND EVENT_NAME = ? AND FK_EVENT_STATUS = 7";
			
			lockOperatorADID = oracleJdbcTemplate.queryForObject(operatorADIDQuery,  new Object[]{borough, eventName}, String.class);
		
			if(!adid.equals(lockOperatorADID)) {
				CountOfOperator = 2;
			}
		} else {
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 7, OPERATOR_AD_ID = ? WHERE BORO_MUNI = ? AND EVENT_NAME = ?", new Object[]{adid, borough, eventName});
		}
		
		if(CountOfOperator == 2){
			meterConnectResponseMapper.setEventLocked(true);
			meterConnectResponseMapper.setMessage("This event is locked. User "+lockOperatorADID+" is currently working on this event.");
		}else {
			meterConnectResponseMapper.setEventLocked(false);
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI != ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{borough, adid});
			oracleJdbcTemplate.update("UPDATE LS_BOROUGH_EVENT_MAPPING SET FK_EVENT_STATUS = 8 WHERE BORO_MUNI = ? AND EVENT_NAME != ? AND FK_EVENT_STATUS = 7 AND OPERATOR_AD_ID = ?", new Object[]{borough, eventName, adid});
		}
		
		return meterConnectResponseMapper;
    }
	
    /*
     * Method to save list of meters selected to create Sub Event.
     * 
     * @Param  meterEventLoadAction List<MeterEventLoadAction>
     * @Param  batchSize 			String
     * @Param  adid 				int
     * 
     * @return 						int
     *                         
     */	
	public int batchInsertMeterSubEventLoad(List<MeterEventLoadAction> meterEventLoadAction, int batchSize, String adid) {
		long processStartTime = DateUtils.processStartTime();
		int batchSizeResult = 0;
		
		try{
				oracleJdbcTemplate.batchUpdate("INSERT INTO LS_CONNECT_EVENT_LIST (FK_METER_EVENT_LOAD_ID,BORO_MUNI,EVENT_NAME,METER_NUMBER) values(?,?,?,?)", meterEventLoadAction, batchSize,
	                new ParameterizedPreparedStatementSetter<MeterEventLoadAction>() {
	                    public void setValues(PreparedStatement ps, MeterEventLoadAction meterEventLoadAction)
							throws SQLException {
	                    	ps.setString(1, String.valueOf(meterEventLoadAction.getMeterEventLoadId()));
	                        ps.setString(2, meterEventLoadAction.getBorough());
	                        ps.setString(3, meterEventLoadAction.getEventName());
	                        ps.setString(4, meterEventLoadAction.getMeterNumber());
	                    }
	                });
				batchSizeResult = batchSize;
				
				LOGGER.info(String.format("Batch insert response time - %s Sec. for %s meters",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime()), meterEventLoadAction.size()));

				return batchSizeResult;
				
		}catch(Exception sqlEx){
			batchSizeResult = 0;
			LOGGER.error("SQLException Ouured: "+sqlEx.toString());
		}
		
		long processEndTime = DateUtils.processEndTime();

		LOGGER.info(String.format("*******************INSERT INTO LSDB %s BATCH %s",batchSize,DateUtils.processResponseTime(processStartTime, processEndTime)));

		return batchSizeResult;
    }

    /*
     * Method to finalize Sub Event.
     * 
     * @Param  borough 		String
     * @Param  eventName 	String
     * @Param  subEventName String
     * @Param  eventId 		int
     * 
     * @return 				boolean
     *                         
     */	
	private boolean finalizeSubEventMeter(final String borough,	final String eventName, final String subEventName, final int eventId) throws MeterEventConnectException, DataIntegrityViolationException{
       
		boolean isSuccess = false;
		oracleJdbcTemplate.execute("INSERT INTO ls_finalize_sub_event_list (fk_meter_event_load_id, boro_muni, event_name, sub_event_name, FK_FINALIZED_EVENT_ID, METER_NUMBER ) select csel.fk_meter_event_load_id,?,?,?,?, csel.METER_NUMBER from LS_CONNECT_EVENT_LIST csel where csel.event_name = ? AND csel.boro_muni = ? ", (PreparedStatementCallback<Boolean>) ps -> {
			ps.setString(1, borough);
			ps.setString(2, eventName);
			ps.setString(3, subEventName);
			ps.setInt(4, eventId);
			ps.setString(5, eventName);
			ps.setString(6, borough);
			ps.execute();
			return true;
		});
		
		isSuccess =  true;
		
        return isSuccess; 
	}
	
    /*
     * Method to finalize Sub Event.
     * 
     * @Param  borough 		String
     * @Param  eventName 	String
     * @Param  subEventName String
     * @Param  totalCount	long
     * @Param  suffix		long
     * @Param  adid			String
     * 
     * @return 				boolean
     *                         
     */	
	private boolean finalizeSubEventMeterDetails(final String borough, final String eventName, final String subeventName, long totalCount, long suffix, final String adid) throws MeterFinalizeException {
		boolean isSuccess = false;
		try{	
			isSuccess = oracleJdbcTemplate.execute("INSERT INTO LS_FINALIZE_SUB_EVENT_LIST_DET (FINALIZED_EVENT_ID, SUB_EVENT_TIME, SUB_EVENT_NAME, BORO_MUNI,EVENT_NAME,OPERATOR_AD_ID, COUNT_OF_METER, SUB_EVENT_SUFFIX) SELECT EELD.FK_FINALIZED_EVENT_ID,?,?,?,?,?,?,? from LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.BORO_MUNI = ? AND EELD.EVENT_NAME = ? AND EELD.EVENT_TYPE = 'D'", (PreparedStatementCallback<Boolean>) ps -> {
				ps.setDate(1, new java.sql.Date(new Date().getTime()));
				ps.setString(2, subeventName);
				ps.setString(3, borough);
				ps.setString(4, eventName);
				ps.setString(5, adid);
				ps.setLong(6, totalCount);
				ps.setLong(7, suffix);
				ps.setString(8, borough);
				ps.setString(9, eventName);
				ps.execute();
				return true;
			});
		}catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			throw new MeterFinalizeException("Exception ocured while inserting record in finalize sub event list dept");
		}
		
		return isSuccess;        
	}
	
    /*
     * Method to find number of meters in Sub Event.
     * 
     * @Param  borough 		String
     * @Param  eventName 	String
     * 
     * @return 				long
     *                         
     */	
	private long finalizeSubEventMeterCount(final String borough, final String event) {
		return oracleJdbcTemplate.queryForObject("select count(*) from LS_CONNECT_EVENT_LIST where boro_muni = ? and event_name = ?",  new Object[]{borough, event}, Long.class);
	}
	
    /*
     * Method to build filter query.
     * 
     * @Param  sortListMap 	Map<String,String>
     * @Param  queryPrefix 	String
     * 
     * @return 				String
     *                         
     */	
	private String buildFilterQuery(final Map<String,String> filterListMap, final String queryPrefix){
		
		StringBuffer buildFilterQuery = new StringBuffer();
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code"})
		        .collect(Collectors.toList());
		filterListMap.forEach((key, value) -> {

			String[] split = value.split(",");
			
			if (value.contains("No Data")) 
				buildFilterQuery.append(" AND (");
			else
				buildFilterQuery.append(" AND ");
			if(fieldsFromVEL.contains(key))
				buildFilterQuery.append("('"+key+"', lve."+key);
				else
					buildFilterQuery.append("('"+key+"', mel."+key);

			buildFilterQuery.append(") IN ( ");
			int i =0;
			for(String val : split){
				if(i==0){
					buildFilterQuery.append("('"+key+"',"+val+")");
					i++;
				}else{
					buildFilterQuery.append(",('"+key+"',"+val+")");
				}
			}	
			buildFilterQuery.append(") ");
			
			if (value.contains("No Data")){
				if(fieldsFromVEL.contains(key))
				buildFilterQuery.append(" OR "+"lve." + key + " IS NULL)");
				else
					buildFilterQuery.append(" OR "+queryPrefix + key + " IS NULL)");
			}
	
		});

		return buildFilterQuery.toString();
	}

    /*
     * Method to build filter query for Connected Meters.
     * 
     * @Param  sortListMap 	Map<String,String>
     * @Param  queryPrefix 	String
     * 
     * @return 				String
     *                         
     */	
	private String buildConnectedMeterFilterQuery(final Map<String,String> filterListMap){
		
		StringBuffer buildFilterQuery = new StringBuffer();
		filterListMap.forEach((key, value) -> {
			String[] split = value.split(",");
			
			if (value.contains("No Data")) 
				buildFilterQuery.append(" AND (");
			else
				buildFilterQuery.append(" AND ");
			
			String queryPrefix;
			if (key.equalsIgnoreCase("req_status")) {
				queryPrefix = "msv.";
			} else if (key.equalsIgnoreCase("sub_event_name")) {
				queryPrefix = "eel.";
			} else {
				queryPrefix = "mel.";
			}

			buildFilterQuery.append("('"+key+"', " +queryPrefix+key);
			buildFilterQuery.append(") IN ( ");
			int i =0;
			for(String val : split){
				if (key.equalsIgnoreCase("req_status")) {
					if (val.replace("\'", "").equals(CONNECTED_COMPLETED)) 
						val = "'" + REQ_STATUS_COMPLETE + "'";
					else if (val.replace("\'", "").equals(CONNECTED_UNKNOWN))
						val = "'" + REQ_STATUS_UNKNOWN + "'";
					else if (val.replace("\'", "").equals(CONNECTED_FAILED))
						val = "'" + REQ_STATUS_FAIL + "'";
				}
				
				if(i==0){
					buildFilterQuery.append("('"+key+"', "+val+")");
					i++;
				}else{
					buildFilterQuery.append(",('"+key+"', "+val+")");
				}
			}	
			buildFilterQuery.append(")");
			
			if (value.contains("No Data")) {
				buildFilterQuery.append(" OR "+queryPrefix + key + " IS NULL)");
			}
		});

		return buildFilterQuery.toString();
	}
	
    /*
     * Method to build sort query.
     * 
     * @Param  sortListMap 	Map<String,String>
     * @Param  queryPrefix 	String
     * 
     * @return 				String
     *                         
     */	
	private String buildSortQuery(final Map<String,String> sortListMap, final String queryPrefix){
		
		StringBuffer buildSortQuery = new StringBuffer("ORDER BY ");
		int flag = 0;
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code", "account_number"})
		        .collect(Collectors.toList());
		
		for (Map.Entry<String, String> entry : sortListMap.entrySet()) {
			if(flag==0){
				if(fieldsFromVEL.contains(entry.getKey()))
				buildSortQuery.append("lve.");
				else
				buildSortQuery.append(queryPrefix);
				buildSortQuery.append(entry.getKey());
				buildSortQuery.append(" "+entry.getValue());
				flag=1;
			}else{
				if(fieldsFromVEL.contains(entry.getKey()))
				buildSortQuery.append(", "+"lve.");
				else
				buildSortQuery.append(", "+queryPrefix);
				buildSortQuery.append(entry.getKey());
				buildSortQuery.append(" "+entry.getValue());
			}
	    }

		return buildSortQuery.toString();
	}
	
    /*
     * Method to build sort query for Connected Meters.
     * 
     * @Param  sortListMap 	Map<String,String>
     * 
     * @return 				String
     *                         
     */	
	private String buildConnectedMeterSortQuery(final Map<String,String> sortListMap){
		
		StringBuffer buildSortQuery = new StringBuffer(" ORDER BY ");
		int flag = 0;
		
		String queryPrefix;
		for (Map.Entry<String, String> entry : sortListMap.entrySet()) {
			
			if (entry.getKey().equalsIgnoreCase("req_status")) {
				queryPrefix = "msv.";
			} else if (entry.getKey().equalsIgnoreCase("sub_event_name")) {
				queryPrefix = "eel.";
			} else {
				queryPrefix = "mel.";
			}
			
			if(flag==0){
				buildSortQuery.append(queryPrefix);
				flag=1;
			}else{
				buildSortQuery.append(", "+queryPrefix);
			}
			
			buildSortQuery.append(entry.getKey());
			buildSortQuery.append(" "+entry.getValue());
	    }

		return buildSortQuery.toString();
	}
	
	// ------------------------------------- Header Queries --------------------------------------------------------------
	
	private int getValidTotalRecord(final String borough, final String eventName) {
		String query = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_validate_event_list vel on vel.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and vel.boro_muni=mel.boro_muni and vel.event_name=mel.event_name where mel.boro_muni = ? and mel.event_name = ? ";
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Integer.class);
    }

	private String getTotalKva(final String borough, final String eventName, final String filterList) {
		String query = "select sum(mel.demand) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name inner join ls_validate_event_list lve on lve.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and lve.boro_muni=mel.boro_muni and lve.event_name=mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) " + filterList;
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},String.class);
    }
	
	private int getCountOfMeters(final String borough, final String eventName, final String filterList) {
		String countQuery = "select count(mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name inner join ls_validate_event_list lve on lve.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and lve.boro_muni=mel.boro_muni and lve.event_name=mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) " + filterList;
		return (Integer)oracleJdbcTemplate.queryForObject(countQuery,  new Object[]{borough, eventName}, Integer.class);
	}
	
	private Long getMeterCountExcludeFinalized(final String borough, final String event){
		return oracleJdbcTemplate.queryForObject("select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID and eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? AND NOT EXISTS (SELECT eelc.fk_meter_event_load_id FROM LS_EXECUTE_EVENT_LIST_CONNECT eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name)",  new Object[]{borough, event}, Long.class);
	}
		
	private Long getTotalMeterCount(final String borough, final String event){
		return oracleJdbcTemplate.queryForObject("select COUNT (mel.METER_EVENT_LOAD_ID) from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.FK_METER_EVENT_LOAD_ID = mel.METER_EVENT_LOAD_ID AND eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name where eel.boro_muni=? and eel.event_name = ? ",  new Object[]{borough, event}, Long.class);
	}
	
	private Long getTotalConnectedMeterCount(final String borough, final String event){
		return oracleJdbcTemplate.queryForObject("SELECT count(*) FROM AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_CONNECT exe "
				+ "INNER JOIN AMI_LOAD_SHEDDING.lsb_meter_status_vw msv ON msv.event_name = exe.event_name AND msv.boro_muni = exe.boro_muni AND exe.meter_number = msv.meter_number "
				+ "WHERE exe.boro_muni=? AND exe.event_name = ? AND msv.req_status='C' AND msv.request_type=2",  new Object[]{borough, event}, Long.class);
	
	}
	private Long getTotalExecutedMeterCount(final String borough, final String event, String filterList, String sortList){
		return oracleJdbcTemplate.queryForObject("SELECT count(*) "
				+ "FROM ls_meter_event_load mel "
				+ "INNER JOIN lsb_meter_status_vw msv ON msv.meter_number = mel.meter_number AND msv.boro_muni = mel.boro_muni AND msv.event_name = mel.event_name "
				+ "INNER JOIN ls_execute_event_list_connect eel ON eel.boro_muni = msv.boro_muni AND eel.event_name = msv.event_name AND eel.meter_number = msv.meter_number "
				+ "WHERE msv.REQUEST_TYPE = 2 AND msv.boro_muni=? and msv.event_name = ? " + filterList + sortList+"",  new Object[]{borough, event}, Long.class);
	
	}
	
	private Long meterCountSubEventBeforeFinalized(final String borough, final String event){
		return oracleJdbcTemplate.queryForObject("SELECT COUNT(fk_meter_event_load_id) FROM ls_connect_event_list WHERE boro_muni = ? AND event_name= ? ",  new Object[]{borough, event}, Long.class);
	}
	
	private Long getTotalCountForConnected(final String borough, final String event){
		return oracleJdbcTemplate.queryForObject("SELECT count(msv.meter_number) FROM lsb_meter_status_vw msv where msv.boro_muni = ? AND msv.event_name = ? and msv.request_type = 2",  new Object[]{borough, event}, Long.class);
	}

	private Long getTotalCountForFinalSubEvent(final String borough, final String event, final String subEvent){
		return oracleJdbcTemplate.queryForObject("SELECT COUNT(fk_meter_event_load_id) FROM ls_finalize_sub_event_list WHERE boro_muni = ? AND event_name= ? AND sub_event_name = ? ",  new Object[]{borough, event, subEvent}, Long.class);
	}
	
	private Double meterSubeventKVABeforeFinalized(final String borough, final String eventName) {
		String query = "SELECT sum(mel.demand) FROM ls_meter_event_load mel inner join LS_CONNECT_EVENT_LIST  fsel on fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name and fsel.fk_meter_event_load_id = mel.meter_event_load_id and mel.boro_muni =? and mel.event_name=?";
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Double.class);
    }
	
	private String getKVAForFinalSubevent(final String borough, final String eventName, String subEventName) {
		String query = "SELECT sum(mel.demand) FROM ls_meter_event_load mel inner join LS_FINALIZE_SUB_EVENT_LIST  fsel on fsel.boro_muni = mel.boro_muni and fsel.event_name = mel.event_name and fsel.fk_meter_event_load_id = mel.meter_event_load_id and mel.boro_muni =? and mel.event_name=? and fsel.sub_event_name=?";
	    return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName,subEventName},String.class);
   }
	
	private Long getTotalFinalizeRecordInEvent(final String borough, final String eventName) {
		String query = "SELECT count (fsel.fk_meter_event_load_id) FROM ls_finalize_sub_event_list fsel LEFT JOIN ls_execute_event_list_connect eelc ON eelc.fk_meter_event_load_id = fsel.fk_meter_event_load_id AND fsel.event_name = eelc.event_name WHERE fsel.boro_muni = ? AND fsel.event_name = ? AND eelc.fk_meter_event_load_id IS NULL";
		//String query = "SELECT count(fk_meter_event_load_id) FROM LS_EXECUTE_EVENT_LIST_CONNECT where boro_muni=? and event_name=?";
	    return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Long.class);
    }
	
	private Double getKVAForConnectedMeters(final String borough, final String eventName) {
		String query = "SELECT SUM(mel.demand) FROM ls_meter_event_load mel INNER JOIN lsb_meter_status_vw msv ON msv.meter_number = mel.meter_number AND msv.boro_muni = mel.boro_muni AND msv.event_name = mel.event_name and msv.request_type = 2 WHERE msv.boro_muni = ? AND msv.event_name = ?";
	    return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Double.class);
    }
	
	private Double getTotalKVAForConnectedMeters(final String borough, final String eventName) {
		String query = "SELECT SUM(mel.demand) FROM ls_meter_event_load mel INNER JOIN AMI_LOAD_SHEDDING.lsb_meter_status_vw msv ON msv.event_name = mel.event_name AND "
					 + "msv.boro_muni = mel.boro_muni AND mel.meter_number = msv.meter_number WHERE mel.boro_muni= ? AND mel.event_name = ? AND "
					 + "msv.req_status='C' AND msv.request_type=2";
		return oracleJdbcTemplate.queryForObject(query, new Object[]{borough, eventName},Double.class);
    }
	
	private String getValidSearchedTotalKVA(final String borough, final String eventName, String meters) {
		return oracleJdbcTemplate.queryForObject("select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("+meters+")",  new Object[]{borough, eventName}, String.class);
    }
	
	private String getKVAForConnectedSelectedMeters(final String borough, final String eventName, final String meters) {
		return oracleJdbcTemplate.queryForObject("select SUM(mel.demand) from ls_meter_event_load mel WHERE mel.boro_muni = ? AND mel.event_name = ? AND mel.meter_number IN ("+meters+")",  new Object[]{borough, eventName}, String.class);
    }

    /*
     * Method to build sort query.
     * 
     * @Param  borough 	  String
     * @Param  eventName  String
     * @Param  filterList String
     * 
     * @return 			  List<MeterEventLoadIdAndDemand>
     *                         
     */	
	private List<MeterEventLoadIdAndDemand> getMeterEventLoadIds(final String borough, final String eventName, final String filterList) {
		String query = "select mel.METER_EVENT_LOAD_ID, mel.demand from ls_meter_event_load mel inner join ls_execute_event_list eel on eel.meter_number = mel.meter_number and eel.boro_muni = mel.boro_muni and eel.event_name = mel.event_name inner join ls_validate_event_list lve on lve.FK_METER_EVENT_LOAD_ID=mel.METER_EVENT_LOAD_ID and lve.boro_muni=mel.boro_muni and lve.event_name=mel.event_name where eel.boro_muni=? and eel.event_name = ?  AND NOT EXISTS (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = esel.boro_muni AND eel.event_name = esel.event_name) AND NOT EXISTS ( SELECT eelc.fk_meter_event_load_id FROM ls_execute_event_list_connect eelc WHERE eelc.fk_meter_event_load_id = mel.meter_event_load_id AND eel.boro_muni = eelc.boro_muni AND eel.event_name = eelc.event_name) " + filterList;
		List<MeterEventLoadIdAndDemand> meterEventLoadIdList = oracleJdbcTemplate.query(query, new Object[]{borough, eventName},new RowMapper<MeterEventLoadIdAndDemand>() {
			@Override
			public MeterEventLoadIdAndDemand mapRow(ResultSet rs, int rowNum)throws SQLException {
				MeterEventLoadIdAndDemand meterEventIdAndKva = new MeterEventLoadIdAndDemand();
				meterEventIdAndKva.setMeterEventLoadId(rs.getLong("METER_EVENT_LOAD_ID"));
				meterEventIdAndKva.setDemand(rs.getString("demand"));
				return meterEventIdAndKva;
			}
        });
		
		return meterEventLoadIdList;
	}
}