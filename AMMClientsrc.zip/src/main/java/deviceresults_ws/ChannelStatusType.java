
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ChannelStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ChannelStatusType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Overflow (std table 64)"/&gt;
 *     &lt;enumeration value="Partial interval due to common state (std table 64)"/&gt;
 *     &lt;enumeration value="Long interval due to common state (std table 64)"/&gt;
 *     &lt;enumeration value="Skipped interval due to common state (std table 64)"/&gt;
 *     &lt;enumeration value="Interval contains test mode data (std table 64)"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_GENERAL_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_SRC_SEL_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_CRC_FLASH_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_SOURCE_NOT_READY_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_UNKNOWN_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_UNSUPPORTED_SOURCE_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_UNKNOWN_SOURCE_ERROR"/&gt;
 *     &lt;enumeration value="CHANNEL_GMI_SUSPICIOUS_ROLLOVER"/&gt;
 *     &lt;enumeration value="CHANNEL_INVALID_DATA"/&gt;
 *     &lt;enumeration value="CHANNEL_PRI_NO_DATA"/&gt;
 *     &lt;enumeration value="The configuration changed during this interval (std table 64)"/&gt;
 *     &lt;enumeration value="Load profile recording stopped (std table 64)"/&gt;
 *     &lt;enumeration value="CHANNEL_C1219_STATUS_NOT_SUPPORTED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ChannelStatusType")
@XmlEnum
public enum ChannelStatusType {

    @XmlEnumValue("Overflow (std table 64)")
    OVERFLOW_STD_TABLE_64("Overflow (std table 64)"),
    @XmlEnumValue("Partial interval due to common state (std table 64)")
    PARTIAL_INTERVAL_DUE_TO_COMMON_STATE_STD_TABLE_64("Partial interval due to common state (std table 64)"),
    @XmlEnumValue("Long interval due to common state (std table 64)")
    LONG_INTERVAL_DUE_TO_COMMON_STATE_STD_TABLE_64("Long interval due to common state (std table 64)"),
    @XmlEnumValue("Skipped interval due to common state (std table 64)")
    SKIPPED_INTERVAL_DUE_TO_COMMON_STATE_STD_TABLE_64("Skipped interval due to common state (std table 64)"),
    @XmlEnumValue("Interval contains test mode data (std table 64)")
    INTERVAL_CONTAINS_TEST_MODE_DATA_STD_TABLE_64("Interval contains test mode data (std table 64)"),
    CHANNEL_GMI_GENERAL_ERROR("CHANNEL_GMI_GENERAL_ERROR"),
    CHANNEL_GMI_SRC_SEL_ERROR("CHANNEL_GMI_SRC_SEL_ERROR"),
    CHANNEL_GMI_CRC_FLASH_ERROR("CHANNEL_GMI_CRC_FLASH_ERROR"),
    CHANNEL_GMI_SOURCE_NOT_READY_ERROR("CHANNEL_GMI_SOURCE_NOT_READY_ERROR"),
    CHANNEL_GMI_UNKNOWN_ERROR("CHANNEL_GMI_UNKNOWN_ERROR"),
    CHANNEL_GMI_UNSUPPORTED_SOURCE_ERROR("CHANNEL_GMI_UNSUPPORTED_SOURCE_ERROR"),
    CHANNEL_GMI_UNKNOWN_SOURCE_ERROR("CHANNEL_GMI_UNKNOWN_SOURCE_ERROR"),
    CHANNEL_GMI_SUSPICIOUS_ROLLOVER("CHANNEL_GMI_SUSPICIOUS_ROLLOVER"),
    CHANNEL_INVALID_DATA("CHANNEL_INVALID_DATA"),
    CHANNEL_PRI_NO_DATA("CHANNEL_PRI_NO_DATA"),
    @XmlEnumValue("The configuration changed during this interval (std table 64)")
    THE_CONFIGURATION_CHANGED_DURING_THIS_INTERVAL_STD_TABLE_64("The configuration changed during this interval (std table 64)"),
    @XmlEnumValue("Load profile recording stopped (std table 64)")
    LOAD_PROFILE_RECORDING_STOPPED_STD_TABLE_64("Load profile recording stopped (std table 64)"),
    @XmlEnumValue("CHANNEL_C1219_STATUS_NOT_SUPPORTED")
    CHANNEL_C_1219_STATUS_NOT_SUPPORTED("CHANNEL_C1219_STATUS_NOT_SUPPORTED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ChannelStatusType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ChannelStatusType fromValue(String v) {
        for (ChannelStatusType c: ChannelStatusType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
