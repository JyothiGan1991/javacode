
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseBatteryInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseBatteryInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BatteryManufacturer" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BatteryModel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BatterySerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BatteryManufacturerTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryExpirationTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryInstalledTime" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BatteryLotNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BatteryLastTestedTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseBatteryInfoType", propOrder = {
    "batteryManufacturer",
    "batteryModel",
    "batterySerialNumber",
    "batteryManufacturerTime",
    "batteryExpirationTime",
    "batteryInstalledTime",
    "batteryLotNumber",
    "batteryLastTestedTime"
})
@XmlSeeAlso({
    BatteryInfoType.class
})
public class BaseBatteryInfoType {

    @XmlElement(name = "BatteryManufacturer", required = true)
    protected String batteryManufacturer;
    @XmlElement(name = "BatteryModel", required = true)
    protected String batteryModel;
    @XmlElement(name = "BatterySerialNumber", required = true)
    protected String batterySerialNumber;
    @XmlElement(name = "BatteryManufacturerTime")
    protected String batteryManufacturerTime;
    @XmlElement(name = "BatteryExpirationTime")
    protected String batteryExpirationTime;
    @XmlElement(name = "BatteryInstalledTime", required = true)
    protected String batteryInstalledTime;
    @XmlElement(name = "BatteryLotNumber")
    protected String batteryLotNumber;
    @XmlElement(name = "BatteryLastTestedTime")
    protected String batteryLastTestedTime;

    /**
     * Gets the value of the batteryManufacturer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryManufacturer() {
        return batteryManufacturer;
    }

    /**
     * Sets the value of the batteryManufacturer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryManufacturer(String value) {
        this.batteryManufacturer = value;
    }

    /**
     * Gets the value of the batteryModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryModel() {
        return batteryModel;
    }

    /**
     * Sets the value of the batteryModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryModel(String value) {
        this.batteryModel = value;
    }

    /**
     * Gets the value of the batterySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatterySerialNumber() {
        return batterySerialNumber;
    }

    /**
     * Sets the value of the batterySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatterySerialNumber(String value) {
        this.batterySerialNumber = value;
    }

    /**
     * Gets the value of the batteryManufacturerTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryManufacturerTime() {
        return batteryManufacturerTime;
    }

    /**
     * Sets the value of the batteryManufacturerTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryManufacturerTime(String value) {
        this.batteryManufacturerTime = value;
    }

    /**
     * Gets the value of the batteryExpirationTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryExpirationTime() {
        return batteryExpirationTime;
    }

    /**
     * Sets the value of the batteryExpirationTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryExpirationTime(String value) {
        this.batteryExpirationTime = value;
    }

    /**
     * Gets the value of the batteryInstalledTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryInstalledTime() {
        return batteryInstalledTime;
    }

    /**
     * Sets the value of the batteryInstalledTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryInstalledTime(String value) {
        this.batteryInstalledTime = value;
    }

    /**
     * Gets the value of the batteryLotNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryLotNumber() {
        return batteryLotNumber;
    }

    /**
     * Sets the value of the batteryLotNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryLotNumber(String value) {
        this.batteryLotNumber = value;
    }

    /**
     * Gets the value of the batteryLastTestedTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryLastTestedTime() {
        return batteryLastTestedTime;
    }

    /**
     * Sets the value of the batteryLastTestedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryLastTestedTime(String value) {
        this.batteryLastTestedTime = value;
    }

}
