
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BaseNicSoftwareTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseNicSoftwareTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConfigName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ConfigDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareRev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwarePatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NicSoftwareReleasedTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseNicSoftwareTypeConfig", propOrder = {
    "configName",
    "configDesc",
    "nicSoftwareVersion",
    "nicSoftwareRev",
    "nicSoftwarePatch",
    "nicSoftwareReleasedTime"
})
@XmlSeeAlso({
    NicSoftwareTypeConfig.class
})
public class BaseNicSoftwareTypeConfig {

    @XmlElement(name = "ConfigName", required = true)
    protected String configName;
    @XmlElement(name = "ConfigDesc")
    protected String configDesc;
    @XmlElement(name = "NicSoftwareVersion")
    protected String nicSoftwareVersion;
    @XmlElement(name = "NicSoftwareRev")
    protected String nicSoftwareRev;
    @XmlElement(name = "NicSoftwarePatch")
    protected String nicSoftwarePatch;
    @XmlElement(name = "NicSoftwareReleasedTime")
    protected String nicSoftwareReleasedTime;

    /**
     * Gets the value of the configName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigName() {
        return configName;
    }

    /**
     * Sets the value of the configName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigName(String value) {
        this.configName = value;
    }

    /**
     * Gets the value of the configDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigDesc() {
        return configDesc;
    }

    /**
     * Sets the value of the configDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigDesc(String value) {
        this.configDesc = value;
    }

    /**
     * Gets the value of the nicSoftwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareVersion() {
        return nicSoftwareVersion;
    }

    /**
     * Sets the value of the nicSoftwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareVersion(String value) {
        this.nicSoftwareVersion = value;
    }

    /**
     * Gets the value of the nicSoftwareRev property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareRev() {
        return nicSoftwareRev;
    }

    /**
     * Sets the value of the nicSoftwareRev property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareRev(String value) {
        this.nicSoftwareRev = value;
    }

    /**
     * Gets the value of the nicSoftwarePatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwarePatch() {
        return nicSoftwarePatch;
    }

    /**
     * Sets the value of the nicSoftwarePatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwarePatch(String value) {
        this.nicSoftwarePatch = value;
    }

    /**
     * Gets the value of the nicSoftwareReleasedTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNicSoftwareReleasedTime() {
        return nicSoftwareReleasedTime;
    }

    /**
     * Sets the value of the nicSoftwareReleasedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNicSoftwareReleasedTime(String value) {
        this.nicSoftwareReleasedTime = value;
    }

}
