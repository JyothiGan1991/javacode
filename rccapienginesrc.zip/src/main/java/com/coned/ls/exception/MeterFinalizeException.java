package com.coned.ls.exception;

public class MeterFinalizeException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public MeterFinalizeException() {
		super();
	}

	public MeterFinalizeException(final String message) {
		super(message);
		
	}
	
	
}
