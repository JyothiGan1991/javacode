
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterConnectionStatusEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MeterConnectionStatusEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="RMT_PROV_RES_STAT_UNKNOWN"/&gt;
 *     &lt;enumeration value="RMT_PROV_RES_STAT_DISCONNECTED"/&gt;
 *     &lt;enumeration value="RMT_PROV_RES_STAT_ARMED"/&gt;
 *     &lt;enumeration value="RMT_PROV_RES_STAT_CONNECTED"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MeterConnectionStatusEnumeration")
@XmlEnum
public enum MeterConnectionStatusEnumeration {

    RMT_PROV_RES_STAT_UNKNOWN("RMT_PROV_RES_STAT_UNKNOWN"),
    RMT_PROV_RES_STAT_DISCONNECTED("RMT_PROV_RES_STAT_DISCONNECTED"),
    RMT_PROV_RES_STAT_ARMED("RMT_PROV_RES_STAT_ARMED"),
    RMT_PROV_RES_STAT_CONNECTED("RMT_PROV_RES_STAT_CONNECTED"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MeterConnectionStatusEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MeterConnectionStatusEnumeration fromValue(String v) {
        for (MeterConnectionStatusEnumeration c: MeterConnectionStatusEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
