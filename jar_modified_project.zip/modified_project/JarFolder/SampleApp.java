public class SampleApp {
    public static void main(String[] args) {
        System.out.println("✅ Sample JAR executed successfully!");
        System.out.println("🚀 Jar Runner is working");
    }
}