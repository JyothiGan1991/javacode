
package com.ssn.schema.service.v2_6.eventmanager;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindEventResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindEventResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Result" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}FindEventResultType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Counts" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}CountsType" minOccurs="0"/>
 *         &lt;element name="EventCategories" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}EventCategoryType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="SearchKey" use="required" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="RowCount" use="required" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="ExceededMaximumNumberOfRows" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *       &lt;attribute name="ErrorsOccurred" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindEventResponseType", propOrder = {
    "result",
    "counts",
    "eventCategories"
})
public class FindEventResponseType {

    @XmlElement(name = "Result")
    protected List<FindEventResultType> result;
    @XmlElement(name = "Counts")
    protected CountsType counts;
    @XmlElement(name = "EventCategories")
    protected List<EventCategoryType> eventCategories;
    @XmlAttribute(name = "SearchKey", required = true)
    protected long searchKey;
    @XmlAttribute(name = "RowCount", required = true)
    protected long rowCount;
    @XmlAttribute(name = "ExceededMaximumNumberOfRows")
    protected Boolean exceededMaximumNumberOfRows;
    @XmlAttribute(name = "ErrorsOccurred", required = true)
    protected boolean errorsOccurred;

    /**
     * Gets the value of the result property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the result property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FindEventResultType }
     * 
     * 
     */
    public List<FindEventResultType> getResult() {
        if (result == null) {
            result = new ArrayList<FindEventResultType>();
        }
        return this.result;
    }

    /**
     * Gets the value of the counts property.
     * 
     * @return
     *     possible object is
     *     {@link CountsType }
     *     
     */
    public CountsType getCounts() {
        return counts;
    }

    /**
     * Sets the value of the counts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountsType }
     *     
     */
    public void setCounts(CountsType value) {
        this.counts = value;
    }

    /**
     * Gets the value of the eventCategories property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventCategories property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventCategories().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EventCategoryType }
     * 
     * 
     */
    public List<EventCategoryType> getEventCategories() {
        if (eventCategories == null) {
            eventCategories = new ArrayList<EventCategoryType>();
        }
        return this.eventCategories;
    }

    /**
     * Gets the value of the searchKey property.
     * 
     */
    public long getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     */
    public void setSearchKey(long value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     */
    public long getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     */
    public void setRowCount(long value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the exceededMaximumNumberOfRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isExceededMaximumNumberOfRows() {
        if (exceededMaximumNumberOfRows == null) {
            return false;
        } else {
            return exceededMaximumNumberOfRows;
        }
    }

    /**
     * Sets the value of the exceededMaximumNumberOfRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExceededMaximumNumberOfRows(Boolean value) {
        this.exceededMaximumNumberOfRows = value;
    }

    /**
     * Gets the value of the errorsOccurred property.
     * 
     */
    public boolean isErrorsOccurred() {
        return errorsOccurred;
    }

    /**
     * Sets the value of the errorsOccurred property.
     * 
     */
    public void setErrorsOccurred(boolean value) {
        this.errorsOccurred = value;
    }

}
