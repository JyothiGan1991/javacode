package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.Meter;

public class MeterRowMapper implements RowMapper<Meter> {

	@Override
	public Meter mapRow(ResultSet rs, int rowNum) throws SQLException {
		// Columns: REQUEST_IDX, METER_NUMBER, MAC_ID, EVENT_NAME
		return new Meter(rs.getBigDecimal(1), rs.getString(2), rs.getString(3), rs.getString(4));
	}
}
