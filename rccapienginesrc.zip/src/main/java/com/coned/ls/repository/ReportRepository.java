package com.coned.ls.repository;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

public interface ReportRepository {

	public List<Map<String, Object>> getEvents(String report_name);
	public List<Map<String, Object>> getCWRData(Map<String, Object> payload);
	public List<Map<String, Object>> getCDRData(Map<String, Object> payload);
	public List<Map<String, Object>> getCRRData(String event_name,String boro_muni,String sub_event_name);
	public Map<String, Object>  getCMRData(String event_name,String boro_muni);
	public Map<String, Object> getCERData(String event_name,String boro_muni);
	
}
