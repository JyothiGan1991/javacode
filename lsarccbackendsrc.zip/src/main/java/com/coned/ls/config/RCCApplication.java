package com.coned.ls.config;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;

/**
 * Spring Boot Application for RCC Disconnect and RCC Connect.
 * 
 * This application implements Rest Api's to perform following functionalities.
 * 
 * 1. Read list of meters available for disconnect and connect operation.
 * 2. Finalize list of meters for disconnect.
 * 3. Create Sub Event by selecting list of meters and finalize for connect.
 * 4. Search, Filter and sort the data created for the events.
 * 5. Read list of connected meters created for the event.
 * 6. Read list of meters grouped in the Sub Event.
 */
@SpringBootApplication(scanBasePackages={"com.coned.ls"})
@EnableWebMvc
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class})
//@PropertySource("classpath:api.properties")
public class RCCApplication extends SpringBootServletInitializer implements WebApplicationInitializer, WebMvcConfigurer{

    /*
     * Initializes the application when running in a Servlet Container (e.g. Weblogic).
     */
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(RCCApplication.class);
    }
	
    /*
     * Initializes the application when running as a Standalone Application.
     */
	public static void main(String[] args) {
		SpringApplication.run(RCCApplication.class, args);
	}
	
    /*
     * Configure the ServletContext with Request context listener.
     */
	@Override 
	public void onStartup( ServletContext servletContext ) throws ServletException {
	    super.onStartup( servletContext );
	    servletContext.addListener( new RequestContextListener() ) ;
	}
	
	/*
	 * Return the ObjectMapper for this Application.
	 */
	@Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, true);
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        return mapper;
 
    }

	/*
	 * Method to configure view resolution.
	 */
	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".html");
        registry.viewResolver(resolver);
    }
	
	/*
	 * Method to configure default Servlet handling. 
	 */
	@Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
}