/*package com.coned.ls.repository;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.config.RCCApplicationTest;
import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.MeterRejectResponseMapper;
import com.coned.ls.service.MetersEventRejectService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ApiEngineApplication.class)
public class MeterEventRejectRepositoryTest {

	
	
	@Autowired
	private MetersEventRejectRepository metersEventRejectRepository;
	
	@Autowired
	private MetersEventRejectService metersEventRejectService;
	
	
	@Test
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class, value="oracleTx")
	@Rollback(true)
	public void rejectMeterEventList() throws MeterRejectException{
		//MeterRejectResponseMapper rejectMeterEventList = metersEventRejectRepository.rejectMeterEventList("A", "SheepsheadBaySampleData7.27.20-1703");
		//System.out.println(rejectMeterEventList.toString());
	}
}
*/