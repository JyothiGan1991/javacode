
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CronJobScheduleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CronJobScheduleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="Interval" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}IntervalType"/&gt;
 *         &lt;element name="Weekly" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}WeeklyType"/&gt;
 *         &lt;element name="SpecificTimes" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}SpecificTimesType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CronJobScheduleType", propOrder = {
    "interval",
    "weekly",
    "specificTimes"
})
public class CronJobScheduleType {

    @XmlElement(name = "Interval")
    protected IntervalType interval;
    @XmlElement(name = "Weekly")
    protected WeeklyType weekly;
    @XmlElement(name = "SpecificTimes")
    protected SpecificTimesType specificTimes;

    /**
     * Gets the value of the interval property.
     * 
     * @return
     *     possible object is
     *     {@link IntervalType }
     *     
     */
    public IntervalType getInterval() {
        return interval;
    }

    /**
     * Sets the value of the interval property.
     * 
     * @param value
     *     allowed object is
     *     {@link IntervalType }
     *     
     */
    public void setInterval(IntervalType value) {
        this.interval = value;
    }

    /**
     * Gets the value of the weekly property.
     * 
     * @return
     *     possible object is
     *     {@link WeeklyType }
     *     
     */
    public WeeklyType getWeekly() {
        return weekly;
    }

    /**
     * Sets the value of the weekly property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeeklyType }
     *     
     */
    public void setWeekly(WeeklyType value) {
        this.weekly = value;
    }

    /**
     * Gets the value of the specificTimes property.
     * 
     * @return
     *     possible object is
     *     {@link SpecificTimesType }
     *     
     */
    public SpecificTimesType getSpecificTimes() {
        return specificTimes;
    }

    /**
     * Sets the value of the specificTimes property.
     * 
     * @param value
     *     allowed object is
     *     {@link SpecificTimesType }
     *     
     */
    public void setSpecificTimes(SpecificTimesType value) {
        this.specificTimes = value;
    }

}
