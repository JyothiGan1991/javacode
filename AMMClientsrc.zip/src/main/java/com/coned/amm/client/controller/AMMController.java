package com.coned.amm.client.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.coned.amm.service.DmgrService;
import com.coned.amm.service.DvcResultsService;
import com.coned.amm.service.JMService;

@RestController
public class AMMController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private DmgrService dMgrService;

	@Autowired
	private JMService jmService;

	@Autowired
	private DvcResultsService drService;

	// OPEn API docs URL - http://localhost:8080/v3/api-docs/
	// Swagger API docs at
	// http://hesomsdev1.conedison.net:7011/AMMClient/swagger-ui.html

	@RequestMapping(value = "/mac-id/{meter-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> getMACID(@PathVariable("meter-id") String meterId) {
		logger.info("Initiataing the request to get the associated MAC ID for Meter [" + meterId + "]");
		return new ResponseEntity<Object>(dMgrService.findDevice(meterId), HttpStatus.OK);
	}

	@RequestMapping(value = "/meter/disconnect/{meter-id}/{mac-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> disconnectMeter(@PathVariable("meter-id") String meterId,
			@PathVariable("mac-id") String macId) {
		logger.info("Invoke the disconnect request for Meter [" + meterId + "] and macid[" + macId + "]");
		return new ResponseEntity<Object>(jmService.remoteConnectDisconnect(meterId, macId, true), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/meter/connect/{meter-id}/{mac-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> connectMeter(@PathVariable("meter-id") String meterId,
			@PathVariable("mac-id") String macId) {
		logger.info("Invoke the connect request for Meter [" + meterId + "] and macid[" + macId + "]");
		return new ResponseEntity<Object>(jmService.remoteConnectDisconnect(meterId, macId, false), HttpStatus.OK);
	}

	@RequestMapping(value = "/rcm/job-status/{job-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> jobsStatus(@PathVariable("job-id") long jobId) {
		logger.info("Invoke the job status request for job id [" + jobId + "]");
		return new ResponseEntity<Object>(jmService.getJobStatus(jobId), HttpStatus.OK);
	}

	@RequestMapping(value = "/rcm/switch-status/{mac-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> switchStatus(@PathVariable("mac-id") String macId) {
		logger.info("Invoke the switch status request for job id [" + macId + "]");
		return new ResponseEntity<Object>(jmService.getSwitchStatus(macId), HttpStatus.OK);
	}

	@RequestMapping(value = "/rcm/switch-results/{job-id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> switchStatusResults(@PathVariable("job-id") long jobId) {
		logger.info("Invoke the job status request for job id [" + jobId + "]");
		return new ResponseEntity<Object>(drService.getSwitchStatusResults(jobId), HttpStatus.OK);
	}
}
