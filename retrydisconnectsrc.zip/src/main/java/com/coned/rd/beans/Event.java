package com.coned.rd.beans;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;

public class Event {

	private BigDecimal requestId;

	private String eventName, boro;

	private List<String> meterList;
	private List<Event> retryList;

	private int meterCount;

	private ZonedDateTime eventTime, expireTime;

	// Timeout metioned in minutes
	private int timeout;

	private Boolean retry;

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Event(BigDecimal requestId, ZonedDateTime eventTime, int meterCount) {
		super();
		this.requestId = requestId;
		this.eventTime = eventTime;
		this.meterCount = meterCount;
	}

	public Event(BigDecimal requestId, String eventName, String boro, ZonedDateTime eventTime) {
		super();
		this.requestId = requestId;
		this.eventName = eventName;
		this.boro = boro;
		this.eventTime = eventTime;
	}

	public Event(BigDecimal requestId, String eventName, String boro, ZonedDateTime eventTime, int timeout) {
		super();
		this.requestId = requestId;
		this.eventName = eventName;
		this.boro = boro;
		this.eventTime = eventTime;
		this.timeout = timeout;
	}

	public Event(BigDecimal requestId, String eventName, String boro) {
		super();
		this.requestId = requestId;
		this.eventName = eventName;
		this.boro = boro;
	}

	public BigDecimal getRequestId() {
		return requestId;
	}

	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getBoro() {
		return boro;
	}

	public void setBoro(String boro) {
		this.boro = boro;
	}

	public List<String> getMeterList() {
		return meterList;
	}

	public void setMeterList(List<String> meterList) {
		this.meterList = meterList;
	}

	public int getMeterCount() {
		return meterCount;
	}

	public void setMeterCount(int meterCount) {
		this.meterCount = meterCount;
	}

	public ZonedDateTime getEventTime() {
		return eventTime;
	}

	public void setEventTime(ZonedDateTime eventTime) {
		this.eventTime = eventTime;
	}

	public ZonedDateTime getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(ZonedDateTime expireTime) {
		this.expireTime = expireTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	public Boolean isRetry() {
		return retry;
	}

	public void setRetry(Boolean retry) {
		this.retry = retry;
	}

	public List<Event> getRetryList() {
		return retryList;
	}

	public void setRetryList(List<Event> retryList) {
		this.retryList = retryList;
	}

	@Override
	public String toString() {
		return "Event [requestId=" + requestId + ", eventName=" + eventName + ", boro=" + boro + ", meterList="
				+ meterList + ", retryList=" + retryList + ", meterCount=" + meterCount + ", eventTime=" + eventTime
				+ ", expireTime=" + expireTime + ", timeout=" + timeout + ", retry=" + retry + "]";
	}
}
