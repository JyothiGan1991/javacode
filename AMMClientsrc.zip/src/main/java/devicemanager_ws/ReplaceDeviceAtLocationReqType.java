
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReplaceDeviceAtLocationReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReplaceDeviceAtLocationReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OldDevice" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceIdentifier"/&gt;
 *         &lt;element name="OldAdminState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="RemoveOldDeviceTS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OldDeviceNote" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NewDevice" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}DeviceIdentifier" minOccurs="0"/&gt;
 *         &lt;element name="NewDeviceNote" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NewLocationInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UpdateDeviceLocationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReplaceDeviceAtLocationReqType", propOrder = {
    "oldDevice",
    "oldAdminState",
    "removeOldDeviceTS",
    "oldDeviceNote",
    "newDevice",
    "newDeviceNote",
    "newLocationInfo"
})
public class ReplaceDeviceAtLocationReqType {

    @XmlElement(name = "OldDevice", required = true)
    protected DeviceIdentifier oldDevice;
    @XmlElement(name = "OldAdminState")
    protected UtilDeviceStateType oldAdminState;
    @XmlElement(name = "RemoveOldDeviceTS")
    protected String removeOldDeviceTS;
    @XmlElement(name = "OldDeviceNote")
    protected String oldDeviceNote;
    @XmlElement(name = "NewDevice")
    protected DeviceIdentifier newDevice;
    @XmlElement(name = "NewDeviceNote")
    protected String newDeviceNote;
    @XmlElement(name = "NewLocationInfo")
    protected UpdateDeviceLocationType newLocationInfo;

    /**
     * Gets the value of the oldDevice property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceIdentifier }
     *     
     */
    public DeviceIdentifier getOldDevice() {
        return oldDevice;
    }

    /**
     * Sets the value of the oldDevice property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceIdentifier }
     *     
     */
    public void setOldDevice(DeviceIdentifier value) {
        this.oldDevice = value;
    }

    /**
     * Gets the value of the oldAdminState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getOldAdminState() {
        return oldAdminState;
    }

    /**
     * Sets the value of the oldAdminState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setOldAdminState(UtilDeviceStateType value) {
        this.oldAdminState = value;
    }

    /**
     * Gets the value of the removeOldDeviceTS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoveOldDeviceTS() {
        return removeOldDeviceTS;
    }

    /**
     * Sets the value of the removeOldDeviceTS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoveOldDeviceTS(String value) {
        this.removeOldDeviceTS = value;
    }

    /**
     * Gets the value of the oldDeviceNote property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldDeviceNote() {
        return oldDeviceNote;
    }

    /**
     * Sets the value of the oldDeviceNote property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldDeviceNote(String value) {
        this.oldDeviceNote = value;
    }

    /**
     * Gets the value of the newDevice property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceIdentifier }
     *     
     */
    public DeviceIdentifier getNewDevice() {
        return newDevice;
    }

    /**
     * Sets the value of the newDevice property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceIdentifier }
     *     
     */
    public void setNewDevice(DeviceIdentifier value) {
        this.newDevice = value;
    }

    /**
     * Gets the value of the newDeviceNote property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewDeviceNote() {
        return newDeviceNote;
    }

    /**
     * Sets the value of the newDeviceNote property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewDeviceNote(String value) {
        this.newDeviceNote = value;
    }

    /**
     * Gets the value of the newLocationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateDeviceLocationType }
     *     
     */
    public UpdateDeviceLocationType getNewLocationInfo() {
        return newLocationInfo;
    }

    /**
     * Sets the value of the newLocationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateDeviceLocationType }
     *     
     */
    public void setNewLocationInfo(UpdateDeviceLocationType value) {
        this.newLocationInfo = value;
    }

}
