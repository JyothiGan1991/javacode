
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PingTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PingTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_NET"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_NET"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "PingTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum PingTypeEnumeration {

    JOB_OP_PING_GW_APP("JOB_OP_PING_GW_APP"),
    JOB_OP_PING_GW_NET("JOB_OP_PING_GW_NET"),
    JOB_OP_PING_DEV_APP("JOB_OP_PING_DEV_APP"),
    JOB_OP_PING_DEV_NET("JOB_OP_PING_DEV_NET"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    PingTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PingTypeEnumeration fromValue(String v) {
        for (PingTypeEnumeration c: PingTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
