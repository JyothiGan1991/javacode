package com.coned.rc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.springframework.jdbc.core.RowMapper;

import com.coned.rc.beans.Event;

public class EventRowMapper implements RowMapper<Event> {
	public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
		ZonedDateTime eventTime = rs.getTimestamp(5).toLocalDateTime().atZone(ZoneId.of("America/New_York"));
		return new Event(rs.getBigDecimal(1), rs.getString(2), rs.getString(3), rs.getString(4), eventTime);
	}
}