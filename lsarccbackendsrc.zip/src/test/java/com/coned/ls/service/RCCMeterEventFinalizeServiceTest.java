package com.coned.ls.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.rest.RESTActionExecutor;

@RunWith(MockitoJUnitRunner.class)
public class RCCMeterEventFinalizeServiceTest {

	@InjectMocks
	MeterEventFinalizeService meterEventFinalizeService;

	@Mock
	RESTActionExecutor restActionExecutor;
	
	@Test
	public void finalizeValidateMeter(){
		 MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		 ResponseEntity<String> response = new ResponseEntity<String>("success", HttpStatus.OK);
		 String adid = "Test";
		Mockito.when(restActionExecutor.finalizeValidateMeters(meterEventFinalize,adid)).thenReturn(response);
		 try {
			ResponseEntity<String> result =  meterEventFinalizeService.finalizeValidateMeter(meterEventFinalize,adid);
			Assert.assertEquals(response.getBody(), result.getBody());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
