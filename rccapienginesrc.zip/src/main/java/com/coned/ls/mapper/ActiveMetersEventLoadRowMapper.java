package com.coned.ls.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.ActiveMetersEventLoad;
import com.coned.ls.domain.MeterEventLoad;


public class ActiveMetersEventLoadRowMapper implements RowMapper<ActiveMetersEventLoad>{

	@Override
	public ActiveMetersEventLoad mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ActiveMetersEventLoad activeMetersEventLoad = new ActiveMetersEventLoad();
		
		activeMetersEventLoad.setBorough(rs.getString("boro_muni"));
		activeMetersEventLoad.setEventName(rs.getString("event_name"));
		activeMetersEventLoad.setAccountNumber(rs.getString("account_number"));
		activeMetersEventLoad.setMeterNumber(rs.getString("meter_number"));
		activeMetersEventLoad.setCustomerZipCode(rs.getString("cust_zip_code"));
		
		return activeMetersEventLoad;
	}
	
	
}
