package com.coned.ls.login;

import java.util.HashMap;

import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;

/**
 * Implementation of Configuration which uses JAAS UsernamePasswordLoginModule.
 * 
 */
public class CustomLoginConfig extends Configuration {
    private static final String APP_NAME = "MyApp";
    
    //Check for search Module
    private static final String LOGIN_MODULE_CLASS = "weblogic.security.auth.login.UsernamePasswordLoginModule";

    /*
     * The Login Configuration entry to use for authentication.
     * 
     */
    @Override
    public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
        if (name.equals(APP_NAME)) {
            AppConfigurationEntry[] configArr = new AppConfigurationEntry[1];

            configArr[0] = new AppConfigurationEntry(LOGIN_MODULE_CLASS,AppConfigurationEntry.LoginModuleControlFlag.OPTIONAL, new HashMap<String, Object>());
            return configArr;
        }
        
        // something funky happened and we're trying to look up a different app
        throw new RuntimeException("Expected app: " + APP_NAME + ", but got: " + name);
    }
}