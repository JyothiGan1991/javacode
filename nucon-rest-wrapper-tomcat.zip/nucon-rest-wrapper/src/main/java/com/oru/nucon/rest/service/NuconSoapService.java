package com.oru.nucon.rest.service;

import com.oru.nucon.rest.dto.AccountRequest;
import com.oru.nucon.rest.dto.ElectricInfoDto;
import com.oru.nucon.rest.dto.LocateInNrgViewerRequest;
import com.oru.nucon.rest.dto.PremiseRequest;
import com.oru.nucon.rest.dto.SendToNrgRequest;
import com.oru.nucon.rest.dto.XYCoordinatesRequest;
import com.oru.nucon.rest.exception.SoapServiceException;
import com.oru.nucon.soap.generated.ElectricInfo;
import com.oru.nucon.soap.generated.NuconWS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class NuconSoapService {

    private static final Logger log = LoggerFactory.getLogger(NuconSoapService.class);

    private final NuconWS soapClient;

    public NuconSoapService(NuconWS soapClient) {
        this.soapClient = soapClient;
    }

    public ElectricInfoDto getElectricInfoByAccount(AccountRequest request) {
        log.debug("Calling SOAP getElectricInfoByAccount with account={}", request.getAccount());
        try {
            ElectricInfo info = soapClient.getElectricInfoByAccount(request.getAccount());
            return toDto(info);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call getElectricInfoByAccount: " + e.getMessage(), e);
        }
    }

    public ElectricInfoDto getElectricInfoByPremise(PremiseRequest request) {
        log.debug("Calling SOAP getElectricInfoByPremise with premise={}", request.getPremise());
        try {
            ElectricInfo info = soapClient.getElectricInfoByPremise(request.getPremise());
            return toDto(info);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call getElectricInfoByPremise: " + e.getMessage(), e);
        }
    }

    public ElectricInfoDto getElectricInfoByXYCoordinates(XYCoordinatesRequest request) {
        log.debug("Calling SOAP getElectricInfoByXYCoordinates with x={}, y={}", request.getX(), request.getY());
        try {
            ElectricInfo info = soapClient.getElectricInfoByXYCoordinates(request.getX(), request.getY());
            return toDto(info);
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call getElectricInfoByXYCoordinates: " + e.getMessage(), e);
        }
    }

    public void sendToNRG(SendToNrgRequest request) {
        log.debug("Calling SOAP sendToNRG with arg0={}, arg1={}, arg2={}",
                request.getArg0(), request.getArg1(), request.getArg2());
        try {
            Integer arg1 = request.getArg1();
            soapClient.sendToNRG(request.getArg0(), arg1, request.getArg2());
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call sendToNRG: " + e.getMessage(), e);
        }
    }

    public void locateInNRGViewer(LocateInNrgViewerRequest request) {
        log.debug("Calling SOAP locateInNRGViewer with arg0={}, arg1={}, arg2={}, arg3={}",
                request.getArg0(), request.getArg1(), request.getArg2(), request.getArg3());
        try {
            soapClient.locateInNRGViewer(
                    request.getArg0(),
                    request.getArg1(),
                    request.getArg2(),
                    request.getArg3());
        } catch (Exception e) {
            throw new SoapServiceException("Failed to call locateInNRGViewer: " + e.getMessage(), e);
        }
    }

    private ElectricInfoDto toDto(ElectricInfo info) {
        if (info == null) {
            return null;
        }
        ElectricInfoDto dto = new ElectricInfoDto();
        dto.setPartiality(info.getPartiality());
        dto.setCircuit(info.getCircuit());
        dto.setCode(info.getCode());
        dto.setHgridX(info.getHgridX());
        dto.setHgridY(info.getHgridY());
        dto.setInvolt(info.getInvolt());
        dto.setKva1(info.getKVA1());
        dto.setKva2(info.getKVA2());
        dto.setKva3(info.getKVA3());
        dto.setKyBa(info.getKyBa());
        dto.setKyPremNo(info.getKyPremNo());
        dto.setPhase(info.getPhase());
        dto.setPhase3(info.getPhase3());
        dto.setSegment(info.getSegment());
        dto.setService(info.getService());
        dto.setServpoleX(info.getServpoleX());
        dto.setServpoleY(info.getServpoleY());
        dto.setTranGridX(info.getTranGridX());
        dto.setTranGridY(info.getTranGridY());
        dto.setTransformer(info.getTransformer());
        dto.setTranstype(info.getTranstype());
        return dto;
    }
}
