package com.coned.jpa.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coned.model.User;
import com.coned.model.UserLogin;
import com.coned.model.Role;

@Repository
public interface UserLoginRepository extends JpaRepository<UserLogin, Long> {
	List<User> findByUsernameContaining(String username);
	Optional<User> findByUsername(String username);
}