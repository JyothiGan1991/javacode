package com.oru.rest.controller;

import com.oru.rest.dto.IsGasMainRequest;
import com.oru.rest.dto.VerifyPoleRequest;
import com.oru.rest.exception.GlobalExceptionHandler;
import com.oru.rest.security.TokenAuthFilter;
import com.oru.rest.service.poe.PoeSoapService;
import com.oru.soap.nucon.generated.NuconWS;
import com.oru.soap.poe.generated.POEWebServicesSEI;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PoeController.class)
@Import({GlobalExceptionHandler.class, TokenAuthFilter.class})
@TestPropertySource(properties = {"api.auth.enabled=true", "api.auth.token=test-token"})
class PoeControllerTest {

    private static final String AUTH = "Bearer test-token";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PoeSoapService poeSoapService;

    @MockBean
    private POEWebServicesSEI poeClient;

    @MockBean
    private NuconWS nuconClient;

    @Test
    void isGasMain_ok() throws Exception {
        when(poeSoapService.isGasMain(any(IsGasMainRequest.class))).thenReturn(true);
        mockMvc.perform(post("/api/v1/nrg/is-gas-main")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"radius\":10}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(true));
    }

    @Test
    void verifyPole_ok() throws Exception {
        when(poeSoapService.verifyPole(any(VerifyPoleRequest.class))).thenReturn(false);
        mockMvc.perform(get("/api/v1/nrg/verify-pole")
                        .header("Authorization", AUTH)
                        .param("x", "1").param("y", "2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.result").value(false));
    }

    @Test
    void missingAuth_401() throws Exception {
        mockMvc.perform(get("/api/v1/nrg/verify-pole").param("x", "1").param("y", "2"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }

    @Test
    void wrongToken_401() throws Exception {
        mockMvc.perform(get("/api/v1/nrg/verify-pole")
                        .header("Authorization", "Bearer wrong")
                        .param("x", "1").param("y", "2"))
                .andExpect(status().isUnauthorized());
    }
}
