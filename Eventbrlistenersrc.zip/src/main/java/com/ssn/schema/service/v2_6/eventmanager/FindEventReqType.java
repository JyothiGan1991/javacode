
package com.ssn.schema.service.v2_6.eventmanager;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.ssn.schema.service.v2_6.basictypes.CachedResultsType;


/**
 * <p>Java class for FindEventReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindEventReqType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}EventSearchParametersType"/>
 *           &lt;element name="CachedResults" type="{urn:com:ssn:schema:service:v2.6:BasicTypes.xsd}CachedResultsType"/>
 *         &lt;/choice>
 *         &lt;element name="GetPremiseDetails" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="NumberRows" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="SortMap" type="{urn:com:ssn:schema:service:v2.6:EventManager.xsd}NonGroupedSortMap" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindEventReqType", propOrder = {
    "searchParameters",
    "cachedResults",
    "getPremiseDetails",
    "numberRows",
    "sortMap"
})
public class FindEventReqType {

    @XmlElement(name = "SearchParameters")
    protected EventSearchParametersType searchParameters;
    @XmlElement(name = "CachedResults")
    protected CachedResultsType cachedResults;
    @XmlElement(name = "GetPremiseDetails")
    protected Boolean getPremiseDetails;
    @XmlElement(name = "NumberRows")
    protected int numberRows;
    @XmlElement(name = "SortMap")
    protected List<NonGroupedSortMap> sortMap;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link EventSearchParametersType }
     *     
     */
    public EventSearchParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link EventSearchParametersType }
     *     
     */
    public void setSearchParameters(EventSearchParametersType value) {
        this.searchParameters = value;
    }

    /**
     * Gets the value of the cachedResults property.
     * 
     * @return
     *     possible object is
     *     {@link CachedResultsType }
     *     
     */
    public CachedResultsType getCachedResults() {
        return cachedResults;
    }

    /**
     * Sets the value of the cachedResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link CachedResultsType }
     *     
     */
    public void setCachedResults(CachedResultsType value) {
        this.cachedResults = value;
    }

    /**
     * Gets the value of the getPremiseDetails property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetPremiseDetails() {
        return getPremiseDetails;
    }

    /**
     * Sets the value of the getPremiseDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetPremiseDetails(Boolean value) {
        this.getPremiseDetails = value;
    }

    /**
     * Gets the value of the numberRows property.
     * 
     */
    public int getNumberRows() {
        return numberRows;
    }

    /**
     * Sets the value of the numberRows property.
     * 
     */
    public void setNumberRows(int value) {
        this.numberRows = value;
    }

    /**
     * Gets the value of the sortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NonGroupedSortMap }
     * 
     * 
     */
    public List<NonGroupedSortMap> getSortMap() {
        if (sortMap == null) {
            sortMap = new ArrayList<NonGroupedSortMap>();
        }
        return this.sortMap;
    }

}
