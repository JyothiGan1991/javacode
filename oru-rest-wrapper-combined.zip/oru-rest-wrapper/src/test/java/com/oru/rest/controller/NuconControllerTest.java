package com.oru.rest.controller;

import com.oru.rest.dto.AccountRequest;
import com.oru.rest.dto.ElectricInfoDto;
import com.oru.rest.exception.GlobalExceptionHandler;
import com.oru.rest.security.TokenAuthFilter;
import com.oru.rest.service.nucon.NuconSoapService;
import com.oru.soap.nucon.generated.NuconWS;
import com.oru.soap.poe.generated.POEWebServicesSEI;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NuconController.class)
@Import({GlobalExceptionHandler.class, TokenAuthFilter.class})
@TestPropertySource(properties = {"api.auth.enabled=true", "api.auth.token=test-token"})
class NuconControllerTest {

    private static final String AUTH = "Bearer test-token";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NuconSoapService nuconSoapService;

    @MockBean
    private POEWebServicesSEI poeClient;

    @MockBean
    private NuconWS nuconClient;

    @Test
    void byAccount_ok() throws Exception {
        ElectricInfoDto dto = new ElectricInfoDto();
        dto.setCircuit("C1");
        when(nuconSoapService.getElectricInfoByAccount(any(AccountRequest.class))).thenReturn(dto);
        mockMvc.perform(post("/api/v1/nrg/electric-info/by-account")
                        .header("Authorization", AUTH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"account\":\"A1\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.circuit").value("C1"));
    }

    @Test
    void byAccount_get_ok() throws Exception {
        ElectricInfoDto dto = new ElectricInfoDto();
        dto.setTransformer("T1");
        when(nuconSoapService.getElectricInfoByAccount(any(AccountRequest.class))).thenReturn(dto);
        mockMvc.perform(get("/api/v1/nrg/electric-info/by-account")
                        .header("Authorization", AUTH)
                        .param("account", "A1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.transformer").value("T1"));
    }

    @Test
    void missingAuth_401() throws Exception {
        mockMvc.perform(get("/api/v1/nrg/electric-info/by-account").param("account", "x"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Authentication failed"));
    }
}
