package com.coned.ls.repository;

import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;

public interface UserManagementRepository {

	public ResponseEntity<Map<String, Object>> createUser(Map<String, Object> payload);
	public ResponseEntity<Map<String, Object>> updateUser(String username, Map<String, Object> payload);
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy);
	public List<Map<String, Object>> getUsers();
//	public ResponseEntity<Map<String, Object>> listLDAPUsers(String username);

}
