
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateRelayTypeReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateRelayTypeReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="RelayTypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *           &lt;element name="RelayTypeConfigName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateRelayTypeReq", propOrder = {
    "relayTypeConfigID",
    "relayTypeConfigName"
})
public class UpdateRelayTypeReq {

    @XmlElement(name = "RelayTypeConfigID")
    protected Long relayTypeConfigID;
    @XmlElement(name = "RelayTypeConfigName")
    protected String relayTypeConfigName;

    /**
     * Gets the value of the relayTypeConfigID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRelayTypeConfigID() {
        return relayTypeConfigID;
    }

    /**
     * Sets the value of the relayTypeConfigID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRelayTypeConfigID(Long value) {
        this.relayTypeConfigID = value;
    }

    /**
     * Gets the value of the relayTypeConfigName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelayTypeConfigName() {
        return relayTypeConfigName;
    }

    /**
     * Sets the value of the relayTypeConfigName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelayTypeConfigName(String value) {
        this.relayTypeConfigName = value;
    }

}
