
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceSortColumnName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeviceSortColumnName"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="MacID"/&gt;
 *     &lt;enumeration value="UtilDeviceID"/&gt;
 *     &lt;enumeration value="IPAddress"/&gt;
 *     &lt;enumeration value="UiqDeviceStateID"/&gt;
 *     &lt;enumeration value="UtlDeviceStateID"/&gt;
 *     &lt;enumeration value="Name"/&gt;
 *     &lt;enumeration value="SerialNumber"/&gt;
 *     &lt;enumeration value="DidType"/&gt;
 *     &lt;enumeration value="DidSubtype"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DeviceSortColumnName")
@XmlEnum
public enum DeviceSortColumnName {

    @XmlEnumValue("MacID")
    MAC_ID("MacID"),
    @XmlEnumValue("UtilDeviceID")
    UTIL_DEVICE_ID("UtilDeviceID"),
    @XmlEnumValue("IPAddress")
    IP_ADDRESS("IPAddress"),
    @XmlEnumValue("UiqDeviceStateID")
    UIQ_DEVICE_STATE_ID("UiqDeviceStateID"),
    @XmlEnumValue("UtlDeviceStateID")
    UTL_DEVICE_STATE_ID("UtlDeviceStateID"),
    @XmlEnumValue("Name")
    NAME("Name"),
    @XmlEnumValue("SerialNumber")
    SERIAL_NUMBER("SerialNumber"),
    @XmlEnumValue("DidType")
    DID_TYPE("DidType"),
    @XmlEnumValue("DidSubtype")
    DID_SUBTYPE("DidSubtype");
    private final String value;

    DeviceSortColumnName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeviceSortColumnName fromValue(String v) {
        for (DeviceSortColumnName c: DeviceSortColumnName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
