
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AlarmClearJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AlarmClearJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="ClearByDevices" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ClearByDevicesType"/&gt;
 *         &lt;element name="ClearByEventSearch" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ClearByEventSearchType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlarmClearJobType", propOrder = {
    "clearByDevices",
    "clearByEventSearch"
})
public class AlarmClearJobType {

    @XmlElement(name = "ClearByDevices")
    protected ClearByDevicesType clearByDevices;
    @XmlElement(name = "ClearByEventSearch")
    protected ClearByEventSearchType clearByEventSearch;

    /**
     * Gets the value of the clearByDevices property.
     * 
     * @return
     *     possible object is
     *     {@link ClearByDevicesType }
     *     
     */
    public ClearByDevicesType getClearByDevices() {
        return clearByDevices;
    }

    /**
     * Sets the value of the clearByDevices property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClearByDevicesType }
     *     
     */
    public void setClearByDevices(ClearByDevicesType value) {
        this.clearByDevices = value;
    }

    /**
     * Gets the value of the clearByEventSearch property.
     * 
     * @return
     *     possible object is
     *     {@link ClearByEventSearchType }
     *     
     */
    public ClearByEventSearchType getClearByEventSearch() {
        return clearByEventSearch;
    }

    /**
     * Sets the value of the clearByEventSearch property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClearByEventSearchType }
     *     
     */
    public void setClearByEventSearch(ClearByEventSearchType value) {
        this.clearByEventSearch = value;
    }

}
