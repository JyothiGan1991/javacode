package com.coned.ls.service;

import org.springframework.http.ResponseEntity;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;

/**
 * 
 * Interface for Meter Event Finalize Service class.
 *
 */
public interface MetersEventFinalizeService {
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeMeterEvent(final MeterEventFinalize meterEventFinalize, final String adid)throws MeterFinalizeException;
}
