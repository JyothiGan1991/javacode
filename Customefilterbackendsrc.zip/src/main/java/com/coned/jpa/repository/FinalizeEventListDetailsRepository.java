package com.coned.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coned.model.FinalizeEventListDetails;

@Repository
public interface FinalizeEventListDetailsRepository extends JpaRepository<FinalizeEventListDetails, Long> {
	/*
	 * List<FinalizeEventListDetails> findByUsernameContaining(String username);
	 * Optional<FinalizeEventListDetails> findByUsername(String username);
	 */
}