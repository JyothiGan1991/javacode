
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetDeviceReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetDeviceReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="MacID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *           &lt;element name="GwSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="CommonAttr" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttr" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Location" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Contact" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="LocationAddnlInfo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RouteUp" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RfStats" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RouteDown" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Children" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Details" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DeviceCapabilities" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="NetworkInfrastructureDevices" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetDeviceReqType", propOrder = {
    "macID",
    "gwSerialNumber",
    "commonAttr",
    "deviceAttr",
    "location",
    "contact",
    "locationAddnlInfo",
    "routeUp",
    "rfStats",
    "routeDown",
    "children",
    "details",
    "deviceCapabilities",
    "networkInfrastructureDevices"
})
public class GetDeviceReqType {

    @XmlElement(name = "MacID")
    protected String macID;
    @XmlElement(name = "GwSerialNumber")
    protected String gwSerialNumber;
    @XmlElement(name = "CommonAttr")
    protected Boolean commonAttr;
    @XmlElement(name = "DeviceAttr")
    protected Boolean deviceAttr;
    @XmlElement(name = "Location")
    protected Boolean location;
    @XmlElement(name = "Contact")
    protected Boolean contact;
    @XmlElement(name = "LocationAddnlInfo")
    protected Boolean locationAddnlInfo;
    @XmlElement(name = "RouteUp")
    protected Boolean routeUp;
    @XmlElement(name = "RfStats")
    protected Boolean rfStats;
    @XmlElement(name = "RouteDown")
    protected Boolean routeDown;
    @XmlElement(name = "Children")
    protected Boolean children;
    @XmlElement(name = "Details")
    protected Boolean details;
    @XmlElement(name = "DeviceCapabilities")
    protected Boolean deviceCapabilities;
    @XmlElement(name = "NetworkInfrastructureDevices")
    protected Boolean networkInfrastructureDevices;

    /**
     * Gets the value of the macID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMacID() {
        return macID;
    }

    /**
     * Sets the value of the macID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMacID(String value) {
        this.macID = value;
    }

    /**
     * Gets the value of the gwSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGwSerialNumber() {
        return gwSerialNumber;
    }

    /**
     * Sets the value of the gwSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGwSerialNumber(String value) {
        this.gwSerialNumber = value;
    }

    /**
     * Gets the value of the commonAttr property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCommonAttr() {
        return commonAttr;
    }

    /**
     * Sets the value of the commonAttr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCommonAttr(Boolean value) {
        this.commonAttr = value;
    }

    /**
     * Gets the value of the deviceAttr property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeviceAttr() {
        return deviceAttr;
    }

    /**
     * Sets the value of the deviceAttr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeviceAttr(Boolean value) {
        this.deviceAttr = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocation(Boolean value) {
        this.location = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setContact(Boolean value) {
        this.contact = value;
    }

    /**
     * Gets the value of the locationAddnlInfo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLocationAddnlInfo() {
        return locationAddnlInfo;
    }

    /**
     * Sets the value of the locationAddnlInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLocationAddnlInfo(Boolean value) {
        this.locationAddnlInfo = value;
    }

    /**
     * Gets the value of the routeUp property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRouteUp() {
        return routeUp;
    }

    /**
     * Sets the value of the routeUp property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRouteUp(Boolean value) {
        this.routeUp = value;
    }

    /**
     * Gets the value of the rfStats property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRfStats() {
        return rfStats;
    }

    /**
     * Sets the value of the rfStats property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRfStats(Boolean value) {
        this.rfStats = value;
    }

    /**
     * Gets the value of the routeDown property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRouteDown() {
        return routeDown;
    }

    /**
     * Sets the value of the routeDown property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRouteDown(Boolean value) {
        this.routeDown = value;
    }

    /**
     * Gets the value of the children property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isChildren() {
        return children;
    }

    /**
     * Sets the value of the children property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setChildren(Boolean value) {
        this.children = value;
    }

    /**
     * Gets the value of the details property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDetails() {
        return details;
    }

    /**
     * Sets the value of the details property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDetails(Boolean value) {
        this.details = value;
    }

    /**
     * Gets the value of the deviceCapabilities property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeviceCapabilities() {
        return deviceCapabilities;
    }

    /**
     * Sets the value of the deviceCapabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeviceCapabilities(Boolean value) {
        this.deviceCapabilities = value;
    }

    /**
     * Gets the value of the networkInfrastructureDevices property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNetworkInfrastructureDevices() {
        return networkInfrastructureDevices;
    }

    /**
     * Sets the value of the networkInfrastructureDevices property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNetworkInfrastructureDevices(Boolean value) {
        this.networkInfrastructureDevices = value;
    }

}
