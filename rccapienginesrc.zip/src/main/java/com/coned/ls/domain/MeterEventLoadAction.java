package com.coned.ls.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MeterEventLoadAction implements Comparable<MeterEventLoadAction>{

	private Long meterEventLoadId;		
	private String borough;
	private String eventName;
	private Date actionTimeStamp;
	private String operatorAdID;
	private int eventStatus;
	private String meterNumber;
	private String meterStatus;
	private String cmdStatus;
	private String reqStatus;

	
	public MeterEventLoadAction(){
	}
	
	public MeterEventLoadAction(long meterEventLoadId){
		this.meterEventLoadId = meterEventLoadId;
	}
	
	public MeterEventLoadAction(long meterEventLoadId, String borough,
			String eventName, Date actionTimeStamp, String operatorAdID,
			int eventStatus) {
		super();
		this.meterEventLoadId = meterEventLoadId;
		this.borough = borough;
		this.eventName = eventName;
		this.actionTimeStamp = actionTimeStamp;
		this.operatorAdID = operatorAdID;
		this.eventStatus = eventStatus;
	}

	
	public MeterEventLoadAction(long meterEventLoadId, String borough,
			String eventName, Date actionTimeStamp, String operatorAdID) {
		super();
		this.meterEventLoadId = meterEventLoadId;
		this.borough = borough;
		this.eventName = eventName;
		this.actionTimeStamp = actionTimeStamp;
		this.operatorAdID = operatorAdID;
	}
	
	public MeterEventLoadAction(long meterEventLoadId, String borough,
			String eventName) {
		super();
		this.meterEventLoadId = meterEventLoadId;
		this.borough = borough;
		this.eventName = eventName;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Date getActionTimeStamp() {
		return actionTimeStamp;
	}

	public void setActionTimeStamp(Date actionTimeStamp) {
		this.actionTimeStamp = actionTimeStamp;
	}

	public String getOperatorAdID() {
		return operatorAdID;
	}

	public void setOperatorAdID(String operatorAdID) {
		this.operatorAdID = operatorAdID;
	}

	

	public int getEventStatus() {
		return eventStatus;
	}

	public void setEventStatus(int eventStatus) {
		this.eventStatus = eventStatus;
	}

	@Override
	public boolean equals(Object anObject) {
		if (!(anObject instanceof MeterEventLoadAction)) {
            return false;
        }
		MeterEventLoadAction otherMember = (MeterEventLoadAction)anObject;
        return otherMember.getMeterEventLoadId().equals(getMeterEventLoadId());
	}

	@Override
	public int hashCode() {
		return this.meterEventLoadId.hashCode();
	}


	public String getMeterNumber() {
		return meterNumber;
	}


	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	@Override
	public int compareTo(MeterEventLoadAction meterEvent) {
		System.out.println("inside compareTo");
		return (int) (this.meterEventLoadId - meterEvent.meterEventLoadId);
	}
	
	public List<MeterEventLoadAction> convertSubEventToMeterEvent(List<String> meterIds) {
		
		List<MeterEventLoadAction> meterEventLoadActions = new ArrayList<MeterEventLoadAction>();
		for(String meterId : meterIds){
			meterEventLoadActions.add(new MeterEventLoadAction(Long.parseLong(meterId)));
		}
	//	System.out.println("Meter to be excluded : "+meterEventLoadActions.toString());
		return meterEventLoadActions;
	}

	public Long getMeterEventLoadId() {
		return meterEventLoadId;
	}

	public void setMeterEventLoadId(Long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}

	public String getMeterStatus() {
		return meterStatus;
	}

	public void setMeterStatus(String meterStatus) {
		this.meterStatus = meterStatus;
	}

	public String getCmdStatus() {
		return cmdStatus;
	}

	public void setCmdStatus(String cmdStatus) {
		this.cmdStatus = cmdStatus;
	}

	public String getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	@Override
	public String toString() {
		return "MeterEventLoadAction [meterEventLoadId=" + meterEventLoadId + "]";
	}
	
}
