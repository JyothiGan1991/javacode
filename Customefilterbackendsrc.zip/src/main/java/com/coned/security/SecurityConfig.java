package com.coned.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger logger =
            LoggerFactory.getLogger(SecurityConfig.class);

    /*
    @Value("${aocc.http.auth.tokenName}")
    private String authHeaderName;

    @Value("${aocc.http.auth.tokenValue}")
    private String authHeaderValue;
    */

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        logger.debug(" -- Start configure() -- ");

        http
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth ->
                auth.requestMatchers("/").permitAll()
                    .anyRequest().authenticated())
            .csrf(csrf -> csrf.disable());

        logger.debug(" -- End configure() -- ");

        return http.build();
    }
}