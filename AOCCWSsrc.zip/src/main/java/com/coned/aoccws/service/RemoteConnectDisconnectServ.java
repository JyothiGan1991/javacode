package com.coned.aoccws.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coned.aoccws.beans.AoccRequest;
import com.coned.aoccws.beans.AoccResponse;
import com.coned.aoccws.dao.AMMDao;
import com.coned.aoccws.error.AMMException;

@Service
public class RemoteConnectDisconnectServ {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	protected AMMDao dao;

	public Object getVersion() {
		try {
			InputStream input = getClass().getResourceAsStream("/version.properties");
			if (input == null) {
				logger.info("Unable to find /META-INF/maven/com.oru/AOCCWS/pom.properties");
				return "Unable to find /META-INF/maven/com.oru/AOCCWS/pom.properties";
			} else {
				// load a properties file from class path, inside static method	
				Properties prop = new Properties();
				prop.load(input);
				logger.info("" + prop);
				return prop;
			}
		} catch (IOException e) {
			// logger.error("Failed to get the project version; ", e);
			return "Failed to get the project version";
		}
	}

	public AoccResponse saveRequest(AoccRequest req) throws AMMException {	
		try {
			if(req.getEventType().equalsIgnoreCase("D")){
				dao.saveRequestToNewDisconnectProcess(req);
			}
			if(req.getEventType().equalsIgnoreCase("C")){
				dao.saveRequestToNewConnectProcess(req);
			}
		} catch (Exception e) {
			logger.error("Error saving the disconnect request to new process; ", e);			
		}
		try {
			return dao.saveAoccRequest(req);
		} catch (AMMException e) {
			logger.error("Error saving the request; ", e.getMessage());			
			dao.saveError(req);
			throw new AMMException(""+e.getMessage());
		}
		
	}
}
