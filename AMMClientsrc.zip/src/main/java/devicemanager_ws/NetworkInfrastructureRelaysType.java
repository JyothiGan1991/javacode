
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkInfrastructureRelaysType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkInfrastructureRelaysType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Relay" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}NetworkInfrastructureRelayType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInfrastructureRelaysType", propOrder = {
    "relay"
})
public class NetworkInfrastructureRelaysType {

    @XmlElement(name = "Relay", required = true)
    protected List<NetworkInfrastructureRelayType> relay;

    /**
     * Gets the value of the relay property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relay property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelay().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkInfrastructureRelayType }
     * 
     * 
     */
    public List<NetworkInfrastructureRelayType> getRelay() {
        if (relay == null) {
            relay = new ArrayList<NetworkInfrastructureRelayType>();
        }
        return this.relay;
    }

}
