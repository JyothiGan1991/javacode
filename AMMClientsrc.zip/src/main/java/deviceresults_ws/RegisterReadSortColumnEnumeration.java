
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegisterReadSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RegisterReadSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="GatewaySerialNumber"/&gt;
 *     &lt;enumeration value="GatewayName"/&gt;
 *     &lt;enumeration value="GatewayCollectedTime"/&gt;
 *     &lt;enumeration value="ReadTime"/&gt;
 *     &lt;enumeration value="Season"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RegisterReadSortColumnEnumeration")
@XmlEnum
public enum RegisterReadSortColumnEnumeration {

    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("GatewaySerialNumber")
    GATEWAY_SERIAL_NUMBER("GatewaySerialNumber"),
    @XmlEnumValue("GatewayName")
    GATEWAY_NAME("GatewayName"),
    @XmlEnumValue("GatewayCollectedTime")
    GATEWAY_COLLECTED_TIME("GatewayCollectedTime"),
    @XmlEnumValue("ReadTime")
    READ_TIME("ReadTime"),
    @XmlEnumValue("Season")
    SEASON("Season");
    private final String value;

    RegisterReadSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RegisterReadSortColumnEnumeration fromValue(String v) {
        for (RegisterReadSortColumnEnumeration c: RegisterReadSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
