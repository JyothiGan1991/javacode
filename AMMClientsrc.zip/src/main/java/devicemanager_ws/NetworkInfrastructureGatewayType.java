
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkInfrastructureGatewayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkInfrastructureGatewayType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommonAttributes" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetDeviceType"/&gt;
 *         &lt;element name="Gateway" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetGatewayType"/&gt;
 *         &lt;element name="Alarms" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}AlarmsType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInfrastructureGatewayType", propOrder = {
    "commonAttributes",
    "gateway",
    "alarms"
})
public class NetworkInfrastructureGatewayType {

    @XmlElement(name = "CommonAttributes", required = true)
    protected GetDeviceType commonAttributes;
    @XmlElement(name = "Gateway", required = true)
    protected GetGatewayType gateway;
    @XmlElement(name = "Alarms")
    protected AlarmsType alarms;

    /**
     * Gets the value of the commonAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link GetDeviceType }
     *     
     */
    public GetDeviceType getCommonAttributes() {
        return commonAttributes;
    }

    /**
     * Sets the value of the commonAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetDeviceType }
     *     
     */
    public void setCommonAttributes(GetDeviceType value) {
        this.commonAttributes = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link GetGatewayType }
     *     
     */
    public GetGatewayType getGateway() {
        return gateway;
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetGatewayType }
     *     
     */
    public void setGateway(GetGatewayType value) {
        this.gateway = value;
    }

    /**
     * Gets the value of the alarms property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmsType }
     *     
     */
    public AlarmsType getAlarms() {
        return alarms;
    }

    /**
     * Sets the value of the alarms property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmsType }
     *     
     */
    public void setAlarms(AlarmsType value) {
        this.alarms = value;
    }

}
