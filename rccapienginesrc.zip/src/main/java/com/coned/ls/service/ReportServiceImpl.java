package com.coned.ls.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.coned.ls.repository.ReportRepository;

@Service("reportService")
public class ReportServiceImpl implements ReportService {
	@Autowired
	private ReportRepository reportRepository;

	@Override
	public ResponseEntity<List<Map<String, Object>>> getEvents(String report_name){
		return ResponseEntity.ok().body(reportRepository.getEvents(report_name));
	} 
	public ResponseEntity<List<Map<String, Object>>> getCWRData(@RequestBody Map<String, Object> payload){
		return ResponseEntity.ok().body(reportRepository.getCWRData(payload));
	}
	public ResponseEntity<List<Map<String, Object>>> getCDRData(@RequestBody Map<String, Object> payload){
		return ResponseEntity.ok().body(reportRepository.getCDRData(payload));
	}
	/*
	public ResponseEntity<List<Map<String, Object>>> getCRRData(@RequestBody Map<String, Object> payload){
		return ResponseEntity.ok().body(reportRepository.getCRRData(payload));
	}
	public ResponseEntity<Map<String, Object>> getCERData(@RequestBody Map<String, Object> payload){
		return ResponseEntity.ok().body(reportRepository.getCERData(payload));
	} */
	
	public ResponseEntity<List<Map<String, Object>>> getCRRData(@RequestBody Map<String, Object> payload){
		String event_name = (String) payload.get("eventName");
		String boro_muni = (String) payload.get("boroMuni");
		String sub_event_name = (String) payload.get("subEventName");
		return ResponseEntity.ok().body(reportRepository.getCRRData(event_name,boro_muni,sub_event_name));
	}
	public ResponseEntity<Map<String, Object>> getCERData(@RequestBody Map<String, Object> payload){
		String event_name = (String) payload.get("eventName");
		String boro_muni = (String) payload.get("boroMuni");
		return ResponseEntity.ok().body(reportRepository.getCERData(event_name,boro_muni));
	}
	
	public ResponseEntity<Map<String, Object>> getCMRData(@RequestBody Map<String, Object> payload){
		String event_name = (String) payload.get("eventName");
		String boro_muni = (String) payload.get("boroMuni");
		return ResponseEntity.ok().body(reportRepository.getCMRData(event_name,boro_muni));
	}

}
