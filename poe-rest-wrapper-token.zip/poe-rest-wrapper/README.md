# POE REST Wrapper API (Java 8 / WAR for Tomcat)

Spring Boot 2.7 REST API that wraps the POE SOAP Web Services defined in `POEWebServices.wsdl`.

**Target:** Java 8, packaged as **WAR** for deployment on external Apache Tomcat.

## Features

- REST endpoints that internally invoke the corresponding SOAP operations
- Configurable SOAP endpoint URL
- Request validation
- Global exception handling
- Unit tests with mocked SOAP client
- Maven project importable in Eclipse
- Produces a deployable WAR (`poe-rest-wrapper.war`)


## API Authentication

All `/api/**` endpoints require a Bearer token.

Configure in `application.yml`:

```yaml
api:
  auth:
    enabled: true
    token: change-me-poe-secret-token
```

Example request:

```bash
curl -X POST http://localhost:9090/api/v1/poe/is-gas-main \
  -H "Authorization: Bearer change-me-poe-secret-token" \
  -H "Content-Type: application/json" \
  -d '{"premise":"123 Main St","radius":50}'
```

Missing or invalid token returns **HTTP 401**:

```json
{
  "timestamp": "...",
  "status": 401,
  "error": "Unauthorized",
  "message": "Authentication failed",
  "path": "/api/v1/poe/..."
}
```

Set `api.auth.enabled: false` to disable authentication (not recommended for production).

## SOAP Operations Wrapped

| SOAP Operation   | REST Endpoint (POST & GET)          | Request fields                          | Response      |
|------------------|-------------------------------------|-----------------------------------------|---------------|
| `isGasMain`      | `/api/v1/poe/is-gas-main`           | `premise` (optional), `radius` (int)    | `{ "result": true/false }` |
| `verifyPole`     | `/api/v1/poe/verify-pole`           | `x` (int), `y` (int)                    | `{ "result": true/false }` |
| `incidentCount`  | `/api/v1/poe/incident-count`        | `startDate`, `startTime`, `endDate`, `endTime` (all optional strings) | `{ "result": <int> }` |

## Requirements

- JDK 8+ (project is compiled with source/target 1.8)
- Maven 3.6+
- Apache Tomcat 8.5 / 9.x (for WAR deployment)

## Build

```bash
mvn clean package
```

This produces:

- `target/poe-rest-wrapper.war`  ← deploy this to Tomcat

## Deploy to Tomcat

1. Copy `target/poe-rest-wrapper.war` into Tomcat's `webapps/` directory.
2. Start/restart Tomcat.
3. Application context path will be `/poe-rest-wrapper` by default (based on WAR name).

   Example base URL: `http://localhost:8080/poe-rest-wrapper`

4. Optional: rename WAR to `ROOT.war` to deploy at root context.

### Override SOAP endpoint on Tomcat

Create or edit:

`TOMCAT_HOME/conf/Catalina/localhost/poe-rest-wrapper.xml`

or set system property / environment, or use `application.yml` packaged in the WAR, or external config:

```bash
# Example: set in setenv.sh or catalina options
-Dpoe.soap.endpoint-url=http://your-soap-host:8080/poeWebServices/services/POEWebServicesPort
```

Or place an external `application.yml` / `application.properties` in a location on the classpath that Tomcat can see.

## Run locally (embedded Tomcat for development)

Even though packaging is WAR, you can still run with embedded Tomcat:

```bash
mvn spring-boot:run
```

Default port: **9090**

## Configuration

`src/main/resources/application.yml`:

```yaml
server:
  port: 9090

poe:
  soap:
    endpoint-url: http://localhost:8080/poeWebServices/services/POEWebServicesPort
    connect-timeout-ms: 5000
    read-timeout-ms: 10000
```

## Example Requests

Assuming deployed at context `/poe-rest-wrapper` on Tomcat port 8080:

### isGasMain (POST)

```bash
curl -X POST http://localhost:8080/poe-rest-wrapper/api/v1/poe/is-gas-main \
  -H "Content-Type: application/json" \
  -d '{"premise":"123 Main St","radius":50}'
```

### verifyPole (POST)

```bash
curl -X POST http://localhost:8080/poe-rest-wrapper/api/v1/poe/verify-pole \
  -H "Content-Type: application/json" \
  -d '{"x":100,"y":200}'
```

### incidentCount (POST)

```bash
curl -X POST http://localhost:8080/poe-rest-wrapper/api/v1/poe/incident-count \
  -H "Content-Type: application/json" \
  -d '{"startDate":"2024-01-01","startTime":"00:00:00","endDate":"2024-12-31","endTime":"23:59:59"}'
```

## Import into Eclipse

1. File → Import → Existing Maven Projects
2. Select the `poe-rest-wrapper` folder
3. Ensure a Java 8 (or higher) JRE is configured
4. Maven → Update Project if needed
5. CXF code generation runs on `mvn generate-sources` / `mvn compile`

## Project Structure

```
poe-rest-wrapper/
├── pom.xml
├── README.md
├── src/main/java/com/oru/poe/rest/
│   ├── PoeRestWrapperApplication.java   (extends SpringBootServletInitializer)
│   ├── config/SoapClientConfig.java
│   ├── controller/PoeController.java
│   ├── dto/ ...
│   ├── exception/ ...
│   └── service/PoeSoapService.java
├── src/main/resources/
│   ├── application.yml
│   └── wsdl/POEWebServices.wsdl
└── src/test/java/com/oru/poe/rest/
    ├── controller/PoeControllerTest.java
    └── service/PoeSoapServiceTest.java
```

## Notes

- SOAP client classes are generated at build time from the WSDL into `target/generated-sources/cxf`.
- `spring-boot-starter-tomcat` is scoped as `provided` so the WAR does not embed Tomcat jars (uses the server's Tomcat).
- If the SOAP service is unavailable, REST endpoints return HTTP 502 with an error body.
