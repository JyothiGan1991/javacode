package com.oru.service;

import java.util.List;
import java.util.Map;

public interface CircuitService {
    List<Map<String, String>> getCircuitData(int duration);
}
