
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AuxiliarySwitchControlParametersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuxiliarySwitchControlParametersType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DurationInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RandomizeStart" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RandomizeStartTimeInMinutes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuxiliarySwitchControlParametersType", propOrder = {
    "durationInMinutes",
    "randomizeStart",
    "randomizeStartTimeInMinutes"
})
public class AuxiliarySwitchControlParametersType {

    @XmlElement(name = "DurationInMinutes")
    protected Integer durationInMinutes;
    @XmlElement(name = "RandomizeStart")
    protected Boolean randomizeStart;
    @XmlElement(name = "RandomizeStartTimeInMinutes")
    protected Integer randomizeStartTimeInMinutes;

    /**
     * Gets the value of the durationInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDurationInMinutes() {
        return durationInMinutes;
    }

    /**
     * Sets the value of the durationInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDurationInMinutes(Integer value) {
        this.durationInMinutes = value;
    }

    /**
     * Gets the value of the randomizeStart property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRandomizeStart() {
        return randomizeStart;
    }

    /**
     * Sets the value of the randomizeStart property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRandomizeStart(Boolean value) {
        this.randomizeStart = value;
    }

    /**
     * Gets the value of the randomizeStartTimeInMinutes property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRandomizeStartTimeInMinutes() {
        return randomizeStartTimeInMinutes;
    }

    /**
     * Sets the value of the randomizeStartTimeInMinutes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRandomizeStartTimeInMinutes(Integer value) {
        this.randomizeStartTimeInMinutes = value;
    }

}
