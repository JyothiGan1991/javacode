
package deviceresults_ws;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegisterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegisterType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Summation" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="SummationUOM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SummationUOMDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CumulativeDemand" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="ContinuousCumulativeDemand" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="MaxDemands" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}MaxDemandsType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DemandUOM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DemandUOMDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}ChannelStatusType" minOccurs="0"/&gt;
 *         &lt;element name="CumulativeDemandIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ContinuousCumulativeDemandIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SummationIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Coincidence" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}CoincidenceType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Number" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegisterType", propOrder = {
    "summation",
    "summationUOM",
    "summationUOMDescription",
    "cumulativeDemand",
    "continuousCumulativeDemand",
    "maxDemands",
    "demandUOM",
    "demandUOMDescription",
    "registerStatus",
    "cumulativeDemandIEEExportChannelID",
    "continuousCumulativeDemandIEEExportChannelID",
    "summationIEEExportChannelID",
    "coincidence"
})
public class RegisterType {

    @XmlElement(name = "Summation")
    protected BigDecimal summation;
    @XmlElement(name = "SummationUOM")
    protected String summationUOM;
    @XmlElement(name = "SummationUOMDescription")
    protected String summationUOMDescription;
    @XmlElement(name = "CumulativeDemand")
    protected BigDecimal cumulativeDemand;
    @XmlElement(name = "ContinuousCumulativeDemand")
    protected BigDecimal continuousCumulativeDemand;
    @XmlElement(name = "MaxDemands")
    protected List<MaxDemandsType> maxDemands;
    @XmlElement(name = "DemandUOM")
    protected String demandUOM;
    @XmlElement(name = "DemandUOMDescription")
    protected String demandUOMDescription;
    @XmlElement(name = "RegisterStatus")
    @XmlSchemaType(name = "string")
    protected ChannelStatusType registerStatus;
    @XmlElement(name = "CumulativeDemandIEEExportChannelID")
    protected String cumulativeDemandIEEExportChannelID;
    @XmlElement(name = "ContinuousCumulativeDemandIEEExportChannelID")
    protected String continuousCumulativeDemandIEEExportChannelID;
    @XmlElement(name = "SummationIEEExportChannelID")
    protected String summationIEEExportChannelID;
    @XmlElement(name = "Coincidence")
    protected List<CoincidenceType> coincidence;
    @XmlAttribute(name = "Number", required = true)
    protected int number;

    /**
     * Gets the value of the summation property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSummation() {
        return summation;
    }

    /**
     * Sets the value of the summation property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSummation(BigDecimal value) {
        this.summation = value;
    }

    /**
     * Gets the value of the summationUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSummationUOM() {
        return summationUOM;
    }

    /**
     * Sets the value of the summationUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSummationUOM(String value) {
        this.summationUOM = value;
    }

    /**
     * Gets the value of the summationUOMDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSummationUOMDescription() {
        return summationUOMDescription;
    }

    /**
     * Sets the value of the summationUOMDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSummationUOMDescription(String value) {
        this.summationUOMDescription = value;
    }

    /**
     * Gets the value of the cumulativeDemand property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCumulativeDemand() {
        return cumulativeDemand;
    }

    /**
     * Sets the value of the cumulativeDemand property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCumulativeDemand(BigDecimal value) {
        this.cumulativeDemand = value;
    }

    /**
     * Gets the value of the continuousCumulativeDemand property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getContinuousCumulativeDemand() {
        return continuousCumulativeDemand;
    }

    /**
     * Sets the value of the continuousCumulativeDemand property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setContinuousCumulativeDemand(BigDecimal value) {
        this.continuousCumulativeDemand = value;
    }

    /**
     * Gets the value of the maxDemands property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the maxDemands property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMaxDemands().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MaxDemandsType }
     * 
     * 
     */
    public List<MaxDemandsType> getMaxDemands() {
        if (maxDemands == null) {
            maxDemands = new ArrayList<MaxDemandsType>();
        }
        return this.maxDemands;
    }

    /**
     * Gets the value of the demandUOM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDemandUOM() {
        return demandUOM;
    }

    /**
     * Sets the value of the demandUOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDemandUOM(String value) {
        this.demandUOM = value;
    }

    /**
     * Gets the value of the demandUOMDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDemandUOMDescription() {
        return demandUOMDescription;
    }

    /**
     * Sets the value of the demandUOMDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDemandUOMDescription(String value) {
        this.demandUOMDescription = value;
    }

    /**
     * Gets the value of the registerStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ChannelStatusType }
     *     
     */
    public ChannelStatusType getRegisterStatus() {
        return registerStatus;
    }

    /**
     * Sets the value of the registerStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChannelStatusType }
     *     
     */
    public void setRegisterStatus(ChannelStatusType value) {
        this.registerStatus = value;
    }

    /**
     * Gets the value of the cumulativeDemandIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCumulativeDemandIEEExportChannelID() {
        return cumulativeDemandIEEExportChannelID;
    }

    /**
     * Sets the value of the cumulativeDemandIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCumulativeDemandIEEExportChannelID(String value) {
        this.cumulativeDemandIEEExportChannelID = value;
    }

    /**
     * Gets the value of the continuousCumulativeDemandIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContinuousCumulativeDemandIEEExportChannelID() {
        return continuousCumulativeDemandIEEExportChannelID;
    }

    /**
     * Sets the value of the continuousCumulativeDemandIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContinuousCumulativeDemandIEEExportChannelID(String value) {
        this.continuousCumulativeDemandIEEExportChannelID = value;
    }

    /**
     * Gets the value of the summationIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSummationIEEExportChannelID() {
        return summationIEEExportChannelID;
    }

    /**
     * Sets the value of the summationIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSummationIEEExportChannelID(String value) {
        this.summationIEEExportChannelID = value;
    }

    /**
     * Gets the value of the coincidence property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coincidence property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoincidence().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoincidenceType }
     * 
     * 
     */
    public List<CoincidenceType> getCoincidence() {
        if (coincidence == null) {
            coincidence = new ArrayList<CoincidenceType>();
        }
        return this.coincidence;
    }

    /**
     * Gets the value of the number property.
     * 
     */
    public int getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     */
    public void setNumber(int value) {
        this.number = value;
    }

}
