
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UIQDeviceStateTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="UIQDeviceStateTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UIQ_DEVICE_STATE_NEW"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INSTALLED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_DISCOVERED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INITIALIZING"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INIT_FAILED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INITIALIZED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_ACTIVE"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_INACTIVE"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_UNREACHABLE"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_REMOVED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_MAINTENANCE"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_OPTIMIZE"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_RETIRED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_DISCONNECTED"/>
 *     &lt;enumeration value="UIQ_DEVICE_STATE_SVC_DISCONECT"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "UIQDeviceStateTypeEnum")
@XmlEnum
public enum UIQDeviceStateTypeEnum {

    UIQ_DEVICE_STATE_NEW("UIQ_DEVICE_STATE_NEW"),
    UIQ_DEVICE_STATE_INSTALLED("UIQ_DEVICE_STATE_INSTALLED"),
    UIQ_DEVICE_STATE_DISCOVERED("UIQ_DEVICE_STATE_DISCOVERED"),
    UIQ_DEVICE_STATE_INITIALIZING("UIQ_DEVICE_STATE_INITIALIZING"),
    UIQ_DEVICE_STATE_INIT_FAILED("UIQ_DEVICE_STATE_INIT_FAILED"),
    UIQ_DEVICE_STATE_INITIALIZED("UIQ_DEVICE_STATE_INITIALIZED"),
    UIQ_DEVICE_STATE_ACTIVE("UIQ_DEVICE_STATE_ACTIVE"),
    UIQ_DEVICE_STATE_INACTIVE("UIQ_DEVICE_STATE_INACTIVE"),
    UIQ_DEVICE_STATE_UNREACHABLE("UIQ_DEVICE_STATE_UNREACHABLE"),
    UIQ_DEVICE_STATE_REMOVED("UIQ_DEVICE_STATE_REMOVED"),
    UIQ_DEVICE_STATE_MAINTENANCE("UIQ_DEVICE_STATE_MAINTENANCE"),
    UIQ_DEVICE_STATE_OPTIMIZE("UIQ_DEVICE_STATE_OPTIMIZE"),
    UIQ_DEVICE_STATE_RETIRED("UIQ_DEVICE_STATE_RETIRED"),
    UIQ_DEVICE_STATE_DISCONNECTED("UIQ_DEVICE_STATE_DISCONNECTED"),
    UIQ_DEVICE_STATE_SVC_DISCONECT("UIQ_DEVICE_STATE_SVC_DISCONECT"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    UIQDeviceStateTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static UIQDeviceStateTypeEnum fromValue(String v) {
        for (UIQDeviceStateTypeEnum c: UIQDeviceStateTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
