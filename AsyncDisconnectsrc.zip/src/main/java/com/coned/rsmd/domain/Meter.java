package com.coned.rsmd.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Meter {
	private BigDecimal id;
	private BigDecimal requestId;
	private String meterNumber, macAddress, boro, eventName;
	private Long jobId;
	private Timestamp requestTime;
	private Timestamp disconnectTime;

	public Meter(BigDecimal id, BigDecimal requestId, String eventName, String meterNumber, String boro,
			String macAddress) {
		this.id = id;
		this.requestId = requestId;
		this.eventName = eventName;
		this.meterNumber = meterNumber;
		this.boro = boro;
		this.macAddress = macAddress;
	}

	public Meter(BigDecimal id, BigDecimal requestId, String eventName, String meterNumber, String boro) {
		this.id = id;
		this.requestId = requestId;
		this.eventName = eventName;
		this.meterNumber = meterNumber;
		this.boro = boro;
	}

	public BigDecimal getRequestId() {
		return this.requestId;
	}

	public void setRequestId(BigDecimal requestId) {
		this.requestId = requestId;
	}

	public String getMeterNumber() {
		return this.meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public String getMacAddress() {
		return this.macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getBoro() {
		return this.boro;
	}

	public void setBoro(String boro) {
		this.boro = boro;
	}

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public Long getJobId() {
		return this.jobId;
	}

	public void setJobId(long id) {
		this.jobId = id;
	}

	public Timestamp getRequestTime() {
		return this.requestTime;
	}

	public void setRequestTime(Timestamp requestTime) {
		this.requestTime = requestTime;
	}

	public Timestamp getDisconnectTime() {
		return disconnectTime;
	}

	public void setDisconnectTime(Timestamp disconnectTime) {
		this.disconnectTime = disconnectTime;
	}

	@Override
	public String toString() {
		return "Meter [id=" + id + ", requestId=" + requestId + ", meterNumber=" + meterNumber + ", macAddress="
				+ macAddress + ", boro=" + boro + ", eventName=" + eventName + ", jobId=" + jobId + ", requestTime="
				+ requestTime + ", disconnectTime=" + disconnectTime + "]";
	}

}
