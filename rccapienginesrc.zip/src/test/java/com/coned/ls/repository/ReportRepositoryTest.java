package com.coned.ls.repository;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.tree.RowMapper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito.Then;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.exception.MeterEventConnectException;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { ReportRepository.class })
@AutoConfigureMockMvc

public class ReportRepositoryTest {
	@Autowired
	private WebApplicationContext wac;

	@MockBean
	private ReportRepository reportRepository;

	@InjectMocks
	private JdbcReportRepository jdbcReportRepository;

	private MockMvc mockMvc;

	@Mock
	protected JdbcTemplate oracleJdbcTemplate;

	@Mock
	protected JdbcTemplate sqlServerJdbcTemplate;

	@Mock
	protected JdbcTemplate starJdbcTemplate;

	@Mock
	protected JdbcTemplate oracleCommonJdbcTemplate;

	@Test
	@Before
	public void setup() {
		ReflectionTestUtils.setField(jdbcReportRepository, "oracleJdbcTemplate", oracleJdbcTemplate);
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

	}

	@Test
	public void getEvents() throws Exception {
		String report_name = "crr";
		List<Map<String, Object>> result = jdbcReportRepository.getEvents(report_name);
		Assert.assertNotNull(result);
	}
	@Test
	public void getCDRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		List<Map<String, Object>> result1 = jdbcReportRepository.getCDRData(payload);
//		ResponseEntity<List<Map<String, Object>>> actual = (ResponseEntity<List<Map<String, Object>>>) result1;
		Assert.assertNotNull("test");
	}	@Test
	public void getCRRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		String event_name = (String) payload.get("eventName");
		String boro_muni = (String) payload.get("boroMuni");
		String sub_event_name = (String) payload.get("sub_event_name");
		
		List<Map<String, Object>> result1 = jdbcReportRepository.getCRRData(event_name,boro_muni,sub_event_name);
//		ResponseEntity<List<Map<String, Object>>> actual = (ResponseEntity<List<Map<String, Object>>>) result1;
		Assert.assertNotNull("test");
	}	@Test
	public void getCWRData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
        List<Map<String, Object>> result1 = jdbcReportRepository.getCWRData(payload);
//		ResponseEntity<List<Map<String, Object>>> actual = (ResponseEntity<List<Map<String, Object>>>) result1;
		Assert.assertNotNull("test");
	}	
	@Test
	public void getCERData() {
		Map<String, Object> expected = new HashMap<String, Object>();
		ResponseEntity<Map<String, Object>> result = new ResponseEntity<Map<String, Object>>(expected, new HttpHeaders(),HttpStatus.OK);
		Map<String, Object> payload = new HashMap<String, Object>();
		
		String adid = "ADID";
		payload.put("adid", adid);
		
		String event_name = (String) payload.get("eventName");
		String boro_muni = (String) payload.get("boroMuni");
        Map<String, Object> result1 = jdbcReportRepository.getCERData(event_name,boro_muni);
		ResponseEntity<Map<String, Object>> actual = (ResponseEntity<Map<String, Object>>) result1;
		Assert.assertNotNull("test");
	}
}
