package com.coned.ls.exception;

public class MeterValidateException extends Exception {

	private static final long serialVersionUID = -470180507998010368L;

	public MeterValidateException() {
		super();
	}

	public MeterValidateException(final String message) {
		super(message);
	}
	public MeterValidateException(String message,Throwable cause) {
	   super(message,cause);
	}
}
