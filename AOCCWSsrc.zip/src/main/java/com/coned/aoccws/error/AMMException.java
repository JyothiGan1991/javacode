package com.coned.aoccws.error;

public class AMMException extends Exception{

	private static final long serialVersionUID = 1L;
	
	private String exceptionMessage;
	private String errorCode;
	
	public AMMException(){
		super();
	}
	/**
	 * @param exceptionMessage the exception message
	 */
	public AMMException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
}
