
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MonthEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MonthEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MONTH_JANUARY"/>
 *     &lt;enumeration value="MONTH_FEBRUARY"/>
 *     &lt;enumeration value="MONTH_MARCH"/>
 *     &lt;enumeration value="MONTH_APRIL"/>
 *     &lt;enumeration value="MONTH_MAY"/>
 *     &lt;enumeration value="MONTH_JUNE"/>
 *     &lt;enumeration value="MONTH_JULY"/>
 *     &lt;enumeration value="MONTH_AUGUST"/>
 *     &lt;enumeration value="MONTH_SEPTEMBER"/>
 *     &lt;enumeration value="MONTH_OCTOBER"/>
 *     &lt;enumeration value="MONTH_NOVEMBER"/>
 *     &lt;enumeration value="MONTH_DECEMBER"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MonthEnumeration")
@XmlEnum
public enum MonthEnumeration {

    MONTH_JANUARY("MONTH_JANUARY"),
    MONTH_FEBRUARY("MONTH_FEBRUARY"),
    MONTH_MARCH("MONTH_MARCH"),
    MONTH_APRIL("MONTH_APRIL"),
    MONTH_MAY("MONTH_MAY"),
    MONTH_JUNE("MONTH_JUNE"),
    MONTH_JULY("MONTH_JULY"),
    MONTH_AUGUST("MONTH_AUGUST"),
    MONTH_SEPTEMBER("MONTH_SEPTEMBER"),
    MONTH_OCTOBER("MONTH_OCTOBER"),
    MONTH_NOVEMBER("MONTH_NOVEMBER"),
    MONTH_DECEMBER("MONTH_DECEMBER"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    MonthEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MonthEnumeration fromValue(String v) {
        for (MonthEnumeration c: MonthEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
