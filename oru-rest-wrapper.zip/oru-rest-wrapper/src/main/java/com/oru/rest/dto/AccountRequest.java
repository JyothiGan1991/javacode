package com.oru.rest.dto;

public class AccountRequest {
    private String account;
    public AccountRequest() {}
    public AccountRequest(String account) { this.account = account; }
    public String getAccount() { return account; }
    public void setAccount(String account) { this.account = account; }
}
