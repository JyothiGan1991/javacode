package com.coned.ls.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.RCCApplication;
import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.service.MeterEventFinalizeService;
import com.coned.ls.service.MeterEventValidateService;
import com.coned.ls.service.OpenEventService;
import com.fasterxml.jackson.databind.ObjectMapper;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = RCCApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

public class RCCDisconnectControllerTest {
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Mock
	private MeterEventValidateService meterEventValidateService = new MeterEventValidateService();
	
	@Mock
	private MeterEventFinalizeService meterEventFinalizeService = new MeterEventFinalizeService();
	
	@Mock
	private OpenEventService openEventService;
	
	@InjectMocks
	RCCDisconnectController rccDisconnectController;
	
	List<MeterEventLoad> meterEventLoads= new ArrayList<>();
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
	
	private static final String baseURL = "http://localhost:7001/rcc/v07/lsa-rcc-disconnect";
	@Test
	@Before
	public void setup() throws Exception{
		rccDisconnectController = new RCCDisconnectController();
		System.out.println("@Before annotation method is being called ....");
		
		ReflectionTestUtils.setField(rccDisconnectController, "openEventService", openEventService);
		ReflectionTestUtils.setField(rccDisconnectController, "meterEventValidateService", meterEventValidateService);
		ReflectionTestUtils.setField(rccDisconnectController, "meterEventFinalizeService", meterEventFinalizeService);

		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		String borough = "B";
		MeterEventLoad meterEventLoad = new MeterEventLoad();
		meterEventLoad.setBorough("B");
		meterEventLoad.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoad.setDemand("8.20");
		meterEventLoad.setFeeder("3220");
		meterEventLoad.setBuildingNumber("320");
		meterEventLoad.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoad.setCustomerZipCode("11120");
		meterEventLoad.setMeterNumber("9477420");
		meterEventLoad.setAccountNumber("11111222220000");
		meterEventLoad.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoad);
		
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
	}
	
	@Test
	public void getBoroughName() throws Exception {
		List<String> expected = new ArrayList<String>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected,new HttpHeaders(), HttpStatus.OK);
		
		String fields = "boro";
		Mockito.when(openEventService.getBoroughAndEventName(fields)).thenReturn(result);
		
		ResponseEntity<List<String>> actual =  rccDisconnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidBoroughName() throws Exception {

		List<String> expected = new ArrayList<>();
		expected.add("B");
		expected.add("M");
		expected.add("Q");
		expected.add("X");
		expected.add("S");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expected, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());

	}

	@Test
	public void getEventName() throws Exception {
		List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);
		
		String fields = "event_name";
		Mockito.when(openEventService.getBoroughAndEventName(fields)).thenReturn(result);
		
		ResponseEntity<List<String>> actual =  rccDisconnectController.getBoroughAndEventName(fields);
		Assert.assertEquals(HttpStatus.OK, actual.getStatusCode());
	
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void getInvalidEventName() throws Exception {

		List<String> expectedEventNameList = new ArrayList<String>();
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");

		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList, new HttpHeaders(),
				HttpStatus.OK);

		String fields = "Test";
		Mockito.when(openEventService.getBoroughAndEventNameForConnect(fields)).thenReturn(result);
		ResponseEntity<List<String>> actual = rccDisconnectController.getBoroughAndEventName(fields);

		Assert.assertEquals(result.getStatusCode(), actual.getStatusCode());
	}

	
	@Test
	public void getEventNameByBorough() throws Exception{
        List<String> expectedEventNameList  = new ArrayList<String>();
		
		expectedEventNameList.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		expectedEventNameList.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		expectedEventNameList.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		expectedEventNameList.add("OceanParkway.01.10/28/20-01:17:18.AUTO");
		expectedEventNameList.add("BoroughHall.01.10/27/20-12:14:17.ZHUT");
		
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(expectedEventNameList,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		Mockito.when(openEventService.getOpenEvent(borough)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getEventNameByBorough(borough);
		Assert.assertEquals(result.getBody().size(), actual.getBody().size());
	}
	
	
	@Test
	public void getValidateMeter() throws Exception{
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		
		meterValidateResponseMapper.setPageNumber(20);
		meterValidateResponseMapper.setPageSize(1);
		meterValidateResponseMapper.setTotalRecord(2);
		meterValidateResponseMapper.setRecordOffsetRange("abcd");
		//meterValidateResponseMapper.setInsertTime(date);
		meterValidateResponseMapper.setBorough("M");
		meterValidateResponseMapper.setEventName("QRST");
		meterValidateResponseMapper.setNetwork("GHIJ");
		meterValidateResponseMapper.setRemainingRow(3);
		meterValidateResponseMapper.setTotalValidRecord(2);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setMessage("abcdef");
		ResponseEntity<MeterValidateResponseMapper> result = new ResponseEntity<MeterValidateResponseMapper>(meterValidateResponseMapper,new HttpHeaders(), HttpStatus.OK);

		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		int startRowIndex = 1;
		int batchSize = 50;
		String filterList = "Flatbush";
		String sortList = "ZHUT";
		String adid = "XYZ";
		
		MeterOpenEvent meterOpenEvent = new MeterOpenEvent();
		meterOpenEvent.setBorough("M");
		meterOpenEvent.setEventName("QRST");
		meterOpenEvent.setStartRowIndex(1);
		meterOpenEvent.setBatchSize(500);
		
		Mockito.when(meterEventValidateService.getValidateMeters(meterOpenEvent)).thenReturn(result);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.getValidateMeter(request, meterOpenEvent);
		Assert.assertNotNull(actual); 
		
	}
	@Test
	public void finalizeValidateMeters() throws Exception{
		ResponseEntity<String> message = new ResponseEntity<String>("success", new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid= "XYZ";
		Mockito.when(meterEventFinalizeService.finalizeValidateMeter(meterEventFinalize,adid)).thenReturn(message);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "XYZ");
		ResponseEntity<String> actual =  rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals("success", actual.getBody());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void InvalidfinalizeValidateMeters() throws Exception{
		ResponseEntity<String> response = new ResponseEntity<String>(new HttpHeaders(), HttpStatus.OK);
		MeterEventFinalize meterEventFinalize = new MeterEventFinalize();
		String adid= "XYZ";
		Mockito.when(meterEventFinalizeService.finalizeValidateMeter(meterEventFinalize,adid)).thenReturn(response);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(null, null);
		ResponseEntity<String> actual =  rccDisconnectController.finalizeValidateMeters(request,meterEventFinalize);
		Assert.assertEquals(response.getBody(), actual.getBody());
	}
	
	
	@Test
	public void searchMeter() throws Exception {
		
        Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		
		meterValidateResponseMapper.setPageNumber(20);
		meterValidateResponseMapper.setPageSize(1);
		meterValidateResponseMapper.setTotalRecord(2);
		meterValidateResponseMapper.setRecordOffsetRange("abcd");
		//meterValidateResponseMapper.setInsertTime(date);
		meterValidateResponseMapper.setBorough("M");
		meterValidateResponseMapper.setEventName("QRST");
		meterValidateResponseMapper.setNetwork("GHIJ");
		meterValidateResponseMapper.setRemainingRow(3);
		meterValidateResponseMapper.setTotalValidRecord(2);
		meterValidateResponseMapper.setValidResponse(true);
		meterValidateResponseMapper.setMessage("abcdef");

		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough("M");
		meterSearch.setEvent("XYZ");
		Mockito.when(meterEventValidateService.searchMeter(meterSearch)).thenReturn(meterValidateResponseMapper);
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.searchMeter(meterSearch);
		Assert.assertEquals("M", actual.getBody().getBorough());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void InvalidsearchMeter() throws Exception {
		
        Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YY-MM-DD");
		sdf.format(date);
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		MeterSearch meterSearch = new MeterSearch();
		meterSearch.setBorough(null);
		meterSearch.setEvent(null);
		Mockito.when(meterEventValidateService.searchMeter(meterSearch)).thenReturn(meterValidateResponseMapper);
		ResponseEntity<MeterValidateResponseMapper> actual =  rccDisconnectController.searchMeter(meterSearch);
		Assert.assertEquals(meterValidateResponseMapper, actual);
	}
	
	@Test
	public void getFieldValuesByBoroughAndEventName() throws Exception {
		List<String> fieldvalues  = new ArrayList<String>();
		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String fieldName = "MeterNumber";
		ResponseEntity<List<String>> result = new ResponseEntity<List<String>>(fieldvalues,new HttpHeaders(), HttpStatus.OK);
        Mockito.when(meterEventValidateService.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName)).thenReturn(result);
		ResponseEntity<List<String>> actual =  rccDisconnectController.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		Assert.assertEquals(result.getBody(), actual.getBody());
	}
	@Test
	public void getLockedStatusByBoroughAndEventName() throws Exception {
		MeterLockedStatusResponseMapper mockdata  = new MeterLockedStatusResponseMapper();
		mockdata.setMessage("message");
		mockdata.setStatus(true);
		//HttpServletRequest request = null ;
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("adid", "BUDIDHAK");
		String borough = "M";
		String eventName= "Flatbush.01.10/27/20-12:05:45.ZHUT";
		String adid = "BUDIDHAK";
        Mockito.when(meterEventValidateService.getLockedStatusByBoroughAndEventName(borough, eventName, adid)).thenReturn(mockdata);
        MeterLockedStatusResponseMapper actual =  rccDisconnectController.getLockedStatusByBoroughAndEventName(request,borough, eventName);
		Assert.assertEquals(null, null);
	}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "BUDIDHAK");
		String adid = "BUDIDHAK";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventValidateService).unlockEvents(adid);
		rccDisconnectController.unlockEvents(request);
	}
	
	@Test(expected =IllegalArgumentException.class)
	public void unlockEvents2(){
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("adid", "");
		String adid = "";
		Mockito.doThrow(new IllegalArgumentException()).when(meterEventValidateService).unlockEvents(adid);
		rccDisconnectController.unlockEvents(request);
	}
}
