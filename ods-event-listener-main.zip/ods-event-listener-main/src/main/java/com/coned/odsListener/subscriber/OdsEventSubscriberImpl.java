package com.coned.odsListener.subscriber;

import java.io.StringReader;
import java.util.concurrent.TimeUnit;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import com.coned.odsListener.handler.MessageHandler;
import com.tibco.ods.EndDeviceEventsEventMessageType;


@Service
public class OdsEventSubscriberImpl implements OdsEventSubscriber {
	private static Logger logger = LoggerFactory.getLogger(OdsEventSubscriberImpl.class);
	
	@Autowired
	@Qualifier("odsUnmarshaller")
	protected Unmarshaller odsUnmarshaller;
	
	@Autowired
	@Qualifier("multispeakMarshaller")
	protected Marshaller multispeakMarshaller;
	
	@Autowired
	protected MessageHandler messageHandler;

	@Override
	@JmsListener(destination = "${tibco.ssn.ods.queue}", containerFactory = "listenerConnFactory")
	public void processMessage(Object eventNotification) throws JMSException {
		logger.info("### Message received in queue ###");
		long startTime = System.nanoTime();
		try {
			final TextMessage messageFromQueue = (TextMessage) eventNotification;
			logger.info(messageFromQueue.getText());
			
			StringReader reader = new StringReader(messageFromQueue.getText());
			JAXBElement <EndDeviceEventsEventMessageType> events = (JAXBElement<EndDeviceEventsEventMessageType>) odsUnmarshaller.unmarshal(reader);
			
			messageHandler.handleODSEvent(events);
		} catch (Exception e) {
			logger.error("" + e);
			e.printStackTrace();
		} finally {
			long endTime = System.nanoTime();
			long durationInMillis = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
			logger.info("Time taken to process the message in milliseconds is: " + durationInMillis + "\n");
		}
	}

}
