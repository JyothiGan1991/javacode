package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.rest.RESTActionExecutor;

/**
 * 
 * Service class for RCC Disconnect.
 *
 */
@Component
public class MeterEventValidateService {
	
	RESTActionExecutor restActionExecutor = new  RESTActionExecutor();
	
	/*
	 * Method to read list of meters created for the event.
	 * 
	 * @param  meterOpenEvent MeterOpenEvent
     * @return 				  ResponseEntity<MeterValidateResponseMapper>
	 */	
	public ResponseEntity<MeterValidateResponseMapper> getValidateMeters(final MeterOpenEvent meterOpenEvent) {
		return restActionExecutor.getValidateMeter(meterOpenEvent);
	}
	
	/*
	 * Method to read list of invalid meters for given borough and event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 			     MeterValidateResponseMapper 
	 */	
	public MeterValidateResponseMapper getInvalidateMeters(final String borough, final String eventName, final int startRowIndex,final int batchSize) {
		return restActionExecutor.getInvalidateMeter(borough, eventName, startRowIndex,batchSize);
	}
	
	/*
	 * Method to search for a list of disconnected meters.
	 * 
	 * @param  meterSearch MeterSearch
     * @return 			   MeterValidateResponseMapper 
	 */	
	public MeterValidateResponseMapper searchMeter(final MeterSearch meterSearch) {
		return restActionExecutor.searchMeter(meterSearch);
	}
	
	/*
	 * Method to read list of values for given field.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  fieldName String
     * @return 			 ResponseEntity<List<String>>
	 */	
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName){
		if(null!=borough && null!=eventName && null!=fieldName){
			return restActionExecutor.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		}else{
			throw new IllegalArgumentException("Invalid arguments are found in the request.");
		}
	}		
	
	/*
	 * Method to check event is locked by some other user.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  adid		 String
     * @return 			 MeterLockedStatusResponseMapper 
	 */	
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(final String borough, final String eventName, final String adid) {
		return restActionExecutor.getLockedStatusByBoroughAndEventName(borough, eventName, adid);
	}
	
	/*
	 * Method to unlock the event.
	 * 
	 * @param  adid	String
     * @return 		void 
	 */
	public void unlockEvents(final String adid) {
		restActionExecutor.unlockEvents(adid);
	}
}