
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JobSubTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="JobSubTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_SEARCH_CACHE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CLEAR_EXPORT_DATA"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_JOB_UPDATE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SEC_LOG_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_TASK_STATS_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_POP_DAILY_RSR_SUM"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_GAP_FILL"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INTERVAL_RECOVERY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_NETWORK_STATUS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_METER_SEC_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ARCHIVE_JOBS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_BILL_CYCLE_SUMMARY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_UNFILL_GAP_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_NET_BACKBONE_HST"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REGISTER_RECOVERY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CMD_QUEUE_RETRY"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RSND_FAIL_NP_RES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ITVL_SUCCESS_PROC"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_HEALTH_FLAG_EVENT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_DAY_START_PROC"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_NEW_ROUTES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_INS_ROUTES"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_ROUTES_LAST"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SCHED_SUM_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_EVENT_LOG_GAP_FILL"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SET_UNREACHABLE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RESET_UNREACHABLE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ALARM_COUNTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_UNSCHED_METER_CNT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_TABLE_3_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ERR_HIST_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_CARDINALITY_STATS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ALL_OUTAGES_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_INFER_OUTAGES_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_LATENCY_RPT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_DEV_STATE_SNAPSHOT"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_GEN_READ_SUCCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RESOLVE_EVENTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DEVICE_CACHE"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_ADD_PARTITIONS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_REMOVE_PARTITIONS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_NETSTATUS_COUNTS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_RMT_PROV_PROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_DB"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ADVANCED_METER"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_EVENT"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DEVICE"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_ARB_METER_CMD"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_POWER_QUALITY"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_GENERIC"/&gt;
 *     &lt;enumeration value="JOB_OP_EXPORT_DMD_RESET_FAILS"/&gt;
 *     &lt;enumeration value="JOB_OP_LP_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_SECLOG_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_CONS_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_CURR_RST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_REGISTER_SELF_RST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_DL"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_REG"/&gt;
 *     &lt;enumeration value="JOB_OP_NCC_EL"/&gt;
 *     &lt;enumeration value="JOB_OP_IMU_PROXY_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NEW_DATA_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_METER_EL_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_ERR_HIST_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_NIC_NEW_DATA_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_GW_NET"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_APP"/&gt;
 *     &lt;enumeration value="JOB_OP_PING_DEV_NET"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ARM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GET_STATUS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_RESET_TS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_PPM"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_PP_BALNCE"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DLP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_DLP_PROPS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_LOCK"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L1"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISCONNECT_L2"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DEACT_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_ESCC"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_SET_ESCC_PROP"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_BOOST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_GROUP_CONFIG"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_BROADCAST"/&gt;
 *     &lt;enumeration value="JOB_OP_PROV_SET_IGNORE_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_CLEAR_TAMPER"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_ENABLE_DS"/&gt;
 *     &lt;enumeration value="JOB_OP_PROVISION_DISABLE_DS"/&gt;
 *     &lt;enumeration value="JOB_OP_BRDG_NTFCTN_LINK_STATE"/&gt;
 *     &lt;enumeration value="JOB_OP_ZB_METER_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_ITRON_IMU_PROXY_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_DEV_PROG_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_DEMAND_RESET"/&gt;
 *     &lt;enumeration value="JOB_OP_GENERIC_METER_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_IMU_PREPROCESS"/&gt;
 *     &lt;enumeration value="JOB_OP_REG_PREV_SESN_READ"/&gt;
 *     &lt;enumeration value="JOB_OP_CRON_SYNC_SEGMENT_DB"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "JobSubTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd")
@XmlEnum
public enum JobSubTypeEnumeration {

    JOB_OP_CRON_CLEAR_SEARCH_CACHE("JOB_OP_CRON_CLEAR_SEARCH_CACHE"),
    JOB_OP_CRON_CLEAR_EXPORT_DATA("JOB_OP_CRON_CLEAR_EXPORT_DATA"),
    JOB_OP_CRON_JOB_UPDATE("JOB_OP_CRON_JOB_UPDATE"),
    JOB_OP_CRON_INTERVAL_PROCESS("JOB_OP_CRON_INTERVAL_PROCESS"),
    JOB_OP_CRON_REGISTER_PROCESS("JOB_OP_CRON_REGISTER_PROCESS"),
    JOB_OP_CRON_SEC_LOG_PROCESS("JOB_OP_CRON_SEC_LOG_PROCESS"),
    JOB_OP_CRON_TASK_STATS_PROCESS("JOB_OP_CRON_TASK_STATS_PROCESS"),
    JOB_OP_CRON_POP_DAILY_RSR_SUM("JOB_OP_CRON_POP_DAILY_RSR_SUM"),
    JOB_OP_CRON_INTERVAL_GAP_FILL("JOB_OP_CRON_INTERVAL_GAP_FILL"),
    JOB_OP_CRON_INTERVAL_RECOVERY("JOB_OP_CRON_INTERVAL_RECOVERY"),
    JOB_OP_CRON_GEN_NETWORK_STATUS("JOB_OP_CRON_GEN_NETWORK_STATUS"),
    JOB_OP_CRON_GEN_METER_SEC_RPT("JOB_OP_CRON_GEN_METER_SEC_RPT"),
    JOB_OP_CRON_ARCHIVE_JOBS("JOB_OP_CRON_ARCHIVE_JOBS"),
    JOB_OP_CRON_BILL_CYCLE_SUMMARY("JOB_OP_CRON_BILL_CYCLE_SUMMARY"),
    JOB_OP_CRON_UNFILL_GAP_PROCESS("JOB_OP_CRON_UNFILL_GAP_PROCESS"),
    JOB_OP_CRON_NET_BACKBONE_HST("JOB_OP_CRON_NET_BACKBONE_HST"),
    JOB_OP_CRON_REGISTER_RECOVERY("JOB_OP_CRON_REGISTER_RECOVERY"),
    JOB_OP_CRON_CMD_QUEUE_RETRY("JOB_OP_CRON_CMD_QUEUE_RETRY"),
    JOB_OP_CRON_RSND_FAIL_NP_RES("JOB_OP_CRON_RSND_FAIL_NP_RES"),
    JOB_OP_CRON_ITVL_SUCCESS_PROC("JOB_OP_CRON_ITVL_SUCCESS_PROC"),
    JOB_OP_CRON_HEALTH_FLAG_EVENT("JOB_OP_CRON_HEALTH_FLAG_EVENT"),
    JOB_OP_CRON_DAY_START_PROC("JOB_OP_CRON_DAY_START_PROC"),
    JOB_OP_CRON_SYNC_NEW_ROUTES("JOB_OP_CRON_SYNC_NEW_ROUTES"),
    JOB_OP_CRON_SYNC_INS_ROUTES("JOB_OP_CRON_SYNC_INS_ROUTES"),
    JOB_OP_CRON_SYNC_ROUTES_LAST("JOB_OP_CRON_SYNC_ROUTES_LAST"),
    JOB_OP_CRON_SCHED_SUM_PROCESS("JOB_OP_CRON_SCHED_SUM_PROCESS"),
    JOB_OP_CRON_EVENT_LOG_GAP_FILL("JOB_OP_CRON_EVENT_LOG_GAP_FILL"),
    JOB_OP_CRON_SET_UNREACHABLE("JOB_OP_CRON_SET_UNREACHABLE"),
    JOB_OP_CRON_RESET_UNREACHABLE("JOB_OP_CRON_RESET_UNREACHABLE"),
    JOB_OP_CRON_ALARM_COUNTS("JOB_OP_CRON_ALARM_COUNTS"),
    JOB_OP_CRON_UNSCHED_METER_CNT("JOB_OP_CRON_UNSCHED_METER_CNT"),
    JOB_OP_CRON_TABLE_3_PROCESS("JOB_OP_CRON_TABLE_3_PROCESS"),
    JOB_OP_CRON_ERR_HIST_PROCESS("JOB_OP_CRON_ERR_HIST_PROCESS"),
    JOB_OP_CRON_CARDINALITY_STATS("JOB_OP_CRON_CARDINALITY_STATS"),
    JOB_OP_CRON_ALL_OUTAGES_RPT("JOB_OP_CRON_ALL_OUTAGES_RPT"),
    JOB_OP_CRON_INFER_OUTAGES_RPT("JOB_OP_CRON_INFER_OUTAGES_RPT"),
    JOB_OP_CRON_GEN_LATENCY_RPT("JOB_OP_CRON_GEN_LATENCY_RPT"),
    JOB_OP_CRON_DEV_STATE_SNAPSHOT("JOB_OP_CRON_DEV_STATE_SNAPSHOT"),
    JOB_OP_CRON_GEN_READ_SUCCESS("JOB_OP_CRON_GEN_READ_SUCCESS"),
    JOB_OP_CRON_RESOLVE_EVENTS("JOB_OP_CRON_RESOLVE_EVENTS"),
    JOB_OP_CRON_SYNC_DEVICE_CACHE("JOB_OP_CRON_SYNC_DEVICE_CACHE"),
    JOB_OP_CRON_ADD_PARTITIONS("JOB_OP_CRON_ADD_PARTITIONS"),
    JOB_OP_CRON_REMOVE_PARTITIONS("JOB_OP_CRON_REMOVE_PARTITIONS"),
    JOB_OP_CRON_NETSTATUS_COUNTS("JOB_OP_CRON_NETSTATUS_COUNTS"),
    JOB_OP_CRON_RMT_PROV_PROCESS("JOB_OP_CRON_RMT_PROV_PROCESS"),
    JOB_OP_CRON_SYNC_DB("JOB_OP_CRON_SYNC_DB"),
    JOB_OP_EXPORT_ADVANCED_METER("JOB_OP_EXPORT_ADVANCED_METER"),
    JOB_OP_EXPORT_EVENT("JOB_OP_EXPORT_EVENT"),
    JOB_OP_EXPORT_DEVICE("JOB_OP_EXPORT_DEVICE"),
    JOB_OP_EXPORT_ARB_METER_CMD("JOB_OP_EXPORT_ARB_METER_CMD"),
    JOB_OP_EXPORT_POWER_QUALITY("JOB_OP_EXPORT_POWER_QUALITY"),
    JOB_OP_EXPORT_GENERIC("JOB_OP_EXPORT_GENERIC"),
    JOB_OP_EXPORT_DMD_RESET_FAILS("JOB_OP_EXPORT_DMD_RESET_FAILS"),
    JOB_OP_LP_READ("JOB_OP_LP_READ"),
    JOB_OP_REGISTER_CURR_READ("JOB_OP_REGISTER_CURR_READ"),
    JOB_OP_SECLOG_READ("JOB_OP_SECLOG_READ"),
    JOB_OP_CONS_READ("JOB_OP_CONS_READ"),
    JOB_OP_REGISTER_CURR_RST_READ("JOB_OP_REGISTER_CURR_RST_READ"),
    JOB_OP_REGISTER_SELF_READ("JOB_OP_REGISTER_SELF_READ"),
    JOB_OP_REGISTER_SELF_RST_READ("JOB_OP_REGISTER_SELF_RST_READ"),
    JOB_OP_NCC_DL("JOB_OP_NCC_DL"),
    JOB_OP_NCC_REG("JOB_OP_NCC_REG"),
    JOB_OP_NCC_EL("JOB_OP_NCC_EL"),
    JOB_OP_IMU_PROXY_READ("JOB_OP_IMU_PROXY_READ"),
    JOB_OP_NEW_DATA_READ("JOB_OP_NEW_DATA_READ"),
    JOB_OP_METER_EL_READ("JOB_OP_METER_EL_READ"),
    JOB_OP_ERR_HIST_READ("JOB_OP_ERR_HIST_READ"),
    JOB_OP_NIC_NEW_DATA_READ("JOB_OP_NIC_NEW_DATA_READ"),
    JOB_OP_PING_GW_APP("JOB_OP_PING_GW_APP"),
    JOB_OP_PING_GW_NET("JOB_OP_PING_GW_NET"),
    JOB_OP_PING_DEV_APP("JOB_OP_PING_DEV_APP"),
    JOB_OP_PING_DEV_NET("JOB_OP_PING_DEV_NET"),
    JOB_OP_PROVISION_ARM("JOB_OP_PROVISION_ARM"),
    JOB_OP_PROVISION_CONNECT("JOB_OP_PROVISION_CONNECT"),
    JOB_OP_PROVISION_DISCONNECT("JOB_OP_PROVISION_DISCONNECT"),
    JOB_OP_PROVISION_GET_STATUS("JOB_OP_PROVISION_GET_STATUS"),
    JOB_OP_PROVISION_RESET_TS("JOB_OP_PROVISION_RESET_TS"),
    JOB_OP_PROVISION_ENABLE_PPM("JOB_OP_PROVISION_ENABLE_PPM"),
    JOB_OP_PROVISION_DISABLE_PPM("JOB_OP_PROVISION_DISABLE_PPM"),
    JOB_OP_PROVISION_SET_PP_BALNCE("JOB_OP_PROVISION_SET_PP_BALNCE"),
    JOB_OP_PROVISION_ENABLE_DLP("JOB_OP_PROVISION_ENABLE_DLP"),
    JOB_OP_PROVISION_DISABLE_DLP("JOB_OP_PROVISION_DISABLE_DLP"),
    JOB_OP_PROVISION_SET_DLP_PROPS("JOB_OP_PROVISION_SET_DLP_PROPS"),
    JOB_OP_PROVISION_ENABLE_LOCK("JOB_OP_PROVISION_ENABLE_LOCK"),
    JOB_OP_PROVISION_DISABLE_LOCK("JOB_OP_PROVISION_DISABLE_LOCK"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L1")
    JOB_OP_PROVISION_CONNECT_L_1("JOB_OP_PROVISION_CONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L1")
    JOB_OP_PROVISION_DISCONNECT_L_1("JOB_OP_PROVISION_DISCONNECT_L1"),
    @XmlEnumValue("JOB_OP_PROVISION_CONNECT_L2")
    JOB_OP_PROVISION_CONNECT_L_2("JOB_OP_PROVISION_CONNECT_L2"),
    @XmlEnumValue("JOB_OP_PROVISION_DISCONNECT_L2")
    JOB_OP_PROVISION_DISCONNECT_L_2("JOB_OP_PROVISION_DISCONNECT_L2"),
    JOB_OP_PROVISION_ACT_ESCC("JOB_OP_PROVISION_ACT_ESCC"),
    JOB_OP_PROVISION_DEACT_ESCC("JOB_OP_PROVISION_DEACT_ESCC"),
    JOB_OP_PROVISION_ENABLE_ESCC("JOB_OP_PROVISION_ENABLE_ESCC"),
    JOB_OP_PROVISION_DISABLE_ESCC("JOB_OP_PROVISION_DISABLE_ESCC"),
    JOB_OP_PROVISION_SET_ESCC_PROP("JOB_OP_PROVISION_SET_ESCC_PROP"),
    JOB_OP_PROVISION_ENABLE_BOOST("JOB_OP_PROVISION_ENABLE_BOOST"),
    JOB_OP_PROVISION_DISABLE_BOOST("JOB_OP_PROVISION_DISABLE_BOOST"),
    JOB_OP_PROVISION_GROUP_CONFIG("JOB_OP_PROVISION_GROUP_CONFIG"),
    JOB_OP_PROVISION_BROADCAST("JOB_OP_PROVISION_BROADCAST"),
    JOB_OP_PROV_SET_IGNORE_TAMPER("JOB_OP_PROV_SET_IGNORE_TAMPER"),
    JOB_OP_PROVISION_CLEAR_TAMPER("JOB_OP_PROVISION_CLEAR_TAMPER"),
    JOB_OP_PROVISION_ENABLE_DS("JOB_OP_PROVISION_ENABLE_DS"),
    JOB_OP_PROVISION_DISABLE_DS("JOB_OP_PROVISION_DISABLE_DS"),
    JOB_OP_BRDG_NTFCTN_LINK_STATE("JOB_OP_BRDG_NTFCTN_LINK_STATE"),
    JOB_OP_ZB_METER_READ("JOB_OP_ZB_METER_READ"),
    JOB_OP_ITRON_IMU_PROXY_READ("JOB_OP_ITRON_IMU_PROXY_READ"),
    JOB_OP_DEV_PROG_READ("JOB_OP_DEV_PROG_READ"),
    JOB_OP_DEMAND_RESET("JOB_OP_DEMAND_RESET"),
    JOB_OP_GENERIC_METER_READ("JOB_OP_GENERIC_METER_READ"),
    JOB_OP_CRON_IMU_PREPROCESS("JOB_OP_CRON_IMU_PREPROCESS"),
    JOB_OP_REG_PREV_SESN_READ("JOB_OP_REG_PREV_SESN_READ"),
    JOB_OP_CRON_SYNC_SEGMENT_DB("JOB_OP_CRON_SYNC_SEGMENT_DB"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    JobSubTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JobSubTypeEnumeration fromValue(String v) {
        for (JobSubTypeEnumeration c: JobSubTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
