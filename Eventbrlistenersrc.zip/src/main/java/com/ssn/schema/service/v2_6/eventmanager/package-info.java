@javax.xml.bind.annotation.XmlSchema(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ssn.schema.service.v2_6.eventmanager;
