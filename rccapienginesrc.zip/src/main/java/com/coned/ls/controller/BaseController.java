package com.coned.ls.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * Base Controller for API Engine.
 *
 */
@RestController
@RequestMapping("/")
public class BaseController {

	@RequestMapping("/")
	public ModelAndView index(){
		return new ModelAndView("welcome");
	}
	public boolean isEmptyOrNull(String string){
		return (isNull(string.trim()) || isEmpty(string.trim()));
	}
	
	public boolean isNull(final String string){
		return (null==string);
	}
	
	public boolean isEmpty(final String string){
		return (string.trim().length()<=0);
	}
}
