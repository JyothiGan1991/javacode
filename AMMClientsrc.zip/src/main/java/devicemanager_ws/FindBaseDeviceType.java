
package devicemanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindBaseDeviceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindBaseDeviceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DidType" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}DeviceTypeType" minOccurs="0"/&gt;
 *         &lt;element name="DidSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UiqDeviceState" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UiqDeviceStateTypeWithOp" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UtilDeviceState" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}UtilDeviceStateType" minOccurs="0"/&gt;
 *         &lt;element name="UtilNmState" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}UtilNetworkStateType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CatalogNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NetworkID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RFChannel" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BackboneDevice" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Suspect" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SuspectReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RetiredTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="InsertTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="UpdateTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="InstallTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="RemoveTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="LastCommTime" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}TimeRangeType" minOccurs="0"/&gt;
 *         &lt;element name="LastReadByCROC" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DeviceConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindDeviceConfigType" minOccurs="0"/&gt;
 *         &lt;element name="BatteryInfo" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}FindBatteryInfoType" minOccurs="0"/&gt;
 *         &lt;element name="JobID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TimeZoneID" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}TimeZoneType" minOccurs="0"/&gt;
 *         &lt;element name="UIQDeviceStateTransition" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}StateTransitionType" minOccurs="0"/&gt;
 *         &lt;choice minOccurs="0"&gt;
 *           &lt;element name="ParentDeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *           &lt;element name="ParentDeviceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *           &lt;element name="ParentDeviceSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="DeviceAttribute1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DeviceAttribute5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindBaseDeviceType", propOrder = {
    "didType",
    "didSubtype",
    "utilDeviceID",
    "uiqDeviceState",
    "utilDeviceState",
    "utilNmState",
    "name",
    "serialNumber",
    "catalogNumber",
    "networkID",
    "rfChannel",
    "ipAddress",
    "description",
    "backboneDevice",
    "suspect",
    "suspectReason",
    "retiredTime",
    "insertTime",
    "updateTime",
    "installTime",
    "removeTime",
    "lastCommTime",
    "lastReadByCROC",
    "deviceConfig",
    "batteryInfo",
    "jobID",
    "timeZoneID",
    "uiqDeviceStateTransition",
    "parentDeviceMacID",
    "parentDeviceName",
    "parentDeviceSerialNumber",
    "deviceAttribute1",
    "deviceAttribute2",
    "deviceAttribute3",
    "deviceAttribute4",
    "deviceAttribute5"
})
public class FindBaseDeviceType {

    @XmlElement(name = "DidType")
    protected DeviceTypeType didType;
    @XmlElement(name = "DidSubtype")
    protected DeviceSubTypeType didSubtype;
    @XmlElement(name = "UtilDeviceID")
    protected String utilDeviceID;
    @XmlElement(name = "UiqDeviceState")
    protected List<UiqDeviceStateTypeWithOp> uiqDeviceState;
    @XmlElement(name = "UtilDeviceState")
    protected UtilDeviceStateType utilDeviceState;
    @XmlElement(name = "UtilNmState")
    protected UtilNetworkStateType utilNmState;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "SerialNumber")
    protected String serialNumber;
    @XmlElement(name = "CatalogNumber")
    protected String catalogNumber;
    @XmlElement(name = "NetworkID")
    protected String networkID;
    @XmlElement(name = "RFChannel")
    protected Integer rfChannel;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "BackboneDevice")
    protected Boolean backboneDevice;
    @XmlElement(name = "Suspect")
    protected Boolean suspect;
    @XmlElement(name = "SuspectReason")
    protected String suspectReason;
    @XmlElement(name = "RetiredTime")
    protected TimeRangeType retiredTime;
    @XmlElement(name = "InsertTime")
    protected TimeRangeType insertTime;
    @XmlElement(name = "UpdateTime")
    protected TimeRangeType updateTime;
    @XmlElement(name = "InstallTime")
    protected TimeRangeType installTime;
    @XmlElement(name = "RemoveTime")
    protected TimeRangeType removeTime;
    @XmlElement(name = "LastCommTime")
    protected TimeRangeType lastCommTime;
    @XmlElement(name = "LastReadByCROC")
    protected Boolean lastReadByCROC;
    @XmlElement(name = "DeviceConfig")
    protected FindDeviceConfigType deviceConfig;
    @XmlElement(name = "BatteryInfo")
    protected FindBatteryInfoType batteryInfo;
    @XmlElement(name = "JobID")
    protected String jobID;
    @XmlElement(name = "TimeZoneID")
    protected TimeZoneType timeZoneID;
    @XmlElement(name = "UIQDeviceStateTransition")
    protected StateTransitionType uiqDeviceStateTransition;
    @XmlElement(name = "ParentDeviceMacID")
    protected String parentDeviceMacID;
    @XmlElement(name = "ParentDeviceName")
    protected String parentDeviceName;
    @XmlElement(name = "ParentDeviceSerialNumber")
    protected String parentDeviceSerialNumber;
    @XmlElement(name = "DeviceAttribute1")
    protected String deviceAttribute1;
    @XmlElement(name = "DeviceAttribute2")
    protected String deviceAttribute2;
    @XmlElement(name = "DeviceAttribute3")
    protected String deviceAttribute3;
    @XmlElement(name = "DeviceAttribute4")
    protected String deviceAttribute4;
    @XmlElement(name = "DeviceAttribute5")
    protected String deviceAttribute5;

    /**
     * Gets the value of the didType property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceTypeType }
     *     
     */
    public DeviceTypeType getDidType() {
        return didType;
    }

    /**
     * Sets the value of the didType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceTypeType }
     *     
     */
    public void setDidType(DeviceTypeType value) {
        this.didType = value;
    }

    /**
     * Gets the value of the didSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDidSubtype() {
        return didSubtype;
    }

    /**
     * Sets the value of the didSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDidSubtype(DeviceSubTypeType value) {
        this.didSubtype = value;
    }

    /**
     * Gets the value of the utilDeviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilDeviceID() {
        return utilDeviceID;
    }

    /**
     * Sets the value of the utilDeviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilDeviceID(String value) {
        this.utilDeviceID = value;
    }

    /**
     * Gets the value of the uiqDeviceState property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the uiqDeviceState property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUiqDeviceState().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UiqDeviceStateTypeWithOp }
     * 
     * 
     */
    public List<UiqDeviceStateTypeWithOp> getUiqDeviceState() {
        if (uiqDeviceState == null) {
            uiqDeviceState = new ArrayList<UiqDeviceStateTypeWithOp>();
        }
        return this.uiqDeviceState;
    }

    /**
     * Gets the value of the utilDeviceState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public UtilDeviceStateType getUtilDeviceState() {
        return utilDeviceState;
    }

    /**
     * Sets the value of the utilDeviceState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilDeviceStateType }
     *     
     */
    public void setUtilDeviceState(UtilDeviceStateType value) {
        this.utilDeviceState = value;
    }

    /**
     * Gets the value of the utilNmState property.
     * 
     * @return
     *     possible object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public UtilNetworkStateType getUtilNmState() {
        return utilNmState;
    }

    /**
     * Sets the value of the utilNmState property.
     * 
     * @param value
     *     allowed object is
     *     {@link UtilNetworkStateType }
     *     
     */
    public void setUtilNmState(UtilNetworkStateType value) {
        this.utilNmState = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the catalogNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCatalogNumber() {
        return catalogNumber;
    }

    /**
     * Sets the value of the catalogNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCatalogNumber(String value) {
        this.catalogNumber = value;
    }

    /**
     * Gets the value of the networkID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkID() {
        return networkID;
    }

    /**
     * Sets the value of the networkID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkID(String value) {
        this.networkID = value;
    }

    /**
     * Gets the value of the rfChannel property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRFChannel() {
        return rfChannel;
    }

    /**
     * Sets the value of the rfChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRFChannel(Integer value) {
        this.rfChannel = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the backboneDevice property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBackboneDevice() {
        return backboneDevice;
    }

    /**
     * Sets the value of the backboneDevice property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBackboneDevice(Boolean value) {
        this.backboneDevice = value;
    }

    /**
     * Gets the value of the suspect property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSuspect() {
        return suspect;
    }

    /**
     * Sets the value of the suspect property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSuspect(Boolean value) {
        this.suspect = value;
    }

    /**
     * Gets the value of the suspectReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuspectReason() {
        return suspectReason;
    }

    /**
     * Sets the value of the suspectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuspectReason(String value) {
        this.suspectReason = value;
    }

    /**
     * Gets the value of the retiredTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getRetiredTime() {
        return retiredTime;
    }

    /**
     * Sets the value of the retiredTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setRetiredTime(TimeRangeType value) {
        this.retiredTime = value;
    }

    /**
     * Gets the value of the insertTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getInsertTime() {
        return insertTime;
    }

    /**
     * Sets the value of the insertTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setInsertTime(TimeRangeType value) {
        this.insertTime = value;
    }

    /**
     * Gets the value of the updateTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getUpdateTime() {
        return updateTime;
    }

    /**
     * Sets the value of the updateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setUpdateTime(TimeRangeType value) {
        this.updateTime = value;
    }

    /**
     * Gets the value of the installTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getInstallTime() {
        return installTime;
    }

    /**
     * Sets the value of the installTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setInstallTime(TimeRangeType value) {
        this.installTime = value;
    }

    /**
     * Gets the value of the removeTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getRemoveTime() {
        return removeTime;
    }

    /**
     * Sets the value of the removeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setRemoveTime(TimeRangeType value) {
        this.removeTime = value;
    }

    /**
     * Gets the value of the lastCommTime property.
     * 
     * @return
     *     possible object is
     *     {@link TimeRangeType }
     *     
     */
    public TimeRangeType getLastCommTime() {
        return lastCommTime;
    }

    /**
     * Sets the value of the lastCommTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeRangeType }
     *     
     */
    public void setLastCommTime(TimeRangeType value) {
        this.lastCommTime = value;
    }

    /**
     * Gets the value of the lastReadByCROC property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLastReadByCROC() {
        return lastReadByCROC;
    }

    /**
     * Sets the value of the lastReadByCROC property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLastReadByCROC(Boolean value) {
        this.lastReadByCROC = value;
    }

    /**
     * Gets the value of the deviceConfig property.
     * 
     * @return
     *     possible object is
     *     {@link FindDeviceConfigType }
     *     
     */
    public FindDeviceConfigType getDeviceConfig() {
        return deviceConfig;
    }

    /**
     * Sets the value of the deviceConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindDeviceConfigType }
     *     
     */
    public void setDeviceConfig(FindDeviceConfigType value) {
        this.deviceConfig = value;
    }

    /**
     * Gets the value of the batteryInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FindBatteryInfoType }
     *     
     */
    public FindBatteryInfoType getBatteryInfo() {
        return batteryInfo;
    }

    /**
     * Sets the value of the batteryInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FindBatteryInfoType }
     *     
     */
    public void setBatteryInfo(FindBatteryInfoType value) {
        this.batteryInfo = value;
    }

    /**
     * Gets the value of the jobID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobID() {
        return jobID;
    }

    /**
     * Sets the value of the jobID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobID(String value) {
        this.jobID = value;
    }

    /**
     * Gets the value of the timeZoneID property.
     * 
     * @return
     *     possible object is
     *     {@link TimeZoneType }
     *     
     */
    public TimeZoneType getTimeZoneID() {
        return timeZoneID;
    }

    /**
     * Sets the value of the timeZoneID property.
     * 
     * @param value
     *     allowed object is
     *     {@link TimeZoneType }
     *     
     */
    public void setTimeZoneID(TimeZoneType value) {
        this.timeZoneID = value;
    }

    /**
     * Gets the value of the uiqDeviceStateTransition property.
     * 
     * @return
     *     possible object is
     *     {@link StateTransitionType }
     *     
     */
    public StateTransitionType getUIQDeviceStateTransition() {
        return uiqDeviceStateTransition;
    }

    /**
     * Sets the value of the uiqDeviceStateTransition property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateTransitionType }
     *     
     */
    public void setUIQDeviceStateTransition(StateTransitionType value) {
        this.uiqDeviceStateTransition = value;
    }

    /**
     * Gets the value of the parentDeviceMacID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceMacID() {
        return parentDeviceMacID;
    }

    /**
     * Sets the value of the parentDeviceMacID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceMacID(String value) {
        this.parentDeviceMacID = value;
    }

    /**
     * Gets the value of the parentDeviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceName() {
        return parentDeviceName;
    }

    /**
     * Sets the value of the parentDeviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceName(String value) {
        this.parentDeviceName = value;
    }

    /**
     * Gets the value of the parentDeviceSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentDeviceSerialNumber() {
        return parentDeviceSerialNumber;
    }

    /**
     * Sets the value of the parentDeviceSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentDeviceSerialNumber(String value) {
        this.parentDeviceSerialNumber = value;
    }

    /**
     * Gets the value of the deviceAttribute1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute1() {
        return deviceAttribute1;
    }

    /**
     * Sets the value of the deviceAttribute1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute1(String value) {
        this.deviceAttribute1 = value;
    }

    /**
     * Gets the value of the deviceAttribute2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute2() {
        return deviceAttribute2;
    }

    /**
     * Sets the value of the deviceAttribute2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute2(String value) {
        this.deviceAttribute2 = value;
    }

    /**
     * Gets the value of the deviceAttribute3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute3() {
        return deviceAttribute3;
    }

    /**
     * Sets the value of the deviceAttribute3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute3(String value) {
        this.deviceAttribute3 = value;
    }

    /**
     * Gets the value of the deviceAttribute4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute4() {
        return deviceAttribute4;
    }

    /**
     * Sets the value of the deviceAttribute4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute4(String value) {
        this.deviceAttribute4 = value;
    }

    /**
     * Gets the value of the deviceAttribute5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceAttribute5() {
        return deviceAttribute5;
    }

    /**
     * Sets the value of the deviceAttribute5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceAttribute5(String value) {
        this.deviceAttribute5 = value;
    }

}
