
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IMUTypeConfig complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IMUTypeConfig"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}BaseIMUTypeConfig"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TypeConfigID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IMUTypeConfig", propOrder = {
    "typeConfigID"
})
public class IMUTypeConfig
    extends BaseIMUTypeConfig
{

    @XmlElement(name = "TypeConfigID")
    protected long typeConfigID;

    /**
     * Gets the value of the typeConfigID property.
     * 
     */
    public long getTypeConfigID() {
        return typeConfigID;
    }

    /**
     * Sets the value of the typeConfigID property.
     * 
     */
    public void setTypeConfigID(long value) {
        this.typeConfigID = value;
    }

}
