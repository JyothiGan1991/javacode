package com.coned.model;

import java.sql.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "ls_finalize_event_list", schema = "AMI_LOAD_SHEDDING")
public class FinalizedEventList {

	@Id
//    @GeneratedValue(strategy = GenerationType.)
	@Column(name = "fk_meter_event_load_id")
	private Long meterEventLoadId;

	@Column(name = "event_name")
	private String eventname;

	@Column(name = "boro_muni")
	private String borough;

	
	@OneToOne(mappedBy = "finevent", fetch = FetchType.LAZY)
	private MeterEventLoad meter;

	/*
	  @JsonBackReference
	  
	  @ManyToOne(cascade = CascadeType.ALL)
	  
	  @JoinColumn(name = "event_name") private FinalizeEventListDetails
	  finalizeEventListDetails;
	 

	
	  public FinalizedEventList() {
	  
	  }
	  
	  public FinalizedEventList(String eventname, String borough, Date logintime) {
	  this.username = eventname; this.token = borough; this.logintime = logintime;
	  }
	 */

	public MeterEventLoad getMeter() {
		return meter;
	}

	public void setMeter(MeterEventLoad meter) {
		this.meter = meter;
	}

	public Long getMeterEventLoadId() {
		return meterEventLoadId;
	}

	public void setMeterEventLoadId(Long meterEventLoadId) {
		this.meterEventLoadId = meterEventLoadId;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	/*
	 * public Date getLogintime() { return logintime; }
	 * 
	 * public void setLogintime(Date logintime) { this.logintime = logintime; }
	 */

	@Override
	public String toString() {
//        return "User [meterEventLoadId=" + meterEventLoadId + ", eventname=" + eventname + ", logintime=" + logintime + "]";
		return "User [meterEventLoadId=" + meterEventLoadId + ", eventname=" + eventname + "]";
	}
}
