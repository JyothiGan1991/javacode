package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for open events.
 *
 */
@Repository
public class JdbcOpenEventRepository implements OpenEventRepository {

private static final Logger LOGGER = LogManager.getLogger(JdbcOpenEventRepository.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	@Autowired
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	
	
	@Autowired
	@Qualifier("starJdbcTemplate")
	protected JdbcTemplate starJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;
	
    /*
     * Method to read list of new and active borough.
	 *
     * @return List<String>
     *                         
     */		 
	@Override
	public List<String> getNewAndActiveBorough() {
		
		LOGGER.info("REPO CALL --> get new & active borough");
    
	    long processStartTime = DateUtils.processStartTime();
	    
		String newBoroughQuery = "SELECT Boro FROM dbo.ami_meters_event_load where InsertTime >= ? and InsertTime < ? GROUP by Boro";
	    List<String> newBoroughList = sqlServerJdbcTemplate.query(newBoroughQuery, new Object[]{DateUtils.get3DaysOldDateAsString(), 
	    															DateUtils.getCurrentDateAsString()}, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("Boro"));
			}
        });		
	    
	    LOGGER.info(String.format("LogWriter ---->  New borough list from VCAP response time : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  New borough list from VCAP : %s",newBoroughList));
	    
	    long processStartTimeLSDB = DateUtils.processStartTime();
	    
		String query = 	"SELECT BEM.boro_muni FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.BORO_MUNI FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.boro_muni = BEM.boro_muni and feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.BORO_MUNI FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.boro_muni = BEM.boro_muni and EELD.event_name = BEM.event_name) group by BEM.boro_muni";
	    List<String> activeBoroughList = oracleJdbcTemplate.query(query, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("boro_muni"));
			}
        });
	   
	    LOGGER.info(String.format("LogWriter ---->  Active borough list from LSDB response time : %s Sec.",DateUtils.processResponseTime(processStartTimeLSDB, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  Active borough list from LSDB : %s",activeBoroughList));
	    
	    Set<String> newActiveBorough = new HashSet<>();
	    if(!newBoroughList.isEmpty() && !activeBoroughList.isEmpty()){
	    	List<String> newList = Stream.concat(newBoroughList.stream(), activeBoroughList.stream()).collect(Collectors.toList());
	    	newActiveBorough = new HashSet<String>(newList);
	    }else if(!newBoroughList.isEmpty() ){
	    	newActiveBorough = new HashSet<String>(newBoroughList);
	    }else if(!activeBoroughList.isEmpty() ){
	    	newActiveBorough = new HashSet<String>(activeBoroughList);
	    }
	    
	    return newActiveBorough.stream().collect(Collectors.toList());
	}

    /*
     * Method to read list of new and active events.
	 *
     * @return List<String>
     *                         
     */	
	@Override
	public List<String> getNewAndActiveEvent() {
		
		LOGGER.info("REPO CALL --> get new & active event");

	    long processStartTime = DateUtils.processStartTime();
	    
		String newEventQuery = "SELECT EventName FROM dbo.ami_meters_event_load where InsertTime >= ? and InsertTime < ? GROUP by EventName";
	    List<String> newEventList = sqlServerJdbcTemplate.query(newEventQuery, new Object[]{DateUtils.get3DaysOldDateAsString(), 
	    															DateUtils.getCurrentDateAsString()}, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("EventName"));
			}
        });		
	    
	    LOGGER.info(String.format("LogWriter ---->   New event list from VCAP response time : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->   New event list from VCAP : %s",newEventList));
	    
	    long processStartTimeLSDB = DateUtils.processStartTime();

	    String query = 	"SELECT BEM.EVENT_NAME FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.EVENT_NAME FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.event_name = BEM.event_name) group by BEM.EVENT_NAME";
	    List<String> activeEventList = oracleJdbcTemplate.query(query, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("EVENT_NAME"));
			}
        });
	   
	    LOGGER.info(String.format("LogWriter ---->   Active event list from LSDB response time : %s Sec.",DateUtils.processResponseTime(processStartTimeLSDB, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->   Active event list from LSDB : %s",activeEventList));
	    
	    Set<String> newActiveEvent = new HashSet<>();
	    if(!newEventList.isEmpty() && !activeEventList.isEmpty()){
	    	List<String> newList = Stream.concat(newEventList.stream(), activeEventList.stream()).collect(Collectors.toList());
	    	newActiveEvent = new HashSet<String>(newList);
	    }else if(!newEventList.isEmpty() ){
	    	newActiveEvent = new HashSet<String>(newEventList);
	    }else if(!activeEventList.isEmpty() ){
	    	newActiveEvent = new HashSet<String>(activeEventList);
	    }

	    List<String> newActiveEventList = newActiveEvent.stream().collect(Collectors.toList());
	    Collections.sort(newActiveEventList);

	    return newActiveEventList;
	}

    /*
     * Method to read list of new and active events by borough.
	 *
     * @Param borough String
     * 
     * @return 		  List<String>
     *                         
     */	
	@Override
	public List<String> getNewAndActiveEventByBorough(final String borough) {
		
		LOGGER.info(String.format("REPO CALL --> get new & active event by borough %s ",borough));

	    long processStartTime = DateUtils.processStartTime();

		String newEventByBoroughQuery = "SELECT EventName FROM ami_meters_event_load WHERE Boro = ? AND InsertTime >= ? and InsertTime < ? group by EventName";
	    List<String> newBoroughListByEvent = sqlServerJdbcTemplate.query(newEventByBoroughQuery, new Object[]{borough, DateUtils.get3DaysOldDateAsString(), 
	    															DateUtils.getCurrentDateAsString()}, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("EventName"));
			}
        });		    
	    
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from VCAP response time : %s Sec.",borough,DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from VCAP : %s",borough,newBoroughListByEvent));

	    String activeboroughQuery = 	"SELECT BEM.EVENT_NAME FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE BEM.boro_muni = ? group by BEM.EVENT_NAME";
	    List<String> activeboroughList = oracleJdbcTemplate.query(activeboroughQuery, new Object[]{borough},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("event_name"));
			}
        });
	    
	    newBoroughListByEvent.removeAll(activeboroughList);
	    
	    long processStartTimeNQ = DateUtils.processStartTime();

	    String query = 	"SELECT BEM.EVENT_NAME FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.BORO_MUNI FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.boro_muni = BEM.boro_muni and feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.BORO_MUNI FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.boro_muni = BEM.boro_muni and EELD.event_name = BEM.event_name) and BEM.boro_muni = ? group by BEM.EVENT_NAME";
	    List<String> activeBoroughListByEvent = oracleJdbcTemplate.query(query, new Object[]{borough},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("event_name"));
			}
        });
	    
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from LSDB response time : %s Sec.",borough,DateUtils.processResponseTime(processStartTimeNQ, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from LSDB : %s",borough,activeBoroughListByEvent));
	    
	    List<String> newActiveEventListByBorough = Stream.concat(newBoroughListByEvent.stream(), activeBoroughListByEvent.stream()).collect(Collectors.toList());
	    Collections.sort(newActiveEventListByBorough);
	    
	    return newActiveEventListByBorough;
	}
	
    /*
     * Method to read list of borough finalized for connect from database.
	 *
     * @return List<String>
     *                         
     */	
	@Override
	public List<String> getSubFinalizeBorough() {
		LOGGER.info("Request for borough for RCC Connect from execute event list details");
		
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_CON_FIN_BOROUGH").returningResultSet("SP_SUB_FIN_BOROUGH", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("boro_muni"));
			}
        });
		
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute();
		List<LinkedCaseInsensitiveMap<String>> newBoroughList = (List<LinkedCaseInsensitiveMap<String>>) simpleJdbcCallResult.get("BORO");
		List<String> boroughList = new ArrayList<String>();
		
		for(LinkedCaseInsensitiveMap<String>  le: newBoroughList){
			String string = le.get("BORO_MUNI");
			boroughList.add(string);
		}
		
	    LOGGER.info(String.format("Borough List - %s", boroughList));
	    
	    return boroughList;
	}

    /*
     * Method to read list of event finalized for connect from database.
	 *
     * @return List<String>
     *                         
     */	
	@Override
	public List<String> getSubFinalizeEvent() {
		LOGGER.info("Request for event for RCC Connect from execute event list details");
		
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_CON_FIN_EVENT_NAME").returningResultSet("SP_CON_FIN_EVENT_NAME", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("event_name"));
			}
        });
		
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute();
		List<LinkedCaseInsensitiveMap<String>> newBoroughList = (List<LinkedCaseInsensitiveMap<String>>) simpleJdbcCallResult.get("EVENTNAME");
		List<String> eventList = new ArrayList<>();
		
		for(LinkedCaseInsensitiveMap<String>  le: newBoroughList){
			String string = le.get("EVENT_NAME");
			eventList.add(string);
		}
		
		LOGGER.info(String.format("Event List  - %s", eventList));
		
		return eventList;
	}

    /*
     * Method to read list of event finalized for connect by borough from database.
	 *
     * @Param borough String
     * 
     * @return        List<String>
     *                         
     */	
	@Override
	public List<String> getSubFinalizeEventByBorough(String borough) {
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_CON_FIN_EVENT_NAME_BOROUGH").returningResultSet("SP_CON_FIN_EVENT_NAME_BOROUGH", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("event_name"));
			}
        });
		
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("BOROUGH", borough);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<LinkedCaseInsensitiveMap<String>> newBoroughList = (List<LinkedCaseInsensitiveMap<String>>) simpleJdbcCallResult.get("EVENTNAME");
		List<String> eventListByBorough = new ArrayList<>();
		
		for(LinkedCaseInsensitiveMap<String>  le: newBoroughList){
			String string = le.get("EVENT_NAME");
			eventListByBorough.add(string);
		}
		
	    LOGGER.info(String.format("eventNameList - %s", eventListByBorough));
	    
		return eventListByBorough;
	}

    /*
     * Method to read list of sub event finalized for connect from database.
	 *
     * @Param borough   String
     * @Param eventName String
     * 
     * @return 		    List<String>
     *                         
     */	
	@Override
	public List<String> getSubFinalizeEventByEventAndBorough(final String borought, final String eventName) {
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_CON_FIN_SUB_EVENT_NAME").returningResultSet("SP_CON_FIN_SUB_EVENT_NAME", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("sub_event_name"));
			}
        });

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("BOROUGH", borought);
		inParamMap.put("EVENTNAME", eventName);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<LinkedCaseInsensitiveMap<String>> newBoroughList = (List<LinkedCaseInsensitiveMap<String>>) simpleJdbcCallResult.get("SUBEVENTNAME");
		List<String> eventListByBorough = new ArrayList<>();
		
		for(LinkedCaseInsensitiveMap<String>  le: newBoroughList){
			String string = le.get("SUB_EVENT_NAME");
			eventListByBorough.add(string);
		}
		
	    LOGGER.info(String.format("eventNameList - %s", eventListByBorough));
	    
		return eventListByBorough;
	}

    /*
     * Method to read list of borough for disconnected meters from database.
     * 
     * @return List<String>
     *                         
     */	
	@Override
	public List<String> getExecuteBorough() {
//		String newBoroughQuery = "Select DISTINCT eel.boro_muni FROM LS_EXECUTE_EVENT_LIST EEL where NOT EXISTS  (SELECT esel.fk_meter_event_load_id FROM LS_FINALIZE_SUB_EVENT_LIST ESEL WHERE esel.fk_meter_event_load_id = eel.fk_meter_event_load_id) GROUP BY eel.boro_muni";
		String newBoroughQuery = "SELECT DISTINCT eel.BORO_MUNI FROM LS_EXECUTE_EVENT_LIST eel";
		
	    List<String> newBoroughList = oracleJdbcTemplate.query(newBoroughQuery, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("Boro_muni"));
			}
        });		
		
		LOGGER.info(String.format("New borough list : %s",newBoroughList));
		
		return newBoroughList;
	}

    /*
     * Method to read list of event for disconnected meters from database.
     * 
     * @return List<String>
     *                         
     */	
	@Override
	public List<String> getExecuteEvent() {
		String executeEventQuery = "Select DISTINCT eel.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST EEL GROUP BY eel.EVENT_NAME ORDER BY EVENT_NAME ASC";
		List<String> executeEventList = oracleJdbcTemplate.query(executeEventQuery, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("Event_Name"));
			}
        });		
		
	    Collections.sort(executeEventList);
	    
		LOGGER.info(String.format("Execute event list : %s",executeEventList));
		
		return executeEventList;
	}

    /*
     * Method to read list of event for disconnected meters by borough from database.
     * 
     * @Param borough String
     * 
     * @return        List<String>
     *                         
     */	
	@Override
	public List<String> getExecuteEventByBorough(final String borough) {
		String executeEventQuery = "Select DISTINCT eel.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST EEL where eel.BORO_MUNI = ? GROUP BY eel.EVENT_NAME ORDER BY EVENT_NAME ASC";
		List<String> executeEventList = oracleJdbcTemplate.query(executeEventQuery,new Object[]{borough},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("Event_Name"));
			}
        });		
		
	    Collections.sort(executeEventList);
	    
		LOGGER.info(String.format("Execute event list by borough : %s",executeEventList));
		
		return executeEventList;
	}
}
