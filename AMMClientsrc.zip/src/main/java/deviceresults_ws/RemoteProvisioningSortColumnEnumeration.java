
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemoteProvisioningSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RemoteProvisioningSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="RequestedProvisioningAction"/&gt;
 *     &lt;enumeration value="ProvisioningCommandStatus"/&gt;
 *     &lt;enumeration value="MeterConnectionStatus"/&gt;
 *     &lt;enumeration value="PrepayEnabled"/&gt;
 *     &lt;enumeration value="PrepayBalance"/&gt;
 *     &lt;enumeration value="PrepayOverdraftLimit"/&gt;
 *     &lt;enumeration value="RemoteProvisioningDataType"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="JobCreator"/&gt;
 *     &lt;enumeration value="JobExecutionTime"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RemoteProvisioningSortColumnEnumeration")
@XmlEnum
public enum RemoteProvisioningSortColumnEnumeration {

    @XmlEnumValue("RequestedProvisioningAction")
    REQUESTED_PROVISIONING_ACTION("RequestedProvisioningAction"),
    @XmlEnumValue("ProvisioningCommandStatus")
    PROVISIONING_COMMAND_STATUS("ProvisioningCommandStatus"),
    @XmlEnumValue("MeterConnectionStatus")
    METER_CONNECTION_STATUS("MeterConnectionStatus"),
    @XmlEnumValue("PrepayEnabled")
    PREPAY_ENABLED("PrepayEnabled"),
    @XmlEnumValue("PrepayBalance")
    PREPAY_BALANCE("PrepayBalance"),
    @XmlEnumValue("PrepayOverdraftLimit")
    PREPAY_OVERDRAFT_LIMIT("PrepayOverdraftLimit"),
    @XmlEnumValue("RemoteProvisioningDataType")
    REMOTE_PROVISIONING_DATA_TYPE("RemoteProvisioningDataType"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("JobCreator")
    JOB_CREATOR("JobCreator"),
    @XmlEnumValue("JobExecutionTime")
    JOB_EXECUTION_TIME("JobExecutionTime");
    private final String value;

    RemoteProvisioningSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RemoteProvisioningSortColumnEnumeration fromValue(String v) {
        for (RemoteProvisioningSortColumnEnumeration c: RemoteProvisioningSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
