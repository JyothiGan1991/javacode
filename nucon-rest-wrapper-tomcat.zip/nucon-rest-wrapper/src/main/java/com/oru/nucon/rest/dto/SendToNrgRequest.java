package com.oru.nucon.rest.dto;

public class SendToNrgRequest {
    private String arg0;
    private Integer arg1;
    private String arg2;

    public SendToNrgRequest() {}
    public SendToNrgRequest(String arg0, Integer arg1, String arg2) {
        this.arg0 = arg0;
        this.arg1 = arg1;
        this.arg2 = arg2;
    }

    public String getArg0() { return arg0; }
    public void setArg0(String arg0) { this.arg0 = arg0; }
    public Integer getArg1() { return arg1; }
    public void setArg1(Integer arg1) { this.arg1 = arg1; }
    public String getArg2() { return arg2; }
    public void setArg2(String arg2) { this.arg2 = arg2; }
}
