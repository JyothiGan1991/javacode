package com.coned.ls.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.exception.MeterValidateException;
import com.coned.ls.exception.VcapRecordNotFoundException;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.MeterEventValidateRepository;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Service class for RCC Disconnect.
 *
 */
@Service("meterEventValidateService")
public class MeterEventValidateServiceImpl implements MeterEventValidateService {

	private static final Logger LOGGER = LogManager.getLogger(MeterEventValidateServiceImpl.class);
	
	@Autowired
	private MeterEventValidateRepository meterEventValidateRepository;
	
    /*
     * Method to return list of meters created for the event, API supports sorting, filtering and pagination.
     * 
     * @Param meterOpenEvent MeterOpenEvent 
     * 
     * @return 				 ResponseEntity<MeterValidateResponseMapper> 
     *                         
     */
	@Override
	public ResponseEntity<MeterValidateResponseMapper> getValidateMeter(final MeterOpenEvent meterOpenEvent) throws MeterValidateException,VcapRecordNotFoundException{

		long processStartTime = DateUtils.processStartTime();
		
		MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper();
		
		String borough = meterOpenEvent.getBorough();
		String eventName = meterOpenEvent.getEventName();
		int startRowIndex = meterOpenEvent.getStartRowIndex();
		int batchSize = meterOpenEvent.getBatchSize();
		String adid = meterOpenEvent.getAdid();
		String fromDate = meterOpenEvent.getFromDate();
		String toDate = meterOpenEvent.getToDate();
		String filterList = " ";
		String sortList = " ";
		
		if(meterOpenEvent.isFilterApplied()){
			filterList = buildFilterQuery(meterOpenEvent.getFilterList(),"mel.");
		}
		if(meterOpenEvent.isSortApplied()){
			sortList = buildSortQuery(meterOpenEvent.getSortList(),"mel.");
		}
		
		try{
			meterValidateResponseMapper = isEventFinalized(borough, eventName);
			if (!meterValidateResponseMapper.getIsEventFinalized()) {
				meterValidateResponseMapper = isEventLocked(borough, eventName, adid);
	
				boolean isEventLocked = meterValidateResponseMapper.getIsEventLocked();
				String message = meterValidateResponseMapper.getMessage();
				if(!meterValidateResponseMapper.getIsEventLocked()){
					if(!verifyNewEventEntryInLS(borough, eventName)){
						if(pushMeterEventFromVcapToLS(borough, eventName, fromDate, toDate, adid)){
							validateMeterEventWithStar(borough, eventName);
							meterValidateResponseMapper = getValidateMeterList(borough,eventName,startRowIndex,batchSize,filterList,sortList);
						}else{
							LOGGER.info(String.format("VCAP Data not found"));
							meterValidateResponseMapper.setValidResponse(false);
						}
					}else{
						meterValidateResponseMapper = getValidateMeterList(borough,eventName,startRowIndex,batchSize,filterList,sortList);
					}
				}else{
					meterValidateResponseMapper =  getValidateMeterList(borough,eventName,startRowIndex,batchSize,filterList,sortList);
				}
	
				meterValidateResponseMapper.setIsEventLocked(isEventLocked);
				if (isEventLocked) {
					meterValidateResponseMapper.setMessage(message);
				}
			}
		}catch(VcapRecordNotFoundException vcapRecordNotFoundException){
			LOGGER.error(vcapRecordNotFoundException.getMessage(), vcapRecordNotFoundException);
		}catch(MeterValidateException meterValidateException){
			LOGGER.error(meterValidateException.getMessage(), meterValidateException);
		}
		
		LOGGER.info(String.format("LogWriter ----> Service - Valid Meters : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return ResponseEntity.ok().body(meterValidateResponseMapper);		
	}

    /*
     * Method to return list of values for a given field.
     * 
     * @Param borough  	 String 
     * @Param eventName  String
     * @Param fieldName  String
     * 
     * @return 			 ResponseEntity<List<String>>  
     *                         
     */
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		List<String> fieldValues = meterEventValidateRepository.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
		return ResponseEntity.ok().body(fieldValues);
	}
	
    /*
     * Method to search list of meters.
     * 
     * @Param meterSearch  MeterSearch 
     * 
     * @return 			   ResponseEntity<MeterValidateResponseMapper>  
     *                         
     */
	@Override
	public ResponseEntity<MeterValidateResponseMapper>  searchMeters(final MeterSearch meterSearch) {
		MeterValidateResponseMapper searchMeters = meterEventValidateRepository.searchMeters(meterSearch);
		return ResponseEntity.ok().body(searchMeters);
	}

    /*
     * Method to check new event in LSDB.
     * 
     * @Param borough  	 String 
     * @Param eventName  String
     * 
     * @return 			 boolean  
     *                         
     */
	@Override
	public boolean verifyNewEventEntryInLS(final String borough, final String eventName) {
		return meterEventValidateRepository.verifyNewEventEntryInLS(borough, eventName);
	}

    /*
     * Method to load data from VCAP to LSDB.
     * 
     * @Param borough  	 String 
     * @Param eventName  String
     * @Param fromDate   String
     * @Param toDate     String
     * @Param adid       String
     * 
     * @return 			 boolean  
     *                         
     */
	@Override
	public boolean pushMeterEventFromVcapToLS(final String borough, final String eventName, final String fromDate, final String toDate, final String adid) throws MeterValidateException, VcapRecordNotFoundException {
		return meterEventValidateRepository.pushMeterEventFromVcapToLS(borough, eventName, fromDate, toDate, adid);
	}

    /*
     * Method to read list of valid meters from the database.
     * 
     * @Param borough  	    String 
     * @Param eventName     String
     * @Param startRowIndex int
     * @Param batchSize     int
     * @Param filterList    String
     * @Param sortList      String
     * 
     * @return 			    MeterValidateResponseMapper  
     *                         
     */
	@Override
	public MeterValidateResponseMapper getValidateMeterList(final String borough, final String eventName, final int startRowIndex, final int batchSize, final String filterList, final String sortList) throws MeterValidateException {
		return meterEventValidateRepository.getValidateMeterList(borough, eventName, startRowIndex, batchSize,filterList, sortList);
	}

    /*
     * Method to check event is locked.
     * 
     * @Param borough  	String 
     * @Param eventName String
     * @Param adid      String
     * 
     * @return 			MeterValidateResponseMapper  
     *                         
     */
	@Override
	public MeterValidateResponseMapper isEventLocked(final String borough, final String eventName, final String adid) {
		return meterEventValidateRepository.isEventLocked(borough, eventName, adid);
	}

    /*
     * Method to check event is finalized.
     * 
     * @Param borough  	String 
     * @Param eventName String
     * 
     * @return 			MeterValidateResponseMapper  
     *                         
     */
	@Override
	public MeterValidateResponseMapper isEventFinalized(String borough, final String eventName) {
		return meterEventValidateRepository.isEventFinalized(borough, eventName);
	}
	
    /*
     * Method to validate meters with Star database.
     * 
     * @Param borough  	String 
     * @Param eventName String
     * 
     * @return 			boolean  
     *                         
     */
	@Override
	public boolean validateMeterEventWithStar(final String borough, final String eventName) {
		return meterEventValidateRepository.validateMeterEventWithStar(borough, eventName);
	}

    /*
     * Method to read list of invalid meters from database.
     * 
     * @Param borough  	    String 
     * @Param eventName     String
     * @Param startRowIndex int
     * @Param batchSize     int
     * 
     * @return 			    MeterValidateResponseMapper  
     *                         
     */
	@Override
	public MeterValidateResponseMapper getInValidateMeterList(final String borough, final String eventName,final int startRowIndex, final int batchSize) {
		return meterEventValidateRepository.getInValidateMeterList(borough, eventName, startRowIndex, batchSize);
	}
	
    /*
     * Method to check locked status of event.
     * 
     * @Param borough  	    String 
     * @Param eventName     String
     * @Param adid			String
     * 
     * @return 			    MeterLockedStatusResponseMapper  
     *                         
     */
	@Override
	public MeterLockedStatusResponseMapper getLockedStatusByBoroughAndEventName(final String borough, final String eventName, final String adid) {
		return meterEventValidateRepository.getLockedStatusByBoroughAndEventName(borough, eventName, adid);
	}
	
    /*
     * Method to build filter query.
     * 
     * @Param filterListMap filterListMap
     * @Param queryPrefix   String
     * 
     * @return 			    String  
     *                         
     */
	private String buildFilterQuery(final Map<String,String> filterListMap, final String queryPrefix){
		
		long processStartTime = DateUtils.processStartTime();
		
		StringBuffer buildFilterQuery = new StringBuffer();
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code"})
		        .collect(Collectors.toList());
		
		filterListMap.forEach((key, value) -> {
			
			String[] split = value.split(",");
			if (value.contains("No Data")) 
				buildFilterQuery.append(" AND (");
			else
				buildFilterQuery.append(" AND ");
			
			if(fieldsFromVEL.contains(key))
				buildFilterQuery.append("('"+key+"', vel."+key);
			else
				buildFilterQuery.append("('"+key+"', mel."+key);
			
			buildFilterQuery.append(") IN ( ");
			int i =0;
			for(String val : split){
				if(i==0){
					buildFilterQuery.append("('"+key+"',"+val+")");
					i++;
				}else{
					buildFilterQuery.append(",('"+key+"',"+val+")");
				}
			}	
			buildFilterQuery.append(")");		
			
			if (value.contains("No Data")){
				if(fieldsFromVEL.contains(key))
				buildFilterQuery.append(" OR "+"vel." + key + " IS NULL)");
				else
				buildFilterQuery.append(" OR "+queryPrefix + key + " IS NULL)");

			}
		});
		
		LOGGER.info(String.format("LogWriter ----> Build Filter Query : %s Sec.",DateUtils.processResponseTime(processStartTime, DateUtils.processEndTime())));
		return buildFilterQuery.toString();
	}
	
    /*
     * Method to build sort query.
     * 
     * @Param filterListMap filterListMap
     * @Param queryPrefix   String
     * 
     * @return 			    String  
     *                         
     */
	private String buildSortQuery(final Map<String,String> sortListMap, final String queryPrefix){
		
		StringBuffer buildSortQuery = new StringBuffer();
		
		buildSortQuery.append("ORDER BY ");
		List<String> fieldsFromVEL=Arrays.stream(new String[]{"building_num", "service_address", "cust_zip_code", "account_number"})
		        .collect(Collectors.toList());
		
		int flag = 0;
		for (Map.Entry<String, String> entry : sortListMap.entrySet()) {
			
			if(flag==0){
				if(fieldsFromVEL.contains(entry.getKey()))
					buildSortQuery.append("vel.");
				else
				buildSortQuery.append(queryPrefix);
				buildSortQuery.append(entry.getKey());
				buildSortQuery.append(" "+entry.getValue());
				flag=1;
			}else{
				if(fieldsFromVEL.contains(entry.getKey()))
					buildSortQuery.append(", "+"vel.");
				else
				buildSortQuery.append(", "+queryPrefix);
				buildSortQuery.append(entry.getKey());
				buildSortQuery.append(" "+entry.getValue());
			}
	    }

		System.out.println("sortListQueryString : "+ buildSortQuery);
		return buildSortQuery.toString();
	}
	
    /*
     * Method to unlock the events.
     * 
     * @Param adid String
     * 
     * @return 	   void  
     *                         
     */
	public void unlockEvents(final String adid) {
		meterEventValidateRepository.unlockEvents(adid);
	}
}