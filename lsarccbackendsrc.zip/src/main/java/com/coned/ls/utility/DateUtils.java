package com.coned.ls.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * Utility class to implement reusable date methods.
 *
 */
public class DateUtils {

	private static final Logger logger = LogManager.getLogger(DateUtils.class);
	private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	
	private static Date date = new Date();
	
	public static Date getDate() {
		return new Date();
	}

	public static void setDate(Date date) {
		DateUtils.date = date;
	}

	public static String getCurrentDateAsString(){
		Date date = new Date();
        String currentDate = dateFormat.format(date);
        
        return currentDate;
	}
	
	public static String get3DaysOldDateAsString(){
        Calendar cal = Calendar.getInstance();
        
        DateFormat newDateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00.000");
        
        cal.setTime(getDate());
        cal.add(Calendar.DATE, -3);
        
        Date todate1 = cal.getTime();    
        String oldDate3Days = newDateFormat.format(todate1);
        
        return oldDate3Days;
	}
	
	public static String[] getValidateDate(final Date fromDate){
		logger.info(String.format("Form Date %s",fromDate));
		
		String fromToDate[] = new String[2];
		
		DateUtils.setDate(fromDate);
		
		fromToDate[0] = DateUtils.get3DaysOldDateAsString();
		fromToDate[1] = DateUtils.getCurrentDateAsString();
		
		logger.info(String.format("Date Converted"));
		logger.info(String.format("Form Date String %s",fromToDate[0]));
		logger.info(String.format("To Date String %s",fromToDate[1]));
		
		return fromToDate;
	}
	
	public static Date get3DaysOldDate(){
        Calendar cal = Calendar.getInstance();
        
        cal.setTime(getDate());
        cal.add(Calendar.DATE, -3);
        
        return cal.getTime();    
	}
	
	public static String[] convertURLDate(String fromDate, String toDate){
		logger.info(String.format("From date %s nd to date %s",fromDate,toDate));
		
		String convertedDate[] = new String[2];
		String splitString[] = fromDate.split("%");
		String subString = splitString[1].substring(4); 
		convertedDate[0] = splitString[0]+" "+subString;
		
		String splitString1[] = toDate.split("%");
		String subString1 = splitString1[1].substring(4); 
		convertedDate[1] = splitString1[0]+" "+subString1;
		
		logger.info(String.format("Date Converted"));
		logger.info(String.format("Form Date String %s",convertedDate[0]));
		logger.info(String.format("To Date String %s",convertedDate[1]));
		
		return convertedDate;
	}
	
	public static long processStartTime(){
		return System.currentTimeMillis(); 
	}
	
	public static long processEndTime(){
		return System.currentTimeMillis(); 
	}
	
	public static long processResponseTime(final long startTime, final long endTime){
		long timeSeconds = TimeUnit.MILLISECONDS.toSeconds(endTime - startTime);
		return timeSeconds;
	}
	
	
}
