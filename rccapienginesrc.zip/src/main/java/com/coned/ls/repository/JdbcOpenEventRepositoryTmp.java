package com.coned.ls.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for open events.
 *
 */
@Repository
public class JdbcOpenEventRepositoryTmp implements OpenEventRepositoryTmp {

private static final Logger LOGGER = LogManager.getLogger(JdbcOpenEventRepositoryTmp.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	@Autowired
	@Qualifier("sqlServerJdbcTemplate")
	protected JdbcTemplate sqlServerJdbcTemplate;
	
	
	@Autowired
	@Qualifier("starJdbcTemplate")
	protected JdbcTemplate starJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;
	
		 
	@Override
	public List<String> getNewAndActiveBorough() {
		
		LOGGER.info("** TEMP ** REPO CALL --> get new & active borough");
    
	    long processStartTime = DateUtils.processStartTime();
	    
		long processStartTimeLSDB = DateUtils.processStartTime();
	    
		String query = 	"SELECT BEM.boro_muni FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.BORO_MUNI FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.boro_muni = BEM.boro_muni and feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.BORO_MUNI FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.boro_muni = BEM.boro_muni and EELD.event_name = BEM.event_name) group by BEM.boro_muni";
	    List<String> activeBoroughList = oracleJdbcTemplate.query(query, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("boro_muni"));
			}
        });
	   
	    LOGGER.info(String.format("LogWriter ---->  Active borough list from LSDB response time : %s Sec.",DateUtils.processResponseTime(processStartTimeLSDB, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  Active borough list from LSDB : %s",activeBoroughList));
	    
	    Set<String> newActiveBorough = new HashSet<>();
	    if(!activeBoroughList.isEmpty()) {
	    	newActiveBorough = new HashSet<String>(activeBoroughList);
	    }
	    return newActiveBorough.stream().collect(Collectors.toList());
	}

	@Override
	public List<String> getNewAndActiveEvent() {
		
		LOGGER.info("** TEMP ** --> REPO CALL --> get new & active event");

	    long processStartTime = DateUtils.processStartTime();
	    
	    long processStartTimeLSDB = DateUtils.processStartTime();

	    String query = 	"SELECT BEM.EVENT_NAME FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.EVENT_NAME FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.EVENT_NAME FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.event_name = BEM.event_name) group by BEM.EVENT_NAME";
	    List<String> activeEventList = oracleJdbcTemplate.query(query, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("EVENT_NAME"));
			}
        });
	   
	    LOGGER.info(String.format("LogWriter ---->   Active event list from LSDB response time : %s Sec.",DateUtils.processResponseTime(processStartTimeLSDB, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->   Active event list from LSDB : %s",activeEventList));
	    
	    Set<String> newActiveEvent = new HashSet<>();
	    if(!activeEventList.isEmpty() ){
	    	newActiveEvent = new HashSet<String>(activeEventList);
	    }

	    List<String> newActiveEventList = newActiveEvent.stream().collect(Collectors.toList());
	    Collections.sort(newActiveEventList);

	    return newActiveEventList;
	}

	@Override
	public List<String> getNewAndActiveEventByBorough(final String borough) {
		
		LOGGER.info(String.format(" ** TEMP ** REPO CALL --> get new & active event by borough %s ",borough));

	    long processStartTime = DateUtils.processStartTime();
	    long processStartTimeNQ = DateUtils.processStartTime();
	    String query = 	"SELECT BEM.EVENT_NAME FROM LS_BOROUGH_EVENT_MAPPING BEM WHERE NOT EXISTS (SELECT FELD.BORO_MUNI FROM LS_FINALIZE_EVENT_LIST_DETAILS FELD where feld.boro_muni = BEM.boro_muni and feld.event_name = BEM.event_name) AND NOT EXISTS (SELECT EELD.BORO_MUNI FROM LS_EXECUTE_EVENT_LIST_DETAILS EELD where EELD.boro_muni = BEM.boro_muni and EELD.event_name = BEM.event_name) and BEM.boro_muni = ? group by BEM.EVENT_NAME";
	    List<String> activeBoroughListByEvent = oracleJdbcTemplate.query(query, new Object[]{borough},new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum)throws SQLException {
				return new String(rs.getString("event_name"));
			}
        });
	    
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from LSDB response time : %s Sec.",borough,DateUtils.processResponseTime(processStartTimeNQ, DateUtils.processEndTime())));
	    LOGGER.info(String.format("LogWriter ---->  New event list by borough %s from LSDB : %s",borough,activeBoroughListByEvent));
    
	    return activeBoroughListByEvent;
	}
}
