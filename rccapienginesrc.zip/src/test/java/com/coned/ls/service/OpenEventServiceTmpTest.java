package com.coned.ls.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.coned.ls.config.ApiEngineApplication;
import com.coned.ls.controller.AuthenticationController;
import com.coned.ls.domain.MeterEventLoad;
import com.coned.ls.domain.OpenEvent;
import com.coned.ls.mapper.MeterConnectResponseMapper;
import com.coned.ls.mapper.MeterValidateResponseMapper;
import com.coned.ls.repository.AuthorizationRepository;
import com.coned.ls.repository.JdbcAuthorizationRepository;
import com.coned.ls.repository.OpenEventRepository;
import com.coned.ls.repository.OpenEventRepositoryTmp;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes={OpenEventServiceTmp.class})
@AutoConfigureMockMvc
public class OpenEventServiceTmpTest {

	@Autowired
	private WebApplicationContext wac;
	
	@InjectMocks
	private OpenEventServiceTmp openEventService = new OpenEventServiceTmpImpl();
	
	@Mock
	private OpenEventRepositoryTmp openEventRepository;
	
	@Mock
	private AuthenticationController authController;
	
	@Mock
	private AuthorizationService authService = new AuthorizationServiceImpl();
	
	@Mock
	private AuthorizationRepository  authorizationRepository;// = new JdbcAuthorizationRepository();
	
	@Mock
	private JdbcAuthorizationRepository jdbcAuthRepository;
	
	@Mock
	protected JdbcTemplate oracleJdbcTemplate;
	
	
	private MockMvc mockMvc;
	
	private OpenEvent openEvent;
	
	private List<MeterEventLoad> meterEventLoads;
	
	private MeterEventLoad  meterEventLoad;
	
	MeterValidateResponseMapper meterValidateResponseMapper = new MeterValidateResponseMapper(); 
	
	
	@Test
	@Before
	public void setup(){
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		meterEventLoads = new ArrayList<>();
		
		MeterEventLoad meterEventLoadB = new MeterEventLoad();
		meterEventLoadB.setBorough("B");
		meterEventLoadB.setEventName("SheepsheadBaySampleData7.27.20-1300");
		meterEventLoadB.setDemand("8.20");
		meterEventLoadB.setFeeder("3220");
		meterEventLoadB.setBuildingNumber("320");
		meterEventLoadB.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadB.setCustomerZipCode("11120");
		meterEventLoadB.setMeterNumber("9477420");
		meterEventLoadB.setAccountNumber("11111222220000");
		meterEventLoadB.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadB);
		
		MeterEventLoad meterEventLoadC = new MeterEventLoad();
		meterEventLoadC.setBorough("C");
		meterEventLoadC.setEventName("SheepsheadBaySampleData7.27.20-1350");
		meterEventLoadC.setDemand("8.26");
		meterEventLoadC.setFeeder("3226");
		meterEventLoadC.setBuildingNumber("326");
		meterEventLoadC.setServiceAddress("PAERDEGAT 7TH ST");
		meterEventLoadC.setCustomerZipCode("11126");
		meterEventLoadC.setMeterNumber("9477426");
		meterEventLoadC.setAccountNumber("11111222220000");
		meterEventLoadC.setNetwork("Flatbush");
		meterEventLoads.add(meterEventLoadC);
		
		meterEventLoad = meterEventLoadC;
		openEvent = new  OpenEvent("SheepsheadBaySampleData7.27.20-1300", "B");
		meterValidateResponseMapper.setMeterEventLoads(meterEventLoads);
	}
	
	@Test
	public void getNewAndActiveEvent(){
		List<String> eventname = new ArrayList<String>();
		eventname.add("SheepsheadBaySampleData7.27.20-1300");
		eventname.add("Flatbush.23.11/08/20-23:24:06.KUMARM");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(eventname, HttpStatus.OK);
		Mockito.when(openEventRepository.getNewAndActiveEvent()).thenReturn(eventname);
		ResponseEntity<List<String>> result = openEventService.getNewAndActiveEvent();
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
	@Test
	public void getNewAndActiveEventByBorough(){
		List<String> eventName = new ArrayList<String>();
		eventName.add("Flatbush.01.10/27/20-12:05:45.ZHUT");
		eventName.add("SheepsheadBay.01.10/28/20-01:17:20.AUTO");
		eventName.add("Ridgewood.09.10/11/20-09:27:18.AUTO");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(eventName, HttpStatus.OK);
		Mockito.when(openEventRepository.getNewAndActiveEventByBorough(Mockito.anyString())).thenReturn(eventName);
		ResponseEntity<List<String>> result = openEventService.getNewAndActiveEventByBorough(Mockito.anyString());
		Assert.assertEquals(response.getBody().size(), result.getBody().size());
	}
	
}

