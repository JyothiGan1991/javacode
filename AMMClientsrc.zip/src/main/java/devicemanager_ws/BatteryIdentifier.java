
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BatteryIdentifier complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BatteryIdentifier"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BatteryManufacturer" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BatterySerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BatteryIdentifier", propOrder = {
    "batteryManufacturer",
    "batterySerialNumber"
})
public class BatteryIdentifier {

    @XmlElement(name = "BatteryManufacturer", required = true)
    protected String batteryManufacturer;
    @XmlElement(name = "BatterySerialNumber", required = true)
    protected String batterySerialNumber;

    /**
     * Gets the value of the batteryManufacturer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatteryManufacturer() {
        return batteryManufacturer;
    }

    /**
     * Sets the value of the batteryManufacturer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatteryManufacturer(String value) {
        this.batteryManufacturer = value;
    }

    /**
     * Gets the value of the batterySerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatterySerialNumber() {
        return batterySerialNumber;
    }

    /**
     * Sets the value of the batterySerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatterySerialNumber(String value) {
        this.batterySerialNumber = value;
    }

}
