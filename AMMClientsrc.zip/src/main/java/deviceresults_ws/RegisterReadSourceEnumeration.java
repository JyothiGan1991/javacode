
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegisterReadSourceEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RegisterReadSourceEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_EO_CURR_READ"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_EO_SELF_READ"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_TBL23"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_TBL24"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_TBL25"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_TBL26"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_CURRENT_EOB"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_EOB_SELF_READ"/&gt;
 *     &lt;enumeration value="REG_SRC_TYPE_EOB_DR_READ"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RegisterReadSourceEnumeration")
@XmlEnum
public enum RegisterReadSourceEnumeration {

    REG_SRC_TYPE_EO_CURR_READ("REG_SRC_TYPE_EO_CURR_READ"),
    REG_SRC_TYPE_EO_SELF_READ("REG_SRC_TYPE_EO_SELF_READ"),
    @XmlEnumValue("REG_SRC_TYPE_TBL23")
    REG_SRC_TYPE_TBL_23("REG_SRC_TYPE_TBL23"),
    @XmlEnumValue("REG_SRC_TYPE_TBL24")
    REG_SRC_TYPE_TBL_24("REG_SRC_TYPE_TBL24"),
    @XmlEnumValue("REG_SRC_TYPE_TBL25")
    REG_SRC_TYPE_TBL_25("REG_SRC_TYPE_TBL25"),
    @XmlEnumValue("REG_SRC_TYPE_TBL26")
    REG_SRC_TYPE_TBL_26("REG_SRC_TYPE_TBL26"),
    REG_SRC_TYPE_CURRENT_EOB("REG_SRC_TYPE_CURRENT_EOB"),
    REG_SRC_TYPE_EOB_SELF_READ("REG_SRC_TYPE_EOB_SELF_READ"),
    REG_SRC_TYPE_EOB_DR_READ("REG_SRC_TYPE_EOB_DR_READ"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    RegisterReadSourceEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RegisterReadSourceEnumeration fromValue(String v) {
        for (RegisterReadSourceEnumeration c: RegisterReadSourceEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
