
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AlarmType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AlarmType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;attribute name="IsAlarm" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="IsUserClearable" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="Status" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}AlarmStatusEnum" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlarmType")
public class AlarmType {

    @XmlAttribute(name = "IsAlarm")
    protected Boolean isAlarm;
    @XmlAttribute(name = "IsUserClearable")
    protected Boolean isUserClearable;
    @XmlAttribute(name = "Status")
    protected AlarmStatusEnum status;

    /**
     * Gets the value of the isAlarm property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsAlarm() {
        return isAlarm;
    }

    /**
     * Sets the value of the isAlarm property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsAlarm(Boolean value) {
        this.isAlarm = value;
    }

    /**
     * Gets the value of the isUserClearable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserClearable() {
        return isUserClearable;
    }

    /**
     * Sets the value of the isUserClearable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserClearable(Boolean value) {
        this.isUserClearable = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link AlarmStatusEnum }
     *     
     */
    public AlarmStatusEnum getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlarmStatusEnum }
     *     
     */
    public void setStatus(AlarmStatusEnum value) {
        this.status = value;
    }

}
