package com.coned.ls.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.coned.ls.domain.Meter;
import com.coned.ls.repository.OutageRepository;

@Service
public class RemoteOperationService {
	private static final Logger logger = LoggerFactory.getLogger(RemoteOperationService.class);
	private RestTemplate restTemplate;
	@Autowired
	private OutageRepository outRepo;
	@Autowired
	private Environment env;
	@Autowired
	private NmsTicketService nmsTicketService;

	public RemoteOperationService() {
		restTemplate = new RestTemplate();
	}

	public void processMetersWithNullMacAddr() {
		List<Meter> mList = outRepo.getMetersWithNullMacAddr();
		if (mList.size() > 0) {
			logger.info("List of meters with null mac address [" + mList + "]");

			// get a collection of all the ids.
			List<BigDecimal> ids = mList.stream().map(Meter::getId).collect(Collectors.toList());
			logger.info("List of ids that needs to be marked as Fail [" + ids + "]");

			outRepo.updateMeters(mList, ids);
		}

	}

	public void disconnectMeters() {
		List<Meter> disconnectMetersList = outRepo.getAOCCmeters(false);
		if (disconnectMetersList.size() > 0) {
			logger.info("Disconnect Meter List[" + disconnectMetersList + "]");

			disconnectMetersList.forEach((m) -> {
				logger.info("Request Id : " + m.getRequestId() + ", Event Name : " + m.getEventName());
				invokeDisconect(m, m.getMacAddress());
			});
		}

	}

	// Invoke Disconnect
	private void invokeDisconect(Meter m, String macId) {
		logger.info("Invoke disconnect for meter[" + m.getMeterNumber() + "] with MAC ID[" + macId + "]");
		Object obj = restTemplate.getForObject(env.getProperty("amm_disconnect_meter"), Object.class,
				m.getMeterNumber(), macId);
		logger.info("Job Id for disconnect meter [" + obj + "]");

		int jobId = (int) obj;
		outRepo.saveJob(m.getRequestId(), m.getMeterNumber(), m.getMacAddress(), jobId, 1);

		// Create NMS AMILS outage ticket (configurable, fail-soft)
		nmsTicketService.createAmilsTicketIfRequired(m, jobId);
	}

	public void updateStatus() {
		// logger.info("Verify if all the meters of a request are processed");
		outRepo.updateRequestStatus();
		outRepo.updateRequestStatusForFailedMeters();
	}

	public void connectMeters() {
		List<Meter> connectMetersList = outRepo.getAOCCmeters(Boolean.TRUE);
		if (connectMetersList.size() > 0) {
			logger.info("Connect Meter List[" + connectMetersList + "]");

			connectMetersList.forEach((m) -> {
				logger.info("Request Id : " + m.getRequestId());

				// Invoke Connect
				logger.info(
						"Invoke connect for meter[" + m.getMeterNumber() + "] with MAC ID[" + m.getMacAddress() + "]");

				Object obj = restTemplate.getForObject(env.getProperty("amm_connect_meter"), Object.class,
						m.getMeterNumber(), m.getMacAddress());
				logger.info("Job Id for connect meter [" + obj + "]");

				int jobId = (int) obj;

				outRepo.saveJob(m.getRequestId(), m.getMeterNumber(), m.getMacAddress(), jobId, 2);

			});
		}

	}

}
