
package com.ssn.schema.service.v2_6.eventmanager;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ssn.schema.service.v2_6.eventmanager package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetAlarmStatusResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "GetAlarmStatusResponse");
    private final static QName _FindEvent_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "FindEvent");
    private final static QName _GetSubscriptionStatus_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "GetSubscriptionStatus");
    private final static QName _GetAlarmStatus_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "GetAlarmStatus");
    private final static QName _EditSubscriptionStatus_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "EditSubscriptionStatus");
    private final static QName _FindEventResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "FindEventResponse");
    private final static QName _GetSubscriptionStatusResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "GetSubscriptionStatusResponse");
    private final static QName _EditSubscriptionStatusResponse_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "EditSubscriptionStatusResponse");
    private final static QName _ErrorCodeFault_QNAME = new QName("urn:com:ssn:schema:service:v2.6:EventManager.xsd", "ErrorCodeFault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ssn.schema.service.v2_6.eventmanager
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetSubscriptionStatusReqType }
     * 
     */
    public GetSubscriptionStatusReqType createGetSubscriptionStatusReqType() {
        return new GetSubscriptionStatusReqType();
    }

    /**
     * Create an instance of {@link EditSubscriptionStatusRequestType }
     * 
     */
    public EditSubscriptionStatusRequestType createEditSubscriptionStatusRequestType() {
        return new EditSubscriptionStatusRequestType();
    }

    /**
     * Create an instance of {@link FindEventResponseType }
     * 
     */
    public FindEventResponseType createFindEventResponseType() {
        return new FindEventResponseType();
    }

    /**
     * Create an instance of {@link GetAlarmStatusType }
     * 
     */
    public GetAlarmStatusType createGetAlarmStatusType() {
        return new GetAlarmStatusType();
    }

    /**
     * Create an instance of {@link FindEventReqType }
     * 
     */
    public FindEventReqType createFindEventReqType() {
        return new FindEventReqType();
    }

    /**
     * Create an instance of {@link GetAlarmStatusResponseType }
     * 
     */
    public GetAlarmStatusResponseType createGetAlarmStatusResponseType() {
        return new GetAlarmStatusResponseType();
    }

    /**
     * Create an instance of {@link ErrorCodeFaultType }
     * 
     */
    public ErrorCodeFaultType createErrorCodeFaultType() {
        return new ErrorCodeFaultType();
    }

    /**
     * Create an instance of {@link EmptyType }
     * 
     */
    public EmptyType createEmptyType() {
        return new EmptyType();
    }

    /**
     * Create an instance of {@link GetSubscriptionStatusResponseType }
     * 
     */
    public GetSubscriptionStatusResponseType createGetSubscriptionStatusResponseType() {
        return new GetSubscriptionStatusResponseType();
    }

    /**
     * Create an instance of {@link AlarmType }
     * 
     */
    public AlarmType createAlarmType() {
        return new AlarmType();
    }

    /**
     * Create an instance of {@link EventCategoryType }
     * 
     */
    public EventCategoryType createEventCategoryType() {
        return new EventCategoryType();
    }

    /**
     * Create an instance of {@link SourceType }
     * 
     */
    public SourceType createSourceType() {
        return new SourceType();
    }

    /**
     * Create an instance of {@link CategoryType }
     * 
     */
    public CategoryType createCategoryType() {
        return new CategoryType();
    }

    /**
     * Create an instance of {@link SeverityType }
     * 
     */
    public SeverityType createSeverityType() {
        return new SeverityType();
    }

    /**
     * Create an instance of {@link CountsType }
     * 
     */
    public CountsType createCountsType() {
        return new CountsType();
    }

    /**
     * Create an instance of {@link TimestampType }
     * 
     */
    public TimestampType createTimestampType() {
        return new TimestampType();
    }

    /**
     * Create an instance of {@link EventSubscriptionStatusType }
     * 
     */
    public EventSubscriptionStatusType createEventSubscriptionStatusType() {
        return new EventSubscriptionStatusType();
    }

    /**
     * Create an instance of {@link DefinedAckType }
     * 
     */
    public DefinedAckType createDefinedAckType() {
        return new DefinedAckType();
    }

    /**
     * Create an instance of {@link ParameterType }
     * 
     */
    public ParameterType createParameterType() {
        return new ParameterType();
    }

    /**
     * Create an instance of {@link UIQDeviceStateType }
     * 
     */
    public UIQDeviceStateType createUIQDeviceStateType() {
        return new UIQDeviceStateType();
    }

    /**
     * Create an instance of {@link AckType }
     * 
     */
    public AckType createAckType() {
        return new AckType();
    }

    /**
     * Create an instance of {@link EventLocationType }
     * 
     */
    public EventLocationType createEventLocationType() {
        return new EventLocationType();
    }

    /**
     * Create an instance of {@link EventSearchParametersType }
     * 
     */
    public EventSearchParametersType createEventSearchParametersType() {
        return new EventSearchParametersType();
    }

    /**
     * Create an instance of {@link NonGroupedSortMap }
     * 
     */
    public NonGroupedSortMap createNonGroupedSortMap() {
        return new NonGroupedSortMap();
    }

    /**
     * Create an instance of {@link FindEventResultType }
     * 
     */
    public FindEventResultType createFindEventResultType() {
        return new FindEventResultType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAlarmStatusResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "GetAlarmStatusResponse")
    public JAXBElement<GetAlarmStatusResponseType> createGetAlarmStatusResponse(GetAlarmStatusResponseType value) {
        return new JAXBElement<GetAlarmStatusResponseType>(_GetAlarmStatusResponse_QNAME, GetAlarmStatusResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindEventReqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "FindEvent")
    public JAXBElement<FindEventReqType> createFindEvent(FindEventReqType value) {
        return new JAXBElement<FindEventReqType>(_FindEvent_QNAME, FindEventReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSubscriptionStatusReqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "GetSubscriptionStatus")
    public JAXBElement<GetSubscriptionStatusReqType> createGetSubscriptionStatus(GetSubscriptionStatusReqType value) {
        return new JAXBElement<GetSubscriptionStatusReqType>(_GetSubscriptionStatus_QNAME, GetSubscriptionStatusReqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAlarmStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "GetAlarmStatus")
    public JAXBElement<GetAlarmStatusType> createGetAlarmStatus(GetAlarmStatusType value) {
        return new JAXBElement<GetAlarmStatusType>(_GetAlarmStatus_QNAME, GetAlarmStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EditSubscriptionStatusRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "EditSubscriptionStatus")
    public JAXBElement<EditSubscriptionStatusRequestType> createEditSubscriptionStatus(EditSubscriptionStatusRequestType value) {
        return new JAXBElement<EditSubscriptionStatusRequestType>(_EditSubscriptionStatus_QNAME, EditSubscriptionStatusRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindEventResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "FindEventResponse")
    public JAXBElement<FindEventResponseType> createFindEventResponse(FindEventResponseType value) {
        return new JAXBElement<FindEventResponseType>(_FindEventResponse_QNAME, FindEventResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSubscriptionStatusResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "GetSubscriptionStatusResponse")
    public JAXBElement<GetSubscriptionStatusResponseType> createGetSubscriptionStatusResponse(GetSubscriptionStatusResponseType value) {
        return new JAXBElement<GetSubscriptionStatusResponseType>(_GetSubscriptionStatusResponse_QNAME, GetSubscriptionStatusResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "EditSubscriptionStatusResponse")
    public JAXBElement<EmptyType> createEditSubscriptionStatusResponse(EmptyType value) {
        return new JAXBElement<EmptyType>(_EditSubscriptionStatusResponse_QNAME, EmptyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorCodeFaultType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:com:ssn:schema:service:v2.6:EventManager.xsd", name = "ErrorCodeFault")
    public JAXBElement<ErrorCodeFaultType> createErrorCodeFault(ErrorCodeFaultType value) {
        return new JAXBElement<ErrorCodeFaultType>(_ErrorCodeFault_QNAME, ErrorCodeFaultType.class, null, value);
    }

}
