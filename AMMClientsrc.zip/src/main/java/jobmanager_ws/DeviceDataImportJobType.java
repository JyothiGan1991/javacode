
package jobmanager_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeviceDataImportJobType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeviceDataImportJobType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DeviceMacID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ImportOption" type="{urn:com:ssn:schema:service:v2.5:JobManager.xsd}ImportOptionType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeviceDataImportJobType", propOrder = {
    "deviceMacID",
    "importOption"
})
public class DeviceDataImportJobType {

    @XmlElement(name = "DeviceMacID")
    protected List<String> deviceMacID;
    @XmlElement(name = "ImportOption", required = true)
    protected ImportOptionType importOption;

    /**
     * Gets the value of the deviceMacID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deviceMacID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeviceMacID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeviceMacID() {
        if (deviceMacID == null) {
            deviceMacID = new ArrayList<String>();
        }
        return this.deviceMacID;
    }

    /**
     * Gets the value of the importOption property.
     * 
     * @return
     *     possible object is
     *     {@link ImportOptionType }
     *     
     */
    public ImportOptionType getImportOption() {
        return importOption;
    }

    /**
     * Sets the value of the importOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImportOptionType }
     *     
     */
    public void setImportOption(ImportOptionType value) {
        this.importOption = value;
    }

}
