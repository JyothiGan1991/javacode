package com.coned.jpa.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.coned.model.ExecuteEventList;
import com.coned.model.ExecuteEventListDetails;
import com.coned.model.FinalizedEventList;
import com.coned.model.RejectEventList;
import com.coned.model.FinalizeEventListDetails;
import com.coned.model.RejectEventListDetails;
import com.coned.service.FinalizedEventService;

import com.coned.exception.ResourceMissingException;
import com.coned.jpa.repository.ExecuteEventListDetailsRepository;
import com.coned.jpa.repository.ExecuteEventListRepository;
import com.coned.jpa.repository.FinalizeEventListDetailsRepository;
import com.coned.jpa.repository.FinalizeEventListRepository;
import com.coned.jpa.repository.MeterEventLoadRepository;
import com.coned.jpa.repository.RejectEventListDetailsRepository;
import com.coned.jpa.repository.RejectEventListRepository;

@RestController
@CrossOrigin
@PropertySource("classpath:queries.properties" )
public class FinalizeEventListDetailsController {

	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";
	private static String FINALIZE = "finalize";
	private static String EXECUTE = "execute";
	private static String REJECT = "reject";

	private static final Logger logger = LoggerFactory.getLogger(FinalizeEventListDetailsController.class);

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	@Autowired
	private FinalizeEventListDetailsRepository finRep;
	@Autowired
	private FinalizeEventListRepository finEvtLstRep;

	@Autowired
	private ExecuteEventListDetailsRepository exeRep;

	@Autowired
	private ExecuteEventListRepository exeListRep;

	@Autowired
	private MeterEventLoadRepository metRep;

	@Autowired
	private RejectEventListDetailsRepository rejRep;

	@Autowired
	private RejectEventListRepository rejListRep;

	@Autowired
	FinalizedEventService eventSrv;
	
	@Autowired
	private Environment env;
	
	@PersistenceContext
	private EntityManager em;
	
	
	@GetMapping("/disconnect/events")
	public List getFinalizedEventListDetails() {
		return eventSrv.getFinalizedEventListDetails();
	}

	@GetMapping("/disconnect/events/{id}")
	public ResponseEntity<Map<String, Object>> getFinalizedEventListDetailsById(
			@PathVariable(value = "id") Long eventid) throws ResourceMissingException {
		return eventSrv.getFinalizedEventListDetailsById(eventid);
	}	

	@PostMapping("/disconnect/events")
	@CrossOrigin
	@Transactional
	public Map<String, Object> disconnectEventQ(@RequestBody Map<String, Object> payload)
			throws ResourceMissingException {
		return eventSrv.disconnectEventQ(payload);
	}
}
