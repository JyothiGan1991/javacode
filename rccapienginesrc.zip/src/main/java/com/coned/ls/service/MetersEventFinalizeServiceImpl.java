package com.coned.ls.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.coned.ls.domain.MeterEventFinalize;
import com.coned.ls.exception.MeterFinalizeException;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.repository.MetersEventFinalizeRepository;

/**
 * 
 * Service class for Meters Event Finalize for RCC Disconnect.
 *
 */
@Service("metersEventFinalizeService")
public class MetersEventFinalizeServiceImpl  implements MetersEventFinalizeService{

	@Autowired
	private MetersEventFinalizeRepository  metersEventFinalizeRepository;

	@Override
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeMeterEvent(final MeterEventFinalize meterEventFinalize, final String adid) throws MeterFinalizeException{
		MeterFinalizeResponseMapper finalizeMeterEventList = new MeterFinalizeResponseMapper();
		
		finalizeMeterEventList = metersEventFinalizeRepository.finalizeMeterEvent(meterEventFinalize, adid);
		
		if(finalizeMeterEventList.isResult()){
			finalizeMeterEventList.setMessage("SUCCESS");
			return ResponseEntity.status(HttpStatus.CREATED).body(finalizeMeterEventList);
		}else{
			return ResponseEntity.status(finalizeMeterEventList.getStatusCode()).body(finalizeMeterEventList);
		}
	}
}
