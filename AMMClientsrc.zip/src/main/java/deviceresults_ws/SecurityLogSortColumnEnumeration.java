
package deviceresults_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SecurityLogSortColumnEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SecurityLogSortColumnEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="JobName"/&gt;
 *     &lt;enumeration value="JobID"/&gt;
 *     &lt;enumeration value="DeviceName"/&gt;
 *     &lt;enumeration value="DeviceMacID"/&gt;
 *     &lt;enumeration value="GatewaySerialNumber"/&gt;
 *     &lt;enumeration value="GatewayName"/&gt;
 *     &lt;enumeration value="GatewayCollectedTime"/&gt;
 *     &lt;enumeration value="LastCalibratedTime"/&gt;
 *     &lt;enumeration value="CalibratorName"/&gt;
 *     &lt;enumeration value="LastProgramTime"/&gt;
 *     &lt;enumeration value="ProgrammerName"/&gt;
 *     &lt;enumeration value="ProgramCount"/&gt;
 *     &lt;enumeration value="DemandResetCount"/&gt;
 *     &lt;enumeration value="LastDemandResetTime"/&gt;
 *     &lt;enumeration value="CommSessionCount"/&gt;
 *     &lt;enumeration value="LastCommSessionTime"/&gt;
 *     &lt;enumeration value="BadPasswordCount"/&gt;
 *     &lt;enumeration value="RTPEntryCount"/&gt;
 *     &lt;enumeration value="LastRTPEntryTime"/&gt;
 *     &lt;enumeration value="CumulativePowerOutageSeconds"/&gt;
 *     &lt;enumeration value="PowerOutageCount"/&gt;
 *     &lt;enumeration value="LastPowerOutageTime"/&gt;
 *     &lt;enumeration value="EEPROMWriteCount"/&gt;
 *     &lt;enumeration value="LastTLCUpdateTime"/&gt;
 *     &lt;enumeration value="TLCName"/&gt;
 *     &lt;enumeration value="LastTransInaccAdjustTime"/&gt;
 *     &lt;enumeration value="TransInaccAdjustName"/&gt;
 *     &lt;enumeration value="LastTimeChangeTime"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SecurityLogSortColumnEnumeration")
@XmlEnum
public enum SecurityLogSortColumnEnumeration {

    @XmlEnumValue("JobName")
    JOB_NAME("JobName"),
    @XmlEnumValue("JobID")
    JOB_ID("JobID"),
    @XmlEnumValue("DeviceName")
    DEVICE_NAME("DeviceName"),
    @XmlEnumValue("DeviceMacID")
    DEVICE_MAC_ID("DeviceMacID"),
    @XmlEnumValue("GatewaySerialNumber")
    GATEWAY_SERIAL_NUMBER("GatewaySerialNumber"),
    @XmlEnumValue("GatewayName")
    GATEWAY_NAME("GatewayName"),
    @XmlEnumValue("GatewayCollectedTime")
    GATEWAY_COLLECTED_TIME("GatewayCollectedTime"),
    @XmlEnumValue("LastCalibratedTime")
    LAST_CALIBRATED_TIME("LastCalibratedTime"),
    @XmlEnumValue("CalibratorName")
    CALIBRATOR_NAME("CalibratorName"),
    @XmlEnumValue("LastProgramTime")
    LAST_PROGRAM_TIME("LastProgramTime"),
    @XmlEnumValue("ProgrammerName")
    PROGRAMMER_NAME("ProgrammerName"),
    @XmlEnumValue("ProgramCount")
    PROGRAM_COUNT("ProgramCount"),
    @XmlEnumValue("DemandResetCount")
    DEMAND_RESET_COUNT("DemandResetCount"),
    @XmlEnumValue("LastDemandResetTime")
    LAST_DEMAND_RESET_TIME("LastDemandResetTime"),
    @XmlEnumValue("CommSessionCount")
    COMM_SESSION_COUNT("CommSessionCount"),
    @XmlEnumValue("LastCommSessionTime")
    LAST_COMM_SESSION_TIME("LastCommSessionTime"),
    @XmlEnumValue("BadPasswordCount")
    BAD_PASSWORD_COUNT("BadPasswordCount"),
    @XmlEnumValue("RTPEntryCount")
    RTP_ENTRY_COUNT("RTPEntryCount"),
    @XmlEnumValue("LastRTPEntryTime")
    LAST_RTP_ENTRY_TIME("LastRTPEntryTime"),
    @XmlEnumValue("CumulativePowerOutageSeconds")
    CUMULATIVE_POWER_OUTAGE_SECONDS("CumulativePowerOutageSeconds"),
    @XmlEnumValue("PowerOutageCount")
    POWER_OUTAGE_COUNT("PowerOutageCount"),
    @XmlEnumValue("LastPowerOutageTime")
    LAST_POWER_OUTAGE_TIME("LastPowerOutageTime"),
    @XmlEnumValue("EEPROMWriteCount")
    EEPROM_WRITE_COUNT("EEPROMWriteCount"),
    @XmlEnumValue("LastTLCUpdateTime")
    LAST_TLC_UPDATE_TIME("LastTLCUpdateTime"),
    @XmlEnumValue("TLCName")
    TLC_NAME("TLCName"),
    @XmlEnumValue("LastTransInaccAdjustTime")
    LAST_TRANS_INACC_ADJUST_TIME("LastTransInaccAdjustTime"),
    @XmlEnumValue("TransInaccAdjustName")
    TRANS_INACC_ADJUST_NAME("TransInaccAdjustName"),
    @XmlEnumValue("LastTimeChangeTime")
    LAST_TIME_CHANGE_TIME("LastTimeChangeTime");
    private final String value;

    SecurityLogSortColumnEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SecurityLogSortColumnEnumeration fromValue(String v) {
        for (SecurityLogSortColumnEnumeration c: SecurityLogSortColumnEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
