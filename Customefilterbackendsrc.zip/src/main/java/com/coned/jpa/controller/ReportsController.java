package com.coned.jpa.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class ReportsController {

	private static final Logger logger = LoggerFactory.getLogger(ReportsController.class);

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	@PersistenceContext
	private EntityManager em;

	@PostMapping("/report/events/extfail")
	@CrossOrigin
	public Map<String, Object> getExtFailEvents(@RequestBody Map<String, Object> payload) {
		logger.debug("---------------------- START - getExtFailEvents() ------------------------");
		Map<String, Object> allFailedEvts = new HashMap<String, Object>();
		try {
			String event_name = (String) payload.get("eventName");
			String boro_muni = (String) payload.get("boroMuni");
			
		
			allFailedEvts.put("event_name", event_name);
			allFailedEvts.put("boro_muni", boro_muni);
			

			String qstr = "SELECT COUNT(*) FROM ami_load_shedding.ls_execute_event_list_connect eel WHERE eel.event_name='"+event_name+"' AND eel.boro_muni='"+boro_muni+"'";
			
			logger.debug("qstr? " + qstr);
			int total_meters = ((Number)em.createNativeQuery(qstr).getSingleResult()).intValue();
			logger.info("Failed meter count: "+total_meters);
			allFailedEvts.put("meter_count", total_meters);
			
			/*qstr = "SELECT DISTINCT ms.meter_number, ms.prv_cmd_status, ms.meter_status, "
					+ "exc.execute_time, mel.account_number, mel.building_num, mel.service_address, mel.cust_zip_code "
					+ "FROM AMI_LOAD_SHEDDING.lsb_meter_status_vw ms "
					+ "INNER JOIN AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_DETAILS exc ON exc.event_name = ms.event_name "
					+ "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.meter_number = ms.meter_number "
					+ "WHERE ms.PRV_CMD_STATUS <> 'GMI_RSM_SUCCESS' AND ms.meter_status <> '"+meter_status+"' AND  ms.request_type = "+req_type+" "
					+ "AND ms.event_name='"+eventName+"' AND ms.boro_muni='"+boroMuni+"'";*/
			
			/*
			 * qstr =
			 * "SELECT DISTINCT msv.meter_number, msv.prv_cmd_status AS conn_prv_cmd_status, "
			 * +
			 * "msv.meter_status as conn_meter_status, exc.execute_time AS conn_execute_time, "
			 * +
			 * "mel.account_number, mel.building_num, mel.service_address, mel.cust_zip_code, "
			 * + "disc_prv_cmd_status, disc_meter_status, disc_execute_time   " +
			 * "FROM ami_load_shedding.LSB_METER_STATUS_VW msv  " +
			 * "INNER JOIN ami_load_shedding.LS_EXECUTE_EVENT_LIST_DETAILS exc ON exc.boro_muni = msv.boro_muni AND exc.event_name = msv.event_name AND exc.sub_event = msv.sub_event_name "
			 * +
			 * "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.boro_muni = msv.boro_muni AND mel.event_name = msv.event_name AND mel.meter_number = msv.meter_number "
			 * +
			 * "LEFT JOIN (SELECT msv2.event_name, msv2.boro_muni, msv2.meter_number, msv2.prv_cmd_status AS disc_prv_cmd_status, "
			 * +
			 * "msv2.meter_status AS disc_meter_status, exc2.execute_time as disc_execute_time "
			 * + "FROM ami_load_shedding.LSB_METER_STATUS_VW msv2 " +
			 * "INNER JOIN ami_load_shedding.LS_EXECUTE_EVENT_LIST_DETAILS exc2 ON exc2.event_name = msv2.event_name "
			 * + "WHERE msv2.request_type IN ("+opp_req_type+") AND exc2.event_type='"
			 * +opp_event_type+"') sq " + "ON sq.event_name=mel.event_name " +
			 * "AND sq.boro_muni=mel.boro_muni AND sq.meter_number = mel.meter_number " +
			 * "WHERE msv.req_status <> 'C' " +
			 * "AND msv.request_type IN ("+req_type+") AND exc.event_type='"
			 * +event_type+"' AND " +
			 * "msv.event_name='"+event_name+"' AND msv.boro_muni='"+boro_muni+"'";
			 */
	

			qstr = "SELECT lmct.meter_number, "
					+ "'' AS conn_prv_cmd_status, "
					+ "'' AS conn_meter_status, "
					+ "CAST(lmct.result_time AS DATE), "
					+ "lve.account_number, "
					+ "lve.building_num, "
					+ "lve.service_address, "
					+ "lve.cust_zip_code,  "
					+ "'' AS disc_prv_cmd_status, "
					+ "'' AS disc_meter_status, "
					+ "CAST(sq.LAST_UPDATE_TIME AS DATE) as disc_execute_time  "
					+ "FROM AMI_LOAD_SHEDDING.LSB_CONN_JOB LMCT  "
					+ "LEFT JOIN AMI_LOAD_SHEDDING.LSB_EVT_RESPONSE LER ON LMCT.JOB_ID = LER.JOB_ID AND UPPER(LMCT.MAC_ID) = UPPER(LER.MAC_ID) AND LER.event_id='300043'  "
					+ "JOIN AMI_LOAD_SHEDDING.ls_validate_event_list lve ON lve.boro_muni = LMCT.boro_muni AND lve.event_name = LMCT.event_name  "
					+ "AND lve.meter_number = LMCT.meter_number  "
					+ "left JOIN (select METER_NUMBER, LAST_UPDATE_TIME from AMI_LOAD_SHEDDING.LSB_DISCONNECT_METERS  "
					+ "where request_idx =( select MIN(REQUEST_IDX) from AMI_LOAD_SHEDDING.lsb_disconnect_requests where event_name='"+event_name+"') )sq  "
					+ "ON sq.meter_number = LMCT.meter_number "
					+ "WHERE LMCT.event_name='"+event_name+"' and lmct.boro_muni='"+boro_muni+"'  and LER.event_code is null and lmct.status is null "
					+ "order by meter_number";
			
			logger.debug("qstr? " + qstr);
			Query q = em.createNativeQuery(qstr);
			List<Object[]> rows = q.getResultList();
			
			logger.info("result" + rows);
		
			logger.info("Total_Exe_Meters:"+total_meters+ "NumOfFailedMeters ? " + rows.size());			
			allFailedEvts.put("exception_count", rows.size());
			
			List<Map<String, Object>> result = new ArrayList<>(rows.size());
			for (Object[] row : rows) {
				
				Map<String, Object> events = new HashMap<String, Object>();
				events.put("meter_number", (String) row[0]);
				events.put("prv_cmd_status", (String) row[1]);
				events.put("meter_status", (String) row[2]);

				Date executeTime = (Date) row[3];
				String executeTimeStr = "";
				if (executeTime != null)
					executeTimeStr = executeTime.toString();

				events.put("execute_time", executeTimeStr);
				events.put("account_number", (String) row[4]);
				events.put("building_num", (String) row[5]);

				events.put("service_address", (String) row[6]);
				events.put("cust_zip_code", (String) row[7]);
				
				events.put("disc_prv_cmd_status", (String) row[8]);
				events.put("disc_meter_status", (String) row[9]);
				executeTime = (Date) row[10];
				executeTimeStr = "";
				if (executeTime != null)
					executeTimeStr = executeTime.toString();
				events.put("disc_execute_time", executeTimeStr);
				
				events = replaceNullValues(events, "");
				result.add(events);
			}
			allFailedEvts.put("meters", result);
			logger.info(" -- users size: " + rows.size());
			return allFailedEvts;
		} catch (Exception e) {
			logger.error("**Exception getExtFailEvents(): " , e);
		}
		return allFailedEvts;
	}
	
	public static <T, K> Map<K, T> replaceNullValues(Map<K, T> map, T defaultValue) {
		  
        map = map.entrySet()
                  .stream()
                  .map(entry -> {
                      if (entry.getValue() == null)
                          entry.setValue(defaultValue);
                      return entry;
                  })
                  .collect(Collectors.toMap(Map.Entry::getKey,
                                            Map.Entry::getValue));
        return map;
    }
	
	
	@GetMapping("/report/events")
	@CrossOrigin
	public List<Map> getConnectFailedEvents() {
		logger.debug("---------------------- START - getConnectFailedEvents() ------------------------");
		try {
			/*
			 * String qstr = "SELECT DISTINCT msv.boro_muni, msv.event_name " +
			 * "FROM AMI_LOAD_SHEDDING.lsb_meter_status_vw msv " +
			 * "INNER JOIN AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_DETAILS exc ON exc.boro_muni = msv.boro_muni AND exc.event_name = msv.event_name "
			 * // +
			 * "INNER JOIN AMI_LOAD_SHEDDING.ls_execute_event_list_connect elc ON elc.boro_muni = msv.boro_muni AND elc.event_name = msv.event_name "
			 * // +
			 * "INNER JOIN ami_load_shedding.LS_METER_EVENT_LOAD mel ON mel.boro_muni = msv.boro_muni  AND mel.event_name = msv.event_name AND mel.meter_number = msv.meter_number "
			 * +
			 * "WHERE msv.req_status <> 'C' AND msv.request_type IN (2) AND exc.event_type='C' "
			 * + "Order by msv.boro_muni";
			 */

			String qstr = "SELECT distinct boro_muni, event_name "
					+ "FROM AMI_LOAD_SHEDDING.LS_EXECUTE_EVENT_LIST_DETAILS "
					+ "WHERE event_type='C' AND EXECUTE_TIME >= current_timestamp - 15 "
					+ "Order by boro_muni, event_name";

			logger.debug("qstr? " + qstr);
			Query q = em.createNativeQuery(qstr);
			List<Object[]> rows = q.getResultList();
			logger.debug("NumOfFailedEvents ? " + rows.size());
			
			Map allFailedEvts = new HashMap();
			List<Map<String, Object>> result = new ArrayList<>(rows.size());
			for (Object[] row : rows) {
				Map<String, Object> events = new HashMap<String, Object>();
				events.put("boro", (String) row[0]);
				Map<String, String> evn = new HashMap<String, String>();
				evn.put("eventName", (String) row[1]);
				events.put("eventinfo", evn);
				result.add(events);
			}
			Map<String, List<Object>> byEventList = result.stream()
				    .collect(Collectors.groupingBy(map -> map.get("boro").toString(),
				                                   Collectors.mapping(map -> map.get("eventinfo"),
				                                                      Collectors.toList())));
			
			String[] keys = new String[byEventList.size()];
			Object[] values = new Object[byEventList.size()];
			int index = 0;
			List<Map> allevents = new ArrayList<Map>();
			Map<String, Object> map = new HashMap<String, Object>();
			for (Entry<String, List<Object>> mapEntry : byEventList.entrySet()) {
				map = new HashMap<String, Object>();
				keys[index] = mapEntry.getKey();
				map.put("boroughName", keys[index]);
				values[index] = mapEntry.getValue();
				map.put("events", values[index]);
				allevents.add(map);
				index++;
			}
			
			logger.debug(" -- users size: " + rows.size());
			logger.debug("---------------------- END - getConnectFailedEvents() ------------------------");
			return allevents;
		} catch (Exception e) {
			logger.debug("**Exception getConnectFailedEvents() - " + e);
		}
		return null;
	}
}

/*
 * logger.debug(((BigDecimal) row[0]).intValue() + "" + (String) row[1] + "" +
 * ((BigDecimal) row[2]).intValue() + " " + (String) row[3]); int userId =
 * ((BigDecimal) row[0]).intValue(); int isActive = ((BigDecimal)
 * row[2]).intValue(); String isActiveStr = "Active"; if (isActive != 1)
 * isActiveStr = "InActive"; String roleName = (String) row[3]; String createdBy
 * = ""; if (row[4] != null) createdBy = (String) row[4];
 * 
 * Date createdAt = (Date) row[6]; String createdAtStr = ""; if (createdAt !=
 * null) createdAtStr = createdAt.toString();
 * 
 * String updatedBy = ""; if (row[5] != null) createdBy = (String) row[5];
 * 
 * Date updatedAt = (Date) row[7]; String updatedAtStr = ""; if (updatedAt !=
 * null) updatedAtStr = updatedAt.toString();
 */
