
package deviceresults_ws;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CoincidenceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoincidenceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="uom" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="uomDescription" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CoincidenceIEEExportChannelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="DemandRegisterNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="Number" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoincidenceType", propOrder = {
    "value",
    "uom",
    "uomDescription",
    "coincidenceIEEExportChannelID"
})
public class CoincidenceType {

    @XmlElement(required = true)
    protected BigDecimal value;
    @XmlElement(required = true)
    protected String uom;
    @XmlElement(required = true)
    protected String uomDescription;
    @XmlElement(name = "CoincidenceIEEExportChannelID")
    protected String coincidenceIEEExportChannelID;
    @XmlAttribute(name = "DemandRegisterNumber", required = true)
    protected int demandRegisterNumber;
    @XmlAttribute(name = "Number", required = true)
    protected int number;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValue(BigDecimal value) {
        this.value = value;
    }

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUom() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUom(String value) {
        this.uom = value;
    }

    /**
     * Gets the value of the uomDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUomDescription() {
        return uomDescription;
    }

    /**
     * Sets the value of the uomDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUomDescription(String value) {
        this.uomDescription = value;
    }

    /**
     * Gets the value of the coincidenceIEEExportChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoincidenceIEEExportChannelID() {
        return coincidenceIEEExportChannelID;
    }

    /**
     * Sets the value of the coincidenceIEEExportChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoincidenceIEEExportChannelID(String value) {
        this.coincidenceIEEExportChannelID = value;
    }

    /**
     * Gets the value of the demandRegisterNumber property.
     * 
     */
    public int getDemandRegisterNumber() {
        return demandRegisterNumber;
    }

    /**
     * Sets the value of the demandRegisterNumber property.
     * 
     */
    public void setDemandRegisterNumber(int value) {
        this.demandRegisterNumber = value;
    }

    /**
     * Gets the value of the number property.
     * 
     */
    public int getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     */
    public void setNumber(int value) {
        this.number = value;
    }

}
