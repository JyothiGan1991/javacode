
package com.coned.ls.repository;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import com.coned.ls.domain.Meter;

@Repository
// @Configuration
@PropertySource(value = { "classpath:queries.properties" })
public class OutageRepository {

	// TODO - HIMA - Change the class name
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Environment env;

	private JdbcTemplate jdbcTemplate;

	private TransactionTemplate txTemplate;

	private DataSource datasource;

	@Autowired
	private void setDataSource(DataSource datasource) {
		this.datasource = datasource;
		this.jdbcTemplate = new JdbcTemplate(datasource);
		this.txTemplate = new TransactionTemplate(new DataSourceTransactionManager(datasource));
	}

	public TransactionTemplate getTxTemplate() {
		return txTemplate;
	}

	private NamedParameterJdbcTemplate getNamedParamTemplate() {
		return new NamedParameterJdbcTemplate(datasource);
	}

	public List<Meter> getAOCCmeters(Boolean isConnect) {
		return jdbcTemplate.query((isConnect) ? env.getProperty("GET_AOCC_CONNECT_METERS")
				: env.getProperty("GET_AOCC_DISCONNECT_METERS"), new MeterRowMapper());
	}

	/*
	 * return jdbcTemplate.query( (isConnect) ?
	 * env.getProperty("GET_AOCC_CONNECT_METERS") :
	 * env.getProperty("GET_AOCC_DISCONNECT_METERS"), new
	 * ResultSetExtractor<Map<BigDecimal, List<String>>>() {
	 * 
	 * @Override public Map<BigDecimal, List<String>> extractData(ResultSet rs)
	 * throws SQLException, DataAccessException { Map<BigDecimal, List<String>>
	 * meterMap = new HashMap<>(); while (rs.next()) { BigDecimal eventName =
	 * rs.getBigDecimal("REQUEST_IDX"); // BigDecimal meterNumber = //
	 * rs.getBigDecimal("METER_NUMBER"); String meterNumber =
	 * rs.getString("METER_NUMBER"); List<String> metersList =
	 * meterMap.get(eventName); if (metersList == null) { List<String> newmeters
	 * = new ArrayList<>(); newmeters.add(meterNumber); meterMap.put(eventName,
	 * newmeters); } else { meterMap.get(eventName).add(meterNumber); } } return
	 * meterMap; } });
	 */

	public int updateMeterStatus(BigDecimal reqId, String meter, String macId, String status) {
		return jdbcTemplate.update(env.getProperty("UPDATE_METER_STATUS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setString(1, macId);
				stmt.setString(2, status);
				stmt.setBigDecimal(3, reqId);
				stmt.setString(4, meter);
			}
		});
	}

	public int saveJobId(BigDecimal reqId, String meter, String macId, long jobId, int reqType) {
		return jdbcTemplate.update(env.getProperty("SAVE_JOB_ID"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, reqId);
				stmt.setInt(2, reqType);
				stmt.setString(3, meter);
				stmt.setString(4, macId);
				stmt.setLong(5, jobId);

			}
		});
	}

	@Transactional(rollbackFor = { SQLException.class, Exception.class })
	public void saveJob(BigDecimal reqId, String meter, String macId, long jobId, int reqType) {

		int rows = updateMeterStatus(reqId, meter, macId, "I");
		logger.info("Successfully updated [" + rows + "] records in AMI_LOAD_SHEDDING.LSB_AOCC_METERS table.");

		int jobRows = saveJobId(reqId, meter, macId, jobId, reqType);
		logger.info("Successfully inserted [" + jobRows + "] records to AMI_LOAD_SHEDDING.LSB_JOB_STATUS table.");

		int eventRows = updateEventStatus(reqId);
		logger.info("Successfully updated [" + eventRows + "] records in AMI_LOAD_SHEDDING.LSB_AOCC_REQUESTS table.");

	}

	protected int updateEventStatus(BigDecimal reqId) {
		return jdbcTemplate.update(env.getProperty("UPDATE_EVENT_STATUS"), new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
				stmt.setBigDecimal(1, reqId);
			}
		});
	}

	public void updateRequestStatus() {
		int rows = jdbcTemplate.update(env.getProperty("UPDATE_REQ_STATUS"));
		if (rows > 0) {
			logger.info("Successfully marked [" + rows
					+ "] records as Complete in AMI_LOAD_SHEDDING.LSB_AOCC_REQUESTS table.");
		} else {
			// logger.info("No records to update");
		}
	}

	public void updateRequestStatusForFailedMeters() {
		int rows = jdbcTemplate.update(env.getProperty("UPDATE_REQ_STATUS_FOR_FAILED_METERS"));
		if (rows > 0) {
			logger.info("Successfully marked [" + rows
					+ "] records as Failed in AMI_LOAD_SHEDDING.LSB_AOCC_REQUESTS table.");
		}
	}

	public List<Meter> getMetersWithNullMacAddr() {
		return jdbcTemplate.query(env.getProperty("GET_METERS_WITH_NULL_MACID"), new EventRowMapper());
	}

	@Transactional(rollbackFor = { SQLException.class, Exception.class })
	public void updateMeters(List<Meter> mList, List<BigDecimal> ids) {

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("ids", ids);

		int updatedRows = getNamedParamTemplate().update(env.getProperty("UPDATE_METER_STATUS_TO_FAIL"), params);

		if (updatedRows > 0) {
			logger.info("Successfully marked [" + updatedRows
					+ "] records as Failed in AMI_LOAD_SHEDDING.LSB_AOCC_METERS table.");
		}

		int[] batchupdatedRows = jdbcTemplate.batchUpdate(env.getProperty("SAVE_METER_STATUS"),
				new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, mList.get(i).getEventName());
						ps.setString(2, mList.get(i).getBoro());
						ps.setInt(3, mList.get(i).getRequestType());
						ps.setString(4, mList.get(i).getMeterNumber());
					}

					@Override
					public int getBatchSize() {
						return mList.size();
					}

				});

		if (batchupdatedRows.length > 0) {
			logger.info("Successfully inserted [" + batchupdatedRows.length
					+ "] records to AMI_LOAD_SHEDDING.LSB_METER_STATUS table.");
		}

		/*
		 * if (!((mList.size() == updatedRows) && (mList.size() ==
		 * batchupdatedRows.length))) { logger.
		 * error("Roll back the transaction as the number of rows updated and inserted are not same."
		 * ); try { throw new SQLException(
		 * "Rolling back the transaction as the number of rows updated and inserted are not same."
		 * ); } catch (Exception e) { logger.error } }
		 */
	}

}
