package com.coned.jpa.controller;

import java.util.Hashtable;

import javax.management.Descriptor;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserMgmtHelper {

	private static final Logger logger = LoggerFactory.getLogger(UserMgmtController.class);

	// The attribute you want to read (for a specific user)
	private static final String ATTRIBUTE_NAME = "pwdChangedTime";

	// The Class of the configured Authenticator Provider, here it is OID
	// Check the API if you use something else
	// API Docs:
	// http://docs.oracle.com/cd/E12839_01/apirefs.1111/e13945/weblogic/security/providers/authentication/OracleInternetDirectoryAuthenticatorMBean.html
	final String OID_AUTHENTICATOR_MBEAN_NAME = "weblogic.security.providers.authentication.OracleInternetDirectoryAuthenticatorMBean";

	// The rest here should be static and stay unchanged
	private static final String COM_SUN_JNDI_LDAP_LDAP_CTX_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
	private static final String INTERFACE_CLASS_NAME = "interfaceClassName";
	private static final String AUTHENTICATION_PROVIDERS = "AuthenticationProviders";
	private static final String DEFAULT_REALM = "DefaultRealm";
	private static final String SECURITY_CONFIGURATION = "SecurityConfiguration";
	private static final String DOMAIN_CONFIGURATION = "DomainConfiguration";
	final String MBEAN_SERVER = "java:comp/env/jmx/domainRuntime";
	final String DOMAIN_MBEAN_NAME = "com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";

	public String getAttribute(String username, String password) {
		logger.debug("--- START - getAttribute() ---");
		final MBeanServer connection = getConnection();
		final ObjectName defaultAuthenticator = getAuthenticator(connection);

		String rest = null;
		try {
			/*String host = getHost(defaultAuthenticator, connection);
			String port = getPort(defaultAuthenticator, connection);
			logger.debug("host? "+host+" port? "+port);*/
			String host = "localhost";
			String port = "7001";
			String userBaseDN = getUserBaseDN(defaultAuthenticator, connection);
			DirContext ctx = getConnectionLdapOid(username, password, host, port, userBaseDN);
			rest = getAttribute(ctx, "cn=" + username + "," + userBaseDN, username);
		} catch (Exception ref) {
			logger.error("**Exception - getAttribute(): "+ref);
		}
		logger.debug("--- END - getAttribute() ---");
		return rest;
	}

	private MBeanServer getConnection() {
		logger.debug("--- START - getConnection() ---");
		MBeanServer connection;
		try {
			InitialContext ctx = new InitialContext();
			connection = (MBeanServer) ctx.lookup(MBEAN_SERVER);
		} catch (Exception e) {
			logger.error("**Exception - getConnection(): "+e);
			throw new RuntimeException(e);
		}
		logger.debug("--- END - getConnection() ---");
		return connection;
	}

	private ObjectName getAuthenticator(MBeanServer connection) {
		logger.debug("--- START - getAuthenticator() ---");
		ObjectName authenticator = null;
		ObjectName[] authenticationProviders;
		try {
			ObjectName configurationMBeans = new ObjectName(DOMAIN_MBEAN_NAME);
			ObjectName domain = (ObjectName) connection.getAttribute(configurationMBeans, DOMAIN_CONFIGURATION);

			ObjectName security = (ObjectName) connection.getAttribute(domain, SECURITY_CONFIGURATION);

			ObjectName realm = (ObjectName) connection.getAttribute(security, DEFAULT_REALM);

			authenticationProviders = (ObjectName[]) connection.getAttribute(realm, AUTHENTICATION_PROVIDERS);

			for (int p = 0; p < authenticationProviders.length; p++) {

				ModelMBeanInfo info = (ModelMBeanInfo) connection.getMBeanInfo(authenticationProviders[p]);
				Descriptor desc = info.getMBeanDescriptor();
				String className = (String) desc.getFieldValue(INTERFACE_CLASS_NAME);

				if (className.equals(OID_AUTHENTICATOR_MBEAN_NAME)) {
					authenticator = authenticationProviders[p];
					break;
				}
			}

		} catch (Exception e) {
			logger.error("**Exception - getAttribute(): "+e);
		}
		logger.debug("--- END - getAuthenticator() ---");
		return authenticator;
	}

	private DirContext getConnectionLdapOid(String username, String password, String host, String port,
			String userBaseDN) throws NamingException {
		logger.debug("--- START - getConnectionLdapOid() ---");
		Hashtable<String, String> jndiProps = new Hashtable<String, String>();
		jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, COM_SUN_JNDI_LDAP_LDAP_CTX_FACTORY);
		jndiProps.put(Context.PROVIDER_URL, "ldap://" + host + ":" + port);
		jndiProps.put(Context.SECURITY_AUTHENTICATION, "simple");
		jndiProps.put(Context.SECURITY_PRINCIPAL, "cn=" + username + "," + userBaseDN);
		jndiProps.put(Context.SECURITY_CREDENTIALS, password);
		DirContext ctx = new InitialDirContext(jndiProps);
		logger.debug("--- START - getConnectionLdapOid() ---");
		return ctx;
	}

	private String getHost(ObjectName defaultAuthenticator, MBeanServer connection) throws Exception {
		String result = (String) connection.getAttribute(defaultAuthenticator, "Host");
		return result;
	}

	private String getPort(ObjectName defaultAuthenticator, MBeanServer connection) throws Exception {
		String result = ((Integer) connection.getAttribute(defaultAuthenticator, "Port")).toString();
		return result;
	}

	private String getUserBaseDN(ObjectName defaultAuthenticator, MBeanServer connection) throws Exception {
		String result = (String) connection.getAttribute(defaultAuthenticator, "UserBaseDN");
		return result;
	}

	@SuppressWarnings("rawtypes")
	public static String getAttribute(DirContext ctx, String DN, String user) {
		logger.debug("--- START - getAttribute(DirContext ctx, String DN, String user) ---");
		String attrName, attrValue = "";
		String result = null;
		try {
			SearchControls ctls = new SearchControls();
			ctls.setSearchScope(SearchControls.OBJECT_SCOPE);
			ctls.setReturningAttributes(new String[0]);
			NamingEnumeration sre = null;
			sre = ctx.search(DN, "cn=" + user, ctls);
			if (!(sre != null && sre.hasMoreElements())) {
				return null;
			}
			Attributes attrs = null;
			String returnAttrs[] = { ATTRIBUTE_NAME };
			attrs = ctx.getAttributes(DN, returnAttrs);
			NamingEnumeration enu = attrs.getAll();
			if ((enu != null) && enu.hasMore()) {
				Attribute attr = (Attribute) enu.next();
				attrName = attr.getID();
				NamingEnumeration attrValues = attr.getAll();
				if (attrValues.hasMore()) {
					attrValue = (String) attrValues.next();
				}
			}
			result = attrValue;
		} catch (NamingException e) {
			logger.error("**Exception - getAttribute(DirContext ctx, String DN, String user): "+e);
		}
		logger.debug("--- END - getAttribute(DirContext ctx, String DN, String user) ---");
		return result;
	}
}