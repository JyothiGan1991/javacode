package com.coned.ls.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.coned.ls.domain.OpenEvent;


public class OpenEventRowMapper implements RowMapper<OpenEvent>{

	@Override
	public OpenEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		OpenEvent openEvent = new OpenEvent();
		
		openEvent.setBorough(rs.getString("boro_muni"));
		openEvent.setEvent(rs.getString("event_name"));
		
		return openEvent;
	}
	
	
}
