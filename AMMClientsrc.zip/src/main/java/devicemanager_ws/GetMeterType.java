
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetMeterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetMeterType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MeterType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MeterTypeConfig" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MeterTypeConfig" minOccurs="0"/&gt;
 *         &lt;element name="RemoteProvisioning" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="PrePayModeStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="DemandLimitModeStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="SwitchLockoutStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="BoostStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="IgnoreTamperDetectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="DoorSensorStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="TamperStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="ESCCActivationStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="ESCCEnableStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="LC1ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="LC2ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType"/&gt;
 *         &lt;element name="MismatchedProgram" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}MismatchedProgramType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetMeterType", propOrder = {
    "meterTypeConfig",
    "remoteProvisioning",
    "prePayModeStatus",
    "demandLimitModeStatus",
    "switchLockoutStatus",
    "boostStatus",
    "ignoreTamperDetectionStatus",
    "doorSensorStatus",
    "tamperStatus",
    "esccActivationStatus",
    "esccEnableStatus",
    "lc1ConnectionStatus",
    "lc2ConnectionStatus",
    "mismatchedProgram"
})
public class GetMeterType
    extends MeterType
{

    @XmlElement(name = "MeterTypeConfig")
    protected MeterTypeConfig meterTypeConfig;
    @XmlElement(name = "RemoteProvisioning")
    protected Boolean remoteProvisioning;
    @XmlElement(name = "PrePayModeStatus", required = true)
    protected RemoteProvisioningModeStatusType prePayModeStatus;
    @XmlElement(name = "DemandLimitModeStatus", required = true)
    protected RemoteProvisioningModeStatusType demandLimitModeStatus;
    @XmlElement(name = "SwitchLockoutStatus", required = true)
    protected RemoteProvisioningModeStatusType switchLockoutStatus;
    @XmlElement(name = "BoostStatus", required = true)
    protected RemoteProvisioningModeStatusType boostStatus;
    @XmlElement(name = "IgnoreTamperDetectionStatus", required = true)
    protected RemoteProvisioningModeStatusType ignoreTamperDetectionStatus;
    @XmlElement(name = "DoorSensorStatus", required = true)
    protected RemoteProvisioningModeStatusType doorSensorStatus;
    @XmlElement(name = "TamperStatus", required = true)
    protected RemoteProvisioningModeStatusType tamperStatus;
    @XmlElement(name = "ESCCActivationStatus", required = true)
    protected RemoteProvisioningModeStatusType esccActivationStatus;
    @XmlElement(name = "ESCCEnableStatus", required = true)
    protected RemoteProvisioningModeStatusType esccEnableStatus;
    @XmlElement(name = "LC1ConnectionStatus", required = true)
    protected RemoteProvisioningModeStatusType lc1ConnectionStatus;
    @XmlElement(name = "LC2ConnectionStatus", required = true)
    protected RemoteProvisioningModeStatusType lc2ConnectionStatus;
    @XmlElement(name = "MismatchedProgram")
    protected MismatchedProgramType mismatchedProgram;

    /**
     * Gets the value of the meterTypeConfig property.
     * 
     * @return
     *     possible object is
     *     {@link MeterTypeConfig }
     *     
     */
    public MeterTypeConfig getMeterTypeConfig() {
        return meterTypeConfig;
    }

    /**
     * Sets the value of the meterTypeConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterTypeConfig }
     *     
     */
    public void setMeterTypeConfig(MeterTypeConfig value) {
        this.meterTypeConfig = value;
    }

    /**
     * Gets the value of the remoteProvisioning property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRemoteProvisioning() {
        return remoteProvisioning;
    }

    /**
     * Sets the value of the remoteProvisioning property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRemoteProvisioning(Boolean value) {
        this.remoteProvisioning = value;
    }

    /**
     * Gets the value of the prePayModeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getPrePayModeStatus() {
        return prePayModeStatus;
    }

    /**
     * Sets the value of the prePayModeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setPrePayModeStatus(RemoteProvisioningModeStatusType value) {
        this.prePayModeStatus = value;
    }

    /**
     * Gets the value of the demandLimitModeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getDemandLimitModeStatus() {
        return demandLimitModeStatus;
    }

    /**
     * Sets the value of the demandLimitModeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setDemandLimitModeStatus(RemoteProvisioningModeStatusType value) {
        this.demandLimitModeStatus = value;
    }

    /**
     * Gets the value of the switchLockoutStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getSwitchLockoutStatus() {
        return switchLockoutStatus;
    }

    /**
     * Sets the value of the switchLockoutStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setSwitchLockoutStatus(RemoteProvisioningModeStatusType value) {
        this.switchLockoutStatus = value;
    }

    /**
     * Gets the value of the boostStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getBoostStatus() {
        return boostStatus;
    }

    /**
     * Sets the value of the boostStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setBoostStatus(RemoteProvisioningModeStatusType value) {
        this.boostStatus = value;
    }

    /**
     * Gets the value of the ignoreTamperDetectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getIgnoreTamperDetectionStatus() {
        return ignoreTamperDetectionStatus;
    }

    /**
     * Sets the value of the ignoreTamperDetectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setIgnoreTamperDetectionStatus(RemoteProvisioningModeStatusType value) {
        this.ignoreTamperDetectionStatus = value;
    }

    /**
     * Gets the value of the doorSensorStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getDoorSensorStatus() {
        return doorSensorStatus;
    }

    /**
     * Sets the value of the doorSensorStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setDoorSensorStatus(RemoteProvisioningModeStatusType value) {
        this.doorSensorStatus = value;
    }

    /**
     * Gets the value of the tamperStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getTamperStatus() {
        return tamperStatus;
    }

    /**
     * Sets the value of the tamperStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setTamperStatus(RemoteProvisioningModeStatusType value) {
        this.tamperStatus = value;
    }

    /**
     * Gets the value of the esccActivationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getESCCActivationStatus() {
        return esccActivationStatus;
    }

    /**
     * Sets the value of the esccActivationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setESCCActivationStatus(RemoteProvisioningModeStatusType value) {
        this.esccActivationStatus = value;
    }

    /**
     * Gets the value of the esccEnableStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getESCCEnableStatus() {
        return esccEnableStatus;
    }

    /**
     * Sets the value of the esccEnableStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setESCCEnableStatus(RemoteProvisioningModeStatusType value) {
        this.esccEnableStatus = value;
    }

    /**
     * Gets the value of the lc1ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getLC1ConnectionStatus() {
        return lc1ConnectionStatus;
    }

    /**
     * Sets the value of the lc1ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setLC1ConnectionStatus(RemoteProvisioningModeStatusType value) {
        this.lc1ConnectionStatus = value;
    }

    /**
     * Gets the value of the lc2ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getLC2ConnectionStatus() {
        return lc2ConnectionStatus;
    }

    /**
     * Sets the value of the lc2ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setLC2ConnectionStatus(RemoteProvisioningModeStatusType value) {
        this.lc2ConnectionStatus = value;
    }

    /**
     * Gets the value of the mismatchedProgram property.
     * 
     * @return
     *     possible object is
     *     {@link MismatchedProgramType }
     *     
     */
    public MismatchedProgramType getMismatchedProgram() {
        return mismatchedProgram;
    }

    /**
     * Sets the value of the mismatchedProgram property.
     * 
     * @param value
     *     allowed object is
     *     {@link MismatchedProgramType }
     *     
     */
    public void setMismatchedProgram(MismatchedProgramType value) {
        this.mismatchedProgram = value;
    }

}
