/**
 * 
 */
package com.coned.odsListener.publisher;

import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.coned.odsListener.model.ODSEvent;
import com.conor.schema.ArrayOfOutageDetectionEvent;
import com.conor.schema.ODEventNotification;
import com.conor.schema.OutageDetectDeviceType;
import com.conor.schema.OutageDetectionEvent;
import com.conor.schema.OutageEventType;

/**
 * @author DATHATHRIA
 *
 */
@Service("ceconyRestoreQueuePublisher")
public class CeconyRestoreQueuePublisher implements MessagePublisher {
	private static Logger logger = LoggerFactory.getLogger(CeconyRestoreQueuePublisher.class);
	
	@Autowired
	private Environment env;
	
	@Autowired
	protected Marshaller jaxbMarshaller;
	
	@Autowired
	@Qualifier("ceconyRestoreJmsTemplate")
	private JmsTemplate ceconyRestoreJmsTemplate;

	/* (non-Javadoc)
	 * @see com.coned.odsListener.publisher.MessagePublisher#publishMessage(java.util.List)
	 */
	@Override
	public void publishMessage(List<ODSEvent> listOfCeconyRestoreEvents) {
		long startTime = System.nanoTime();
		ODEventNotification odEventNotification = convertToODEventNotification(listOfCeconyRestoreEvents);
		Integer numberOfEventsToPublish = odEventNotification.getODEvents().getOutageDetectionEvent().size();
		
		if (numberOfEventsToPublish > 0) {
			String queueName = env.getProperty("cecony.oms.restore.queue");
			logger.info("Publishing [" + numberOfEventsToPublish + "] messages to [" + queueName + "] queue");

			try {
				StringWriter sw = new StringWriter();
				jaxbMarshaller.marshal(odEventNotification, sw);
				String xmlString = sw.toString();
				logger.info("[" + xmlString + "]");
				ceconyRestoreJmsTemplate.convertAndSend(queueName, xmlString);
				logger.info("Published " + numberOfEventsToPublish + " messages to queue");
			} catch (JAXBException e) {
				logger.error("JAXB Exception: Error while marshaling: " + e);
			} catch (JmsException jmsEx) {
				logger.error("JMS Exception: Error while sending message to [" + queueName + "] queue: " + jmsEx);
			} catch (Exception ex) {
				logger.error("Error while sending message to [" + queueName + "] queue: " + ex);
			}

			long endTime = System.nanoTime();
			long durationInMillis = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
			logger.info("Time taken to publish to Cecony queue in milliseconds is: " + durationInMillis);
		}
	}
	
	private ODEventNotification convertToODEventNotification(List<ODSEvent> listOfCeconyRestoreEvents) {
		ODEventNotification odEventNotification = new ODEventNotification();
		ArrayOfOutageDetectionEvent array = new ArrayOfOutageDetectionEvent();
		
		for (ODSEvent odsEvent : listOfCeconyRestoreEvents) {
			OutageDetectionEvent odEvent = new OutageDetectionEvent();
			odEvent.setUtility("CECONY");
			odEvent.setEventTime(odsEvent.getEventTime());
			odEvent.setOutageEventType(OutageEventType.RESTORATION);
			odEvent.setOutageDetectionDeviceID(odsEvent.getDeviceUtilId());
			odEvent.setOutageDetectionDeviceType(OutageDetectDeviceType.METER);
			
			array.getOutageDetectionEvent().add(odEvent);
		}
		odEventNotification.setODEvents(array);
		return odEventNotification;
	}

}
