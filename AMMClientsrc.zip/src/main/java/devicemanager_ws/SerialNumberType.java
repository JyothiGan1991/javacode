
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SerialNumberType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SerialNumberType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SerialNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DeviceSubtype" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}DeviceSubTypeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SerialNumberType", propOrder = {
    "serialNumber",
    "deviceSubtype"
})
public class SerialNumberType {

    @XmlElement(name = "SerialNumber", required = true)
    protected String serialNumber;
    @XmlElement(name = "DeviceSubtype")
    protected DeviceSubTypeType deviceSubtype;

    /**
     * Gets the value of the serialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Sets the value of the serialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

    /**
     * Gets the value of the deviceSubtype property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public DeviceSubTypeType getDeviceSubtype() {
        return deviceSubtype;
    }

    /**
     * Sets the value of the deviceSubtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceSubTypeType }
     *     
     */
    public void setDeviceSubtype(DeviceSubTypeType value) {
        this.deviceSubtype = value;
    }

}
