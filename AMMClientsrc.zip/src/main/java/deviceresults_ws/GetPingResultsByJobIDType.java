
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetPingResultsByJobIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetPingResultsByJobIDType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="SearchParameters" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}PingByJobSearchParametersType"/&gt;
 *           &lt;element name="CachedResults" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}StringKeyCachedResultsType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="NumberRows" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="SortMap" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}PingSortMapType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetPingResultsByJobIDType", propOrder = {
    "searchParameters",
    "cachedResults",
    "numberRows",
    "sortMap"
})
public class GetPingResultsByJobIDType {

    @XmlElement(name = "SearchParameters")
    protected PingByJobSearchParametersType searchParameters;
    @XmlElement(name = "CachedResults")
    protected StringKeyCachedResultsType cachedResults;
    @XmlElement(name = "NumberRows")
    protected int numberRows;
    @XmlElement(name = "SortMap")
    protected List<PingSortMapType> sortMap;

    /**
     * Gets the value of the searchParameters property.
     * 
     * @return
     *     possible object is
     *     {@link PingByJobSearchParametersType }
     *     
     */
    public PingByJobSearchParametersType getSearchParameters() {
        return searchParameters;
    }

    /**
     * Sets the value of the searchParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link PingByJobSearchParametersType }
     *     
     */
    public void setSearchParameters(PingByJobSearchParametersType value) {
        this.searchParameters = value;
    }

    /**
     * Gets the value of the cachedResults property.
     * 
     * @return
     *     possible object is
     *     {@link StringKeyCachedResultsType }
     *     
     */
    public StringKeyCachedResultsType getCachedResults() {
        return cachedResults;
    }

    /**
     * Sets the value of the cachedResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringKeyCachedResultsType }
     *     
     */
    public void setCachedResults(StringKeyCachedResultsType value) {
        this.cachedResults = value;
    }

    /**
     * Gets the value of the numberRows property.
     * 
     */
    public int getNumberRows() {
        return numberRows;
    }

    /**
     * Sets the value of the numberRows property.
     * 
     */
    public void setNumberRows(int value) {
        this.numberRows = value;
    }

    /**
     * Gets the value of the sortMap property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sortMap property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSortMap().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PingSortMapType }
     * 
     * 
     */
    public List<PingSortMapType> getSortMap() {
        if (sortMap == null) {
            sortMap = new ArrayList<PingSortMapType>();
        }
        return this.sortMap;
    }

}
