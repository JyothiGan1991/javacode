
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FindMeterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FindMeterType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Mode" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="ModeFunc" type="{urn:com:ssn:schema:service:v2.5:DeviceTypes.xsd}MeterModeType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FormType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VoltType" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ln_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_v_sqr_hr_ll_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_sqr_hr_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_i_n_sqr_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_va_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Scale_vah_sf" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LineFreq" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Timebase" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleScalar" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrSampleDivisor" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleDivisor" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltSampleScalar" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CurrTransRatio" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VoltTransRatio" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="UtilQyMeterRegRatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ChannelNum" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="UIQProgramID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TariffID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Class" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RolloverPoint" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="NetByteOrder" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="WakeupInterval" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="MeterKH" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterKT" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterCA" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="MeterTV" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="UnscheduledMeters" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}EmptyType" minOccurs="0"/&gt;
 *         &lt;element name="Uom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UomMultiplier" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="UomOffset" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="UomRatioF1" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="UomRatioP1" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="PrePayModeStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="DemandLimitModeStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="SwitchLockoutStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="ESCCActivationStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="ESCCEnableStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="LC1ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="LC2ConnectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="IgnoreTamperDetectionStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="DoorSensorStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="TamperStatus" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}RemoteProvisioningModeStatusType" minOccurs="0"/&gt;
 *         &lt;element name="MicroAP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="MicroAPAPMode" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FindMeterType", propOrder = {
    "mode",
    "modeFunc",
    "name",
    "description",
    "formType",
    "baseType",
    "voltType",
    "scaleVSqrHrLnSf",
    "scaleVSqrHrLlSf",
    "scaleISqrHrSf",
    "scaleINSqrSf",
    "scaleVaSf",
    "scaleVahSf",
    "lineFreq",
    "timebase",
    "currSampleScalar",
    "currSampleDivisor",
    "voltSampleDivisor",
    "voltSampleScalar",
    "currTransRatio",
    "voltTransRatio",
    "utilQyMeterRegRatio",
    "channelNum",
    "uiqProgramID",
    "tariffID",
    "clazz",
    "rolloverPoint",
    "netByteOrder",
    "wakeupInterval",
    "meterKH",
    "meterKT",
    "meterCA",
    "meterTV",
    "unscheduledMeters",
    "uom",
    "uomMultiplier",
    "uomOffset",
    "uomRatioF1",
    "uomRatioP1",
    "prePayModeStatus",
    "demandLimitModeStatus",
    "switchLockoutStatus",
    "esccActivationStatus",
    "esccEnableStatus",
    "lc1ConnectionStatus",
    "lc2ConnectionStatus",
    "ignoreTamperDetectionStatus",
    "doorSensorStatus",
    "tamperStatus",
    "microAP",
    "microAPAPMode"
})
public class FindMeterType {

    @XmlElement(name = "Mode")
    protected MeterModeType mode;
    @XmlElement(name = "ModeFunc")
    protected MeterModeType modeFunc;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Description")
    protected String description;
    @XmlElement(name = "FormType")
    protected String formType;
    @XmlElement(name = "BaseType")
    protected String baseType;
    @XmlElement(name = "VoltType")
    protected Long voltType;
    @XmlElement(name = "Scale_v_sqr_hr_ln_sf")
    protected Long scaleVSqrHrLnSf;
    @XmlElement(name = "Scale_v_sqr_hr_ll_sf")
    protected Long scaleVSqrHrLlSf;
    @XmlElement(name = "Scale_i_sqr_hr_sf")
    protected Long scaleISqrHrSf;
    @XmlElement(name = "Scale_i_n_sqr_sf")
    protected Long scaleINSqrSf;
    @XmlElement(name = "Scale_va_sf")
    protected Long scaleVaSf;
    @XmlElement(name = "Scale_vah_sf")
    protected Long scaleVahSf;
    @XmlElement(name = "LineFreq")
    protected Long lineFreq;
    @XmlElement(name = "Timebase")
    protected Long timebase;
    @XmlElement(name = "CurrSampleScalar")
    protected Long currSampleScalar;
    @XmlElement(name = "CurrSampleDivisor")
    protected Long currSampleDivisor;
    @XmlElement(name = "VoltSampleDivisor")
    protected Long voltSampleDivisor;
    @XmlElement(name = "VoltSampleScalar")
    protected Long voltSampleScalar;
    @XmlElement(name = "CurrTransRatio")
    protected Long currTransRatio;
    @XmlElement(name = "VoltTransRatio")
    protected Long voltTransRatio;
    @XmlElement(name = "UtilQyMeterRegRatio")
    protected String utilQyMeterRegRatio;
    @XmlElement(name = "ChannelNum")
    protected Integer channelNum;
    @XmlElement(name = "UIQProgramID")
    protected Integer uiqProgramID;
    @XmlElement(name = "TariffID")
    protected String tariffID;
    @XmlElement(name = "Class")
    protected Integer clazz;
    @XmlElement(name = "RolloverPoint")
    protected Integer rolloverPoint;
    @XmlElement(name = "NetByteOrder")
    protected Boolean netByteOrder;
    @XmlElement(name = "WakeupInterval")
    protected Integer wakeupInterval;
    @XmlElement(name = "MeterKH")
    protected Double meterKH;
    @XmlElement(name = "MeterKT")
    protected Double meterKT;
    @XmlElement(name = "MeterCA")
    protected Double meterCA;
    @XmlElement(name = "MeterTV")
    protected Double meterTV;
    @XmlElement(name = "UnscheduledMeters")
    protected EmptyType unscheduledMeters;
    @XmlElement(name = "Uom")
    protected String uom;
    @XmlElement(name = "UomMultiplier")
    protected Double uomMultiplier;
    @XmlElement(name = "UomOffset")
    protected Double uomOffset;
    @XmlElement(name = "UomRatioF1")
    protected Double uomRatioF1;
    @XmlElement(name = "UomRatioP1")
    protected Double uomRatioP1;
    @XmlElement(name = "PrePayModeStatus")
    protected RemoteProvisioningModeStatusType prePayModeStatus;
    @XmlElement(name = "DemandLimitModeStatus")
    protected RemoteProvisioningModeStatusType demandLimitModeStatus;
    @XmlElement(name = "SwitchLockoutStatus")
    protected RemoteProvisioningModeStatusType switchLockoutStatus;
    @XmlElement(name = "ESCCActivationStatus")
    protected RemoteProvisioningModeStatusType esccActivationStatus;
    @XmlElement(name = "ESCCEnableStatus")
    protected RemoteProvisioningModeStatusType esccEnableStatus;
    @XmlElement(name = "LC1ConnectionStatus")
    protected RemoteProvisioningModeStatusType lc1ConnectionStatus;
    @XmlElement(name = "LC2ConnectionStatus")
    protected RemoteProvisioningModeStatusType lc2ConnectionStatus;
    @XmlElement(name = "IgnoreTamperDetectionStatus")
    protected RemoteProvisioningModeStatusType ignoreTamperDetectionStatus;
    @XmlElement(name = "DoorSensorStatus")
    protected RemoteProvisioningModeStatusType doorSensorStatus;
    @XmlElement(name = "TamperStatus")
    protected RemoteProvisioningModeStatusType tamperStatus;
    @XmlElement(name = "MicroAP")
    protected Boolean microAP;
    @XmlElement(name = "MicroAPAPMode")
    protected Boolean microAPAPMode;

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setMode(MeterModeType value) {
        this.mode = value;
    }

    /**
     * Gets the value of the modeFunc property.
     * 
     * @return
     *     possible object is
     *     {@link MeterModeType }
     *     
     */
    public MeterModeType getModeFunc() {
        return modeFunc;
    }

    /**
     * Sets the value of the modeFunc property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeterModeType }
     *     
     */
    public void setModeFunc(MeterModeType value) {
        this.modeFunc = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the formType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormType() {
        return formType;
    }

    /**
     * Sets the value of the formType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormType(String value) {
        this.formType = value;
    }

    /**
     * Gets the value of the baseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseType() {
        return baseType;
    }

    /**
     * Sets the value of the baseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseType(String value) {
        this.baseType = value;
    }

    /**
     * Gets the value of the voltType property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltType() {
        return voltType;
    }

    /**
     * Sets the value of the voltType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltType(Long value) {
        this.voltType = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLnSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVSqrHrLnSf() {
        return scaleVSqrHrLnSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLnSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVSqrHrLnSf(Long value) {
        this.scaleVSqrHrLnSf = value;
    }

    /**
     * Gets the value of the scaleVSqrHrLlSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVSqrHrLlSf() {
        return scaleVSqrHrLlSf;
    }

    /**
     * Sets the value of the scaleVSqrHrLlSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVSqrHrLlSf(Long value) {
        this.scaleVSqrHrLlSf = value;
    }

    /**
     * Gets the value of the scaleISqrHrSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleISqrHrSf() {
        return scaleISqrHrSf;
    }

    /**
     * Sets the value of the scaleISqrHrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleISqrHrSf(Long value) {
        this.scaleISqrHrSf = value;
    }

    /**
     * Gets the value of the scaleINSqrSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleINSqrSf() {
        return scaleINSqrSf;
    }

    /**
     * Sets the value of the scaleINSqrSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleINSqrSf(Long value) {
        this.scaleINSqrSf = value;
    }

    /**
     * Gets the value of the scaleVaSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVaSf() {
        return scaleVaSf;
    }

    /**
     * Sets the value of the scaleVaSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVaSf(Long value) {
        this.scaleVaSf = value;
    }

    /**
     * Gets the value of the scaleVahSf property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getScaleVahSf() {
        return scaleVahSf;
    }

    /**
     * Sets the value of the scaleVahSf property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setScaleVahSf(Long value) {
        this.scaleVahSf = value;
    }

    /**
     * Gets the value of the lineFreq property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLineFreq() {
        return lineFreq;
    }

    /**
     * Sets the value of the lineFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLineFreq(Long value) {
        this.lineFreq = value;
    }

    /**
     * Gets the value of the timebase property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTimebase() {
        return timebase;
    }

    /**
     * Sets the value of the timebase property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTimebase(Long value) {
        this.timebase = value;
    }

    /**
     * Gets the value of the currSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrSampleScalar() {
        return currSampleScalar;
    }

    /**
     * Sets the value of the currSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrSampleScalar(Long value) {
        this.currSampleScalar = value;
    }

    /**
     * Gets the value of the currSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrSampleDivisor() {
        return currSampleDivisor;
    }

    /**
     * Sets the value of the currSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrSampleDivisor(Long value) {
        this.currSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleDivisor property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltSampleDivisor() {
        return voltSampleDivisor;
    }

    /**
     * Sets the value of the voltSampleDivisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltSampleDivisor(Long value) {
        this.voltSampleDivisor = value;
    }

    /**
     * Gets the value of the voltSampleScalar property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltSampleScalar() {
        return voltSampleScalar;
    }

    /**
     * Sets the value of the voltSampleScalar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltSampleScalar(Long value) {
        this.voltSampleScalar = value;
    }

    /**
     * Gets the value of the currTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCurrTransRatio() {
        return currTransRatio;
    }

    /**
     * Sets the value of the currTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCurrTransRatio(Long value) {
        this.currTransRatio = value;
    }

    /**
     * Gets the value of the voltTransRatio property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVoltTransRatio() {
        return voltTransRatio;
    }

    /**
     * Sets the value of the voltTransRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVoltTransRatio(Long value) {
        this.voltTransRatio = value;
    }

    /**
     * Gets the value of the utilQyMeterRegRatio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilQyMeterRegRatio() {
        return utilQyMeterRegRatio;
    }

    /**
     * Sets the value of the utilQyMeterRegRatio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilQyMeterRegRatio(String value) {
        this.utilQyMeterRegRatio = value;
    }

    /**
     * Gets the value of the channelNum property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getChannelNum() {
        return channelNum;
    }

    /**
     * Sets the value of the channelNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setChannelNum(Integer value) {
        this.channelNum = value;
    }

    /**
     * Gets the value of the uiqProgramID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getUIQProgramID() {
        return uiqProgramID;
    }

    /**
     * Sets the value of the uiqProgramID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUIQProgramID(Integer value) {
        this.uiqProgramID = value;
    }

    /**
     * Gets the value of the tariffID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTariffID() {
        return tariffID;
    }

    /**
     * Sets the value of the tariffID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTariffID(String value) {
        this.tariffID = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClazz(Integer value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the rolloverPoint property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRolloverPoint() {
        return rolloverPoint;
    }

    /**
     * Sets the value of the rolloverPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRolloverPoint(Integer value) {
        this.rolloverPoint = value;
    }

    /**
     * Gets the value of the netByteOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNetByteOrder() {
        return netByteOrder;
    }

    /**
     * Sets the value of the netByteOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNetByteOrder(Boolean value) {
        this.netByteOrder = value;
    }

    /**
     * Gets the value of the wakeupInterval property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWakeupInterval() {
        return wakeupInterval;
    }

    /**
     * Sets the value of the wakeupInterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWakeupInterval(Integer value) {
        this.wakeupInterval = value;
    }

    /**
     * Gets the value of the meterKH property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterKH() {
        return meterKH;
    }

    /**
     * Sets the value of the meterKH property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterKH(Double value) {
        this.meterKH = value;
    }

    /**
     * Gets the value of the meterKT property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterKT() {
        return meterKT;
    }

    /**
     * Sets the value of the meterKT property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterKT(Double value) {
        this.meterKT = value;
    }

    /**
     * Gets the value of the meterCA property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterCA() {
        return meterCA;
    }

    /**
     * Sets the value of the meterCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterCA(Double value) {
        this.meterCA = value;
    }

    /**
     * Gets the value of the meterTV property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMeterTV() {
        return meterTV;
    }

    /**
     * Sets the value of the meterTV property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMeterTV(Double value) {
        this.meterTV = value;
    }

    /**
     * Gets the value of the unscheduledMeters property.
     * 
     * @return
     *     possible object is
     *     {@link EmptyType }
     *     
     */
    public EmptyType getUnscheduledMeters() {
        return unscheduledMeters;
    }

    /**
     * Sets the value of the unscheduledMeters property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmptyType }
     *     
     */
    public void setUnscheduledMeters(EmptyType value) {
        this.unscheduledMeters = value;
    }

    /**
     * Gets the value of the uom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUom() {
        return uom;
    }

    /**
     * Sets the value of the uom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUom(String value) {
        this.uom = value;
    }

    /**
     * Gets the value of the uomMultiplier property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUomMultiplier() {
        return uomMultiplier;
    }

    /**
     * Sets the value of the uomMultiplier property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUomMultiplier(Double value) {
        this.uomMultiplier = value;
    }

    /**
     * Gets the value of the uomOffset property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUomOffset() {
        return uomOffset;
    }

    /**
     * Sets the value of the uomOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUomOffset(Double value) {
        this.uomOffset = value;
    }

    /**
     * Gets the value of the uomRatioF1 property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUomRatioF1() {
        return uomRatioF1;
    }

    /**
     * Sets the value of the uomRatioF1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUomRatioF1(Double value) {
        this.uomRatioF1 = value;
    }

    /**
     * Gets the value of the uomRatioP1 property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUomRatioP1() {
        return uomRatioP1;
    }

    /**
     * Sets the value of the uomRatioP1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUomRatioP1(Double value) {
        this.uomRatioP1 = value;
    }

    /**
     * Gets the value of the prePayModeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getPrePayModeStatus() {
        return prePayModeStatus;
    }

    /**
     * Sets the value of the prePayModeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setPrePayModeStatus(RemoteProvisioningModeStatusType value) {
        this.prePayModeStatus = value;
    }

    /**
     * Gets the value of the demandLimitModeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getDemandLimitModeStatus() {
        return demandLimitModeStatus;
    }

    /**
     * Sets the value of the demandLimitModeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setDemandLimitModeStatus(RemoteProvisioningModeStatusType value) {
        this.demandLimitModeStatus = value;
    }

    /**
     * Gets the value of the switchLockoutStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getSwitchLockoutStatus() {
        return switchLockoutStatus;
    }

    /**
     * Sets the value of the switchLockoutStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setSwitchLockoutStatus(RemoteProvisioningModeStatusType value) {
        this.switchLockoutStatus = value;
    }

    /**
     * Gets the value of the esccActivationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getESCCActivationStatus() {
        return esccActivationStatus;
    }

    /**
     * Sets the value of the esccActivationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setESCCActivationStatus(RemoteProvisioningModeStatusType value) {
        this.esccActivationStatus = value;
    }

    /**
     * Gets the value of the esccEnableStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getESCCEnableStatus() {
        return esccEnableStatus;
    }

    /**
     * Sets the value of the esccEnableStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setESCCEnableStatus(RemoteProvisioningModeStatusType value) {
        this.esccEnableStatus = value;
    }

    /**
     * Gets the value of the lc1ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getLC1ConnectionStatus() {
        return lc1ConnectionStatus;
    }

    /**
     * Sets the value of the lc1ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setLC1ConnectionStatus(RemoteProvisioningModeStatusType value) {
        this.lc1ConnectionStatus = value;
    }

    /**
     * Gets the value of the lc2ConnectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getLC2ConnectionStatus() {
        return lc2ConnectionStatus;
    }

    /**
     * Sets the value of the lc2ConnectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setLC2ConnectionStatus(RemoteProvisioningModeStatusType value) {
        this.lc2ConnectionStatus = value;
    }

    /**
     * Gets the value of the ignoreTamperDetectionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getIgnoreTamperDetectionStatus() {
        return ignoreTamperDetectionStatus;
    }

    /**
     * Sets the value of the ignoreTamperDetectionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setIgnoreTamperDetectionStatus(RemoteProvisioningModeStatusType value) {
        this.ignoreTamperDetectionStatus = value;
    }

    /**
     * Gets the value of the doorSensorStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getDoorSensorStatus() {
        return doorSensorStatus;
    }

    /**
     * Sets the value of the doorSensorStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setDoorSensorStatus(RemoteProvisioningModeStatusType value) {
        this.doorSensorStatus = value;
    }

    /**
     * Gets the value of the tamperStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public RemoteProvisioningModeStatusType getTamperStatus() {
        return tamperStatus;
    }

    /**
     * Sets the value of the tamperStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemoteProvisioningModeStatusType }
     *     
     */
    public void setTamperStatus(RemoteProvisioningModeStatusType value) {
        this.tamperStatus = value;
    }

    /**
     * Gets the value of the microAP property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMicroAP() {
        return microAP;
    }

    /**
     * Sets the value of the microAP property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMicroAP(Boolean value) {
        this.microAP = value;
    }

    /**
     * Gets the value of the microAPAPMode property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMicroAPAPMode() {
        return microAPAPMode;
    }

    /**
     * Sets the value of the microAPAPMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMicroAPAPMode(Boolean value) {
        this.microAPAPMode = value;
    }

}
