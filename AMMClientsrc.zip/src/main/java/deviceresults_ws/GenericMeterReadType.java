
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericMeterReadType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericMeterReadType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MeterReadRecord" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}GenericMeterReadRecordType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericMeterReadType", propOrder = {
    "meterReadRecord"
})
public class GenericMeterReadType {

    @XmlElement(name = "MeterReadRecord")
    protected List<GenericMeterReadRecordType> meterReadRecord;

    /**
     * Gets the value of the meterReadRecord property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the meterReadRecord property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMeterReadRecord().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GenericMeterReadRecordType }
     * 
     * 
     */
    public List<GenericMeterReadRecordType> getMeterReadRecord() {
        if (meterReadRecord == null) {
            meterReadRecord = new ArrayList<GenericMeterReadRecordType>();
        }
        return this.meterReadRecord;
    }

}
