package com.coned.ls.repository;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXPrincipal;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.security.auth.Subject;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.coned.ls.domain.MeterEventLoadIdAndDemand;
import com.coned.ls.exception.RecordNotFoundException;

import weblogic.jndi.Environment;
import weblogic.management.MBeanHome;
import weblogic.management.security.authentication.AuthenticationProviderMBean;
import weblogic.management.security.authentication.UserAttributeReaderMBean;
import weblogic.management.security.authentication.UserReaderMBean;
import weblogic.security.providers.authentication.DefaultAuthenticatorMBean;

@Repository
public class JdbcUserManagementRepository implements UserManagementRepository {
	private static String SUCCESS = "success";
	private static String FAILED = "failed";
	private static String OTHER = "other";
	private static int DIABLED_ROLE_ID = 0;
	private static int RCC_ROLE_ID = 1;
	private static int ADMIN_ROLE_ID = 3;
	private static int OPERATOR_ROLE_ID = 4;

	private static int API_KEY_EXPIRE = 12;
	private static int LOGOUT = 11;

	private String APP_NAME = "AOCCApp";
	private static final Logger logger = LoggerFactory.getLogger(JdbcUserManagementRepository.class);

	private String hostname = System.getProperty("aocc.server.hostname");
	private String portString = System.getProperty("aocc.server.portnumber");

	private String ldapUsername = System.getProperty("aocc.ldap.username");
	private String ldapPassword = System.getProperty("aocc.ldap.password");

	private static MBeanServerConnection connection;
	private static JMXConnector connector;
	private static final ObjectName service = null;
	ObjectName[] atnProviders = null;
	ObjectName mBeanTypeService = null;

	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;

	@Autowired
	private org.springframework.core.env.Environment env;

	public List<Map<String, Object>> getUsers() {
		logger.debug("---------------------- START - getUsers() ------------------------");
		List<Object> lsuser = null;
		try {
			String qstr = "SELECT u.id, u.user_ad_id as username, u.status, r.role, uc.user_ad_id AS createdBy, uu.user_ad_id as updatedBy, u.created_at, u.updated_at FROM ami_load_shedding.ls_user_role r INNER JOIN ami_load_shedding.ls_user u ON u.role_id = r.role_id LEFT JOIN ami_load_shedding.ls_user uc ON uc.id = u.createdBy LEFT JOIN ami_load_shedding.ls_user uu ON uu.id = u.updatedBy WHERE u.status=1 ORDER By u.created_at DESC";
			logger.debug("qstr? " + qstr);
			/*lsuser = oracleJdbcTemplate.query(qstr, new Object[] {}, new RowMapper<Object>() {
				@Override
				public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
					Map<String, Object> user = new HashMap<String, Object>();
					user.put("userId", rs.getInt("id"));
					user.put("userName", rs.getString("username"));
					user.put("roleName", rs.getString("role"));
					logger.info("uname? " + rs.getString("username")+" role? "+rs.getString("role"));
					return user;
				}
			});*/
			
			return oracleJdbcTemplate.query(qstr, new ResultSetExtractor<List<Map<String, Object>>>() {
		        public List<Map<String, Object>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		          List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		          while ( rs.next() ) {
		        	  Map<String, Object> user = new HashMap<String, Object>();
						user.put("userId", rs.getInt("id"));
						user.put("userName", rs.getString("username"));
						user.put("roleName", Arrays.asList(rs.getString("role")));
		            list.add( user );
		          }
		          return list;
		        }
			});  
			
			
//			return ResponseEntity.ok().body(lsuser);
		} catch (Exception e) {
			logger.debug("**Exception getUsers() - " + e);
		}
		return null;
	}

	@Override
	public ResponseEntity<Map<String, Object>> createUser(@RequestBody Map<String, Object> payload) {
		logger.debug("---------------------- START - createUser() ------------------------" + payload.get("adid"));
		Map<String, Object> response = new HashMap<>();
		try {
			response.put("result", FAILED);
			response.put("status", "other");
			String userName = (String) payload.get("userName");
			String qstr = (String) env.getProperty("aocc.user.getUserByName");
			qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
			Map<String, Object> umap = null;
			boolean userExist = true;
			boolean isActive = true;
			try {
				umap = oracleJdbcTemplate.queryForMap(qstr, userName);
				umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));

				int status = ((Number) umap.get("STATUS")).intValue();
				if (status != 1)
					isActive = false;
				response.put("result", FAILED);
				response.put("status", "user already exits");
			} catch (EmptyResultDataAccessException e) {
				logger.error("** EmptyResultDataAccessException: " + e);
				userExist = false;
			}
			if ((userExist && !isActive) || !userExist) {
				String createdBy = (String) payload.get("adid");

				qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
				logger.debug("qstr? " + qstr);
				umap = oracleJdbcTemplate.queryForMap(qstr, createdBy);
				umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));
				int createdById = ((Number) umap.get("ID")).intValue();

				logger.debug(" createdById: " + createdById);

				String roleName = (String) payload.get("roleName");
				int role_id = OPERATOR_ROLE_ID;
				if (roleName.equalsIgnoreCase("Admin"))
					role_id = ADMIN_ROLE_ID;
				else if (roleName.equalsIgnoreCase("Operator"))
					role_id = OPERATOR_ROLE_ID;
				final int roleid = role_id;
				logger.debug("userName? " + userName + " userExist? " + userExist + " isActive? " + isActive
						+ " role_id? " + role_id);
				if (userExist && !isActive) {
					qstr = "UPDATE ami_load_shedding.ls_user "
							+ "SET status=?, role_id=?, updatedBy=?, updated_at=to_date(?,'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(user_ad_id)=UPPER(?)";
					String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
					logger.debug("qstr? " + qstr);
					try {
						oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
							ps.setInt(1, 1);
							ps.setInt(2, roleid);
							ps.setInt(3, createdById);
							ps.setString(4, updateAtStr);
							ps.setString(5, userName);
							return ps.execute();
						});

						logger.debug("userName " + userName + " updateAt" + updateAtStr + " updatedBy? " + createdBy);
						qstr = "UPDATE ami_load_shedding.ls_user_role_mapping SET fk_role_id=:role_id WHERE UPPER(fk_user_ad_id)=UPPER(:userName)";

						oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
							ps.setInt(1, RCC_ROLE_ID);
							ps.setString(2, userName);
							return ps.execute();
						});

						response.put("result", SUCCESS);
						response.put("status", "");
					} catch (Exception e) {
						logger.error(e.getMessage(), e);
					}
				}
				if (!userExist) {
					logger.debug(" userName: " + userName + " roleName: " + roleName + " createdBy: " + createdBy);
					if (userName.isEmpty()) {
						response.put("result", FAILED);
						response.put("status", "other");
					} else {
						try {
							qstr = "Insert into ami_load_shedding.ls_user(user_ad_id, role_id, createdBy) VALUES (UPPER(:userName),:role_id,:createdBy)";
							oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
								ps.setString(1, userName.toUpperCase());
								ps.setInt(2, roleid);
								ps.setInt(3, createdById);
								return ps.execute();
							});

							qstr = "Insert into AMI_LOAD_SHEDDING.LS_USER_ROLE_MAPPING (FK_USER_AD_ID,FK_ROLE_ID) values (:userName,:role_id)";
							oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
								ps.setString(1, userName.toUpperCase());
								ps.setInt(2, RCC_ROLE_ID);
								return ps.execute();
							});

							response.put("result", SUCCESS);
							response.put("status", "");
						} catch (Exception e) {
							logger.error(e.getMessage(), e);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.debug("**Exception - createUser():  " + e);
		}
		logger.debug("---------------------- END - createUser() ------------------------");
		return ResponseEntity.ok().body(response);
	}

	@Override
	public ResponseEntity<Map<String, Object>> updateUser(String username, Map<String, Object> payload) {
		logger.debug("---------------------- START - updateUser() ------------------------");
		Map<String, Object> response = new HashMap<>();
		try {
			response.put("result", FAILED);
			response.put("status", "other");
			String qstr = (String) env.getProperty("aocc.user.getUserByName");
			qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
			Map<String, Object> umap = null;
			boolean userExist = true;

			try {
				umap = oracleJdbcTemplate.queryForMap(qstr, username);
				umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));
			} catch (EmptyResultDataAccessException e) {
				logger.error("** EmptyResultDataAccessException: " + e);
				userExist = false;
			}

			String updatedBy = (String) payload.get("adid");

			qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
			logger.debug("qstr? " + qstr);
			umap = oracleJdbcTemplate.queryForMap(qstr, updatedBy);
			umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));
			int updatedById = ((Number) umap.get("ID")).intValue();

			logger.debug(" updatedById: " + updatedById);

			String roleName = (String) payload.get("roleName");
			int role_id = OPERATOR_ROLE_ID;
			if (roleName.equalsIgnoreCase("Admin"))
				role_id = ADMIN_ROLE_ID;
			else if (roleName.equalsIgnoreCase("Operator"))
				role_id = OPERATOR_ROLE_ID;
			final int roleid = role_id;
			logger.debug("role_id? " + role_id);
			int status_id = 1;
			if (payload.get("isActive") != null) {
				boolean isActive = (boolean) payload.get("isActive");
				logger.debug("status? " + isActive);
				if (!isActive)
					status_id = 0;
			}

			logger.debug("userName? " + username + " userExist? " + userExist + " role_id? " + role_id);
			if (userExist) {
				qstr = (String) env.getProperty("aocc.user.updateUserByName");
				qstr = "UPDATE ami_load_shedding.ls_user SET role_id=:roleId, updatedBy=:updatedBy, updated_at=to_date(:updatedAt,'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(user_ad_id)=UPPER(:userName)";
				String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
				logger.debug("qstr? " + qstr);
				try {
					oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
						ps.setInt(1, roleid);
						ps.setInt(2, updatedById);
						ps.setString(3, updateAtStr);
						ps.setString(4, username);
						return ps.execute();
					});
					logger.debug("userName " + username + " updateAt" + updateAtStr + " updatedBy? " + updatedById);
					qstr = "UPDATE ami_load_shedding.ls_user_role_mapping SET fk_role_id=:role_id WHERE UPPER(fk_user_ad_id)=UPPER(:userName)";

					oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
						ps.setInt(1, RCC_ROLE_ID);
						ps.setString(2, username);
						return ps.execute();
					});

					response.put("result", SUCCESS);
					response.put("status", "");
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			} else {
				response.put("result", FAILED);
				response.put("status", "other");
			}
		} catch (Exception e) {
			logger.debug("**Exception - updateUser(): " + e);
		}
		logger.debug("---------------------- End - updateUser() ------------------------");
		return ResponseEntity.ok().body(response);
	}

	@Override
	public ResponseEntity<Map<String, Object>> deleteUser(String username, String updatedBy) {
		logger.debug("---------------------- START - deleteUser() ------------------------");
		Map<String, Object> response = new HashMap<>();
		try {
			response.put("result", FAILED);
			response.put("status", "other");

			String qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
			Map<String, Object> umap = null;
			boolean userExist = true;
			try {
				umap = oracleJdbcTemplate.queryForMap(qstr, username);
				umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));
			} catch (EmptyResultDataAccessException e) {
				logger.error("** EmptyResultDataAccessException: " + e);
				userExist = false;
			}
			qstr = "SELECT id, status FROM ami_load_shedding.ls_user WHERE UPPER(user_ad_id)=UPPER(?)";
			logger.debug("qstr? " + qstr);
			umap = oracleJdbcTemplate.queryForMap(qstr, updatedBy);
			umap.forEach((K, V) -> logger.debug(K + ", Value : " + V));
			int updatedById = ((Number) umap.get("ID")).intValue();

			logger.debug(" createdById: " + updatedById);

			logger.debug("userName? " + username + " userExist? " + userExist);
			if (userExist) {
				qstr = "UPDATE ami_load_shedding.ls_user SET status=:status, updatedBy=:updatedBy, updated_at=to_date(:updatedAt,'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(user_ad_id)=UPPER(:userName)";
				String updateAtStr = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format(new Date());
				logger.debug("qstr? " + qstr);

				try {
					oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
						ps.setInt(1, 0);
						ps.setInt(2, updatedById);
						ps.setString(3, updateAtStr);
						ps.setString(4, username);
						return ps.execute();
					});

					qstr = "UPDATE ami_load_shedding.ls_user_role_mapping SET fk_role_id=:role_id WHERE UPPER(fk_user_ad_id)=UPPER(:userName)";

					oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
						ps.setInt(1, DIABLED_ROLE_ID);
						ps.setString(2, username);
						return ps.execute();
					});

					final String SELECT_SQL_CLAIM = "SELECT u.user_role_id FROM ami_load_shedding.ls_user_role_mapping u WHERE  UPPER(u.fk_user_ad_id) = UPPER(:userName)";
					oracleJdbcTemplate.queryForObject(SELECT_SQL_CLAIM, new Object[] { username }, Integer.class);
					int user_role_id = ((Number) oracleJdbcTemplate.queryForObject(SELECT_SQL_CLAIM,
							new Object[] { username }, Integer.class)).intValue();
					logger.debug("user_role_id? " + user_role_id);
					qstr = "UPDATE ami_load_shedding.ls_user_login SET api_key_status=:api_key_status, user_login_status=:user_login_status WHERE fk_user_role_id=:fk_user_role_id";

					oracleJdbcTemplate.execute(qstr, (PreparedStatementCallback<Boolean>) ps -> {
						ps.setInt(1, API_KEY_EXPIRE);
						ps.setInt(2, LOGOUT);
						ps.setInt(3, user_role_id);
						return ps.execute();
					});

					response.put("result", SUCCESS);
					response.put("status", "");
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}

				logger.debug("userName " + username + " updateAt? " + updateAtStr + " updatedBy? " + updatedBy
						+ " updatedById? " + updatedById);
				response.put("result", SUCCESS);
				response.put("status", "");
			} else {
				response.put("result", FAILED);
				response.put("status", "other");
			}
		} catch (Exception e) {
			logger.debug("**Exception - deleteUser(): " + e);
		}
		logger.debug("---------------------- End - deleteUser() ------------------------");
		return ResponseEntity.ok().body(response);
	}

}