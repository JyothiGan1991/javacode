
package deviceresults_ws;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MeterReadResultsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeterReadResultsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="IntervalRead" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}IntervalReadType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="SecurityLog" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}SecurityLogType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="RegisterRead" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}RegisterReadType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="Season" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *           &lt;element name="GenericMeterRead" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}GenericMeterReadType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="PartialResultDeviceList" type="{urn:com:ssn:schema:service:v2.5:DeviceResults.xsd}DeviceListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SearchKey" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="RowCount" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="ExceededMaximumNumberOfRows" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" /&gt;
 *       &lt;attribute name="MaxNumberIntervalChannelsOnPage" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeterReadResultsType", propOrder = {
    "intervalRead",
    "securityLog",
    "registerRead",
    "season",
    "genericMeterRead",
    "partialResultDeviceList"
})
public class MeterReadResultsType {

    @XmlElement(name = "IntervalRead")
    protected List<IntervalReadType> intervalRead;
    @XmlElement(name = "SecurityLog")
    protected List<SecurityLogType> securityLog;
    @XmlElement(name = "RegisterRead")
    protected List<RegisterReadType> registerRead;
    @XmlElement(name = "Season")
    protected Integer season;
    @XmlElement(name = "GenericMeterRead")
    protected List<GenericMeterReadType> genericMeterRead;
    @XmlElement(name = "PartialResultDeviceList")
    protected DeviceListType partialResultDeviceList;
    @XmlAttribute(name = "SearchKey")
    protected String searchKey;
    @XmlAttribute(name = "RowCount")
    protected Long rowCount;
    @XmlAttribute(name = "ExceededMaximumNumberOfRows")
    protected Boolean exceededMaximumNumberOfRows;
    @XmlAttribute(name = "MaxNumberIntervalChannelsOnPage")
    protected Integer maxNumberIntervalChannelsOnPage;

    /**
     * Gets the value of the intervalRead property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the intervalRead property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIntervalRead().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IntervalReadType }
     * 
     * 
     */
    public List<IntervalReadType> getIntervalRead() {
        if (intervalRead == null) {
            intervalRead = new ArrayList<IntervalReadType>();
        }
        return this.intervalRead;
    }

    /**
     * Gets the value of the securityLog property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the securityLog property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecurityLog().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SecurityLogType }
     * 
     * 
     */
    public List<SecurityLogType> getSecurityLog() {
        if (securityLog == null) {
            securityLog = new ArrayList<SecurityLogType>();
        }
        return this.securityLog;
    }

    /**
     * Gets the value of the registerRead property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registerRead property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegisterRead().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegisterReadType }
     * 
     * 
     */
    public List<RegisterReadType> getRegisterRead() {
        if (registerRead == null) {
            registerRead = new ArrayList<RegisterReadType>();
        }
        return this.registerRead;
    }

    /**
     * Gets the value of the season property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSeason() {
        return season;
    }

    /**
     * Sets the value of the season property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSeason(Integer value) {
        this.season = value;
    }

    /**
     * Gets the value of the genericMeterRead property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the genericMeterRead property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGenericMeterRead().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GenericMeterReadType }
     * 
     * 
     */
    public List<GenericMeterReadType> getGenericMeterRead() {
        if (genericMeterRead == null) {
            genericMeterRead = new ArrayList<GenericMeterReadType>();
        }
        return this.genericMeterRead;
    }

    /**
     * Gets the value of the partialResultDeviceList property.
     * 
     * @return
     *     possible object is
     *     {@link DeviceListType }
     *     
     */
    public DeviceListType getPartialResultDeviceList() {
        return partialResultDeviceList;
    }

    /**
     * Sets the value of the partialResultDeviceList property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceListType }
     *     
     */
    public void setPartialResultDeviceList(DeviceListType value) {
        this.partialResultDeviceList = value;
    }

    /**
     * Gets the value of the searchKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchKey() {
        return searchKey;
    }

    /**
     * Sets the value of the searchKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchKey(String value) {
        this.searchKey = value;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRowCount(Long value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the exceededMaximumNumberOfRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isExceededMaximumNumberOfRows() {
        if (exceededMaximumNumberOfRows == null) {
            return false;
        } else {
            return exceededMaximumNumberOfRows;
        }
    }

    /**
     * Sets the value of the exceededMaximumNumberOfRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExceededMaximumNumberOfRows(Boolean value) {
        this.exceededMaximumNumberOfRows = value;
    }

    /**
     * Gets the value of the maxNumberIntervalChannelsOnPage property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxNumberIntervalChannelsOnPage() {
        return maxNumberIntervalChannelsOnPage;
    }

    /**
     * Sets the value of the maxNumberIntervalChannelsOnPage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxNumberIntervalChannelsOnPage(Integer value) {
        this.maxNumberIntervalChannelsOnPage = value;
    }

}
