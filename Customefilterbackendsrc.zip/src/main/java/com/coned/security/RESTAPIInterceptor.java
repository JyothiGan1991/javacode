package com.coned.security;

import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import com.coned.exception.UserAuthorizationException;
import com.coned.service.BaseService;
import com.coned.util.AOCCWebUtil;

@Aspect
@Component
public class RESTAPIInterceptor {
	@Autowired
	BaseService baseSrv;
	@Autowired
	AOCCWebUtil util;
	
	private static final Logger logger = LoggerFactory.getLogger(RESTAPIInterceptor.class);
	@Before(value = "execution(* com.coned.jpa.controller.FinalizeEventListDetailsController.*(..)) || "
			+ "execution(* com.coned.jpa.controller.FinalizeSubEventListDetailsController.*(..)) "
			+ "|| execution(* com.coned.jpa.controller.UserMgmtController.*(..))"
			)
	public boolean before(JoinPoint joinPoint) throws UserAuthorizationException {
		logger.debug(" -- Start RESTAPIInterceptor -- ");
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		String apiKey = "";
		String userName = "";
		Map<String, String> hmap = util.readAuthHeader();
		if(hmap != null) {
			if(hmap.containsKey("apiKey"))
				apiKey = util.readAuthHeader().get("apiKey");
			if(hmap.containsKey("userName"))
				userName = util.readAuthHeader().get("userName");
		}
		
		String ipaddress = "";
		if (request != null) {
			ipaddress = request.getHeader("X-FORWARDED-FOR");
			if (ipaddress == null || "".equals(ipaddress)) {
				ipaddress = request.getRemoteAddr();
			}
			logger.debug("clientIp: " + ipaddress);
		}
		logger.debug("apiKey: " + apiKey + " adid? " + userName + " clientIp: " + ipaddress);
		int loginStatus = 10;
		int apiStatus = 13;
		boolean isAuthorized = baseSrv.isUserAuthorized(userName, apiKey, ipaddress, loginStatus, apiStatus);// restActionExecutor.isAPIEndpointAuthorized(adid, apiKey, 13, 10);
		logger.debug("apiEndpointAuthorizeed : " + isAuthorized);
		if (!isAuthorized) {
			throw new UserAuthorizationException("unauthorized", HttpStatus.UNAUTHORIZED);// API_KEY_EXPIRE
		}
		logger.debug(" --  End RESTAPIInterceptor -- ");
		return isAuthorized;
	}
}
