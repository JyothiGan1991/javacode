/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class OHDAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(OHDAttributesThread.class);
    

    OHDAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;  
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
/*String newPointQuery = " select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,    \n" +
*"                         geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, ohd.circuit,ohd.seg,    \n" +
*"                         ohd.subseg,ohd.amp,ohd.div,ohd.custowned,ohd.specialcondition,ohd.lpgasarea,ohd.scada,ohd.groundtripblock,ohd.neutral,    \n" +
*"                         ohd.status,ohd.designdstat,ohd.reclosertype,ohd.headtype,ohd.controltype,ohd.dateinstalled,ohd.datecommissioned,ohd.wmsnumber_install,ohd.wmsnumber_commission,ohd.mainline , devAddress.town,devAddress.state,devAddress.street                        \n" +
*"                         from     \n" +
*"                         ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_ohd ohd, ed_assetlocation devAddress    \n" +
*"                         where geom.fid = ohd.fid     \n" +
*"                         and geom.featuretypeid = def.featuretypeid     \n" +
*"                         and geom.fid = devAddress.fid \n" +
*"                        and ohd.fid in (" + assetToQuery + ") ";*/

        	
//Gandhamj updated the query on 08/21/2023 but it is still in testing process
        	
String newPointQuery = " select geom.fid,geom.featuretypeid,def.featuretypename, \n" + 
        			   " CASE WHEN ohd.fid IN (6561082,4855401) THEN 'circuit:44-5-13'|| substr(geom.attributes,17,300)\n" + 
        			   " else geom.attributes\n" + 
        			   " END attributes,GeometryType(geom.geom) geomType,    \n" +
        			   " geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, ohd.circuit,ohd.seg,    \n" +
        			   " ohd.subseg,ohd.amp,ohd.div,ohd.custowned,ohd.specialcondition,ohd.lpgasarea,ohd.scada,ohd.groundtripblock,ohd.neutral,    \n" +
        			   " ohd.status,ohd.designdstat,ohd.reclosertype,ohd.headtype,ohd.controltype,ohd.dateinstalled,ohd.datecommissioned,ohd.wmsnumber_install,ohd.wmsnumber_commission,ohd.mainline , devAddress.town,devAddress.state,devAddress.street                        \n" +
        			   " from     \n" +
        			   " ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_ohd ohd, ed_assetlocation devAddress    \n" +
        			   " where geom.fid = ohd.fid     \n" +
        			   " and geom.featuretypeid = def.featuretypeid     \n" +
        			   " and geom.fid = devAddress.fid \n" +
        			   " and ohd.fid in (" + assetToQuery + ") ";

       	
        	
            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }
                    asset.setCircuit(circuit);
                    
                    String attributes = rs.getString("attributes");
                    if (attributes != null) {
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            asset.setNmsAttributes(val[0], val[1]);
                        }
                    }

                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);

                    String subSegment = rs.getString("subseg");
                    asset.setNmsAttributes("subSegment", subSegment);


                    String amp = rs.getString("amp");
                    asset.setNmsAttributes("amp", amp);
                    
                    int div = rs.getInt("div");
                    asset.setNmsAttributes("div", Integer.toString(div));
                    
                    boolean custowned = rs.getBoolean("custowned");
                    asset.setNmsAttributes("custowned", String.valueOf(custowned));

                    String specialcondition = rs.getString("specialcondition");
                    asset.setNmsAttributes("specialcondition", specialcondition);

                    String lpgasarea = rs.getString("lpgasarea");
                    asset.setNmsAttributes("lpgasarea", lpgasarea);

                    String scada = rs.getString("scada");
                    asset.setNmsAttributes("scada", scada);                    
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    int neutral = rs.getInt("neutral");
                    asset.setNmsAttributes("neutral", String.valueOf(neutral));

                    String groundtripblock = rs.getString("groundtripblock");
                    asset.setNmsAttributes("groundtripblock", groundtripblock);                    

                    String status = rs.getString("status");
                    asset.setNmsAttributes("status", status);
                    
                    String address = rs.getString("street");
                    asset.setNmsAttributes("location", address);                    
                   
                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);                    

                    String reclosertype = rs.getString("reclosertype");
                    asset.setNmsAttributes("reclosertype", reclosertype);                    
                    
                    String headtype = rs.getString("headtype");
                    asset.setNmsAttributes("headtype", headtype);                    

                    String controltype = rs.getString("controltype");
                    asset.setNmsAttributes("controltype", controltype);                    
                    
                    String town = rs.getString("town");
                    asset.setNmsAttributes("town", town);                    
                    
                    String state = rs.getString("state");
                    asset.setNmsAttributes("state", state);                                        
                    
                    Timestamp dateinstalled = rs.getTimestamp("dateinstalled");
                    if(dateinstalled != null)
                    {
                        String dateinstalledStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(dateinstalled);
                        asset.setNmsAttributes("dateinstalled", dateinstalledStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("dateinstalled", "");
                    }
                    
                    Timestamp datecommissioned = rs.getTimestamp("datecommissioned");
                    if(datecommissioned != null)
                    {
                        String datecommissionedStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(datecommissioned);
                        asset.setNmsAttributes("datecommissioned", datecommissionedStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("datecommissioned", "");
                    }
                    
                    String wmsnumber_install = rs.getString("wmsnumber_install");
                    asset.setNmsAttributes("wmsnumber_install", wmsnumber_install);

                    String wmsnumber_commission = rs.getString("wmsnumber_commission");
                    asset.setNmsAttributes("wmsnumber_commission", wmsnumber_commission);

                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);

                    
                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}

