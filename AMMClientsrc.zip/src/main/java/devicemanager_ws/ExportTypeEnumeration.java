
package devicemanager_ws;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ExportTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ExportTypeEnumeration"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Informational"/&gt;
 *     &lt;enumeration value="Authoritative"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ExportTypeEnumeration", namespace = "urn:com:ssn:schema:service:v2.5:BasicTypes.xsd")
@XmlEnum
public enum ExportTypeEnumeration {

    @XmlEnumValue("Informational")
    INFORMATIONAL("Informational"),
    @XmlEnumValue("Authoritative")
    AUTHORITATIVE("Authoritative");
    private final String value;

    ExportTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ExportTypeEnumeration fromValue(String v) {
        for (ExportTypeEnumeration c: ExportTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
