package com.coned.rsmd.repository;

import java.math.BigDecimal;
import java.util.List;

import com.coned.rsmd.domain.Meter;

public interface OutageRepository {
	List<Meter> getMetersWithNullMacAddr();

	void updateMeters(List<Meter> mList, List<BigDecimal> ids, String finalStatus) throws Exception;

	void saveJob(List<Meter> disconnectMetersList);

	List<Meter> getMeters();
}
