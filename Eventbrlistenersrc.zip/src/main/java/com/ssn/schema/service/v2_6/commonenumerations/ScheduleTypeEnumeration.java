
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ScheduleTypeEnumeration.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ScheduleTypeEnumeration">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SCHEDULE_TYPE_NONE"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_IMMEDIATE"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_FUTURE"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_INTERVAL"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_DAILY"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_WEEKLY"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_DAY_OF_MONTH"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_WEEKDAY_OF_MONTH"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_DAY_OF_WEEK"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_DAY_OF_YEAR"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_WEEKDAY_OF_YEAR"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_BILLING"/>
 *     &lt;enumeration value="SCHEDULE_TYPE_SPECIFIC_TIMES"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ScheduleTypeEnumeration")
@XmlEnum
public enum ScheduleTypeEnumeration {

    SCHEDULE_TYPE_NONE("SCHEDULE_TYPE_NONE"),
    SCHEDULE_TYPE_IMMEDIATE("SCHEDULE_TYPE_IMMEDIATE"),
    SCHEDULE_TYPE_FUTURE("SCHEDULE_TYPE_FUTURE"),
    SCHEDULE_TYPE_INTERVAL("SCHEDULE_TYPE_INTERVAL"),
    SCHEDULE_TYPE_DAILY("SCHEDULE_TYPE_DAILY"),
    SCHEDULE_TYPE_WEEKLY("SCHEDULE_TYPE_WEEKLY"),
    SCHEDULE_TYPE_DAY_OF_MONTH("SCHEDULE_TYPE_DAY_OF_MONTH"),
    SCHEDULE_TYPE_WEEKDAY_OF_MONTH("SCHEDULE_TYPE_WEEKDAY_OF_MONTH"),
    SCHEDULE_TYPE_DAY_OF_WEEK("SCHEDULE_TYPE_DAY_OF_WEEK"),
    SCHEDULE_TYPE_DAY_OF_YEAR("SCHEDULE_TYPE_DAY_OF_YEAR"),
    SCHEDULE_TYPE_WEEKDAY_OF_YEAR("SCHEDULE_TYPE_WEEKDAY_OF_YEAR"),
    SCHEDULE_TYPE_BILLING("SCHEDULE_TYPE_BILLING"),
    SCHEDULE_TYPE_SPECIFIC_TIMES("SCHEDULE_TYPE_SPECIFIC_TIMES"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ScheduleTypeEnumeration(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ScheduleTypeEnumeration fromValue(String v) {
        for (ScheduleTypeEnumeration c: ScheduleTypeEnumeration.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
