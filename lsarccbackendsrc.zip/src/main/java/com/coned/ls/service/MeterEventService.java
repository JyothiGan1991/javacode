package com.coned.ls.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.coned.ls.domain.MeterOpenEvent;
import com.coned.ls.domain.MeterSearch;
import com.coned.ls.domain.SubEvent;
import com.coned.ls.mapper.MeterEventResponseMapper;
import com.coned.ls.mapper.MeterFinalizeResponseMapper;
import com.coned.ls.mapper.MeterLockedStatusResponseMapper;
import com.coned.ls.rest.RESTActionExecutorConnect;

/**
 * 
 * Service class for RCC Connect.
 *
 */
@Component
public class MeterEventService {
	
	RESTActionExecutorConnect restActionExecutorConnect = new  RESTActionExecutorConnect();
	
	/*
	 * Method to read list of disconnected meters created for the event.
	 * 
	 * @param  meterOpenEvent MeterOpenEvent
     * @return 				  ResponseEntity<MeterEventResponseMapper>
	 */	
	public ResponseEntity<MeterEventResponseMapper> getValidMetersForConnect(final MeterOpenEvent meterOpenEvent) {
		return restActionExecutorConnect.getValidMetersForConnect(meterOpenEvent);
	}
	
	/*
	 * Method to read list of connected meters created for the event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 				 ResponseEntity<MeterEventResponseMapper>
	 */	
	public ResponseEntity<MeterEventResponseMapper> getConnectdMeters(final MeterOpenEvent meterOpenEvent) {
		return restActionExecutorConnect.getConnectdMeters(meterOpenEvent);
	}
	
	/*
	 * Method to finalize the meters in the sub event for connect.
	 * 
	 * @param  subEvent SubEvent
	 * @param  adid 	String
     * @return 			ResponseEntity<MeterFinalizeResponseMapper> 
	 */	
	public ResponseEntity<MeterFinalizeResponseMapper> finalizeSubEventMeter(final SubEvent subEvent, final String adid) throws Exception {
		return restActionExecutorConnect.finalizeSubEventMeter(subEvent, adid);
	}
	
	/*
	 * Method to read suffix for sub event.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  items 	 String
     * @return 			 ResponseEntity<Long>
	 */	
	public ResponseEntity<Long> getSubEventSuffix(final String borough,final String eventName, final String items){
		return restActionExecutorConnect.getSubEventSuffix(borough, eventName, items);
	}
	
	/*
	 * Method to read list of meters in the Sub Event.
	 * 
	 * @param  borough   	 String
	 * @param  eventName 	 String
	 * @param  subEventName  String
	 * @param  startRowIndex int
	 * @param  batchSize     int
     * @return 			     MeterEventResponseMapper 
	 */	
	public MeterEventResponseMapper getSubEventMeters(final String borough, final String eventName, final String subEventName, final int startRowIndex,final int batchSize){
		return restActionExecutorConnect.getSubEventMeters(borough, eventName, subEventName, startRowIndex, batchSize);
	}
	
	/*
	 * Method to search list of disconnected meters created for event.
	 * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterEventResponseMapper> 
	 */	
	public ResponseEntity<MeterEventResponseMapper> searchMeters(final MeterSearch meterSearch){
		return restActionExecutorConnect.searchMeter(meterSearch);
	}
	
	/*
	 * Method to search list of connected meters created for the event.
	 * 
     * @RequestBody meterSearch  MeterSearch 
     * @return 					 ResponseEntity<MeterEventResponseMapper> 
	 */	
	public ResponseEntity<MeterEventResponseMapper> searchMetersConnected(final MeterSearch meterSearch){
		return restActionExecutorConnect.searchMeterConnected(meterSearch);
	}
	
	/*
	 * Method to create Sub Event.
	 * 
	 * @param  subEvent   	 SubEvent
     * @return 			     ResponseEntity<MeterEventResponseMapper>
	 */	
	public ResponseEntity<MeterEventResponseMapper> getSubEventMeters(final SubEvent subEvent) throws Exception {
		return restActionExecutorConnect.getSubEventMeters(subEvent);
	}

	/*
	 * Method to read list of values for a given field.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  fieldName String
     * @return 			 ResponseEntity<List<String>>
	 */	
	public ResponseEntity<List<String>> getFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName){
		return restActionExecutorConnect.getFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
	}
	
    /*
     * Method to return list of values for a given field for Connected Meters.
     * 
     * @Parm borough  	String 
     * @Parm eventName  String
     * @Parm fieldName  String
     * 
     * @return 			ResponseEntity<List<String>>  
     *                         
     */
	public ResponseEntity<List<String>> getConnectedMetersFieldValuesByBoroughAndEventName(final String borough, final String eventName, final String fieldName) {
		return restActionExecutorConnect.getConnectedMetersFieldValuesByBoroughAndEventName(borough, eventName, fieldName);
	}
	
	/*
	 * Method to check event is locked.
	 * 
	 * @param  borough   String
	 * @param  eventName String
	 * @param  adid		 String
     * @return 			 MeterLockedStatusResponseMapper 
	 */	
	public MeterLockedStatusResponseMapper isEventLocked(final String borough, final String eventName, final String adid) {
		return restActionExecutorConnect.isEventLocked(borough, eventName, adid);
	}
	
	/*
	 * Method to unlocked the events.
	 * 
	 * @param  adid	String
     * @return 		void 
	 */	
	public void unlockEvents(final String adid) {
		restActionExecutorConnect.unlockEvents(adid);
	}
}

