
package jobmanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AckType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AckType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}AckTypeEnum"/&gt;
 *         &lt;element name="LocalizedValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Operator" type="{urn:com:ssn:schema:service:v2.5:CommonEnumerations.xsd}OperatorEnumeration" default="SQL_EQUAL_TO" /&gt;
 *       &lt;attribute name="OperatorLocalized" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AckType", propOrder = {
    "name",
    "localizedValue"
})
public class AckType {

    @XmlElement(name = "Name", required = true)
    @XmlSchemaType(name = "string")
    protected AckTypeEnum name;
    @XmlElement(name = "LocalizedValue")
    protected String localizedValue;
    @XmlAttribute(name = "Operator")
    protected OperatorEnumeration operator;
    @XmlAttribute(name = "OperatorLocalized")
    protected String operatorLocalized;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link AckTypeEnum }
     *     
     */
    public AckTypeEnum getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link AckTypeEnum }
     *     
     */
    public void setName(AckTypeEnum value) {
        this.name = value;
    }

    /**
     * Gets the value of the localizedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalizedValue() {
        return localizedValue;
    }

    /**
     * Sets the value of the localizedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalizedValue(String value) {
        this.localizedValue = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link OperatorEnumeration }
     *     
     */
    public OperatorEnumeration getOperator() {
        if (operator == null) {
            return OperatorEnumeration.SQL_EQUAL_TO;
        } else {
            return operator;
        }
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperatorEnumeration }
     *     
     */
    public void setOperator(OperatorEnumeration value) {
        this.operator = value;
    }

    /**
     * Gets the value of the operatorLocalized property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorLocalized() {
        return operatorLocalized;
    }

    /**
     * Sets the value of the operatorLocalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorLocalized(String value) {
        this.operatorLocalized = value;
    }

}
