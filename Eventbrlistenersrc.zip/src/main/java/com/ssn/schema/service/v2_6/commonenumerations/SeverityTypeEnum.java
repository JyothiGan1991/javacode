
package com.ssn.schema.service.v2_6.commonenumerations;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SeverityTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SeverityTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EVENT_SEVERITY_EMERGENCY"/>
 *     &lt;enumeration value="EVENT_SEVERITY_ALERT"/>
 *     &lt;enumeration value="EVENT_SEVERITY_CRITICAL"/>
 *     &lt;enumeration value="EVENT_SEVERITY_ERROR"/>
 *     &lt;enumeration value="EVENT_SEVERITY_WARNING"/>
 *     &lt;enumeration value="EVENT_SEVERITY_NOTICE"/>
 *     &lt;enumeration value="EVENT_SEVERITY_INFORMATION"/>
 *     &lt;enumeration value="EVENT_SEVERITY_DEBUG"/>
 *     &lt;enumeration value="EVENT_SEVERITY_CLEAR"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SeverityTypeEnum")
@XmlEnum
public enum SeverityTypeEnum {

    EVENT_SEVERITY_EMERGENCY("EVENT_SEVERITY_EMERGENCY"),
    EVENT_SEVERITY_ALERT("EVENT_SEVERITY_ALERT"),
    EVENT_SEVERITY_CRITICAL("EVENT_SEVERITY_CRITICAL"),
    EVENT_SEVERITY_ERROR("EVENT_SEVERITY_ERROR"),
    EVENT_SEVERITY_WARNING("EVENT_SEVERITY_WARNING"),
    EVENT_SEVERITY_NOTICE("EVENT_SEVERITY_NOTICE"),
    EVENT_SEVERITY_INFORMATION("EVENT_SEVERITY_INFORMATION"),
    EVENT_SEVERITY_DEBUG("EVENT_SEVERITY_DEBUG"),
    EVENT_SEVERITY_CLEAR("EVENT_SEVERITY_CLEAR"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    SeverityTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SeverityTypeEnum fromValue(String v) {
        for (SeverityTypeEnum c: SeverityTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
