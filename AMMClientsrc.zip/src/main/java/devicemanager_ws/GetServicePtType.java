
package devicemanager_ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetServicePtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetServicePtType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ServicePtType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LastBillDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NextBillDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Account" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}GetAccountType" minOccurs="0"/&gt;
 *         &lt;element name="ServicePointTransformer" type="{urn:com:ssn:schema:service:v2.5:DeviceManager.xsd}ServicePtTransformerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetServicePtType", propOrder = {
    "lastBillDate",
    "nextBillDate",
    "account",
    "servicePointTransformer"
})
public class GetServicePtType
    extends ServicePtType
{

    @XmlElement(name = "LastBillDate")
    protected String lastBillDate;
    @XmlElement(name = "NextBillDate")
    protected String nextBillDate;
    @XmlElement(name = "Account")
    protected GetAccountType account;
    @XmlElement(name = "ServicePointTransformer")
    protected ServicePtTransformerType servicePointTransformer;

    /**
     * Gets the value of the lastBillDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastBillDate() {
        return lastBillDate;
    }

    /**
     * Sets the value of the lastBillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastBillDate(String value) {
        this.lastBillDate = value;
    }

    /**
     * Gets the value of the nextBillDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextBillDate() {
        return nextBillDate;
    }

    /**
     * Sets the value of the nextBillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextBillDate(String value) {
        this.nextBillDate = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link GetAccountType }
     *     
     */
    public GetAccountType getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetAccountType }
     *     
     */
    public void setAccount(GetAccountType value) {
        this.account = value;
    }

    /**
     * Gets the value of the servicePointTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link ServicePtTransformerType }
     *     
     */
    public ServicePtTransformerType getServicePointTransformer() {
        return servicePointTransformer;
    }

    /**
     * Sets the value of the servicePointTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServicePtTransformerType }
     *     
     */
    public void setServicePointTransformer(ServicePtTransformerType value) {
        this.servicePointTransformer = value;
    }

}
