package com.coned.ls.repository;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.coned.ls.exception.MeterRejectException;
import com.coned.ls.mapper.MeterRejectResponseMapper;
import com.coned.ls.mapper.NewEventListRowMapper;
import com.coned.ls.utility.DateUtils;

/**
 * 
 * Repository class for rejecting the meters selected for disconnect.
 *
 */
@Repository
public class JdbcMetersEventRejectRepository implements MetersEventRejectRepository{

private static final Logger LOGGER = LogManager.getLogger(JdbcMetersEventRejectRepository.class);
	
	@Autowired
	@Qualifier("oracleJdbcTemplate")
	protected JdbcTemplate oracleJdbcTemplate;
	
	private SimpleJdbcCall simpleJdbcCall;
	
    /*
     * Method to save rejected meters details in the database.
     * 
     * @Param borough  	String
     * @Param eventName String
     * 
     * @return 			MeterRejectResponseMapper 
     *                         
     */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {MeterRejectException.class,Exception.class}, value="oracleTx")
	public MeterRejectResponseMapper rejectMeterEventList(final String borough,	final String eventName) throws MeterRejectException {
		MeterRejectResponseMapper meterRejectResponseMapper = new MeterRejectResponseMapper();
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_FIN_MET_DET_FOR_REJ").returningResultSet("SP_FIN_MET_DET_FOR_REJ",new NewEventListRowMapper());
		
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("Borough", borough);
		inParamMap.put("Event", eventName);	
		inParamMap.put("RejectTime", DateUtils.getDate());
		inParamMap.put("OpeartorADID", "AN20025372");		
		
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
		
		Object object = simpleJdbcCallResult.get("TOTALCOUNT");
		int result = Integer.parseInt(object.toString());
		try{
			if( result == 1 ){
				persistRejectedMeterList(borough, eventName);
				meterRejectResponseMapper.setSuccess(true);
				meterRejectResponseMapper.setMessage("Event has been rejected. Please notify Operator.");
				return meterRejectResponseMapper;
			}else if(result > 1){
				meterRejectResponseMapper.setSuccess(false);
				meterRejectResponseMapper.setMessage("DUPLICATE_RECORD_FOUND");
				throw new MeterRejectException("DUPLICATE_RECORD_FOUND");
			}else{
				meterRejectResponseMapper.setSuccess(false);
				meterRejectResponseMapper.setMessage("RECORD_NOT_FOUND");
				throw new MeterRejectException("RECORD_NOT_FOUND");
			}
		}catch(MeterRejectException ex){
			LOGGER.error(ex.getMessage(), ex);
			throw new MeterRejectException(ex.getMessage(),ex);
		}		
	}
	
    /*
     * Method to save list of rejected meters in the database.
     * 
     * @Param borough  	String
     * @Param eventName String
     * 
     * @return 			void 
     *                         
     */
	private void persistRejectedMeterList(final String borough,	final String eventName) throws MeterRejectException{
		simpleJdbcCall = new SimpleJdbcCall(oracleJdbcTemplate).withProcedureName("SP_REJ_FIN_MET").returningResultSet("SP_REJ_FIN_MET",new NewEventListRowMapper());
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("borough", borough);
		inParamMap.put("event", eventName);		
		
		SqlParameterSource inParamSql = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(inParamSql);
		
		int totalCountFinalize = Integer.parseInt(simpleJdbcCallResult.get("TOTALCOUNTFINALIZE").toString());
		int totalCountReject = Integer.parseInt(simpleJdbcCallResult.get("TOTALCOUNTREJECT").toString());
		try{
			if(! (totalCountFinalize == totalCountReject) ){
				throw new MeterRejectException("MISMATCH_RECORD_FOUND");
			}
		}catch(MeterRejectException ex){
			throw new MeterRejectException(ex.getMessage(),ex);
		}	
	}
}
